package sk.aetheriqa.noteiqa.util;

import androidx.annotation.Nullable;

import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import sk.aetheriqa.noteiqa.data.entity.Task;

/**
 * TaskBucketSorter v2 – rozradí úlohy do bucketov.
 *
 * Buckety v zobrazenom poradí:
 *  TODAY        – DNES (vrátane expirovaných úloh, tie sú TOP s isExpired=true)
 *  TOMORROW     – ZAJTRA
 *  THIS_WEEK    – TENTO TÝŽDEŇ
 *  THIS_MONTH   – TENTO MESIAC
 *  LATER        – NESKÔR (alebo bez termínu)
 *
 * Expirované úlohy: Marek si želá, aby ostali na vrchu DNES bucketu so
 * svetlo-šedou farbou textu, aby si ich nemohol prehliadnuť ale videl, že je
 * to po termíne. UI to detekuje cez `isExpired(t, today)`.
 */
public final class TaskBucketSorter {

    public enum Bucket {
        TODAY,
        TOMORROW,
        THIS_WEEK,
        THIS_MONTH,
        LATER
    }

    private static final ZoneId ZONE = ZoneId.systemDefault();

    private TaskBucketSorter() {}

    public static Map<Bucket, List<Task>> bucketize(List<Task> tasks) {
        Map<Bucket, List<Task>> out = new EnumMap<>(Bucket.class);
        for (Bucket b : Bucket.values()) out.put(b, new ArrayList<>());

        if (tasks == null) return out;

        LocalDate today = LocalDate.now(ZONE);
        LocalDate tomorrow = today.plusDays(1);

        LocalDate endOfWeek = endOfWeek(today);
        LocalDate endOfMonth = today.with(TemporalAdjusters.lastDayOfMonth());

        // Expirované zhromažďujeme zvlášť, aby sme ich hodili na vrch DNES
        List<Task> expired = new ArrayList<>();
        for (Task t : tasks) {
            if (isExpired(t, today)) {
                expired.add(t);
                continue;
            }
            Bucket b = classify(t, today, tomorrow, endOfWeek, endOfMonth);
            out.get(b).add(t);
        }

        // Expirované idú na vrch DNES bucketu (sú vizuálne odlíšené v UI)
        if (!expired.isEmpty()) {
            List<Task> todayList = out.get(Bucket.TODAY);
            // expirované na začiatok
            todayList.addAll(0, expired);
        }

        // v1.0.0 — Re-sort každého bucketu ak má aspoň jednu úlohu s manualSortOrder > 0.
        // Bez manualSort: zachová sa pôvodné time-based zoradenie z DB.
        // S manualSort: úlohy s order > 0 idú podľa neho ASC; s order = 0 idú za ne (preserve relative order).
        for (Bucket b : Bucket.values()) {
            applyManualSortIfAny(out.get(b));
        }

        return out;
    }

    /**
     * Stable sort: úlohy s manualSortOrder > 0 hore (ASC), s 0 dolu v pôvodnom poradí.
     * Ak nikto nemá > 0, robíme NIČ → zachová sa DB time-based sort.
     */
    private static void applyManualSortIfAny(List<Task> bucketList) {
        if (bucketList == null || bucketList.size() < 2) return;
        boolean hasManual = false;
        for (Task t : bucketList) {
            if (t.manualSortOrder > 0L) { hasManual = true; break; }
        }
        if (!hasManual) return;

        // Java sort je stable — pre rovnaké comparator výsledky zachová pôvodné poradie
        java.util.Collections.sort(bucketList, (a, b) -> {
            // Bez manuálu → idú dole. S manuálom → ASC.
            if (a.manualSortOrder == 0L && b.manualSortOrder == 0L) return 0;
            if (a.manualSortOrder == 0L) return 1;   // a ide nižšie
            if (b.manualSortOrder == 0L) return -1;  // b ide nižšie
            return Long.compare(a.manualSortOrder, b.manualSortOrder);
        });
    }

    /**
     * Posledný deň "tohto týždňa" — jediné miesto s touto hranicou (v1.3.3).
     *
     * "Tento týždeň" = od dnes po sobotu vrátane (Marekova konvencia nedeľa–sobota).
     * Ak dnes je sobota, "tento týždeň" je len dnes. Ak dnes je nedeľa, pokrýva
     * nasledujúce dni do najbližšej soboty (6 dní); nedeľa budúceho týždňa už nie.
     */
    public static LocalDate endOfWeek(LocalDate today) {
        if (today.getDayOfWeek() == DayOfWeek.SATURDAY) return today;
        return today.with(TemporalAdjusters.next(DayOfWeek.SATURDAY));
    }

    public static boolean isExpired(Task t, LocalDate today) {
        if (t.dueDate == null || t.dueDate == 0L) return false;
        LocalDate due = Instant.ofEpochMilli(t.dueDate).atZone(ZONE).toLocalDate();
        return due.isBefore(today);
    }

    public static boolean isExpired(Task t) {
        return isExpired(t, LocalDate.now(ZONE));
    }

    public static Bucket classify(Task t,
                                  LocalDate today,
                                  LocalDate tomorrow,
                                  LocalDate endOfWeek,
                                  LocalDate endOfMonth) {
        if (t.dueDate == null || t.dueDate == 0L) {
            return Bucket.LATER;
        }
        LocalDate due = Instant.ofEpochMilli(t.dueDate).atZone(ZONE).toLocalDate();

        if (due.isBefore(today) || due.equals(today)) return Bucket.TODAY;
        if (due.equals(tomorrow)) return Bucket.TOMORROW;
        if (!due.isAfter(endOfWeek)) return Bucket.THIS_WEEK;
        if (!due.isAfter(endOfMonth)) return Bucket.THIS_MONTH;
        return Bucket.LATER;
    }

    /**
     * v1.1.0 — Zaradí ľubovoľný timestamp do bucketu podľa aktuálneho dňa.
     * Používa TasksAdapter pri injekcii KidEvents.
     */
    /**
     * v1.3.3 — koniec týždňa ako epoch millis (začiatok nedele po {@link #endOfWeek}),
     * teda horná hranica [dnes, sobota vrátane] pre Domov „Uhradiť tento týždeň“.
     */
    public static long endOfWeekExclusiveMillis(long now) {
        LocalDate today = Instant.ofEpochMilli(now).atZone(ZONE).toLocalDate();
        return endOfWeek(today).plusDays(1).atStartOfDay(ZONE).toInstant().toEpochMilli();
    }

    public static Bucket classifyTimestamp(long ts) {
        return classifyTimestamp(ts, LocalDate.now(ZONE));
    }

    /**
     * v1.3.3 — rovnaká hranica týždňa ako {@link #classify} (predtým nextOrSame(SUNDAY):
     * v nedeľu bol koniec týždňa dnes a utorok/piatok padli do TENTO MESIAC).
     */
    public static Bucket classifyTimestamp(long ts, LocalDate today) {
        if (ts <= 0L) return Bucket.LATER;
        LocalDate tomorrow = today.plusDays(1);
        LocalDate endOfWeek = endOfWeek(today);
        LocalDate endOfMonth = today.with(TemporalAdjusters.lastDayOfMonth());
        LocalDate d = Instant.ofEpochMilli(ts).atZone(ZONE).toLocalDate();

        if (d.isBefore(today) || d.equals(today)) return Bucket.TODAY;
        if (d.equals(tomorrow)) return Bucket.TOMORROW;
        if (!d.isAfter(endOfWeek)) return Bucket.THIS_WEEK;
        if (!d.isAfter(endOfMonth)) return Bucket.THIS_MONTH;
        return Bucket.LATER;
    }

    public static LinkedHashMap<Bucket, List<Task>> nonEmpty(Map<Bucket, List<Task>> all) {
        LinkedHashMap<Bucket, List<Task>> out = new LinkedHashMap<>();
        for (Map.Entry<Bucket, List<Task>> e : all.entrySet()) {
            if (e.getValue() != null && !e.getValue().isEmpty()) {
                out.put(e.getKey(), e.getValue());
            }
        }
        return out;
    }
}
