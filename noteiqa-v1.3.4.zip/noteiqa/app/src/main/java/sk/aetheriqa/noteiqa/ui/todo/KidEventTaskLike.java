package sk.aetheriqa.noteiqa.ui.todo;

import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;

/**
 * KidEventTaskLike – nosič pre KidEvent injectnutý do TasksAdapter items listu.
 *
 * V UI sa vykresľuje ako task s odlišným štýlom:
 *  - Menší font (šedšia farba)
 *  - Malá ikona dieťaťa ic_kid_small vľavo
 *  - Text: "Alex: Výlet do Bratislavy" (kid name + event title)
 *  - Klik → otvorí KidEventEditorActivity
 *
 * NIE JE uložený v DB — vytvára sa v pamäti z aktuálnych KidEvents pri
 * každom refreshi TasksFragment.
 */
public class KidEventTaskLike {

    public final KidEvent event;
    public final Kid kid; // môže byť null (kidId = 0 → oboje)

    public KidEventTaskLike(KidEvent event, Kid kid) {
        this.event = event;
        this.kid = kid;
    }

    /** "Alex: Výlet do Bratislavy" alebo "Deti: Prázdniny" pri spoločnej udalosti. */
    public String displayTitle(android.content.Context ctx) {
        String prefix = kid != null ? kid.name : ctx.getString(sk.aetheriqa.noteiqa.R.string.kids_label_all);
        return ctx.getString(sk.aetheriqa.noteiqa.R.string.kid_event_todo_title, prefix, event.title);
    }

    /** Timestamp pre bucketovanie — používa startDate udalosti. */
    public long timestamp() {
        return event.startDate;
    }
}
