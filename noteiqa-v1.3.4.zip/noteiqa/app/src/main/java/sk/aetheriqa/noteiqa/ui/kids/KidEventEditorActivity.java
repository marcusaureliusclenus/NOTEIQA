package sk.aetheriqa.noteiqa.ui.kids;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.materialswitch.MaterialSwitch;

import java.util.Calendar;
import java.util.List;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.util.DateUtils;
import sk.aetheriqa.noteiqa.util.DialogThemes;
import sk.aetheriqa.noteiqa.util.ExactAlarmNotice;

/**
 * KidEventEditorActivity – vytvorenie / úprava udalosti.
 *
 * v1.3.3 — switch „Platba / poplatok“: odkryje blok platby v tom istom editore
 * (nič sa neotvára, rozpísaná udalosť sa nestratí). Jeden FAB uloží udalosť a potom
 * platbu s eventId = id udalosti (dieťa a názov z udalosti). Vypnutie switchu
 * existujúcu platbu nemaže, len ju ďalej neupravuje.
 */
public class KidEventEditorActivity extends AppCompatActivity {

    public static final String EXTRA_ID = "eventId";
    public static final String EXTRA_KID_ID = "kidId";

    private KidRepository repo;
    private KidEvent editing;

    private MaterialButtonToggleGroup kidGroup;
    private MaterialButton kidAbtn, kidBbtn, kidAllBtn;
    private Kid kidA, kidB;
    private long selectedKidId = KidRepository.KID_ID_ALL;

    private EditText title, location, note;
    private MaterialSwitch allDay;
    private MaterialButton typeBtn, startBtn, endBtn, notifyBtn;

    private long startDate = 0L;
    private long endDate = 0L;
    private long notifyAt = 0L;
    private int type = KidEvent.TYPE_OTHER;

    // v1.3.3 — platba k udalosti
    private MaterialSwitch paySwitch;
    private View payBlock, payTransferGroup;
    private EditText payAmount, payBeneficiary, payIban, payVs, paySs, payMsg;
    private RadioGroup payMethodGroup;
    private MaterialButton payDueBtn;
    /** 0 = podľa začiatku udalosti; inak ručne zvolená splatnosť. */
    private long payDueDate = 0L;
    /** Existujúca platba naviazaná na udalosť (pri úprave), inak null. */
    private KidPayment linkedPayment;

    /** v1.3.4 — Čo zobrať: 4 riadky. */
    private EditText[] packFields;

    public static Intent newIntent(Context ctx, long eventId, long kidId) {
        Intent i = new Intent(ctx, KidEventEditorActivity.class);
        i.putExtra(EXTRA_ID, eventId);
        i.putExtra(EXTRA_KID_ID, kidId);
        return i;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kid_event_editor);

        repo = KidRepository.getInstance(this);

        MaterialToolbar tb = findViewById(R.id.editor_toolbar);
        tb.setNavigationOnClickListener(v -> finish());
        tb.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();
            if (id == R.id.action_delete) { deleteConfirm(); return true; }
            return false;
        });

        FloatingActionButton fabSave = findViewById(R.id.fab_save);
        fabSave.setOnClickListener(v -> save());

        kidGroup = findViewById(R.id.ev_kid_group);
        kidAbtn = findViewById(R.id.ev_kid_a);
        kidBbtn = findViewById(R.id.ev_kid_b);
        kidAllBtn = findViewById(R.id.ev_kid_all);

        title = findViewById(R.id.ev_title);
        allDay = findViewById(R.id.ev_all_day);
        typeBtn = findViewById(R.id.ev_type_btn);
        startBtn = findViewById(R.id.ev_start_btn);
        endBtn = findViewById(R.id.ev_end_btn);
        notifyBtn = findViewById(R.id.ev_notify_btn);
        location = findViewById(R.id.ev_location);
        note = findViewById(R.id.ev_note);

        paySwitch = findViewById(R.id.ev_payment_switch);
        payBlock = findViewById(R.id.ev_pay_block);
        payTransferGroup = findViewById(R.id.ev_pay_transfer_group);
        payAmount = findViewById(R.id.ev_pay_amount);
        payBeneficiary = findViewById(R.id.ev_pay_beneficiary);
        payIban = findViewById(R.id.ev_pay_iban);
        payVs = findViewById(R.id.ev_pay_vs);
        paySs = findViewById(R.id.ev_pay_ss);
        payMsg = findViewById(R.id.ev_pay_msg);
        payMethodGroup = findViewById(R.id.ev_pay_method_group);
        payDueBtn = findViewById(R.id.ev_pay_due_btn);
        payMethodGroup.check(R.id.ev_pay_method_transfer);
        payMethodGroup.setOnCheckedChangeListener((g, id) -> payTransferGroup.setVisibility(
                id == R.id.ev_pay_method_transfer ? View.VISIBLE : View.GONE));
        paySwitch.setOnCheckedChangeListener((b, on) -> payBlock.setVisibility(on ? View.VISIBLE : View.GONE));
        payDueBtn.setOnClickListener(v -> pickPayDue());

        packFields = new EditText[]{
                findViewById(R.id.ev_pack_1), findViewById(R.id.ev_pack_2),
                findViewById(R.id.ev_pack_3), findViewById(R.id.ev_pack_4)};

        typeBtn.setOnClickListener(v -> pickType());
        startBtn.setOnClickListener(v -> pickStart());
        endBtn.setOnClickListener(v -> pickEnd());
        notifyBtn.setOnClickListener(v -> pickNotify());

        loadKids();

        long editId = getIntent().getLongExtra(EXTRA_ID, 0L);
        if (editId > 0L) {
            tb.setTitle(R.string.kid_event_edit_title);
            loadEvent(editId);
        } else {
            editing = new KidEvent();
            editing.assignKid(getIntent().getLongExtra(EXTRA_KID_ID, KidRepository.KID_ID_ALL));
            selectedKidId = editing.kidIdOrAll();
        }
    }

    private void loadKids() {
        new Thread(() -> {
            List<Kid> kids = repo.getKidsSync();
            runOnUiThread(() -> {
                if (kids == null || kids.size() < 2) return;
                kidA = kids.get(0);
                kidB = kids.get(1);
                kidAbtn.setText(kidA.name);
                kidBbtn.setText(kidB.name);

                kidGroup.addOnButtonCheckedListener((g, checkedId, isChecked) -> {
                    if (!isChecked) return;
                    if (checkedId == R.id.ev_kid_a) selectedKidId = kidA.id;
                    else if (checkedId == R.id.ev_kid_b) selectedKidId = kidB.id;
                    else selectedKidId = KidRepository.KID_ID_ALL;
                });

                if (selectedKidId == kidA.id) kidGroup.check(R.id.ev_kid_a);
                else if (selectedKidId == kidB.id) kidGroup.check(R.id.ev_kid_b);
                else kidGroup.check(R.id.ev_kid_all);
            });
        }, "load-kids").start();
    }

    private void loadEvent(long id) {
        new Thread(() -> {
            KidEvent e = repo.getEventSync(id);
            if (e == null) return;
            KidPayment linked = repo.getPaymentForEventSync(id);
            runOnUiThread(() -> {
                editing = e;
                if (linked != null) bindLinkedPayment(linked);
                selectedKidId = e.kidIdOrAll();
                title.setText(e.title);
                allDay.setChecked(e.allDay);
                type = e.type;
                startDate = e.startDate;
                endDate = e.endDate;
                notifyAt = e.notifyAt;
                location.setText(e.location);
                note.setText(e.note);
                bindPack(e.packList());
                refreshButtons();

                if (kidA != null && kidB != null) {
                    if (e.kidIdOrAll() == kidA.id) kidGroup.check(R.id.ev_kid_a);
                    else if (e.kidIdOrAll() == kidB.id) kidGroup.check(R.id.ev_kid_b);
                    else kidGroup.check(R.id.ev_kid_all);
                }
            });
        }, "load-event").start();
    }

    private void refreshButtons() {
        typeBtn.setText(KidEventsAdapter.typeLabel(this, type));
        startBtn.setText(startDate > 0L
                ? DateUtils.formatLongDate(startDate)
                    + (allDay.isChecked() ? "" : " " + timeOf(startDate))
                : getString(R.string.kid_pick_start));
        endBtn.setText(endDate > 0L
                ? DateUtils.formatLongDate(endDate)
                    + (allDay.isChecked() ? "" : " " + timeOf(endDate))
                : getString(R.string.kid_same_day));
        notifyBtn.setText(notifyAt > 0L
                ? DateUtils.formatLongDate(notifyAt) + " " + timeOf(notifyAt)
                : getString(R.string.kid_no_reminder));
        long due = effectivePayDue();
        payDueBtn.setText(due > 0L
                ? DateUtils.formatLongDate(due)
                : getString(R.string.kid_event_payment_due_same));
    }

    /** v1.3.3 — vyplní blok platby z existujúcej väzby a zapne switch. */
    private void bindLinkedPayment(KidPayment p) {
        linkedPayment = p;
        if (p.amountEur != null) {
            payAmount.setText(String.format(java.util.Locale.getDefault(),
                    "%.2f", p.amountEur).replace('.', ','));
        }
        payBeneficiary.setText(p.beneficiaryName);
        if (p.paymentMethod == KidPayment.METHOD_CASH) payMethodGroup.check(R.id.ev_pay_method_cash);
        else if (p.paymentMethod == KidPayment.METHOD_OTHER) payMethodGroup.check(R.id.ev_pay_method_other);
        else payMethodGroup.check(R.id.ev_pay_method_transfer);
        payIban.setText(p.iban);
        payVs.setText(p.variableSymbol);
        paySs.setText(p.specificSymbol);
        payMsg.setText(p.paymentNote);
        payDueDate = p.dueDate;
        paySwitch.setChecked(true);
    }

    /** v1.3.4 — predmety do 4 riadkov; ak by ich bolo viac (záloha), zvyšok ide do posledného. */
    private void bindPack(List<String> items) {
        for (int i = 0; i < packFields.length; i++) {
            if (i < packFields.length - 1 || items.size() <= packFields.length) {
                packFields[i].setText(i < items.size() ? items.get(i) : "");
            } else {
                packFields[i].setText(TextUtils.join(", ", items.subList(i, items.size())));
            }
        }
    }

    /** Splatnosť platby: ručne zvolená, inak deň začiatku udalosti (0:00). */
    private long effectivePayDue() {
        if (payDueDate > 0L) return payDueDate;
        if (startDate <= 0L) return 0L;
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(startDate);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private void pickPayDue() {
        long seed = effectivePayDue();
        pickDateTime(seed > 0L ? seed : System.currentTimeMillis(), true, picked -> {
            payDueDate = picked;
            refreshButtons();
        });
    }

    private String timeOf(long ts) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ts);
        return String.format(java.util.Locale.getDefault(), "%d:%02d",
                c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
    }

    private void pickType() {
        String[] items = new String[]{
                getString(R.string.kid_event_type_school),
                getString(R.string.kid_event_type_sport),
                getString(R.string.kid_event_type_health),
                getString(R.string.kid_event_type_culture),
                getString(R.string.kid_event_type_holiday),
                getString(R.string.kid_event_type_other)
        };
        int[] values = new int[]{
                KidEvent.TYPE_SCHOOL, KidEvent.TYPE_SPORT, KidEvent.TYPE_HEALTH,
                KidEvent.TYPE_CULTURE, KidEvent.TYPE_HOLIDAY, KidEvent.TYPE_OTHER
        };
        new AlertDialog.Builder(this, DialogThemes.LEA)
                .setTitle(R.string.kid_event_type_label)
                .setItems(items, (d, which) -> {
                    type = values[which];
                    refreshButtons();
                })
                .show();
    }

    private void pickStart() {
        pickDateTime(startDate, allDay.isChecked(), picked -> {
            startDate = picked;
            refreshButtons();
        });
    }

    private void pickEnd() {
        long seed = endDate > 0L ? endDate : (startDate > 0L ? startDate : System.currentTimeMillis());
        pickDateTime(seed, allDay.isChecked(), picked -> {
            endDate = picked;
            refreshButtons();
        });
    }

    private void pickNotify() {
        long seed = notifyAt > 0L
                ? notifyAt
                : (startDate > 0L ? startDate - 24L * 60 * 60 * 1000 : System.currentTimeMillis());
        pickDateTime(seed, false, picked -> {
            notifyAt = picked;
            refreshButtons();
        });
    }

    private interface DateTimeCallback { void onPicked(long ts); }

    // v1.1.1 — Picker bez theme overlay (rovnako ako TaskEditorActivity): dedí tmavú
    // Theme.Material3.Dark z aktivity. ThemeOverlay.Noteiqa.Dialog je overlay pre
    // MaterialAlertDialog, nie plná téma pre framework DatePicker → dával svetlý podklad.
    private void pickDateTime(long seed, boolean skipTime, DateTimeCallback cb) {
        Calendar c = Calendar.getInstance();
        if (seed > 0L) c.setTimeInMillis(seed);
        new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    Calendar picked = Calendar.getInstance();
                    picked.set(year, month, dayOfMonth,
                            skipTime ? 0 : 9, 0, 0);
                    picked.set(Calendar.MILLISECOND, 0);
                    if (skipTime) {
                        cb.onPicked(picked.getTimeInMillis());
                    } else {
                        new TimePickerDialog(this,
                                (v, h, m) -> {
                                    picked.set(Calendar.HOUR_OF_DAY, h);
                                    picked.set(Calendar.MINUTE, m);
                                    cb.onPicked(picked.getTimeInMillis());
                                }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show();
                    }
                },
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void save() {
        String t = title.getText() != null ? title.getText().toString().trim() : "";
        if (TextUtils.isEmpty(t)) {
            Toast.makeText(this, R.string.kid_event_error_title, Toast.LENGTH_SHORT).show();
            return;
        }
        if (startDate <= 0L) {
            Toast.makeText(this, R.string.kid_event_error_start, Toast.LENGTH_SHORT).show();
            return;
        }

        // v1.3.3 — platba k udalosti: všetko over pred zápisom, aby sa neuložila len polovica
        KidPayment payment = null;
        if (paySwitch.isChecked()) {
            Double am = parseAmount(payAmount);
            if (am == null) {
                Toast.makeText(this, R.string.kid_event_payment_error_amount, Toast.LENGTH_SHORT).show();
                return;
            }
            if (selectedKidId == KidRepository.KID_ID_ALL) {
                Toast.makeText(this, R.string.kid_event_payment_error_kid, Toast.LENGTH_SHORT).show();
                return;
            }
            int method = payMethodGroup.getCheckedRadioButtonId();
            String ben = strOrNull(payBeneficiary);
            if (method == R.id.ev_pay_method_transfer && ben == null) {
                Toast.makeText(this, R.string.kid_payment_error_beneficiary, Toast.LENGTH_SHORT).show();
                return;
            }
            payment = linkedPayment != null ? linkedPayment : new KidPayment();
            payment.amountEur = am;
            payment.beneficiaryName = ben;
            payment.paymentMethod = method == R.id.ev_pay_method_cash ? KidPayment.METHOD_CASH
                    : method == R.id.ev_pay_method_other ? KidPayment.METHOD_OTHER
                    : KidPayment.METHOD_TRANSFER;
            boolean transfer = payment.paymentMethod == KidPayment.METHOD_TRANSFER;
            payment.iban = transfer ? strOrNull(payIban) : null;
            payment.variableSymbol = transfer ? strOrNull(payVs) : null;
            payment.specificSymbol = transfer ? strOrNull(paySs) : null;
            payment.paymentNote = transfer ? strOrNull(payMsg) : null;
            payment.dueDate = effectivePayDue();
        }

        if (editing == null) editing = new KidEvent();
        editing.assignKid(selectedKidId);
        editing.title = t;
        editing.type = type;
        editing.startDate = startDate;
        editing.endDate = endDate;
        editing.allDay = allDay.isChecked();
        editing.location = strOrNull(location);
        editing.note = strOrNull(note);
        List<String> pack = new java.util.ArrayList<>();
        for (EditText f : packFields) pack.add(f.getText() != null ? f.getText().toString() : "");
        editing.packItems = KidEvent.joinPack(pack);
        editing.notifyAt = notifyAt;

        ExactAlarmNotice.maybeWarn(this, notifyAt);
        repo.saveEventWithPayment(editing, payment, id -> runOnUiThread(() -> {
            Toast.makeText(this, R.string.kid_event_saved, Toast.LENGTH_SHORT).show();
            finish();
        }));
    }

    /** "25,50" / "25.5" → 25.5; prázdne, nula alebo nečíslo → null. */
    private static Double parseAmount(EditText field) {
        if (field.getText() == null) return null;
        String s = field.getText().toString().trim().replace(',', '.');
        if (s.isEmpty()) return null;
        try {
            double v = Double.parseDouble(s);
            return v > 0d ? v : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private String strOrNull(EditText field) {
        if (field.getText() == null) return null;
        String s = field.getText().toString().trim();
        return s.isEmpty() ? null : s;
    }

    private void deleteConfirm() {
        if (editing == null || editing.id == 0L) { finish(); return; }
        new AlertDialog.Builder(this, DialogThemes.LEA)
                .setTitle(R.string.kid_delete_confirm_title)
                .setMessage(R.string.kid_delete_confirm_message)
                .setPositiveButton(R.string.action_yes, (d, w) -> {
                    repo.deleteEvent(editing.id);
                    Toast.makeText(this, R.string.kid_event_deleted, Toast.LENGTH_SHORT).show();
                    finish();
                })
                .setNegativeButton(R.string.action_no, null)
                .show();
    }
}
