package sk.aetheriqa.noteiqa.ui.home;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.MediatorLiveData;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.data.entity.TaskCategory;
import sk.aetheriqa.noteiqa.data.entity.WeightEntry;
import sk.aetheriqa.noteiqa.data.preferences.UserPreferences;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.data.repository.TaskRepository;
import sk.aetheriqa.noteiqa.data.repository.WeightRepository;
import sk.aetheriqa.noteiqa.ui.kids.KidEventEditorActivity;
import sk.aetheriqa.noteiqa.ui.kids.PaymentTicketActivity;
import sk.aetheriqa.noteiqa.ui.kids.PhotoDraftActivity;
import sk.aetheriqa.noteiqa.ui.kids.VoiceDraftLauncher;
import sk.aetheriqa.noteiqa.ui.todo.TaskDetailActivity;
import sk.aetheriqa.noteiqa.util.DateUtils;
import sk.aetheriqa.noteiqa.util.DiacriticsUtils;
import sk.aetheriqa.noteiqa.util.MotivationalQuotes;

/**
 * HomeFragment – dashboard.
 *
 *  - Avatar kruh (foto z UserPreferences alebo iniciálka mena)
 *  - "Ahoj {name}" v gold serif
 *  - Náhodná motivačná veta z MD súboru (rotácia bez opakovania 30 dní)
 *  - v1.3.2: pod citátom hneď niť dňa s nadpisom "DNES / Nedeľa, 04. októbra 2026"
 *    (pilulky, "A ako ti teda pomôžem?" a info karta sú preč — všetko je na niti)
 *
 * Pozn. motivačná veta sa volí pri každom onResume() (aj keď tab odsunieš a
 * vrátiš sa) — Marekova požiadavka "rotuje aj 5× za deň".
 *
 * Komunikácia s ostatnými tabmi: cez {@link OnQuickActionListener} na hostovi
 * (MainActivity), aby quick actions vedeli prepnúť tab alebo otvoriť activity.
 */
public class HomeFragment extends Fragment {

    public static final String QUICK_TODO = "todo";
    public static final String QUICK_SHOPPING = "shopping";
    public static final String QUICK_WEIGHT = "weight";
    public static final String QUICK_NOTES = "notes";
    public static final String QUICK_KIDS = "kids";

    /** v1.3.0 — max bodov na niti dňa, zvyšok ako "+N ďalších". */
    private static final int THREAD_MAX = 6;

    public interface OnQuickActionListener {
        void onQuickAction(String which);
    }

    private OnQuickActionListener listener;

    private FrameView views;

    /** Lightweight container pre child views – aby som nemal milión privátnych polí. */
    private static class FrameView {
        ImageView avatarPhoto;
        TextView avatarInitial;
        View avatarContainer;
        TextView greeting;
        TextView motivational;
        // v1.3.0 — Zlatá niť dňa (v1.3.2: nadpis s dátumom)
        TextView threadHeading;
        LinearLayout threadRows;
        // v1.0.0 — Streaks
        View streaksContainer;
        TextView streakWeight;
        TextView streakTasks;
        TextView streakApp;
        // v1.0.0 — Insight
        TextView insightSummary;
        TextView insightBestDay;
        TextView insightTrend;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnQuickActionListener) {
            listener = (OnQuickActionListener) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        views = new FrameView();
        views.avatarContainer = view.findViewById(R.id.home_avatar_container);
        views.avatarPhoto = view.findViewById(R.id.home_avatar_photo);
        views.avatarInitial = view.findViewById(R.id.home_avatar_initial);
        views.greeting = view.findViewById(R.id.home_greeting);
        views.motivational = view.findViewById(R.id.home_motivational);
        views.threadHeading = view.findViewById(R.id.home_thread_heading);
        views.threadRows = view.findViewById(R.id.home_thread_rows);
        // hlas je v prázdnom stave nite (odkaz "Hlas") a v Deti
        voice = new VoiceDraftLauncher(this);

        // v1.0.0 — Streaks
        views.streaksContainer = view.findViewById(R.id.home_streaks);
        views.streakWeight = view.findViewById(R.id.streak_weight);
        views.streakTasks = view.findViewById(R.id.streak_tasks);
        views.streakApp = view.findViewById(R.id.streak_app);

        // v1.0.0 — Insight
        views.insightSummary = view.findViewById(R.id.insight_summary);
        views.insightBestDay = view.findViewById(R.id.insight_best_day);
        views.insightTrend = view.findViewById(R.id.insight_trend);

        // Avatar — klik vedie do Nastavení
        views.avatarContainer.setOnClickListener(v -> {
            if (listener != null) listener.onQuickAction("settings");
        });

        // v1.3.0 — Zlatá niť dňa
        subscribeThread();
    }

    @Override
    public void onResume() {
        super.onResume();
        // Refresh personalizovaných údajov pri každom otvorení tabu
        renderProfile();
        renderMotivationalQuote();
        renderHeading();
        renderStreaks();
        renderInsight();

        // v1.3.0 — niť: ak medzičasom prešla polnoc, prihlás sa na nový deň
        if (threadDayStart != startOfDay(System.currentTimeMillis())) subscribeThread();
        scheduleMidnightRefresh();
    }

    @Override
    public void onPause() {
        super.onPause();
        midnightHandler.removeCallbacks(midnightRefresh);
    }

    private void fire(String which) {
        if (listener != null) listener.onQuickAction(which);
    }

    // ===== Renderery =====

    private void renderProfile() {
        UserPreferences prefs = UserPreferences.get(requireContext());
        String name = prefs.getDisplayName();

        views.greeting.setText(getString(R.string.home_greeting_format, name));

        // Avatar: ak existuje foto v internej zložke, zobraz; inak iniciálka
        String photoPath = prefs.getPhotoPath();
        boolean hasPhoto = !TextUtils.isEmpty(photoPath) && new File(photoPath).exists();

        if (hasPhoto) {
            // v1.0.1 — Java BitmapShader robí spoľahlivý circular crop;
            // nezávislé od ShapeableImageView clip ktorý môže na MIUI zlyhať.
            float density = getResources().getDisplayMetrics().density;
            int containerPx = sk.aetheriqa.noteiqa.util.BitmapUtils.dpToPx(120f, density);
            int ringMarginPx = sk.aetheriqa.noteiqa.util.BitmapUtils.dpToPx(3f, density);

            android.graphics.Bitmap circular = sk.aetheriqa.noteiqa.util.BitmapUtils
                    .loadCircular(photoPath, containerPx, ringMarginPx);

            if (circular != null) {
                views.avatarPhoto.setImageBitmap(circular);
                views.avatarPhoto.setVisibility(View.VISIBLE);
                views.avatarInitial.setVisibility(View.GONE);
            } else {
                showInitialFallback(prefs);
            }
        } else {
            showInitialFallback(prefs);
        }
    }

    private void showInitialFallback(UserPreferences prefs) {
        views.avatarPhoto.setVisibility(View.GONE);
        views.avatarPhoto.setImageDrawable(null);
        views.avatarInitial.setVisibility(View.VISIBLE);
        views.avatarInitial.setText(prefs.getInitial());
    }

    private void renderMotivationalQuote() {
        // Idempotentný retry pre prípad, že init z NoteiqaApplication.onCreate
        // ešte nedokončil (race condition pri rýchlom spustení appky)
        sk.aetheriqa.noteiqa.util.MotivationalQuotes.ensureDefaultImported(requireContext());

        String q = MotivationalQuotes.pickQuote(requireContext());
        if (TextUtils.isEmpty(q)) {
            views.motivational.setText(R.string.home_no_quote_placeholder);
            views.motivational.setAlpha(0.6f);
        } else {
            views.motivational.setText(q);
            views.motivational.setAlpha(1f);
        }
    }

    /**
     * v1.3.2 — nadpis nite: "DNES / Nedeľa, 04. októbra 2026".
     * DNES gold bold, lomka tlmená, dátum EEEE, dd. MMMM yyyy (sk-SK), deň na dve číslice.
     */
    private void renderHeading() {
        Context ctx = requireContext();
        String date = capitalizeFirst(new SimpleDateFormat("EEEE, dd. MMMM yyyy",
                new Locale("sk", "SK")).format(new Date()));
        String text = getString(R.string.thread_heading, date);
        SpannableString span = new SpannableString(text);
        int slash = text.indexOf('/');
        if (slash > 0) {
            span.setSpan(new ForegroundColorSpan(ContextCompat.getColor(ctx, R.color.lea_gold)),
                    0, slash, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            span.setSpan(new StyleSpan(Typeface.BOLD), 0, slash, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            span.setSpan(new ForegroundColorSpan(ContextCompat.getColor(ctx, R.color.text_disabled)),
                    slash, slash + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        views.threadHeading.setText(span);
    }

    private String capitalizeFirst(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    // ===== v1.3.0 — Zlatá niť dňa =====

    private VoiceDraftLauncher voice;
    private final Handler midnightHandler = new Handler(Looper.getMainLooper());
    private final Runnable midnightRefresh = () -> {
        if (!isAdded() || views == null) return;
        subscribeThread();
        scheduleMidnightRefresh();
    };
    private MediatorLiveData<Boolean> threadTrigger;
    private long threadDayStart = -1L;

    private List<Task> threadTasks = new ArrayList<>();
    private List<KidEvent> threadEvents = new ArrayList<>();
    private List<KidPayment> threadPayments = new ArrayList<>();
    private List<Kid> threadKids = new ArrayList<>();
    @Nullable private WeightEntry threadWeight;
    private long threadShoppingCategoryId = -1L;

    /** v1.3.2 — dve položky s časom bližšie ako toto = "naraz". */
    private static final long COLLISION_MS = 30L * 60_000L;

    /**
     * Prihlási sa na dáta dnešného dňa. Udalosti a platby idú cez úzke DAO dotazy
     * (observeDay / observeDueByDay), nie cez celý dataset. Volá sa pri vytvorení
     * view, po polnoci (Handler) a v onResume, ak sa zmenil deň.
     */
    private void subscribeThread() {
        if (threadTrigger != null) threadTrigger.removeObservers(getViewLifecycleOwner());

        long dayStart = startOfDay(System.currentTimeMillis());
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(dayStart);
        c.add(Calendar.DAY_OF_MONTH, 1);
        long dayEnd = c.getTimeInMillis();
        c.add(Calendar.DAY_OF_MONTH, 1);
        long tomorrowEnd = c.getTimeInMillis();   // v1.3.2 — riadok "Zajtra"
        threadDayStart = dayStart;

        Context appCtx = requireContext().getApplicationContext();
        KidRepository kidRepo = KidRepository.getInstance(appCtx);

        MediatorLiveData<Boolean> m = new MediatorLiveData<>();
        m.addSource(TaskRepository.getInstance(appCtx).observeActive(), t -> {
            threadTasks = t != null ? t : new ArrayList<>();
            m.setValue(Boolean.TRUE);
        });
        m.addSource(kidRepo.observeDayEvents(dayStart, tomorrowEnd), e -> {
            threadEvents = e != null ? e : new ArrayList<>();
            m.setValue(Boolean.TRUE);
        });
        m.addSource(kidRepo.observeDueByDay(tomorrowEnd), p -> {
            threadPayments = p != null ? p : new ArrayList<>();
            m.setValue(Boolean.TRUE);
        });
        m.addSource(TaskRepository.getInstance(appCtx).observeCategories(), cats -> {
            threadShoppingCategoryId = -1L;
            if (cats != null) {
                for (TaskCategory tc : cats) {
                    if (TaskRepository.SHOPPING_CATEGORY_NAME.equals(tc.name)) threadShoppingCategoryId = tc.id;
                }
            }
            m.setValue(Boolean.TRUE);
        });
        m.addSource(kidRepo.observeKids(), k -> {
            threadKids = k != null ? k : new ArrayList<>();
            m.setValue(Boolean.TRUE);
        });
        m.addSource(WeightRepository.getInstance(appCtx).observeLatest(), w -> {
            threadWeight = w;
            m.setValue(Boolean.TRUE);
        });
        threadTrigger = m;
        m.observe(getViewLifecycleOwner(), ignored -> renderThread(dayStart, dayEnd, tomorrowEnd));
    }

    private void scheduleMidnightRefresh() {
        midnightHandler.removeCallbacks(midnightRefresh);
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(startOfDay(System.currentTimeMillis()));
        c.add(Calendar.DAY_OF_MONTH, 1);
        long delay = c.getTimeInMillis() - System.currentTimeMillis() + 1000L;
        midnightHandler.postDelayed(midnightRefresh, Math.max(delay, 1000L));
    }

    private static long startOfDay(long ts) {
        // Calendar (nie java.time) — minSdk 24 bez desugaringu
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ts);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    /** Jeden bod na niti. tier: 0 po splatnosti, 1 celodenné/splatné dnes, 2 s časom, 3 úloha bez času. */
    private static final class ThreadItem {
        int tier;
        long time;
        String timeText;
        String title;
        String subtitle;
        int color;
        View.OnClickListener click;
        /** v1.3.2 — kolízia: "naraz" / "v deň výletu"; null = nič. */
        String tag;
        /** pre kolízie: id dieťaťa pri platbe po splatnosti. */
        long kidId;
        boolean timed;
        boolean overduePayment;
    }

    private void renderThread(long dayStart, long dayEnd, long tomorrowEnd) {
        if (!isAdded() || views == null) return;
        Context ctx = requireContext();
        List<ThreadItem> items = collectDay(ctx, dayStart, dayEnd, true);

        Collections.sort(items, (a, b) -> a.tier != b.tier
                ? Integer.compare(a.tier, b.tier) : Long.compare(a.time, b.time));
        markCollisions(items, dayStart, dayEnd);

        LinearLayout rows = views.threadRows;
        rows.removeAllViews();
        LayoutInflater inf = LayoutInflater.from(ctx);
        if (items.isEmpty()) {
            rows.addView(threadNote(ctx, getString(R.string.thread_empty)));
            rows.addView(emptyLinks(ctx));
        } else {
            int shown = Math.min(items.size(), THREAD_MAX);
            for (int i = 0; i < shown; i++) {
                ThreadItem it = items.get(i);
                View row = inf.inflate(R.layout.item_thread_row, rows, false);
                View dot = row.findViewById(R.id.thread_dot);
                Drawable bg = dot.getBackground().mutate();
                if (bg instanceof GradientDrawable) ((GradientDrawable) bg).setColor(it.color);
                dot.setBackground(bg);
                ((TextView) row.findViewById(R.id.thread_time)).setText(it.timeText);
                ((TextView) row.findViewById(R.id.thread_title)).setText(it.title);
                ((TextView) row.findViewById(R.id.thread_subtitle)).setText(it.subtitle);
                TextView tag = row.findViewById(R.id.thread_tag);
                if (it.tag != null) {
                    tag.setText(it.tag);
                    tag.setVisibility(View.VISIBLE);
                }
                row.setOnClickListener(it.click);
                rows.addView(row);
            }
            if (items.size() > shown) {
                rows.addView(threadNote(ctx, getString(R.string.thread_more, items.size() - shown)));
            }
        }

        // v1.3.2 — "Zajtra · {najbližšia vec}" na konci, len ak zajtra niečo je
        List<ThreadItem> tomorrow = collectDay(ctx, dayEnd, tomorrowEnd, false);
        if (!tomorrow.isEmpty()) {
            ThreadItem first = tomorrow.get(0);
            for (ThreadItem t : tomorrow) if (t.time < first.time) first = t;
            TextView line = threadNote(ctx, getString(R.string.thread_tomorrow, first.title));
            line.setAlpha(0.7f);
            line.setOnClickListener(first.click);
            rows.addView(line);
        }
    }

    /**
     * Body jedného dňa [from, to). today = true: platby aj po splatnosti a váženie;
     * false (zajtra): len platby so splatnosťou v ten deň, bez váhy. Pri zajtrajšku
     * má vec bez času "time" = začiatok dňa, takže pri výbere najbližšej vyhrá.
     */
    private List<ThreadItem> collectDay(Context ctx, long from, long to, boolean today) {
        int gold = ContextCompat.getColor(ctx, R.color.lea_gold);
        int overdue = ContextCompat.getColor(ctx, R.color.thread_overdue);
        List<ThreadItem> items = new ArrayList<>();

        // Úlohy s dueDate v daný deň (nezarchivované, nedokončené); Nákup má vlastný podtitul
        for (Task t : threadTasks) {
            if (t.completed || t.archivedAt != 0L || t.dueDate == null) continue;
            if (t.dueDate < from || t.dueDate >= to) continue;
            ThreadItem it = new ThreadItem();
            if (t.dueTimeMinutes != null) {
                it.tier = 2;
                it.timed = true;
                it.time = from + t.dueTimeMinutes * 60_000L;
                it.timeText = String.format(Locale.getDefault(), "%d:%02d",
                        t.dueTimeMinutes / 60, t.dueTimeMinutes % 60);
            } else {
                it.tier = 3;
                it.time = today ? Long.MAX_VALUE : from;
                it.timeText = "";
            }
            boolean shopping = t.categoryId != null && t.categoryId == threadShoppingCategoryId;
            String kind = getString(shopping ? R.string.thread_shopping : R.string.thread_task);
            it.title = TextUtils.isEmpty(t.title) ? kind : t.title;
            it.subtitle = kind;
            it.color = gold;
            final long taskId = t.id;
            it.click = v -> startActivity(TaskDetailActivity.newIntent(ctx, taskId));
            items.add(it);
        }

        // Udalosti detí, ktoré pokrývajú deň
        for (KidEvent e : threadEvents) {
            if (!e.coversDay(from, to)) continue;
            Kid kid = findKid(e.kidIdOrAll());
            ThreadItem it = new ThreadItem();
            boolean allDay = e.allDay || e.startDate < from;
            it.tier = allDay ? 1 : 2;
            it.timed = !allDay;
            it.time = allDay ? from : e.startDate;
            it.timeText = allDay ? getString(R.string.kid_all_day_lower) : DateUtils.formatTime(e.startDate);
            it.title = e.title;
            it.subtitle = kid != null ? kid.name : getString(R.string.kids_label_all);
            it.color = kidColor(kid, gold);
            final long eventId = e.id;
            final long eventKid = e.kidIdOrAll();
            it.click = v -> startActivity(KidEventEditorActivity.newIntent(ctx, eventId, eventKid));
            items.add(it);
        }

        // Nezaplatené platby: dnes (aj po splatnosti) / zajtra len so splatnosťou zajtra
        for (KidPayment p : threadPayments) {
            if (p.completed || p.dueDate <= 0L || p.dueDate >= to) continue;
            if (!today && p.dueDate < from) continue;
            Kid kid = findKid(p.kidId);
            boolean late = today && p.dueDate < from;
            ThreadItem it = new ThreadItem();
            it.tier = late ? 0 : 1;
            it.time = today ? p.dueDate : from;
            it.timeText = "";
            it.title = p.amountEur != null
                    ? getString(R.string.thread_payment_title, p.title,
                            String.format(Locale.getDefault(), "%.2f", p.amountEur).replace('.', ','))
                    : p.title;
            String who = kid != null ? kid.name : "";
            it.subtitle = getString(late ? R.string.thread_payment_overdue : R.string.thread_payment_due, who).trim();
            it.color = late ? overdue : kidColor(kid, gold);
            it.overduePayment = late;
            it.kidId = p.kidId;
            final long paymentId = p.id;
            it.click = v -> startActivity(PaymentTicketActivity.newIntent(ctx, paymentId));
            items.add(it);
        }

        // Posledné váženie — len ak je z dneška
        if (today && threadWeight != null && threadWeight.measuredAt >= from && threadWeight.measuredAt < to) {
            ThreadItem it = new ThreadItem();
            it.tier = 2;
            it.timed = true;
            it.time = threadWeight.measuredAt;
            it.timeText = DateUtils.formatTime(threadWeight.measuredAt);
            it.title = getString(R.string.thread_weight_title,
                    String.format(Locale.getDefault(), "%.1f", threadWeight.kg).replace('.', ','));
            it.subtitle = getString(R.string.thread_weight);
            it.color = gold;
            it.click = v -> fire(QUICK_WEIGHT);
            items.add(it);
        }
        return items;
    }

    /**
     * v1.3.2 — kolízie bez novej obrazovky:
     *  - dve položky s časom (udalosť / úloha / váha) do 30 min od seba → "naraz"
     *  - platba po splatnosti v deň, keď má to dieťa (alebo všetky deti) udalosť
     *    → "v deň výletu" / "v deň udalosti"
     */
    private void markCollisions(List<ThreadItem> items, long dayStart, long dayEnd) {
        for (int i = 0; i < items.size(); i++) {
            ThreadItem a = items.get(i);
            if (!a.timed) continue;
            for (int j = i + 1; j < items.size(); j++) {
                ThreadItem b = items.get(j);
                if (b.timed && Math.abs(a.time - b.time) <= COLLISION_MS) {
                    a.tag = getString(R.string.thread_tag_together);
                    b.tag = a.tag;
                }
            }
        }
        for (ThreadItem it : items) {
            if (!it.overduePayment) continue;
            KidEvent hit = null;
            for (KidEvent e : threadEvents) {
                if (!e.coversDay(dayStart, dayEnd)) continue;
                long k = e.kidIdOrAll();
                if (k == KidRepository.KID_ID_ALL || k == it.kidId) {
                    hit = e;
                    if (isTrip(e)) break;
                }
            }
            if (hit != null) {
                it.tag = getString(isTrip(hit) ? R.string.thread_tag_trip_day : R.string.thread_tag_event_day);
            }
        }
    }

    /** Výlet podľa názvu ("Výlet do Tatier"); typ ŠKOLA zahŕňa výlet aj školu, preto názov. */
    private static boolean isTrip(KidEvent e) {
        String n = DiacriticsUtils.stripDiacritics(e.title);
        return n != null && n.toLowerCase(Locale.ROOT).contains("vylet");
    }

    /** Prázdny deň: dva textové odkazy — Hlas a Z fotky. */
    private View emptyLinks(Context ctx) {
        LinearLayout box = new LinearLayout(ctx);
        box.setOrientation(LinearLayout.HORIZONTAL);
        float d = getResources().getDisplayMetrics().density;
        box.setPadding((int) (28 * d), 0, 0, (int) (4 * d));
        box.addView(link(ctx, R.string.thread_link_voice, v -> voice.start(KidRepository.KID_ID_ALL)));
        box.addView(link(ctx, R.string.photo_draft_entry, v -> startActivity(
                PhotoDraftActivity.newIntent(ctx, KidRepository.KID_ID_ALL))));
        return box;
    }

    private TextView link(Context ctx, int textRes, View.OnClickListener click) {
        TextView tv = new TextView(ctx);
        tv.setText(textRes);
        tv.setTextColor(ContextCompat.getColor(ctx, R.color.lea_gold));
        tv.setTextSize(14f);
        float d = getResources().getDisplayMetrics().density;
        tv.setPadding((int) (8 * d), (int) (10 * d), (int) (12 * d), (int) (10 * d));
        tv.setOnClickListener(click);
        return tv;
    }

    private TextView threadNote(Context ctx, String text) {
        TextView tv = new TextView(ctx);
        tv.setText(text);
        tv.setTextColor(ContextCompat.getColor(ctx, R.color.text_secondary));
        tv.setTextSize(13f);
        int pad = (int) (8 * getResources().getDisplayMetrics().density);
        tv.setPadding((int) (36 * getResources().getDisplayMetrics().density), pad, 0, pad);
        return tv;
    }

    @Nullable
    private Kid findKid(long kidId) {
        if (kidId == KidRepository.KID_ID_ALL) return null;
        for (Kid k : threadKids) if (k.id == kidId) return k;
        return null;
    }

    private static int kidColor(@Nullable Kid kid, int fallback) {
        if (kid == null) return fallback;
        try {
            return android.graphics.Color.parseColor(kid.colorHex);
        } catch (IllegalArgumentException e) {
            return fallback;
        }
    }

    // ===== v1.0.0 — Streaks =====

    private void renderStreaks() {
        // Compute na background, render na main
        Context appCtx = requireContext().getApplicationContext();
        new Thread(() -> {
            sk.aetheriqa.noteiqa.util.StreakCalculator.Streaks s =
                    sk.aetheriqa.noteiqa.util.StreakCalculator.compute(appCtx);
            new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                if (!isAdded() || views == null) return;
                applyStreaks(s);
            });
        }, "Streaks").start();
    }

    private void applyStreaks(sk.aetheriqa.noteiqa.util.StreakCalculator.Streaks s) {
        boolean any = false;

        if (s.hasWeightStreak()) {
            views.streakWeight.setText("🔥 " + getString(R.string.streak_weight_format, s.weightStreakDays));
            views.streakWeight.setVisibility(View.VISIBLE);
            any = true;
        } else {
            views.streakWeight.setVisibility(View.GONE);
        }

        if (s.hasTasksStreak()) {
            views.streakTasks.setText("✨ " + getString(R.string.streak_tasks_format, s.tasksDoneThisWeek));
            views.streakTasks.setVisibility(View.VISIBLE);
            any = true;
        } else {
            views.streakTasks.setVisibility(View.GONE);
        }

        if (s.hasAppAge()) {
            String text = sk.aetheriqa.noteiqa.util.StreakCalculator.formatAppAge(
                    requireContext(), s.appAgeDays);
            views.streakApp.setText("💪 " + text);
            views.streakApp.setVisibility(View.VISIBLE);
            any = true;
        } else {
            views.streakApp.setVisibility(View.GONE);
        }

        views.streaksContainer.setVisibility(any ? View.VISIBLE : View.GONE);
    }

    // ===== v1.0.0 — Weekly insight =====

    private void renderInsight() {
        sk.aetheriqa.noteiqa.util.WeeklyInsight.loadAsync(requireContext(), result -> {
            if (!isAdded() || views == null) return;
            applyInsight(result);
        });
    }

    private void applyInsight(sk.aetheriqa.noteiqa.util.WeeklyInsight.Result r) {
        // Summary line: "−0,8 kg · 12 hotových úloh · 3 vážené dni"
        String change = sk.aetheriqa.noteiqa.util.WeeklyInsight
                .formatWeightChange(requireContext(), r.weightChangeKg);
        views.insightSummary.setText(getString(R.string.insight_summary_format,
                change, r.tasksCompletedCount, r.weightDaysCount));

        // Najproduktívnejší deň
        if (r.mostProductiveDayOfWeek != null) {
            String day = sk.aetheriqa.noteiqa.util.WeeklyInsight
                    .slovakDayName(r.mostProductiveDayOfWeek);
            views.insightBestDay.setText(getString(R.string.insight_best_day_format, day));
        } else {
            views.insightBestDay.setText(R.string.insight_best_day_none);
        }

        // Trend
        switch (r.trend) {
            case FALLING:
                views.insightTrend.setText(R.string.insight_trend_falling); break;
            case STABLE:
                views.insightTrend.setText(R.string.insight_trend_stable); break;
            case RISING:
                views.insightTrend.setText(R.string.insight_trend_rising); break;
            case NO_DATA:
            default:
                views.insightTrend.setText(R.string.insight_trend_no_data); break;
        }
    }
}
