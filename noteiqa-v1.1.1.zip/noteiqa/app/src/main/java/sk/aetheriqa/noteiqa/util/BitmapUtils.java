package sk.aetheriqa.noteiqa.util;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Shader;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;

/**
 * BitmapUtils — robí veci s bitmapami čo Android štandardné View triedy
 * niekedy nezvládajú spoľahlivo.
 *
 * v1.0.1: {@link #loadCircular(String, int, int)} — načíta foto zo súboru
 * a vráti circular bitmap pre profilovú fotku v Domov tabe. Prečo cez
 * BitmapShader a nie cez ShapeableImageView clip? Lebo MIUI / starší Android
 * niekedy clip cez `cornerSize="50%"` ignoruje a zobrazí štvorcovú fotku.
 * BitmapShader je 100% spoľahlivý na všetkých zariadeniach.
 */
public final class BitmapUtils {

    private BitmapUtils() {}

    /**
     * Načíta foto zo súboru, vycentruje a oreže do štvorca, potom aplikuje
     * kruhovú masku. Volajúci dostane bitmap pripravený na ImageView.setImageBitmap().
     *
     * @param filePath        absolútna cesta k súboru
     * @param containerPx     veľkosť výsledného bitmapu (zvyčajne == ImageView size)
     * @param ringMarginPx    okraj okolo fotky (transparent rim, kde vidieť background)
     * @return circular bitmap s transparent okrajom okolo, alebo null pri chybe
     */
    @Nullable
    public static Bitmap loadCircular(@NonNull String filePath,
                                      int containerPx,
                                      int ringMarginPx) {
        if (containerPx <= 0) return null;

        // 1) Decode pre kontrolu rozmerov
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(filePath, bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

        // 2) Vyber inSampleSize aby sme nečítali zbytočne veľkú bitmapu do RAM
        int srcMin = Math.min(bounds.outWidth, bounds.outHeight);
        int sample = 1;
        while (srcMin / (sample * 2) > containerPx * 2) sample *= 2;

        BitmapFactory.Options decode = new BitmapFactory.Options();
        decode.inSampleSize = sample;
        decode.inPreferredConfig = Bitmap.Config.ARGB_8888;

        Bitmap source;
        try {
            source = BitmapFactory.decodeFile(filePath, decode);
        } catch (OutOfMemoryError oom) {
            return null;
        }
        if (source == null) return null;

        try {
            return makeCircular(source, containerPx, ringMarginPx);
        } finally {
            // makeCircular sa interne na source neopiera po returne; safe recycle
            if (!source.isRecycled()) source.recycle();
        }
    }

    /**
     * Z ľubovoľne rozmerného source bitmapu vyrobí circular bitmap
     * o veľkosti containerPx, s vnútorným kruhom radius = (containerPx - ringMarginPx*2) / 2.
     */
    @NonNull
    private static Bitmap makeCircular(@NonNull Bitmap source,
                                       int containerPx,
                                       int ringMarginPx) {
        int circleSize = Math.max(1, containerPx - ringMarginPx * 2);

        // Center-crop source na štvorec
        int srcMin = Math.min(source.getWidth(), source.getHeight());
        int cropX = (source.getWidth() - srcMin) / 2;
        int cropY = (source.getHeight() - srcMin) / 2;
        Bitmap cropped = Bitmap.createBitmap(source, cropX, cropY, srcMin, srcMin);

        // Scale na circle size
        Bitmap scaled = (cropped.getWidth() == circleSize)
                ? cropped
                : Bitmap.createScaledBitmap(cropped, circleSize, circleSize, true);

        if (scaled != cropped && !cropped.isRecycled()) cropped.recycle();

        // Output: container size, transparent okrem circle v centre
        Bitmap output = Bitmap.createBitmap(containerPx, containerPx, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

        BitmapShader shader = new BitmapShader(scaled,
                Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        Matrix matrix = new Matrix();
        matrix.postTranslate(ringMarginPx, ringMarginPx);
        shader.setLocalMatrix(matrix);
        paint.setShader(shader);

        float center = containerPx / 2f;
        float radius = circleSize / 2f;
        canvas.drawCircle(center, center, radius, paint);

        if (scaled != cropped && !scaled.isRecycled()) scaled.recycle();

        return output;
    }

    /** Convenience: keď chceš zistiť pixel veľkosť z dp pri konkrétnom DisplayMetrics. */
    public static int dpToPx(float dp, float density) {
        return Math.round(dp * density);
    }

    /** Volajúci by mal po nasvedení bitmapu z `loadCircular` nazvať bitmap.recycle()
     * keď ho nahradí novým — defenzívne pre OOM pri častom obnovení.
     * Toto je informačný komentár, žiaden tu kód nepotrebuje. */
    @SuppressWarnings("unused")
    private static void recycleHint() {}
}
