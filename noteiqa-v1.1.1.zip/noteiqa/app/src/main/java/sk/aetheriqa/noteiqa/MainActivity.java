package sk.aetheriqa.noteiqa;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import sk.aetheriqa.noteiqa.data.repository.TaskRepository;
import sk.aetheriqa.noteiqa.ui.chudnutie.ChudnutieFragment;
import sk.aetheriqa.noteiqa.ui.home.HomeFragment;
import sk.aetheriqa.noteiqa.ui.kids.KidsFragment;
import sk.aetheriqa.noteiqa.ui.notes.NotesFragment;
import sk.aetheriqa.noteiqa.ui.settings.SettingsActivity;
import sk.aetheriqa.noteiqa.ui.todo.TaskEditorActivity;
import sk.aetheriqa.noteiqa.ui.todo.TasksFragment;

/**
 * MainActivity – host pre 5 hlavných kariet:
 *   Domov · Môj to do list · Poznámky · Váženie · Deti
 *
 * Nastavenia sú v gear ikone v pravom hornom rohu (top overlay).
 *
 * v1.1.0 zmeny:
 *  - Deti tab pridaný ako 5. položka
 *  - Nastavenia presunuté z bottom nav do gear ikony (SettingsActivity)
 *  - Deep-linking pre notifikácie: ACTION_OPEN_KIDS + EXTRA_OPEN_PAYMENT_ID / EXTRA_OPEN_EVENT_ID
 */
public class MainActivity extends AppCompatActivity
        implements HomeFragment.OnQuickActionListener {

    /** Deep-link akcia z KidPayment / KidEvent notifikácie. */
    public static final String ACTION_OPEN_KIDS = "sk.aetheriqa.noteiqa.OPEN_KIDS";
    public static final String EXTRA_OPEN_PAYMENT_ID = "openPaymentId";
    public static final String EXTRA_OPEN_EVENT_ID = "openEventId";

    private static final String TAG_HOME = "frag_home";
    private static final String TAG_TODO = "frag_todo";
    private static final String TAG_NOTES = "frag_notes";
    private static final String TAG_CHUDNUTIE = "frag_chudnutie";
    private static final String TAG_KIDS = "frag_kids";

    private BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNav = findViewById(R.id.bottom_nav);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) { showFragment(TAG_HOME); return true; }
            if (id == R.id.nav_todo) { showFragment(TAG_TODO); return true; }
            if (id == R.id.nav_notes) { showFragment(TAG_NOTES); return true; }
            if (id == R.id.nav_chudnutie) { showFragment(TAG_CHUDNUTIE); return true; }
            if (id == R.id.nav_kids) { showFragment(TAG_KIDS); return true; }
            return false;
        });

        // Gear ikona vpravo hore → SettingsActivity
        ImageView gear = findViewById(R.id.top_settings_gear);
        gear.setOnClickListener(v -> startActivity(SettingsActivity.newIntent(this)));

        if (savedInstanceState == null) {
            // Ak nás sem hodila notifikácia z KidReminder, otvor Deti tab
            if (handleDeepLink(getIntent())) {
                bottomNav.setSelectedItemId(R.id.nav_kids);
            } else {
                showFragment(TAG_HOME);
                bottomNav.setSelectedItemId(R.id.nav_home);
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (handleDeepLink(intent)) {
            bottomNav.setSelectedItemId(R.id.nav_kids);
        }
    }

    /**
     * @return true ak intent je Kid deep-link a máme otvoriť Deti tab.
     * Konkrétny payment/event ID sa uloží do intent extras a KidsFragment
     * si ich vyzdvihne pri onResume.
     */
    private boolean handleDeepLink(Intent intent) {
        if (intent == null) return false;
        return ACTION_OPEN_KIDS.equals(intent.getAction());
    }

    private void showFragment(String tag) {
        FragmentTransaction tx = getSupportFragmentManager().beginTransaction();
        for (String t : new String[]{TAG_HOME, TAG_TODO, TAG_NOTES, TAG_CHUDNUTIE, TAG_KIDS}) {
            Fragment f = getSupportFragmentManager().findFragmentByTag(t);
            if (f != null && !f.isHidden()) tx.hide(f);
        }
        Fragment target = getSupportFragmentManager().findFragmentByTag(tag);
        if (target == null) {
            target = createFragment(tag);
            tx.add(R.id.fragment_container, target, tag);
        } else {
            tx.show(target);
        }
        tx.commit();
    }

    private Fragment createFragment(String tag) {
        switch (tag) {
            case TAG_TODO:      return new TasksFragment();
            case TAG_NOTES:     return new NotesFragment();
            case TAG_CHUDNUTIE: return new ChudnutieFragment();
            case TAG_KIDS:      return new KidsFragment();
            case TAG_HOME:
            default:            return new HomeFragment();
        }
    }

    /**
     * Implementácia HomeFragment.OnQuickActionListener.
     * Mapping z dashboardu na jednotlivé taby / akcie.
     */
    @Override
    public void onQuickAction(String which) {
        switch (which) {
            case HomeFragment.QUICK_TODO:
                bottomNav.setSelectedItemId(R.id.nav_todo);
                break;
            case HomeFragment.QUICK_SHOPPING:
                TaskRepository.getInstance(getApplicationContext())
                        .findLastActiveTaskByCategoryName(
                                TaskRepository.SHOPPING_CATEGORY_NAME,
                                taskId -> runOnUiThread(() -> {
                                    if (taskId > 0L) {
                                        startActivity(TaskEditorActivity.newIntent(this, taskId));
                                    } else {
                                        Intent shopIntent = TaskEditorActivity.newIntent(this, 0L);
                                        shopIntent.putExtra(
                                                TaskEditorActivity.EXTRA_PRESELECT_CATEGORY,
                                                TaskRepository.SHOPPING_CATEGORY_NAME);
                                        startActivity(shopIntent);
                                    }
                                }));
                break;
            case HomeFragment.QUICK_WEIGHT:
                bottomNav.setSelectedItemId(R.id.nav_chudnutie);
                break;
            case HomeFragment.QUICK_NOTES:
                bottomNav.setSelectedItemId(R.id.nav_notes);
                break;
        }
    }
}
