package sk.aetheriqa.noteiqa.data.repository;

import android.content.Context;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import sk.aetheriqa.noteiqa.data.db.AppDatabase;
import sk.aetheriqa.noteiqa.data.db.dao.KidDao;
import sk.aetheriqa.noteiqa.data.db.dao.KidEventDao;
import sk.aetheriqa.noteiqa.data.db.dao.KidPaymentDao;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;

/**
 * KidRepository – správa detí, ich platieb a udalostí.
 *
 * Seed pri prvom otvorení: Alex (modrá) + Gabika (ružová).
 * Všetky DB operácie na background threade cez ExecutorService.
 *
 * Notifikácie:
 *  - platby → KidPaymentReminderScheduler.schedule pri save
 *  - udalosti → KidEventReminderScheduler.schedule pri save
 *  - archive/delete → cancel odpovedajúceho reminderu
 */
public class KidRepository {

    /** Special kidId value: udalosť/platba sa týka všetkých detí. */
    public static final long KID_ID_ALL = 0L;

    private static volatile KidRepository INSTANCE;

    public static KidRepository getInstance(Context ctx) {
        if (INSTANCE == null) {
            synchronized (KidRepository.class) {
                if (INSTANCE == null) INSTANCE = new KidRepository(ctx);
            }
        }
        return INSTANCE;
    }

    private final KidDao kidDao;
    private final KidPaymentDao paymentDao;
    private final KidEventDao eventDao;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Context appContext;

    private KidRepository(Context ctx) {
        AppDatabase db = AppDatabase.getInstance(ctx);
        this.kidDao = db.kidDao();
        this.paymentDao = db.kidPaymentDao();
        this.eventDao = db.kidEventDao();
        this.appContext = ctx.getApplicationContext();

        executor.execute(this::seedKidsIfEmpty);
    }

    /** Idempotentný seed 2 default detí pri prvom spustení Deti modulu. */
    private void seedKidsIfEmpty() {
        if (kidDao.count() > 0) return;
        long now = System.currentTimeMillis();

        Kid alex = new Kid("Alex", "#5B8DEF", 0);   // modrá
        alex.createdAt = now;
        alex.updatedAt = now;
        kidDao.insert(alex);

        Kid gabika = new Kid("Gabika", "#E39CC4", 1); // jemná ružová
        gabika.createdAt = now;
        gabika.updatedAt = now;
        kidDao.insert(gabika);
    }

    // ===== Kids =====

    public LiveData<List<Kid>> observeKids() {
        return kidDao.observeAll();
    }

    public List<Kid> getKidsSync() {
        return kidDao.getAllSync();
    }

    // ===== Payments =====

    public LiveData<List<KidPayment>> observePayments() {
        return paymentDao.observeAll();
    }

    public LiveData<List<KidPayment>> observePaymentsByKid(long kidId) {
        return paymentDao.observeByKid(kidId);
    }

    public void savePayment(KidPayment payment, OnSavedCallback cb) {
        executor.execute(() -> {
            long now = System.currentTimeMillis();
            if (payment.createdAt == 0L) payment.createdAt = now;
            payment.updatedAt = now;

            long id;
            if (payment.id == 0L) {
                id = paymentDao.insert(payment);
                payment.id = id;
            } else {
                paymentDao.update(payment);
                id = payment.id;
            }

            sk.aetheriqa.noteiqa.notification.KidReminderScheduler
                    .schedulePayment(appContext, payment);

            if (cb != null) cb.onSaved(id);
        });
    }

    public void setPaymentCompleted(long id, boolean completed) {
        executor.execute(() -> {
            paymentDao.setCompleted(id, completed, System.currentTimeMillis());
            if (completed) {
                sk.aetheriqa.noteiqa.notification.KidReminderScheduler
                        .cancelPayment(appContext, id);
            } else {
                KidPayment p = paymentDao.getById(id);
                if (p != null) {
                    sk.aetheriqa.noteiqa.notification.KidReminderScheduler
                            .schedulePayment(appContext, p);
                }
            }
        });
    }

    public void deletePayment(long id) {
        executor.execute(() -> {
            sk.aetheriqa.noteiqa.notification.KidReminderScheduler
                    .cancelPayment(appContext, id);
            paymentDao.deleteById(id);
        });
    }

    public KidPayment getPaymentSync(long id) {
        return paymentDao.getById(id);
    }

    // ===== Events =====

    public LiveData<List<KidEvent>> observeEvents() {
        return eventDao.observeAll();
    }

    public LiveData<List<KidEvent>> observeEventsByKid(long kidId) {
        return eventDao.observeByKid(kidId);
    }

    public void saveEvent(KidEvent event, OnSavedCallback cb) {
        executor.execute(() -> {
            long now = System.currentTimeMillis();
            if (event.createdAt == 0L) event.createdAt = now;
            event.updatedAt = now;

            long id;
            if (event.id == 0L) {
                id = eventDao.insert(event);
                event.id = id;
            } else {
                eventDao.update(event);
                id = event.id;
            }

            sk.aetheriqa.noteiqa.notification.KidReminderScheduler
                    .scheduleEvent(appContext, event);

            if (cb != null) cb.onSaved(id);
        });
    }

    public void deleteEvent(long id) {
        executor.execute(() -> {
            sk.aetheriqa.noteiqa.notification.KidReminderScheduler
                    .cancelEvent(appContext, id);
            eventDao.deleteById(id);
        });
    }

    public KidEvent getEventSync(long id) {
        return eventDao.getById(id);
    }

    /** Pre injection do To Do listu. */
    public List<KidEvent> getEventsInRangeSync(long fromMillis, long toMillis) {
        return eventDao.getEventsInRangeSync(fromMillis, toMillis);
    }

    /** Pre BootReceiver re-schedule. */
    public void reschedulePendingReminders() {
        executor.execute(() -> {
            long now = System.currentTimeMillis();
            for (KidPayment p : paymentDao.getUpcomingRemindersSync(now)) {
                sk.aetheriqa.noteiqa.notification.KidReminderScheduler
                        .schedulePayment(appContext, p);
            }
            for (KidEvent e : eventDao.getUpcomingRemindersSync(now)) {
                sk.aetheriqa.noteiqa.notification.KidReminderScheduler
                        .scheduleEvent(appContext, e);
            }
        });
    }

    public interface OnSavedCallback {
        void onSaved(long id);
    }
}
