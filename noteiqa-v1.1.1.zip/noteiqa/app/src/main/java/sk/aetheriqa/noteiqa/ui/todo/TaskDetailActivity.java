package sk.aetheriqa.noteiqa.ui.todo;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.flexbox.FlexboxLayout;
import com.google.android.material.appbar.MaterialToolbar;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.data.entity.TaskCategory;
import sk.aetheriqa.noteiqa.data.repository.TaskRepository;
import sk.aetheriqa.noteiqa.util.DateUtils;
import sk.aetheriqa.noteiqa.util.IcsExporter;
import sk.aetheriqa.noteiqa.util.ShoppingItems;

/**
 * TaskDetailActivity v2 – read view úlohy s LEA pill buttons.
 *
 * Buttons (rôzne dĺžky, transparent + 1dp gold stroke + biely text):
 *   - Presuň úlohu
 *   - Zmeniť
 *   - Zdielať úlohu
 *   - Poslať do kalendára (.ics)
 *
 * Veľký solid-gold "Vymazať" button (premenovaný z "Dokončiť"):
 *   - archivuje úlohu (zachovaná v Archíve, dá sa obnoviť)
 *
 * Pri kategórii Nákup zobrazujeme zoznam položiek s checkboxami; checkbox
 * status sa ukladá späť do Task.shoppingItemsJson.
 */
public class TaskDetailActivity extends AppCompatActivity {

    public static final String EXTRA_TASK_ID = "taskId";
    /** Read-only mód pre archív (skryje akčné buttons). */
    public static final String EXTRA_READ_ONLY = "readOnly";

    private TaskRepository repo;
    private long taskId;
    private Task currentTask;
    private boolean readOnly = false;

    private TextView title, category, dateValue, timeValue, repeatValue, note;
    private View dateRow, timeRow, repeatRow;
    private View shoppingSection;
    private LinearLayout shoppingContainer;
    private FlexboxLayout actionsLayout;
    private Button btnRemove;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_detail);

        repo = TaskRepository.getInstance(getApplicationContext());
        taskId = getIntent().getLongExtra(EXTRA_TASK_ID, 0L);
        readOnly = getIntent().getBooleanExtra(EXTRA_READ_ONLY, false);

        MaterialToolbar tb = findViewById(R.id.detail_toolbar);
        tb.setNavigationOnClickListener(v -> finish());

        title = findViewById(R.id.detail_title);
        category = findViewById(R.id.detail_category);
        dateRow = findViewById(R.id.detail_date_row);
        dateValue = findViewById(R.id.detail_date_value);
        timeRow = findViewById(R.id.detail_time_row);
        timeValue = findViewById(R.id.detail_time_value);
        repeatRow = findViewById(R.id.detail_repeat_row);
        repeatValue = findViewById(R.id.detail_repeat_value);
        note = findViewById(R.id.detail_note);
        shoppingSection = findViewById(R.id.detail_shopping_section);
        shoppingContainer = findViewById(R.id.detail_shopping_container);
        actionsLayout = findViewById(R.id.detail_actions);
        btnRemove = findViewById(R.id.btn_remove);

        // Pre archív skryjeme akcie + Vymazať
        if (readOnly) {
            actionsLayout.setVisibility(View.GONE);
            btnRemove.setVisibility(View.GONE);
        } else {
            buildActionPills();
            btnRemove.setOnClickListener(v -> archiveTask());
        }

        if (taskId == 0L) {
            finish();
            return;
        }

        repo.observeById(taskId).observe(this, t -> {
            if (t == null) {
                finish();
                return;
            }
            currentTask = t;
            renderTask(t);
        });
    }

    // ===== Build pill action buttons (LEA štýl) =====

    private void buildActionPills() {
        actionsLayout.removeAllViews();

        addPill(R.string.task_action_move,    v -> showMoveDialog());
        addPill(R.string.task_action_change,  v -> openEditor());
        addPill(R.string.task_action_share_v2, v -> shareTask());
        addPill(R.string.task_action_to_calendar, v -> sendToCalendar());
    }

    private void addPill(int textRes, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(textRes);
        b.setAllCaps(false);
        b.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_lea_outlined_pill));
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(13f);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(18), dp(8), dp(18), dp(8));
        b.setOnClickListener(click);

        FlexboxLayout.LayoutParams lp = new FlexboxLayout.LayoutParams(
                FlexboxLayout.LayoutParams.WRAP_CONTENT,
                FlexboxLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), dp(8), dp(4));
        b.setLayoutParams(lp);

        actionsLayout.addView(b);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    // ===== Render =====

    private void renderTask(Task t) {
        title.setText(TextUtils.isEmpty(t.title) ? "—" : t.title);
        if (t.archivedAt > 0) {
            title.setPaintFlags(title.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            title.setAlpha(0.55f);
        } else {
            title.setPaintFlags(title.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
            title.setAlpha(1f);
        }

        // Kategória — sync read na background thread
        if (t.categoryId != null) {
            new Thread(() -> {
                TaskCategory c = repo.getCategoryByIdSync(t.categoryId);
                runOnUiThread(() -> {
                    if (c != null) {
                        category.setText(c.name);
                        category.setVisibility(View.VISIBLE);
                        // Ak Nákup → zobraz shopping items, skryť note
                        boolean shopping = TaskRepository.SHOPPING_CATEGORY_NAME.equals(c.name);
                        toggleShoppingMode(shopping);
                    } else {
                        category.setVisibility(View.GONE);
                        toggleShoppingMode(false);
                    }
                });
            }).start();
        } else {
            category.setVisibility(View.GONE);
            toggleShoppingMode(false);
        }

        // Date
        if (t.dueDate != null && t.dueDate != 0L) {
            dateRow.setVisibility(View.VISIBLE);
            dateValue.setText(formatDateWithHint(t.dueDate));
        } else {
            dateRow.setVisibility(View.GONE);
        }

        // Time
        if (t.dueTimeMinutes != null) {
            timeRow.setVisibility(View.VISIBLE);
            int h = t.dueTimeMinutes / 60;
            int m = t.dueTimeMinutes % 60;
            timeValue.setText(String.format(Locale.getDefault(), "%d:%02d", h, m));
        } else {
            timeRow.setVisibility(View.GONE);
        }

        // Repeat
        if (t.repeatType != Task.REPEAT_NONE) {
            repeatRow.setVisibility(View.VISIBLE);
            int res;
            switch (t.repeatType) {
                case Task.REPEAT_DAILY:   res = R.string.task_repeat_daily; break;
                case Task.REPEAT_WEEKLY:  res = R.string.task_repeat_weekly; break;
                case Task.REPEAT_MONTHLY: res = R.string.task_repeat_monthly; break;
                case Task.REPEAT_YEARLY:  res = R.string.task_repeat_yearly; break;
                default:                  res = R.string.task_repeat_none; break;
            }
            repeatValue.setText(res);
        } else {
            repeatRow.setVisibility(View.GONE);
        }

        // Note (pre obyčajné kategórie)
        if (!TextUtils.isEmpty(t.note)) {
            note.setVisibility(View.VISIBLE);
            note.setText(t.note);
        } else {
            note.setVisibility(View.GONE);
        }
    }

    private void toggleShoppingMode(boolean shopping) {
        if (shopping && currentTask != null
                && !TextUtils.isEmpty(currentTask.shoppingItemsJson)) {
            shoppingSection.setVisibility(View.VISIBLE);
            // Pri Nákup sa note v hlavičke skryje, lebo zoznam je primárny obsah
            note.setVisibility(View.GONE);
            renderShoppingItems();
        } else {
            shoppingSection.setVisibility(View.GONE);
        }
    }

    private void renderShoppingItems() {
        shoppingContainer.removeAllViews();
        if (currentTask == null) return;
        List<ShoppingItems.Item> items = ShoppingItems.parse(currentTask.shoppingItemsJson);
        LayoutInflater inf = LayoutInflater.from(this);

        for (int i = 0; i < items.size(); i++) {
            final int idx = i;
            final ShoppingItems.Item item = items.get(i);
            View row = inf.inflate(R.layout.item_shopping_check, shoppingContainer, false);
            CheckBox cb = row.findViewById(R.id.shopping_check);
            TextView text = row.findViewById(R.id.shopping_text);
            View trash = row.findViewById(R.id.shopping_remove);
            View moveUp = row.findViewById(R.id.shopping_move_up);
            View moveDown = row.findViewById(R.id.shopping_move_down);
            // V detail view povoľujeme len toggle checkboxu
            trash.setVisibility(View.GONE);
            moveUp.setVisibility(View.GONE);
            moveDown.setVisibility(View.GONE);

            cb.setChecked(item.checked);
            text.setText(item.text);
            updateShoppingTextStyle(text, item.checked);

            cb.setOnCheckedChangeListener((v, checked) -> {
                items.get(idx).checked = checked;
                updateShoppingTextStyle(text, checked);
                // Persist späť do entity
                currentTask.shoppingItemsJson = ShoppingItems.serialize(items);
                repo.save(currentTask, null);
            });

            shoppingContainer.addView(row);
        }
    }

    private void updateShoppingTextStyle(TextView text, boolean checked) {
        if (checked) {
            text.setPaintFlags(text.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            text.setAlpha(0.55f);
        } else {
            text.setPaintFlags(text.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
            text.setAlpha(1f);
        }
    }

    private String formatDateWithHint(long millis) {
        String dateStr = DateUtils.formatLongDate(millis);
        LocalDate due = Instant.ofEpochMilli(millis)
                .atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate today = LocalDate.now();
        if (due.equals(today)) return dateStr + ", " + getString(R.string.task_today_label).toLowerCase(new Locale("sk"));
        if (due.equals(today.plusDays(1))) return dateStr + ", " + getString(R.string.task_tomorrow_label).toLowerCase(new Locale("sk"));
        if (due.getMonth() == today.getMonth() && due.getYear() == today.getYear()) {
            return dateStr + ", " + getString(R.string.task_this_month_label);
        }
        return dateStr;
    }

    // ===== Actions =====

    private void archiveTask() {
        if (currentTask == null) return;
        new AlertDialog.Builder(this,
                sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(R.string.task_complete_confirm_title)
                .setMessage(R.string.task_complete_confirm_msg)
                .setPositiveButton(R.string.action_yes, (d, w) -> {
                    repo.archive(currentTask.id);
                    Toast.makeText(this, R.string.task_archived_toast, Toast.LENGTH_SHORT).show();
                    finish();
                })
                .setNegativeButton(R.string.action_no, null)
                .show();
    }

    private void openEditor() {
        if (currentTask == null) return;
        startActivity(TaskEditorActivity.newIntent(this, currentTask.id));
    }

    private void shareTask() {
        if (currentTask == null) return;
        StringBuilder sb = new StringBuilder();
        if (!TextUtils.isEmpty(currentTask.title)) sb.append(currentTask.title);
        if (currentTask.dueDate != null && currentTask.dueDate != 0L) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(DateUtils.formatLongDate(currentTask.dueDate));
        }
        if (currentTask.dueTimeMinutes != null) {
            int h = currentTask.dueTimeMinutes / 60;
            int m = currentTask.dueTimeMinutes % 60;
            sb.append(' ').append(String.format(Locale.getDefault(), "%d:%02d", h, m));
        }
        if (!TextUtils.isEmpty(currentTask.note)) {
            sb.append("\n\n").append(currentTask.note);
        }
        // Shopping items
        if (!TextUtils.isEmpty(currentTask.shoppingItemsJson)) {
            List<ShoppingItems.Item> items = ShoppingItems.parse(currentTask.shoppingItemsJson);
            if (!items.isEmpty()) {
                sb.append("\n\n");
                for (ShoppingItems.Item it : items) {
                    sb.append(it.checked ? "[x] " : "[ ] ").append(it.text).append('\n');
                }
            }
        }

        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, sb.toString().trim());
        startActivity(Intent.createChooser(send, getString(R.string.task_action_share_v2)));
    }

    private void sendToCalendar() {
        if (currentTask == null) return;
        Intent intent = IcsExporter.buildShareIntent(this, currentTask);
        if (intent == null) {
            Toast.makeText(this,
                    currentTask.dueDate == null
                            ? R.string.ics_export_no_date
                            : R.string.ics_export_failed,
                    Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(intent);
    }

    private void showMoveDialog() {
        if (currentTask == null) return;
        CharSequence[] opts = new CharSequence[]{
                getString(R.string.move_change_date),
                getString(R.string.move_change_time)
        };
        new AlertDialog.Builder(this,
                sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(R.string.move_task_title)
                .setItems(opts, (d, which) -> {
                    if (which == 0) showDatePicker();
                    else showTimePicker();
                })
                .show();
    }

    private void showDatePicker() {
        Calendar cal = Calendar.getInstance();
        if (currentTask.dueDate != null && currentTask.dueDate != 0L) {
            cal.setTimeInMillis(currentTask.dueDate);
        }
        DatePickerDialog dlg = new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    Calendar c = Calendar.getInstance();
                    c.set(Calendar.YEAR, year);
                    c.set(Calendar.MONTH, month);
                    c.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    c.set(Calendar.HOUR_OF_DAY, 0);
                    c.set(Calendar.MINUTE, 0);
                    c.set(Calendar.SECOND, 0);
                    c.set(Calendar.MILLISECOND, 0);
                    currentTask.dueDate = c.getTimeInMillis();
                    repo.save(currentTask, null);
                    Toast.makeText(this, R.string.task_saved_toast, Toast.LENGTH_SHORT).show();
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH));
        dlg.show();
    }

    private void showTimePicker() {
        int h = 9, m = 0;
        if (currentTask.dueTimeMinutes != null) {
            h = currentTask.dueTimeMinutes / 60;
            m = currentTask.dueTimeMinutes % 60;
        }
        TimePickerDialog dlg = new TimePickerDialog(this,
                (view, hourOfDay, minute) -> {
                    currentTask.dueTimeMinutes = hourOfDay * 60 + minute;
                    repo.save(currentTask, null);
                    Toast.makeText(this, R.string.task_saved_toast, Toast.LENGTH_SHORT).show();
                },
                h, m, true);
        dlg.show();
    }

    public static Intent newIntent(Context ctx, long taskId) {
        Intent i = new Intent(ctx, TaskDetailActivity.class);
        i.putExtra(EXTRA_TASK_ID, taskId);
        return i;
    }

    public static Intent newReadOnlyIntent(Context ctx, long taskId) {
        Intent i = new Intent(ctx, TaskDetailActivity.class);
        i.putExtra(EXTRA_TASK_ID, taskId);
        i.putExtra(EXTRA_READ_ONLY, true);
        return i;
    }
}
