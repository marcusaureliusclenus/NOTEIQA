package sk.aetheriqa.noteiqa.ui.notes;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.ChecklistItem;
import sk.aetheriqa.noteiqa.data.entity.Note;
import sk.aetheriqa.noteiqa.data.repository.NoteRepository;

/**
 * NotesFragment v2 – zoznam Poznámok a Zoznamov v jednom buckete.
 *
 *  - FAB → dialóg "Poznámka / Zoznam"
 *  - Long-press na karte → kontextové menu (Zdieľať, Pripnúť, Kopírovať, Archivovať, Zmazať)
 *  - Pre TYPE_CHECKLIST karty načíta items observerom a pošle do adaptora
 *    cez setChecklistMap, ktorý ich rendruje ako preview
 *  - Zoradenie: pinned DESC, updatedAt DESC (DAO query — najnovšie hore)
 */
public class NotesFragment extends Fragment {

    private NotesAdapter adapter;
    private View emptyState;
    private RecyclerView list;
    private NoteRepository repo;

    /** Per-checklist observers, aby sme mohli unsubscribe pri zmene listu. */
    private final Map<Long, LiveData<List<ChecklistItem>>> currentChecklistObservers = new HashMap<>();
    private final Map<Long, List<ChecklistItem>> checklistCache = new HashMap<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_notes, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        repo = NoteRepository.getInstance(requireContext().getApplicationContext());

        list = view.findViewById(R.id.notes_list);
        emptyState = view.findViewById(R.id.notes_empty_state);

        adapter = new NotesAdapter(new NotesAdapter.OnNoteClickListener() {
            @Override
            public void onNoteClick(Note note) {
                openNote(note);
            }

            @Override
            public void onNoteLongClick(Note note, View anchor) {
                showContextMenu(note);
            }
        });

        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        list.setAdapter(adapter);

        repo.observeActive().observe(getViewLifecycleOwner(), notes -> {
            adapter.submitList(notes);
            boolean empty = notes == null || notes.isEmpty();
            emptyState.setVisibility(empty ? View.VISIBLE : View.GONE);
            list.setVisibility(empty ? View.GONE : View.VISIBLE);

            // Pre každú checklist note nastav observer ak ho ešte nemá
            if (notes != null) {
                Set<Long> currentIds = new HashSet<>();
                for (Note n : notes) {
                    if (n.type == Note.TYPE_CHECKLIST) {
                        currentIds.add(n.id);
                        if (!currentChecklistObservers.containsKey(n.id)) {
                            LiveData<List<ChecklistItem>> live = repo.observeChecklistItems(n.id);
                            final long noteId = n.id;
                            live.observe(getViewLifecycleOwner(), items -> {
                                checklistCache.put(noteId, items);
                                adapter.setChecklistMap(checklistCache);
                            });
                            currentChecklistObservers.put(n.id, live);
                        }
                    }
                }
                // Vyhoď cache pre poznámky, ktoré už nie sú checklist alebo zmizli
                checklistCache.keySet().retainAll(currentIds);
            }
        });

        FloatingActionButton fab = view.findViewById(R.id.fab_new_note);
        fab.setOnClickListener(v -> showNewNoteTypeDialog());
    }

    private void openNote(Note note) {
        // Pre TYPE_CHECKLIST otvor ChecklistEditorActivity, inak NoteEditorActivity
        if (note.type == Note.TYPE_CHECKLIST) {
            startActivity(ChecklistEditorActivity.newIntent(requireContext(), note.id));
        } else {
            startActivity(NoteEditorActivity.newIntent(requireContext(), note.id));
        }
    }

    /**
     * FAB dialóg – Poznámka vs Zoznam.
     */
    private void showNewNoteTypeDialog() {
        CharSequence[] options = new CharSequence[]{
                getString(R.string.new_note_type_text),
                getString(R.string.new_note_type_checklist)
        };
        new AlertDialog.Builder(requireContext(),
                sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(R.string.new_note_title)
                .setItems(options, (d, which) -> {
                    if (which == 0) {
                        startActivity(NoteEditorActivity.newIntent(requireContext(), 0L));
                    } else {
                        startActivity(ChecklistEditorActivity.newIntent(requireContext(), 0L));
                    }
                })
                .show();
    }

    /**
     * Kontextové menu (long-press): Zdieľať, Pripnúť, Kopírovať, Archivovať, Zmazať.
     */
    private void showContextMenu(Note note) {
        String pinLabel = getString(note.pinned ? R.string.notes_action_unpin : R.string.notes_action_pin);
        String[] items = new String[]{
                getString(R.string.notes_action_share),
                pinLabel,
                getString(R.string.notes_action_copy),
                getString(R.string.notes_action_archive),
                getString(R.string.notes_action_delete)
        };

        new AlertDialog.Builder(requireContext(),
                sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(TextUtils.isEmpty(note.title)
                        ? getString(R.string.editor_title_default) : note.title)
                .setItems(items, (dialog, which) -> {
                    switch (which) {
                        case 0: shareNote(note); break;
                        case 1: repo.setPinned(note.id, !note.pinned); break;
                        case 2: copyAsPlainText(note); break;
                        case 3: confirmArchive(note); break;
                        case 4: confirmDelete(note); break;
                    }
                })
                .show();
    }

    private void shareNote(Note note) {
        String content = noteToPlainText(note);
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, content);
        if (!TextUtils.isEmpty(note.title)) {
            send.putExtra(Intent.EXTRA_SUBJECT, note.title);
        }
        startActivity(Intent.createChooser(send, getString(R.string.notes_action_share)));
    }

    private void copyAsPlainText(Note note) {
        String content = noteToPlainText(note);
        ClipboardManager cm = (ClipboardManager) requireContext()
                .getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("note", content));
            Toast.makeText(requireContext(), R.string.notes_copied_toast, Toast.LENGTH_SHORT).show();
        }
    }

    private String noteToPlainText(Note note) {
        StringBuilder sb = new StringBuilder();
        if (!TextUtils.isEmpty(note.title)) sb.append(note.title).append("\n\n");
        if (note.type == Note.TYPE_CHECKLIST) {
            List<ChecklistItem> items = checklistCache.get(note.id);
            if (items == null) items = new ArrayList<>();
            for (ChecklistItem it : items) {
                sb.append(it.checked ? "[x] " : "[ ] ").append(it.text).append('\n');
            }
        } else {
            if (!TextUtils.isEmpty(note.body)) sb.append(note.body);
        }
        return sb.toString().trim();
    }

    private void confirmArchive(Note note) {
        new AlertDialog.Builder(requireContext(),
                sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(R.string.notes_archive_confirm_title)
                .setMessage(R.string.notes_archive_confirm_msg)
                .setPositiveButton(R.string.action_yes, (d, w) -> {
                    repo.archive(note.id);
                    Toast.makeText(requireContext(),
                            R.string.notes_archived_toast, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(R.string.action_no, null)
                .show();
    }

    private void confirmDelete(Note note) {
        new AlertDialog.Builder(requireContext(),
                sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(R.string.notes_delete_confirm_title)
                .setMessage(R.string.notes_delete_confirm_msg)
                .setPositiveButton(R.string.action_yes, (d, w) -> {
                    repo.trash(note.id);
                    Toast.makeText(requireContext(),
                            R.string.notes_deleted_toast, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(R.string.action_no, null)
                .show();
    }
}
