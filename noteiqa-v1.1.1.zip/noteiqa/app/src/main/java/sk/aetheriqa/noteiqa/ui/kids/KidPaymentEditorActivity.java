package sk.aetheriqa.noteiqa.ui.kids;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Calendar;
import java.util.List;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.util.DateUtils;
import sk.aetheriqa.noteiqa.util.DialogThemes;

/**
 * KidPaymentEditorActivity – vytvorenie / úprava platby.
 *
 * Extras:
 *   EXTRA_ID = 0 → new, > 0 → edit
 *   EXTRA_KID_ID = predvolené dieťa
 */
public class KidPaymentEditorActivity extends AppCompatActivity {

    public static final String EXTRA_ID = "paymentId";
    public static final String EXTRA_KID_ID = "kidId";

    private KidRepository repo;
    private KidPayment editing;

    private MaterialButtonToggleGroup kidGroup;
    private MaterialButton kidAbtn, kidBbtn;
    private Kid kidA, kidB;
    private long selectedKidId = 0L;

    private EditText title, amount, iban, vs, ss, msg, cashRecipient, note;
    private RadioGroup methodGroup;
    private RadioButton mTransfer, mCash, mOther;
    private View transferGroup, cashGroup;
    private MaterialButton dueBtn, notifyBtn, recurrenceBtn;

    private long dueDate = 0L;
    private long notifyAt = 0L;
    private int recurrence = KidPayment.RECURRENCE_NONE;

    public static Intent newIntent(Context ctx, long paymentId, long kidId) {
        Intent i = new Intent(ctx, KidPaymentEditorActivity.class);
        i.putExtra(EXTRA_ID, paymentId);
        i.putExtra(EXTRA_KID_ID, kidId);
        return i;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kid_payment_editor);

        repo = KidRepository.getInstance(this);

        MaterialToolbar tb = findViewById(R.id.editor_toolbar);
        tb.setNavigationOnClickListener(v -> finish());
        tb.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();
            if (id == R.id.action_delete) { deleteConfirm(); return true; }
            return false;
        });

        FloatingActionButton fabSave = findViewById(R.id.fab_save);
        fabSave.setOnClickListener(v -> save());

        kidGroup = findViewById(R.id.ed_kid_group);
        kidAbtn = findViewById(R.id.ed_kid_a);
        kidBbtn = findViewById(R.id.ed_kid_b);

        title = findViewById(R.id.ed_title);
        amount = findViewById(R.id.ed_amount);
        methodGroup = findViewById(R.id.ed_method_group);
        mTransfer = findViewById(R.id.ed_method_transfer);
        mCash = findViewById(R.id.ed_method_cash);
        mOther = findViewById(R.id.ed_method_other);
        transferGroup = findViewById(R.id.ed_transfer_group);
        cashGroup = findViewById(R.id.ed_cash_group);
        iban = findViewById(R.id.ed_iban);
        vs = findViewById(R.id.ed_vs);
        ss = findViewById(R.id.ed_ss);
        msg = findViewById(R.id.ed_msg);
        cashRecipient = findViewById(R.id.ed_cash_recipient);
        note = findViewById(R.id.ed_note);
        dueBtn = findViewById(R.id.ed_due_btn);
        notifyBtn = findViewById(R.id.ed_notify_btn);
        recurrenceBtn = findViewById(R.id.ed_recurrence_btn);

        methodGroup.setOnCheckedChangeListener((g, checkedId) -> updateMethodVisibility());
        mTransfer.setChecked(true);

        dueBtn.setOnClickListener(v -> pickDueDate());
        notifyBtn.setOnClickListener(v -> pickNotifyDate());
        recurrenceBtn.setOnClickListener(v -> pickRecurrence());

        loadKids();

        long editId = getIntent().getLongExtra(EXTRA_ID, 0L);
        if (editId > 0L) {
            tb.setTitle(R.string.kid_payment_edit_title);
            loadPayment(editId);
        } else {
            editing = new KidPayment();
            editing.kidId = getIntent().getLongExtra(EXTRA_KID_ID, 0L);
            selectedKidId = editing.kidId;
        }
    }

    private void loadKids() {
        new Thread(() -> {
            List<Kid> kids = repo.getKidsSync();
            runOnUiThread(() -> {
                if (kids == null || kids.size() < 2) return;
                kidA = kids.get(0);
                kidB = kids.get(1);
                kidAbtn.setText(kidA.name);
                kidBbtn.setText(kidB.name);

                kidGroup.addOnButtonCheckedListener((g, checkedId, isChecked) -> {
                    if (!isChecked) return;
                    if (checkedId == R.id.ed_kid_a) selectedKidId = kidA.id;
                    else if (checkedId == R.id.ed_kid_b) selectedKidId = kidB.id;
                });

                if (selectedKidId == kidA.id) kidGroup.check(R.id.ed_kid_a);
                else if (selectedKidId == kidB.id) kidGroup.check(R.id.ed_kid_b);
                else kidGroup.check(R.id.ed_kid_a);
            });
        }, "load-kids").start();
    }

    private void loadPayment(long id) {
        new Thread(() -> {
            KidPayment p = repo.getPaymentSync(id);
            if (p == null) return;
            runOnUiThread(() -> {
                editing = p;
                selectedKidId = p.kidId;
                title.setText(p.title);
                if (p.amountEur != null) {
                    amount.setText(String.format(java.util.Locale.getDefault(),
                            "%.2f", p.amountEur).replace('.', ','));
                }
                if (p.paymentMethod == KidPayment.METHOD_CASH) mCash.setChecked(true);
                else if (p.paymentMethod == KidPayment.METHOD_OTHER) mOther.setChecked(true);
                else mTransfer.setChecked(true);
                iban.setText(p.iban);
                vs.setText(p.variableSymbol);
                ss.setText(p.specificSymbol);
                msg.setText(p.paymentNote);
                cashRecipient.setText(p.cashRecipient);
                note.setText(p.note);
                dueDate = p.dueDate;
                notifyAt = p.notifyAt;
                recurrence = p.recurrence;
                refreshButtons();

                if (kidA != null && kidB != null) {
                    if (p.kidId == kidA.id) kidGroup.check(R.id.ed_kid_a);
                    else if (p.kidId == kidB.id) kidGroup.check(R.id.ed_kid_b);
                }
            });
        }, "load-payment").start();
    }

    private void updateMethodVisibility() {
        int checked = methodGroup.getCheckedRadioButtonId();
        transferGroup.setVisibility(checked == R.id.ed_method_transfer ? View.VISIBLE : View.GONE);
        cashGroup.setVisibility(checked == R.id.ed_method_cash ? View.VISIBLE : View.GONE);
    }

    private void refreshButtons() {
        dueBtn.setText(dueDate > 0L
                ? DateUtils.formatLongDate(dueDate)
                : "Vybrať dátum");
        notifyBtn.setText(notifyAt > 0L
                ? DateUtils.formatLongDate(notifyAt) + " " + timeOf(notifyAt)
                : "Bez pripomenutia");
        recurrenceBtn.setText(recurrenceLabel(recurrence));
    }

    private String timeOf(long ts) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ts);
        return String.format(java.util.Locale.getDefault(), "%d:%02d",
                c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
    }

    private String recurrenceLabel(int rec) {
        switch (rec) {
            case KidPayment.RECURRENCE_MONTHLY: return getString(R.string.kid_recurrence_monthly);
            case KidPayment.RECURRENCE_QUARTERLY: return getString(R.string.kid_recurrence_quarterly);
            case KidPayment.RECURRENCE_YEARLY: return getString(R.string.kid_recurrence_yearly);
            default: return getString(R.string.kid_recurrence_none);
        }
    }

    // v1.1.1 — Picker bez theme overlay (rovnako ako TaskEditorActivity): dedí tmavú
    // Theme.Material3.Dark z aktivity. ThemeOverlay.Noteiqa.Dialog je overlay pre
    // MaterialAlertDialog, nie plná téma pre framework DatePicker → dával svetlý podklad.
    private void pickDueDate() {
        Calendar c = Calendar.getInstance();
        if (dueDate > 0L) c.setTimeInMillis(dueDate);
        DatePickerDialog dlg = new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    Calendar picked = Calendar.getInstance();
                    picked.set(year, month, dayOfMonth, 0, 0, 0);
                    picked.set(Calendar.MILLISECOND, 0);
                    dueDate = picked.getTimeInMillis();
                    refreshButtons();
                },
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dlg.show();
    }

    private void pickNotifyDate() {
        Calendar c = Calendar.getInstance();
        if (notifyAt > 0L) c.setTimeInMillis(notifyAt);
        else if (dueDate > 0L) {
            c.setTimeInMillis(dueDate);
            c.add(Calendar.DAY_OF_MONTH, -2);
            c.set(Calendar.HOUR_OF_DAY, 9);
        }
        DatePickerDialog datePicker = new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    Calendar picked = Calendar.getInstance();
                    picked.set(year, month, dayOfMonth, 9, 0, 0);
                    picked.set(Calendar.MILLISECOND, 0);
                    TimePickerDialog tp = new TimePickerDialog(this,
                            (v, h, m) -> {
                                picked.set(Calendar.HOUR_OF_DAY, h);
                                picked.set(Calendar.MINUTE, m);
                                notifyAt = picked.getTimeInMillis();
                                refreshButtons();
                            }, 9, 0, true);
                    tp.show();
                },
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        datePicker.show();
    }

    private void pickRecurrence() {
        String[] items = new String[]{
                getString(R.string.kid_recurrence_none),
                getString(R.string.kid_recurrence_monthly),
                getString(R.string.kid_recurrence_quarterly),
                getString(R.string.kid_recurrence_yearly)
        };
        int[] values = new int[]{
                KidPayment.RECURRENCE_NONE,
                KidPayment.RECURRENCE_MONTHLY,
                KidPayment.RECURRENCE_QUARTERLY,
                KidPayment.RECURRENCE_YEARLY
        };
        new AlertDialog.Builder(this, DialogThemes.LEA)
                .setTitle(R.string.kid_payment_recurrence)
                .setItems(items, (d, which) -> {
                    recurrence = values[which];
                    refreshButtons();
                })
                .show();
    }

    private void save() {
        String t = title.getText() != null ? title.getText().toString().trim() : "";
        if (TextUtils.isEmpty(t)) {
            Toast.makeText(this, "Zadaj názov platby", Toast.LENGTH_SHORT).show();
            return;
        }
        if (dueDate <= 0L) {
            Toast.makeText(this, "Zadaj dátum splatnosti", Toast.LENGTH_SHORT).show();
            return;
        }
        if (selectedKidId <= 0L) {
            Toast.makeText(this, "Vyber dieťa", Toast.LENGTH_SHORT).show();
            return;
        }

        if (editing == null) editing = new KidPayment();
        editing.kidId = selectedKidId;
        editing.title = t;

        String am = amount.getText() != null ? amount.getText().toString().trim() : "";
        am = am.replace(',', '.');
        if (!am.isEmpty()) {
            try { editing.amountEur = Double.parseDouble(am); }
            catch (NumberFormatException e) { editing.amountEur = null; }
        } else {
            editing.amountEur = null;
        }

        int checked = methodGroup.getCheckedRadioButtonId();
        if (checked == R.id.ed_method_cash) editing.paymentMethod = KidPayment.METHOD_CASH;
        else if (checked == R.id.ed_method_other) editing.paymentMethod = KidPayment.METHOD_OTHER;
        else editing.paymentMethod = KidPayment.METHOD_TRANSFER;

        editing.iban = strOrNull(iban);
        editing.variableSymbol = strOrNull(vs);
        editing.specificSymbol = strOrNull(ss);
        editing.paymentNote = strOrNull(msg);
        editing.cashRecipient = strOrNull(cashRecipient);
        editing.note = strOrNull(note);
        editing.dueDate = dueDate;
        editing.notifyAt = notifyAt;
        editing.recurrence = recurrence;

        repo.savePayment(editing, id -> runOnUiThread(() -> {
            Toast.makeText(this, R.string.kid_payment_saved, Toast.LENGTH_SHORT).show();
            finish();
        }));
    }

    private String strOrNull(EditText field) {
        if (field.getText() == null) return null;
        String s = field.getText().toString().trim();
        return s.isEmpty() ? null : s;
    }

    private void deleteConfirm() {
        if (editing == null || editing.id == 0L) { finish(); return; }
        new AlertDialog.Builder(this, DialogThemes.LEA)
                .setTitle(R.string.kid_delete_confirm_title)
                .setMessage(R.string.kid_delete_confirm_message)
                .setPositiveButton("Áno", (d, w) -> {
                    repo.deletePayment(editing.id);
                    Toast.makeText(this, R.string.kid_payment_deleted, Toast.LENGTH_SHORT).show();
                    finish();
                })
                .setNegativeButton("Nie", null)
                .show();
    }
}
