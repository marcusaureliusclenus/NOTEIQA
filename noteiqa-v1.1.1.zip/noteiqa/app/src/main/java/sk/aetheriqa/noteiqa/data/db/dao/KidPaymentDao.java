package sk.aetheriqa.noteiqa.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import sk.aetheriqa.noteiqa.data.entity.KidPayment;

@Dao
public interface KidPaymentDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(KidPayment payment);

    @Update
    int update(KidPayment payment);

    @Delete
    int delete(KidPayment payment);

    @Query("DELETE FROM kid_payments WHERE id = :id")
    int deleteById(long id);

    @Query("SELECT * FROM kid_payments WHERE id = :id")
    KidPayment getById(long id);

    /** Všetky platby (aj zaplatené) pre konkrétne dieťa, zoradené podľa splatnosti. */
    @Query("SELECT * FROM kid_payments WHERE kidId = :kidId ORDER BY dueDate ASC")
    LiveData<List<KidPayment>> observeByKid(long kidId);

    /** Všetky platby všetkých detí zoradené podľa splatnosti. */
    @Query("SELECT * FROM kid_payments ORDER BY dueDate ASC")
    LiveData<List<KidPayment>> observeAll();

    /** Sync – pre notifikačný scheduler a export. */
    @Query("SELECT * FROM kid_payments")
    List<KidPayment> getAllSync();

    /** Aktívne (nezaplatené) platby s notifyAt > now — pre BootReceiver re-schedule. */
    @Query("SELECT * FROM kid_payments WHERE completed = 0 AND notifyAt > :now")
    List<KidPayment> getUpcomingRemindersSync(long now);

    @Query("UPDATE kid_payments SET completed = :completed, completedAt = :ts, updatedAt = :ts WHERE id = :id")
    int setCompleted(long id, boolean completed, long ts);
}
