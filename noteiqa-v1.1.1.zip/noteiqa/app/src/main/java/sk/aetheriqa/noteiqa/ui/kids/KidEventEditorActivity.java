package sk.aetheriqa.noteiqa.ui.kids;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.materialswitch.MaterialSwitch;

import java.util.Calendar;
import java.util.List;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.util.DateUtils;
import sk.aetheriqa.noteiqa.util.DialogThemes;

/**
 * KidEventEditorActivity – vytvorenie / úprava udalosti.
 */
public class KidEventEditorActivity extends AppCompatActivity {

    public static final String EXTRA_ID = "eventId";
    public static final String EXTRA_KID_ID = "kidId";

    private KidRepository repo;
    private KidEvent editing;

    private MaterialButtonToggleGroup kidGroup;
    private MaterialButton kidAbtn, kidBbtn, kidAllBtn;
    private Kid kidA, kidB;
    private long selectedKidId = KidRepository.KID_ID_ALL;

    private EditText title, location, note;
    private MaterialSwitch allDay;
    private MaterialButton typeBtn, startBtn, endBtn, notifyBtn;

    private long startDate = 0L;
    private long endDate = 0L;
    private long notifyAt = 0L;
    private int type = KidEvent.TYPE_OTHER;

    public static Intent newIntent(Context ctx, long eventId, long kidId) {
        Intent i = new Intent(ctx, KidEventEditorActivity.class);
        i.putExtra(EXTRA_ID, eventId);
        i.putExtra(EXTRA_KID_ID, kidId);
        return i;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kid_event_editor);

        repo = KidRepository.getInstance(this);

        MaterialToolbar tb = findViewById(R.id.editor_toolbar);
        tb.setNavigationOnClickListener(v -> finish());
        tb.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();
            if (id == R.id.action_delete) { deleteConfirm(); return true; }
            return false;
        });

        FloatingActionButton fabSave = findViewById(R.id.fab_save);
        fabSave.setOnClickListener(v -> save());

        kidGroup = findViewById(R.id.ev_kid_group);
        kidAbtn = findViewById(R.id.ev_kid_a);
        kidBbtn = findViewById(R.id.ev_kid_b);
        kidAllBtn = findViewById(R.id.ev_kid_all);

        title = findViewById(R.id.ev_title);
        allDay = findViewById(R.id.ev_all_day);
        typeBtn = findViewById(R.id.ev_type_btn);
        startBtn = findViewById(R.id.ev_start_btn);
        endBtn = findViewById(R.id.ev_end_btn);
        notifyBtn = findViewById(R.id.ev_notify_btn);
        location = findViewById(R.id.ev_location);
        note = findViewById(R.id.ev_note);

        typeBtn.setOnClickListener(v -> pickType());
        startBtn.setOnClickListener(v -> pickStart());
        endBtn.setOnClickListener(v -> pickEnd());
        notifyBtn.setOnClickListener(v -> pickNotify());

        loadKids();

        long editId = getIntent().getLongExtra(EXTRA_ID, 0L);
        if (editId > 0L) {
            tb.setTitle(R.string.kid_event_edit_title);
            loadEvent(editId);
        } else {
            editing = new KidEvent();
            editing.kidId = getIntent().getLongExtra(EXTRA_KID_ID, 0L);
            selectedKidId = editing.kidId;
        }
    }

    private void loadKids() {
        new Thread(() -> {
            List<Kid> kids = repo.getKidsSync();
            runOnUiThread(() -> {
                if (kids == null || kids.size() < 2) return;
                kidA = kids.get(0);
                kidB = kids.get(1);
                kidAbtn.setText(kidA.name);
                kidBbtn.setText(kidB.name);

                kidGroup.addOnButtonCheckedListener((g, checkedId, isChecked) -> {
                    if (!isChecked) return;
                    if (checkedId == R.id.ev_kid_a) selectedKidId = kidA.id;
                    else if (checkedId == R.id.ev_kid_b) selectedKidId = kidB.id;
                    else selectedKidId = KidRepository.KID_ID_ALL;
                });

                if (selectedKidId == kidA.id) kidGroup.check(R.id.ev_kid_a);
                else if (selectedKidId == kidB.id) kidGroup.check(R.id.ev_kid_b);
                else kidGroup.check(R.id.ev_kid_all);
            });
        }, "load-kids").start();
    }

    private void loadEvent(long id) {
        new Thread(() -> {
            KidEvent e = repo.getEventSync(id);
            if (e == null) return;
            runOnUiThread(() -> {
                editing = e;
                selectedKidId = e.kidId;
                title.setText(e.title);
                allDay.setChecked(e.allDay);
                type = e.type;
                startDate = e.startDate;
                endDate = e.endDate;
                notifyAt = e.notifyAt;
                location.setText(e.location);
                note.setText(e.note);
                refreshButtons();

                if (kidA != null && kidB != null) {
                    if (e.kidId == kidA.id) kidGroup.check(R.id.ev_kid_a);
                    else if (e.kidId == kidB.id) kidGroup.check(R.id.ev_kid_b);
                    else kidGroup.check(R.id.ev_kid_all);
                }
            });
        }, "load-event").start();
    }

    private void refreshButtons() {
        typeBtn.setText(KidEventsAdapter.typeLabel(type));
        startBtn.setText(startDate > 0L
                ? DateUtils.formatLongDate(startDate)
                    + (allDay.isChecked() ? "" : " " + timeOf(startDate))
                : "Vybrať začiatok");
        endBtn.setText(endDate > 0L
                ? DateUtils.formatLongDate(endDate)
                    + (allDay.isChecked() ? "" : " " + timeOf(endDate))
                : "Rovnaký deň");
        notifyBtn.setText(notifyAt > 0L
                ? DateUtils.formatLongDate(notifyAt) + " " + timeOf(notifyAt)
                : "Bez pripomenutia");
    }

    private String timeOf(long ts) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ts);
        return String.format(java.util.Locale.getDefault(), "%d:%02d",
                c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
    }

    private void pickType() {
        String[] items = new String[]{
                getString(R.string.kid_event_type_school),
                getString(R.string.kid_event_type_sport),
                getString(R.string.kid_event_type_health),
                getString(R.string.kid_event_type_culture),
                getString(R.string.kid_event_type_holiday),
                getString(R.string.kid_event_type_other)
        };
        int[] values = new int[]{
                KidEvent.TYPE_SCHOOL, KidEvent.TYPE_SPORT, KidEvent.TYPE_HEALTH,
                KidEvent.TYPE_CULTURE, KidEvent.TYPE_HOLIDAY, KidEvent.TYPE_OTHER
        };
        new AlertDialog.Builder(this, DialogThemes.LEA)
                .setTitle(R.string.kid_event_type_label)
                .setItems(items, (d, which) -> {
                    type = values[which];
                    refreshButtons();
                })
                .show();
    }

    private void pickStart() {
        pickDateTime(startDate, allDay.isChecked(), picked -> {
            startDate = picked;
            refreshButtons();
        });
    }

    private void pickEnd() {
        long seed = endDate > 0L ? endDate : (startDate > 0L ? startDate : System.currentTimeMillis());
        pickDateTime(seed, allDay.isChecked(), picked -> {
            endDate = picked;
            refreshButtons();
        });
    }

    private void pickNotify() {
        long seed = notifyAt > 0L
                ? notifyAt
                : (startDate > 0L ? startDate - 24L * 60 * 60 * 1000 : System.currentTimeMillis());
        pickDateTime(seed, false, picked -> {
            notifyAt = picked;
            refreshButtons();
        });
    }

    private interface DateTimeCallback { void onPicked(long ts); }

    // v1.1.1 — Picker bez theme overlay (rovnako ako TaskEditorActivity): dedí tmavú
    // Theme.Material3.Dark z aktivity. ThemeOverlay.Noteiqa.Dialog je overlay pre
    // MaterialAlertDialog, nie plná téma pre framework DatePicker → dával svetlý podklad.
    private void pickDateTime(long seed, boolean skipTime, DateTimeCallback cb) {
        Calendar c = Calendar.getInstance();
        if (seed > 0L) c.setTimeInMillis(seed);
        new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    Calendar picked = Calendar.getInstance();
                    picked.set(year, month, dayOfMonth,
                            skipTime ? 0 : 9, 0, 0);
                    picked.set(Calendar.MILLISECOND, 0);
                    if (skipTime) {
                        cb.onPicked(picked.getTimeInMillis());
                    } else {
                        new TimePickerDialog(this,
                                (v, h, m) -> {
                                    picked.set(Calendar.HOUR_OF_DAY, h);
                                    picked.set(Calendar.MINUTE, m);
                                    cb.onPicked(picked.getTimeInMillis());
                                }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show();
                    }
                },
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void save() {
        String t = title.getText() != null ? title.getText().toString().trim() : "";
        if (TextUtils.isEmpty(t)) {
            Toast.makeText(this, "Zadaj názov udalosti", Toast.LENGTH_SHORT).show();
            return;
        }
        if (startDate <= 0L) {
            Toast.makeText(this, "Zadaj začiatok udalosti", Toast.LENGTH_SHORT).show();
            return;
        }

        if (editing == null) editing = new KidEvent();
        editing.kidId = selectedKidId;
        editing.title = t;
        editing.type = type;
        editing.startDate = startDate;
        editing.endDate = endDate;
        editing.allDay = allDay.isChecked();
        editing.location = strOrNull(location);
        editing.note = strOrNull(note);
        editing.notifyAt = notifyAt;

        repo.saveEvent(editing, id -> runOnUiThread(() -> {
            Toast.makeText(this, R.string.kid_event_saved, Toast.LENGTH_SHORT).show();
            finish();
        }));
    }

    private String strOrNull(EditText field) {
        if (field.getText() == null) return null;
        String s = field.getText().toString().trim();
        return s.isEmpty() ? null : s;
    }

    private void deleteConfirm() {
        if (editing == null || editing.id == 0L) { finish(); return; }
        new AlertDialog.Builder(this, DialogThemes.LEA)
                .setTitle(R.string.kid_delete_confirm_title)
                .setMessage(R.string.kid_delete_confirm_message)
                .setPositiveButton("Áno", (d, w) -> {
                    repo.deleteEvent(editing.id);
                    Toast.makeText(this, R.string.kid_event_deleted, Toast.LENGTH_SHORT).show();
                    finish();
                })
                .setNegativeButton("Nie", null)
                .show();
    }
}
