package sk.aetheriqa.noteiqa.ui.todo;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Calendar;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.data.repository.TaskRepository;

/**
 * TasksFragment v3 – long-press na úlohe otvára kontextové menu so 5 akciami.
 *
 * Konfirmácia archivácie je v TaskContextMenu.confirmAndArchive — používa sa
 * z troch miest: checkbox toggle, kontext menu Vymazať, detail view Vymazať.
 */
public class TasksFragment extends Fragment {

    private TaskRepository repo;
    private TasksAdapter adapter;
    private RecyclerView list;
    private View emptyState;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_tasks, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        repo = TaskRepository.getInstance(requireContext().getApplicationContext());

        list = view.findViewById(R.id.tasks_list);
        emptyState = view.findViewById(R.id.tasks_empty_state);

        adapter = new TasksAdapter(new TasksAdapter.OnTaskInteractionListener() {
            @Override
            public void onTaskClick(Task task) {
                startActivity(TaskDetailActivity.newIntent(requireContext(), task.id));
            }

            @Override
            public void onTaskCheckRequested(Task task) {
                TaskContextMenu.confirmAndArchive(requireContext(), repo, task);
            }

            @Override
            public void onTaskLongPressed(Task task) {
                TaskContextMenu.show(requireContext(), task,
                        t -> showMoveDialog(t));
            }

            @Override
            public void onTaskMoveRequested(Task task, int direction) {
                java.util.List<Long> newOrder = adapter.computeReorderedBucket(task, direction);
                if (newOrder != null && !newOrder.isEmpty()) {
                    repo.reorderTasks(newOrder);
                }
            }
        });

        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        list.setAdapter(adapter);

        repo.observeCategories().observe(getViewLifecycleOwner(), adapter::setCategories);

        // v1.1.0 — Kombinuj Tasks a KidEvents cez MediatorLiveData
        sk.aetheriqa.noteiqa.data.repository.KidRepository kidRepo =
                sk.aetheriqa.noteiqa.data.repository.KidRepository.getInstance(requireContext());

        androidx.lifecycle.MediatorLiveData<Object> combined = new androidx.lifecycle.MediatorLiveData<>();
        final java.util.List<sk.aetheriqa.noteiqa.data.entity.Task>[] tasksHolder =
                new java.util.List[]{java.util.Collections.emptyList()};
        final java.util.List<sk.aetheriqa.noteiqa.data.entity.KidEvent>[] eventsHolder =
                new java.util.List[]{java.util.Collections.emptyList()};
        final java.util.List<sk.aetheriqa.noteiqa.data.entity.Kid>[] kidsHolder =
                new java.util.List[]{java.util.Collections.emptyList()};

        combined.addSource(repo.observeActive(), tasks -> {
            tasksHolder[0] = tasks != null ? tasks : java.util.Collections.emptyList();
            combined.setValue(new Object());
        });
        combined.addSource(kidRepo.observeEvents(), events -> {
            eventsHolder[0] = events != null ? events : java.util.Collections.emptyList();
            combined.setValue(new Object());
        });
        combined.addSource(kidRepo.observeKids(), kids -> {
            kidsHolder[0] = kids != null ? kids : java.util.Collections.emptyList();
            combined.setValue(new Object());
        });

        combined.observe(getViewLifecycleOwner(), ignored -> {
            java.util.List<sk.aetheriqa.noteiqa.data.entity.Task> tasks = tasksHolder[0];
            java.util.List<KidEventTaskLike> kidLikes = new java.util.ArrayList<>();

            for (sk.aetheriqa.noteiqa.data.entity.KidEvent e : eventsHolder[0]) {
                // Zobrazujeme len upcoming (od dneška ďalej) — minulosť ide preč
                if (e.startDate < System.currentTimeMillis() - 24L * 60 * 60 * 1000) continue;
                sk.aetheriqa.noteiqa.data.entity.Kid kid = null;
                for (sk.aetheriqa.noteiqa.data.entity.Kid k : kidsHolder[0]) {
                    if (k.id == e.kidId) { kid = k; break; }
                }
                kidLikes.add(new KidEventTaskLike(e, kid));
            }

            adapter.submitWithKidEvents(tasks, kidLikes);

            boolean empty = (tasks == null || tasks.isEmpty()) && kidLikes.isEmpty();
            emptyState.setVisibility(empty ? View.VISIBLE : View.GONE);
            list.setVisibility(empty ? View.GONE : View.VISIBLE);
        });

        FloatingActionButton fab = view.findViewById(R.id.fab_new_task);
        fab.setOnClickListener(v -> {
            startActivity(TaskEditorActivity.newIntent(requireContext(), 0L));
        });
    }

    /**
     * Zobrazí Move dialóg – vyber medzi zmenou dátumu alebo času. Po výbere
     * uloží zmenu cez repo.save() — LiveData refreshne adapter.
     */
    private void showMoveDialog(Task task) {
        CharSequence[] opts = new CharSequence[]{
                getString(R.string.move_change_date),
                getString(R.string.move_change_time)
        };
        new AlertDialog.Builder(requireContext(),
                sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(R.string.move_task_title)
                .setItems(opts, (d, which) -> {
                    if (which == 0) showDatePickerForTask(task);
                    else showTimePickerForTask(task);
                })
                .show();
    }

    private void showDatePickerForTask(Task task) {
        Calendar cal = Calendar.getInstance();
        if (task.dueDate != null && task.dueDate != 0L) cal.setTimeInMillis(task.dueDate);

        new DatePickerDialog(requireContext(),
                (view, year, month, dayOfMonth) -> {
                    Calendar c = Calendar.getInstance();
                    c.set(year, month, dayOfMonth, 0, 0, 0);
                    c.set(Calendar.MILLISECOND, 0);
                    task.dueDate = c.getTimeInMillis();
                    repo.save(task, null);
                    Toast.makeText(requireContext(), R.string.task_saved_toast, Toast.LENGTH_SHORT).show();
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void showTimePickerForTask(Task task) {
        int h = 9, m = 0;
        if (task.dueTimeMinutes != null) {
            h = task.dueTimeMinutes / 60;
            m = task.dueTimeMinutes % 60;
        }
        new TimePickerDialog(requireContext(),
                (view, hourOfDay, minute) -> {
                    task.dueTimeMinutes = hourOfDay * 60 + minute;
                    repo.save(task, null);
                    Toast.makeText(requireContext(), R.string.task_saved_toast, Toast.LENGTH_SHORT).show();
                },
                h, m, true).show();
    }
}
