package sk.aetheriqa.noteiqa.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import sk.aetheriqa.noteiqa.data.entity.Task;

@Dao
public interface TaskDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(Task task);

    @Update
    int update(Task task);

    @Delete
    int delete(Task task);

    /**
     * ŽIVÉ úlohy (archivedAt == 0). Sortovanie:
     *  1. dueDate ASC (NULL na koniec)
     *  2. v rámci dňa po dueTimeMinutes ASC (NULL na koniec)
     *  3. createdAt ASC pri zhode
     *
     * Bucket sa odvodí v UI z dueDate.
     */
    @Query("SELECT * FROM tasks WHERE archivedAt = 0 " +
           "ORDER BY " +
           "  CASE WHEN dueDate IS NULL THEN 1 ELSE 0 END, " +
           "  dueDate ASC, " +
           "  CASE WHEN dueTimeMinutes IS NULL THEN 1 ELSE 0 END, " +
           "  dueTimeMinutes ASC, " +
           "  createdAt ASC")
    LiveData<List<Task>> observeActive();

    /** Archivované – zoradené od najnovšie archivovanej. */
    @Query("SELECT * FROM tasks WHERE archivedAt > 0 ORDER BY archivedAt DESC")
    LiveData<List<Task>> observeArchived();

    @Query("SELECT * FROM tasks WHERE id = :id")
    LiveData<Task> observeById(long id);

    @Query("SELECT * FROM tasks WHERE id = :id")
    Task getById(long id);

    @Query("UPDATE tasks SET archivedAt = :now, completed = 1, completedAt = :now, updatedAt = :now " +
           "WHERE id = :id")
    int archive(long id, long now);

    @Query("UPDATE tasks SET archivedAt = 0, completed = 0, completedAt = 0, updatedAt = :now " +
           "WHERE id = :id")
    int unarchive(long id, long now);

    @Query("UPDATE tasks SET completed = :completed, completedAt = :ts, updatedAt = :ts " +
           "WHERE id = :id")
    int setCompleted(long id, boolean completed, long ts);

    @Query("SELECT * FROM tasks WHERE archivedAt = 0 AND completed = 0 " +
           "AND categoryId = :categoryId " +
           "ORDER BY updatedAt DESC LIMIT 1")
    Task getLastActiveByCategory(long categoryId);

    @Query("SELECT COUNT(*) FROM tasks")
    int count();

    @Query("SELECT COUNT(*) FROM tasks WHERE archivedAt > 0")
    LiveData<Integer> observeArchivedCount();

    /**
     * Počet aktívnych úloh, ktoré majú dueDate v rozmedzí [fromMillis, toMillis).
     * Pre dashboard "Dnešné úlohy: N" pošlú sa medze pre dnešok 00:00 → zajtra 00:00.
     */
    @Query("SELECT COUNT(*) FROM tasks WHERE archivedAt = 0 " +
           "AND dueDate IS NOT NULL " +
           "AND dueDate >= :fromMillis AND dueDate < :toMillis")
    LiveData<Integer> observeCountInRange(long fromMillis, long toMillis);

    /** Pre BootReceiver fáza 2 (push pripomienky). */
    @Query("SELECT * FROM tasks WHERE archivedAt = 0 AND reminderAt > :now")
    List<Task> getWithRemindersAfter(long now);

    /** Pre Export/Backup — sync read všetkých záznamov. */
    @Query("SELECT * FROM tasks")
    List<Task> getAllSync();

    /** v0.5.4 — sync read pre cleanup operácie. */
    @Query("SELECT * FROM tasks WHERE archivedAt > 0")
    List<Task> getArchivedSync();

    /** v0.5.4 — permanentne zmaže všetky archivované úlohy (a kaskádou ich subtasks). */
    @Query("DELETE FROM tasks WHERE archivedAt > 0")
    int deleteAllArchived();

    /** v1.0.0 — počet hotových úloh v zadanom časovom rozsahu (napr. tento týždeň). */
    @Query("SELECT COUNT(*) FROM tasks WHERE completed = 1 " +
           "AND completedAt >= :fromMillis AND completedAt < :toMillis")
    int countCompletedInRange(long fromMillis, long toMillis);

    /** v1.0.0 — všetky completed tasks v rozsahu pre rozbor po dňoch. */
    @Query("SELECT * FROM tasks WHERE completed = 1 " +
           "AND completedAt >= :fromMillis AND completedAt < :toMillis")
    List<Task> getCompletedInRange(long fromMillis, long toMillis);
}
