package sk.aetheriqa.noteiqa.data.repository;

import android.content.Context;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import sk.aetheriqa.noteiqa.data.db.AppDatabase;
import sk.aetheriqa.noteiqa.data.db.dao.ChecklistDao;
import sk.aetheriqa.noteiqa.data.db.dao.NoteDao;
import sk.aetheriqa.noteiqa.data.entity.ChecklistItem;
import sk.aetheriqa.noteiqa.data.entity.Note;
import sk.aetheriqa.noteiqa.util.DiacriticsUtils;

/**
 * NoteRepository – business logika nad NoteDao.
 *
 * Centralizuje:
 *  - Predprípravu searchIndex pri save (DiacriticsUtils)
 *  - Spúšťanie DB operácií na background thread (Executor)
 *  - Pre ViewModely vystavuje LiveData
 *
 * ViewModel nikdy nevolá DAO priamo – ide cez Repository.
 */
public class NoteRepository {

    private static volatile NoteRepository INSTANCE;

    private final NoteDao noteDao;
    private final ChecklistDao checklistDao;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private NoteRepository(Context ctx) {
        AppDatabase db = AppDatabase.getInstance(ctx);
        this.noteDao = db.noteDao();
        this.checklistDao = db.checklistDao();
    }

    public static NoteRepository getInstance(Context ctx) {
        if (INSTANCE == null) {
            synchronized (NoteRepository.class) {
                if (INSTANCE == null) {
                    INSTANCE = new NoteRepository(ctx.getApplicationContext());
                }
            }
        }
        return INSTANCE;
    }

    // ===== Observable streams =====

    public LiveData<List<Note>> observeActive() {
        return noteDao.observeActive();
    }

    public LiveData<List<Note>> observeArchived() {
        return noteDao.observeArchived();
    }

    public LiveData<List<Note>> observeTrashed() {
        return noteDao.observeTrashed();
    }

    public LiveData<Note> observeById(long id) {
        return noteDao.observeById(id);
    }

    public LiveData<List<Note>> search(String userQuery) {
        String normalized = DiacriticsUtils.stripDiacritics(userQuery);
        if (normalized != null) normalized = normalized.toLowerCase();
        return noteDao.search(normalized == null ? "" : normalized);
    }

    // ===== Mutations (background) =====

    public void save(Note note, OnSavedCallback cb) {
        executor.execute(() -> {
            long now = System.currentTimeMillis();
            if (note.createdAt == 0L) note.createdAt = now;
            note.updatedAt = now;
            note.searchIndex = DiacriticsUtils.buildSearchIndex(note.title, note.body);

            long id = note.id == 0 ? noteDao.insert(note) : (noteDao.update(note) > 0 ? note.id : -1);
            if (cb != null) cb.onSaved(id);
        });
    }

    public void archive(long noteId) {
        executor.execute(() -> noteDao.archive(noteId, System.currentTimeMillis()));
    }

    public void unarchive(long noteId) {
        executor.execute(() -> noteDao.unarchive(noteId, System.currentTimeMillis()));
    }

    public void trash(long noteId) {
        executor.execute(() -> noteDao.trash(noteId, System.currentTimeMillis()));
    }

    public void restoreFromTrash(long noteId) {
        executor.execute(() -> noteDao.restoreFromTrash(noteId));
    }

    public void setPinned(long noteId, boolean pinned) {
        executor.execute(() -> noteDao.setPinned(noteId, pinned));
    }

    /** Volá sa z WorkManager-a raz denne. */
    public void purgeOldTrashed() {
        executor.execute(() -> {
            long cutoff = System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000;
            noteDao.purgeOldTrashed(cutoff);
        });
    }

    // ===== Checklist API =====

    public LiveData<List<ChecklistItem>> observeChecklistItems(long noteId) {
        return checklistDao.observeForNote(noteId);
    }

    public List<ChecklistItem> getChecklistItemsSync(long noteId) {
        return checklistDao.getForNote(noteId);
    }

    /** Synchronizuje zoznam checklistu s DB (DELETE + INSERT). */
    public void saveChecklistItems(long noteId, List<ChecklistItem> items) {
        executor.execute(() -> {
            checklistDao.deleteAllForNote(noteId);
            long now = System.currentTimeMillis();
            for (int i = 0; i < items.size(); i++) {
                ChecklistItem item = items.get(i);
                item.noteId = noteId;
                item.sortOrder = i;
                if (item.createdAt == 0L) item.createdAt = now;
                item.updatedAt = now;
            }
            checklistDao.insertAll(items);
        });
    }

    public void toggleChecklistItem(long itemId, boolean checked) {
        executor.execute(() -> checklistDao.setChecked(itemId, checked, System.currentTimeMillis()));
    }

    /**
     * v0.5.4 — permanentne zmaže VŠETKY archivované poznámky.
     * ChecklistItemy + tag väzby sa mažú kaskádou cez FK ON DELETE CASCADE.
     */
    public void deleteAllArchived(OnCountCallback cb) {
        executor.execute(() -> {
            int count = noteDao.deleteAllArchived();
            if (cb != null) cb.onCount(count);
        });
    }

    public interface OnSavedCallback {
        void onSaved(long id);
    }

    /** Callback pre operácie ktoré reportujú počet zasiahnutých záznamov. */
    public interface OnCountCallback {
        void onCount(int count);
    }
}
