package sk.aetheriqa.noteiqa.ui.kids;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Observer;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.tabs.TabLayout;

import java.util.List;

import sk.aetheriqa.noteiqa.MainActivity;
import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;

/**
 * KidsFragment – hostiteľ Deti modulu.
 *
 * Layout:
 *   [Header "Deti"]
 *   [Segment toggle: Alex | Gabika | Oboje]
 *   [TabLayout: Poplatky a platby | Kalendár udalostí]
 *   [FrameLayout kids_content — sub-fragment (Payments alebo Events)]
 *   [FAB kids_fab_add — pridá platbu alebo udalosť podľa aktuálneho tabu]
 *
 * Prvý button je vždy Alex (id 1), druhý Gabika (id 2), tretí "Oboje" (kidId = 0).
 * Farby chipov sú dynamické — pri select sa použije farba dieťaťa (backgroundTint).
 */
public class KidsFragment extends Fragment {

    /** Aktuálne vybrané kidId. 0 = Oboje. */
    private long selectedKidId = KidRepository.KID_ID_ALL;

    /** Aktuálny sub-tab: 0 = Platby, 1 = Kalendár. */
    private int selectedTab = 0;

    private KidRepository repo;
    private MaterialButton btnA, btnB, btnAll;
    private MaterialButtonToggleGroup filterGroup;
    private TabLayout tabs;
    private Kid kidA, kidB;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_kids, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        repo = KidRepository.getInstance(requireContext());

        filterGroup = view.findViewById(R.id.kids_filter_group);
        btnA = view.findViewById(R.id.kids_filter_a);
        btnB = view.findViewById(R.id.kids_filter_b);
        btnAll = view.findViewById(R.id.kids_filter_all);
        tabs = view.findViewById(R.id.kids_tabs);

        // Observe deti — naplň prvé 2 buttony menami; ak sa Alex/Gabika ešte nezaseedovali,
        // buttony zostanú s "..." a čakajú na dáta.
        repo.observeKids().observe(getViewLifecycleOwner(), new Observer<List<Kid>>() {
            @Override
            public void onChanged(List<Kid> kids) {
                if (kids == null || kids.size() < 2) {
                    btnA.setText("…");
                    btnB.setText("…");
                    return;
                }
                kidA = kids.get(0);
                kidB = kids.get(1);
                btnA.setText(kidA.name);
                btnB.setText(kidB.name);

                // Farebný stroke podľa dieťaťa
                try {
                    btnA.setStrokeColor(android.content.res.ColorStateList
                            .valueOf(Color.parseColor(kidA.colorHex)));
                    btnB.setStrokeColor(android.content.res.ColorStateList
                            .valueOf(Color.parseColor(kidB.colorHex)));
                } catch (IllegalArgumentException ignored) {}

                if (filterGroup.getCheckedButtonId() == View.NO_ID) {
                    filterGroup.check(R.id.kids_filter_all);
                }
            }
        });

        filterGroup.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (!isChecked) return;
            if (checkedId == R.id.kids_filter_a && kidA != null) {
                selectedKidId = kidA.id;
            } else if (checkedId == R.id.kids_filter_b && kidB != null) {
                selectedKidId = kidB.id;
            } else {
                selectedKidId = KidRepository.KID_ID_ALL;
            }
            refreshSubFragment();
        });

        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override public void onTabSelected(TabLayout.Tab tab) {
                selectedTab = tab.getPosition();
                refreshSubFragment();
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });

        ImageView fab = view.findViewById(R.id.kids_fab_add);
        fab.setOnClickListener(v -> onFabClick());

        // Handle deep-link (notifikácia z KidReminder)
        handleIncomingDeepLink();

        // Initial state
        refreshSubFragment();
    }

    private void refreshSubFragment() {
        Fragment target;
        if (selectedTab == 0) {
            target = KidPaymentsSubFragment.newInstance(selectedKidId);
        } else {
            target = KidEventsSubFragment.newInstance(selectedKidId);
        }
        FragmentTransaction tx = getChildFragmentManager().beginTransaction();
        tx.replace(R.id.kids_content, target);
        tx.commitNowAllowingStateLoss();
    }

    private void onFabClick() {
        long targetKidId = selectedKidId != KidRepository.KID_ID_ALL
                ? selectedKidId
                : (kidA != null ? kidA.id : 0L);

        Intent intent;
        if (selectedTab == 0) {
            intent = KidPaymentEditorActivity.newIntent(requireContext(), 0L, targetKidId);
        } else {
            intent = KidEventEditorActivity.newIntent(requireContext(), 0L, targetKidId);
        }
        startActivity(intent);
    }

    private void handleIncomingDeepLink() {
        Intent intent = requireActivity().getIntent();
        if (intent == null) return;
        if (!MainActivity.ACTION_OPEN_KIDS.equals(intent.getAction())) return;

        long paymentId = intent.getLongExtra(MainActivity.EXTRA_OPEN_PAYMENT_ID, 0L);
        long eventId = intent.getLongExtra(MainActivity.EXTRA_OPEN_EVENT_ID, 0L);

        if (paymentId > 0L) {
            // Otvor Platby tab a zobraz context dialog s tou konkrétnou platbou
            tabs.selectTab(tabs.getTabAt(0));
            new android.os.Handler().postDelayed(() -> {
                if (isAdded()) {
                    KidPaymentContextDialog.show(requireContext(), repo, paymentId);
                }
            }, 250);
            intent.removeExtra(MainActivity.EXTRA_OPEN_PAYMENT_ID);
        } else if (eventId > 0L) {
            tabs.selectTab(tabs.getTabAt(1));
            intent.removeExtra(MainActivity.EXTRA_OPEN_EVENT_ID);
        }
    }
}
