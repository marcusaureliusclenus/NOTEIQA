package sk.aetheriqa.noteiqa.ui.chudnutie;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.google.android.material.button.MaterialButtonToggleGroup;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.WeightEntry;
import sk.aetheriqa.noteiqa.data.repository.WeightRepository;
import sk.aetheriqa.noteiqa.util.DateUtils;
import sk.aetheriqa.noteiqa.util.MoodFlags;

/**
 * ChudnutieFragment v3 (v0.4.0) – kompaktný layout:
 *  - Vľavo: výrazné kg + 3 riadky meta (deň/dátum/čas)
 *  - Vpravo: 7 mood checkboxov (menzes, po cvičení, ...)
 *  - Pod nimi: tlačidlo Zaznamenať
 *  - Pod ním Min/Priemer/Max
 *  - HNEĎ pod tým Posledné záznamy
 *  - Až úplne dole graf
 *
 * Meta sa autoupdatuje každú minútu (live tikajúce hodiny).
 */
public class ChudnutieFragment extends Fragment {

    private static final int HISTORY_LIMIT = 10;

    private WeightRepository repo;
    private DateUtils.Period currentPeriod = DateUtils.Period.DAYS_30;

    private EditText inputWeight;
    private TextView quickMetaDay, quickMetaDate, quickMetaTime;
    private TextView statMin, statAvg, statMax;
    private LineChart chart;
    private MaterialButtonToggleGroup periodToggle;
    private RecyclerView historyList;
    private TextView historyEmpty;
    private WeightHistoryAdapter historyAdapter;

    private final CheckBox[] moodBoxes = new CheckBox[7];

    /** Ticker pre auto-refresh meta každú minútu. */
    private final Handler tickHandler = new Handler(Looper.getMainLooper());
    private final Runnable tickRunnable = new Runnable() {
        @Override
        public void run() {
            updateQuickMeta();
            tickHandler.postDelayed(this, 60_000);
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_chudnutie, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        repo = WeightRepository.getInstance(requireContext().getApplicationContext());

        inputWeight = view.findViewById(R.id.input_weight);
        quickMetaDay = view.findViewById(R.id.quick_meta_day);
        quickMetaDate = view.findViewById(R.id.quick_meta_date);
        quickMetaTime = view.findViewById(R.id.quick_meta_time);
        statMin = view.findViewById(R.id.stat_min);
        statAvg = view.findViewById(R.id.stat_avg);
        statMax = view.findViewById(R.id.stat_max);
        chart = view.findViewById(R.id.chart);
        periodToggle = view.findViewById(R.id.period_toggle);
        historyList = view.findViewById(R.id.history_list);
        historyEmpty = view.findViewById(R.id.history_empty);

        // Mood checkboxes — pole v poradí MoodFlags.ALL
        moodBoxes[0] = view.findViewById(R.id.mood_menzes);
        moodBoxes[1] = view.findViewById(R.id.mood_po_cviceni);
        moodBoxes[2] = view.findViewById(R.id.mood_malo_spanku);
        moodBoxes[3] = view.findViewById(R.id.mood_vcera_prejedena);
        moodBoxes[4] = view.findViewById(R.id.mood_vcera_alkohol);
        moodBoxes[5] = view.findViewById(R.id.mood_zapecena);
        moodBoxes[6] = view.findViewById(R.id.mood_malo_vody);

        view.findViewById(R.id.btn_log_weight).setOnClickListener(v -> onLogWeight());

        periodToggle.check(R.id.period_30d);
        periodToggle.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (!isChecked) return;
            if (checkedId == R.id.period_7d) currentPeriod = DateUtils.Period.DAYS_7;
            else if (checkedId == R.id.period_30d) currentPeriod = DateUtils.Period.DAYS_30;
            else if (checkedId == R.id.period_90d) currentPeriod = DateUtils.Period.DAYS_90;
            else if (checkedId == R.id.period_1y) currentPeriod = DateUtils.Period.YEAR_1;
            reloadObservers();
        });

        historyAdapter = new WeightHistoryAdapter(this::onWeightLongClick);
        historyList.setLayoutManager(new LinearLayoutManager(requireContext()));
        historyList.setAdapter(historyAdapter);

        repo.observeLastN(HISTORY_LIMIT).observe(getViewLifecycleOwner(), entries -> {
            historyAdapter.submitList(entries);
            boolean empty = entries == null || entries.isEmpty();
            historyEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
            historyList.setVisibility(empty ? View.GONE : View.VISIBLE);
        });

        setupChart();
        reloadObservers();
        updateQuickMeta();
    }

    @Override
    public void onResume() {
        super.onResume();
        tickHandler.post(tickRunnable);
    }

    @Override
    public void onPause() {
        super.onPause();
        tickHandler.removeCallbacks(tickRunnable);
    }

    /** 3-riadkový meta blok pod kg vstupom. */
    private void updateQuickMeta() {
        long now = System.currentTimeMillis();
        // Slovenský deň v týždni v plnom tvare ("nedeľa", "pondelok" ...)
        int dow = DateUtils.isoDayOfWeek(now);
        quickMetaDay.setText(slovakDayLong(dow));

        SimpleDateFormat dateFmt = new SimpleDateFormat("dd.MM.yy", new Locale("sk", "SK"));
        quickMetaDate.setText(dateFmt.format(new Date(now)));

        SimpleDateFormat timeFmt = new SimpleDateFormat("HH:mm", new Locale("sk", "SK"));
        quickMetaTime.setText(timeFmt.format(new Date(now)));
    }

    /** Slovenský dlhý názov dňa. */
    private String slovakDayLong(int isoDay) {
        switch (isoDay) {
            case 1: return "pondelok";
            case 2: return "utorok";
            case 3: return "streda";
            case 4: return "štvrtok";
            case 5: return "piatok";
            case 6: return "sobota";
            case 7: return "nedeľa";
            default: return "";
        }
    }

    private void reloadObservers() {
        repo.observeForPeriod(currentPeriod).observe(getViewLifecycleOwner(), this::renderChart);
        repo.observeMin(currentPeriod).observe(getViewLifecycleOwner(), v -> statMin.setText(formatKg(v)));
        repo.observeAvg(currentPeriod).observe(getViewLifecycleOwner(), v -> statAvg.setText(formatKg(v)));
        repo.observeMax(currentPeriod).observe(getViewLifecycleOwner(), v -> statMax.setText(formatKg(v)));
    }

    private String formatKg(@Nullable Double v) {
        if (v == null) return "—";
        return String.format(Locale.getDefault(), "%.1f", v).replace('.', ',');
    }

    private void onLogWeight() {
        String raw = inputWeight.getText().toString().trim().replace(',', '.');
        if (TextUtils.isEmpty(raw)) {
            Toast.makeText(requireContext(), R.string.weight_invalid, Toast.LENGTH_SHORT).show();
            return;
        }
        double kg;
        try {
            kg = Double.parseDouble(raw);
        } catch (NumberFormatException e) {
            Toast.makeText(requireContext(), R.string.weight_invalid, Toast.LENGTH_SHORT).show();
            return;
        }
        if (kg <= 0 || kg > 500) {
            Toast.makeText(requireContext(), R.string.weight_invalid, Toast.LENGTH_SHORT).show();
            return;
        }

        // Zhromaždi mood flagy
        int flags = 0;
        for (int i = 0; i < moodBoxes.length; i++) {
            if (moodBoxes[i] != null && moodBoxes[i].isChecked()) {
                flags = MoodFlags.set(flags, MoodFlags.ALL[i], true);
            }
        }

        repo.logWeight(kg, null, flags);

        // Reset polí
        inputWeight.setText("");
        for (CheckBox cb : moodBoxes) if (cb != null) cb.setChecked(false);
        inputWeight.clearFocus();
        updateQuickMeta();

        Toast.makeText(requireContext(), R.string.weight_saved, Toast.LENGTH_SHORT).show();
    }

    private void onWeightLongClick(WeightEntry entry) {
        new AlertDialog.Builder(requireContext(),
                sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(DateUtils.formatWeightTimestamp(entry.measuredAt))
                .setMessage(formatKg(entry.kg) + " kg")
                .setPositiveButton(R.string.action_delete, (d, w) -> repo.delete(entry))
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    // ===== Chart =====

    private void setupChart() {
        chart.getDescription().setEnabled(false);
        chart.setNoDataText("");
        chart.setTouchEnabled(true);
        chart.setDragEnabled(true);
        chart.setScaleEnabled(false);
        chart.setPinchZoom(false);
        chart.setDoubleTapToZoomEnabled(false);
        chart.setDrawGridBackground(false);
        chart.setExtraBottomOffset(8f);

        int gridColor = ContextCompat.getColor(requireContext(), R.color.chart_grid);
        int textCol = ContextCompat.getColor(requireContext(), R.color.text_secondary);

        XAxis x = chart.getXAxis();
        x.setPosition(XAxis.XAxisPosition.BOTTOM);
        x.setDrawGridLines(false);
        x.setDrawAxisLine(false);
        x.setTextColor(textCol);
        x.setTextSize(10f);
        x.setGranularity(1f);
        x.setValueFormatter(new ValueFormatter() {
            private final SimpleDateFormat fmt = new SimpleDateFormat("d.M.", new Locale("sk", "SK"));
            @Override
            public String getFormattedValue(float value) {
                return fmt.format(new Date((long) value));
            }
        });

        YAxis yLeft = chart.getAxisLeft();
        yLeft.setDrawAxisLine(false);
        yLeft.setGridColor(gridColor);
        yLeft.setGridLineWidth(0.5f);
        yLeft.setTextColor(textCol);
        yLeft.setTextSize(10f);

        chart.getAxisRight().setEnabled(false);

        Legend legend = chart.getLegend();
        legend.setEnabled(false);
    }

    private void renderChart(List<WeightEntry> entries) {
        if (entries == null || entries.isEmpty()) {
            chart.clear();
            chart.invalidate();
            return;
        }

        List<Entry> points = new ArrayList<>(entries.size());
        for (WeightEntry e : entries) {
            points.add(new Entry((float) e.measuredAt, (float) e.kg));
        }

        int gold = ContextCompat.getColor(requireContext(), R.color.lea_gold);

        LineDataSet set = new LineDataSet(points, "kg");
        set.setColor(gold);
        set.setLineWidth(2f);
        set.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set.setCubicIntensity(0.18f);
        set.setDrawCircles(true);
        set.setCircleColor(gold);
        set.setCircleRadius(3.5f);
        set.setCircleHoleRadius(1.5f);
        set.setCircleHoleColor(Color.parseColor("#0A0A0A"));
        set.setDrawValues(false);
        set.setDrawFilled(true);
        set.setFillColor(gold);
        set.setFillAlpha(60);
        set.setHighlightEnabled(true);
        set.setHighLightColor(gold);
        set.setHighlightLineWidth(0.8f);
        set.setDrawHorizontalHighlightIndicator(false);

        chart.setData(new LineData(set));
        chart.invalidate();
    }
}
