package sk.aetheriqa.noteiqa.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import sk.aetheriqa.noteiqa.data.entity.NoteTagCrossRef;
import sk.aetheriqa.noteiqa.data.entity.Tag;

@Dao
public interface TagDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insert(Tag tag);

    @Update
    int update(Tag tag);

    @Delete
    int delete(Tag tag);

    @Query("SELECT * FROM tags ORDER BY sortOrder ASC, name ASC")
    LiveData<List<Tag>> observeAll();

    @Query("SELECT * FROM tags WHERE id = :id")
    Tag getById(long id);

    @Query("SELECT * FROM tags WHERE name = :name LIMIT 1")
    Tag findByName(String name);

    /** Vráti štítky priradené ku konkrétnej poznámke. */
    @Query("SELECT t.* FROM tags t " +
           "INNER JOIN note_tags nt ON nt.tagId = t.id " +
           "WHERE nt.noteId = :noteId " +
           "ORDER BY t.sortOrder ASC, t.name ASC")
    LiveData<List<Tag>> observeForNote(long noteId);

    // === M:N junction operations ===

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void linkNoteTag(NoteTagCrossRef ref);

    @Query("DELETE FROM note_tags WHERE noteId = :noteId AND tagId = :tagId")
    void unlinkNoteTag(long noteId, long tagId);

    @Query("DELETE FROM note_tags WHERE noteId = :noteId")
    void clearTagsForNote(long noteId);

    /** Pre Export/Backup — sync read všetkých záznamov. */
    @Query("SELECT * FROM tags")
    List<Tag> getAllSync();

    /** Pre Export/Backup — sync read všetkých note↔tag väzieb. */
    @Query("SELECT * FROM note_tags")
    List<NoteTagCrossRef> getAllNoteTagsSync();
}
