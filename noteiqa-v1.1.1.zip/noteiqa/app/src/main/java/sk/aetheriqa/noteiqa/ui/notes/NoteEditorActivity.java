package sk.aetheriqa.noteiqa.ui.notes;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;

import com.google.android.flexbox.FlexboxLayout;
import com.google.android.material.appbar.MaterialToolbar;

import java.io.File;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Note;
import sk.aetheriqa.noteiqa.data.repository.NoteRepository;
import sk.aetheriqa.noteiqa.util.ImageStorage;

/**
 * NoteEditorActivity v2 – pridáva pripájanie obrázka + pill action buttons.
 *
 * Pill buttons (LEA štýl, transparent + 1dp gold stroke):
 *   - Pripojiť obrázok / Vymeniť obrázok / Odstrániť obrázok (kontextové)
 *   - Zdieľať poznámku
 *   - Vymazať (s confirm "Vymazať? Áno/Nie" → trash)
 *
 * Image picker: GetContent kontrakt → kópia do internej zložky cez ImageStorage.
 */
public class NoteEditorActivity extends AppCompatActivity {

    public static final String EXTRA_NOTE_ID = "noteId";
    private static final long NEW_NOTE_ID = 0L;

    private NoteRepository repo;
    private long noteId = NEW_NOTE_ID;
    private Note editedNote;
    private boolean fieldsInitialized = false;
    private boolean changedDueToUserEdit = false;

    private EditText editTitle;
    private EditText editBody;
    private ImageView imagePreview;
    private FlexboxLayout actions;

    /** Image picker — GetContent vráti gallery Uri. */
    private final ActivityResultLauncher<String> pickImage =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) onImagePicked(uri);
            });

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_editor);

        repo = NoteRepository.getInstance(getApplicationContext());

        editTitle = findViewById(R.id.editor_title);
        editBody = findViewById(R.id.editor_body);
        imagePreview = findViewById(R.id.editor_image_preview);
        actions = findViewById(R.id.editor_actions);

        MaterialToolbar tb = findViewById(R.id.editor_toolbar);
        tb.setNavigationOnClickListener(v -> handleBack());
        tb.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.action_save) {
                saveNote();
                finish();
                return true;
            }
            return false;
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                handleBack();
            }
        });

        editedNote = new Note();
        editedNote.type = Note.TYPE_TEXT;

        noteId = getIntent().getLongExtra(EXTRA_NOTE_ID, NEW_NOTE_ID);
        if (noteId != NEW_NOTE_ID) {
            LiveData<Note> live = repo.observeById(noteId);
            live.observe(this, new Observer<Note>() {
                @Override
                public void onChanged(Note n) {
                    if (n != null && !fieldsInitialized) {
                        editedNote = n;
                        editTitle.setText(n.title == null ? "" : n.title);
                        editBody.setText(n.body == null ? "" : n.body);
                        renderImage();
                        rebuildActions();
                        fieldsInitialized = true;
                    }
                }
            });
        } else {
            fieldsInitialized = true;
        }

        rebuildActions();
        renderImage();
    }

    private void rebuildActions() {
        actions.removeAllViews();

        // Pripojiť / Vymeniť / Odstrániť obrázok (kontextové podľa stavu)
        boolean hasImage = !TextUtils.isEmpty(editedNote.attachmentImagePath);
        if (hasImage) {
            addPill(R.string.note_action_change_image, v -> pickImage.launch("image/*"));
            addPill(R.string.note_action_remove_image, v -> removeImage());
        } else {
            addPill(R.string.note_action_attach_image, v -> pickImage.launch("image/*"));
        }

        addPill(R.string.notes_action_share, v -> shareNote());
        addPill(R.string.task_action_remove, v -> confirmDelete());
    }

    private void addPill(int textRes, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(textRes);
        b.setAllCaps(false);
        b.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_lea_outlined_pill));
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(13f);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(18), dp(8), dp(18), dp(8));
        b.setOnClickListener(click);

        FlexboxLayout.LayoutParams lp = new FlexboxLayout.LayoutParams(
                FlexboxLayout.LayoutParams.WRAP_CONTENT,
                FlexboxLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), dp(8), dp(4));
        b.setLayoutParams(lp);

        actions.addView(b);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    // ===== Image =====

    private void onImagePicked(Uri uri) {
        // Background kópia do internej zložky
        new Thread(() -> {
            String path = ImageStorage.importImage(this, uri);
            runOnUiThread(() -> {
                if (path == null) {
                    Toast.makeText(this, "Nepodarilo sa importovať obrázok", Toast.LENGTH_SHORT).show();
                    return;
                }
                // Ak bol už predtým iný obrázok, zmaž ho
                if (!TextUtils.isEmpty(editedNote.attachmentImagePath)
                        && !editedNote.attachmentImagePath.equals(path)) {
                    ImageStorage.deleteIfExists(editedNote.attachmentImagePath);
                }
                editedNote.attachmentImagePath = path;
                changedDueToUserEdit = true;
                renderImage();
                rebuildActions();
            });
        }).start();
    }

    private void removeImage() {
        if (TextUtils.isEmpty(editedNote.attachmentImagePath)) return;
        ImageStorage.deleteIfExists(editedNote.attachmentImagePath);
        editedNote.attachmentImagePath = null;
        changedDueToUserEdit = true;
        renderImage();
        rebuildActions();
    }

    private void renderImage() {
        if (TextUtils.isEmpty(editedNote.attachmentImagePath)
                || !new File(editedNote.attachmentImagePath).exists()) {
            imagePreview.setVisibility(View.GONE);
            imagePreview.setImageDrawable(null);
            return;
        }
        try {
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = 2;
            imagePreview.setImageBitmap(BitmapFactory.decodeFile(editedNote.attachmentImagePath, opts));
            imagePreview.setVisibility(View.VISIBLE);
        } catch (OutOfMemoryError oom) {
            imagePreview.setVisibility(View.GONE);
        }
    }

    // ===== Save / back =====

    private void handleBack() {
        // Ak je nejaký obsah, ulož; ináč zahoď
        String t = editTitle.getText().toString().trim();
        String b = editBody.getText().toString().trim();
        boolean hasImage = !TextUtils.isEmpty(editedNote.attachmentImagePath);
        if (!TextUtils.isEmpty(t) || !TextUtils.isEmpty(b) || hasImage) {
            saveNote();
        }
        finish();
    }

    private void saveNote() {
        editedNote.title = editTitle.getText().toString().trim();
        editedNote.body = editBody.getText().toString().trim();
        editedNote.type = Note.TYPE_TEXT;
        repo.save(editedNote, savedId -> {});
    }

    // ===== Actions =====

    private void shareNote() {
        saveNote(); // aktuálny obsah
        StringBuilder sb = new StringBuilder();
        String t = editTitle.getText().toString().trim();
        String b = editBody.getText().toString().trim();
        if (!t.isEmpty()) sb.append(t).append("\n\n");
        if (!b.isEmpty()) sb.append(b);

        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, sb.toString().trim());
        if (!t.isEmpty()) send.putExtra(Intent.EXTRA_SUBJECT, t);
        startActivity(Intent.createChooser(send, getString(R.string.notes_action_share)));
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this,
                sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(R.string.notes_delete_confirm_title)
                .setMessage(R.string.notes_delete_confirm_msg)
                .setPositiveButton(R.string.action_yes, (d, w) -> {
                    if (noteId != NEW_NOTE_ID) {
                        repo.trash(noteId);
                        Toast.makeText(this, R.string.notes_deleted_toast, Toast.LENGTH_SHORT).show();
                    }
                    finish();
                })
                .setNegativeButton(R.string.action_no, null)
                .show();
    }

    public static Intent newIntent(Context ctx, long noteId) {
        Intent i = new Intent(ctx, NoteEditorActivity.class);
        if (noteId != NEW_NOTE_ID) i.putExtra(EXTRA_NOTE_ID, noteId);
        return i;
    }
}
