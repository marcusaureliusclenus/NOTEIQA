package sk.aetheriqa.noteiqa.notification;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;

/**
 * KidReminderScheduler – tenký wrapper nad AlarmManager pre Deti modul.
 *
 * Používame samostatný requestCode namespace aby sa payment ID a event ID
 * nemohli prekryť medzi sebou ani s Task ID (Task reminder je iná trieda).
 *
 * Payment IDs sú posunuté o 10_000_000, Event IDs o 20_000_000 aby sa
 * garantovane nezhodli s Task IDs (typicky < 100_000 v malých DB).
 */
public final class KidReminderScheduler {

    public static final String EXTRA_KIND = "kind";
    public static final String EXTRA_ID = "id";
    public static final String KIND_PAYMENT = "payment";
    public static final String KIND_EVENT = "event";

    private static final int PAYMENT_REQUEST_OFFSET = 10_000_000;
    private static final int EVENT_REQUEST_OFFSET = 20_000_000;

    private KidReminderScheduler() {}

    // ===== Payments =====

    public static void schedulePayment(Context ctx, KidPayment payment) {
        if (payment == null) return;
        cancelPayment(ctx, payment.id);
        if (payment.completed) return;
        if (payment.notifyAt <= System.currentTimeMillis()) return;

        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        PendingIntent pi = buildPendingIntent(ctx, KIND_PAYMENT, payment.id);
        scheduleAlarm(am, payment.notifyAt, pi);
    }

    public static void cancelPayment(Context ctx, long paymentId) {
        cancelById(ctx, KIND_PAYMENT, paymentId);
        NotificationHelper.cancelKidPayment(ctx, paymentId);
    }

    // ===== Events =====

    public static void scheduleEvent(Context ctx, KidEvent event) {
        if (event == null) return;
        cancelEvent(ctx, event.id);
        if (event.notifyAt <= System.currentTimeMillis()) return;

        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        PendingIntent pi = buildPendingIntent(ctx, KIND_EVENT, event.id);
        scheduleAlarm(am, event.notifyAt, pi);
    }

    public static void cancelEvent(Context ctx, long eventId) {
        cancelById(ctx, KIND_EVENT, eventId);
        NotificationHelper.cancelKidEvent(ctx, eventId);
    }

    // ===== Internals =====

    private static void scheduleAlarm(AlarmManager am, long triggerAt, PendingIntent pi) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
                }
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        }
    }

    private static void cancelById(Context ctx, String kind, long id) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = buildPendingIntent(ctx, kind, id);
        am.cancel(pi);
        pi.cancel();
    }

    private static PendingIntent buildPendingIntent(Context ctx, String kind, long id) {
        Intent intent = new Intent(ctx, KidReminderReceiver.class);
        intent.putExtra(EXTRA_KIND, kind);
        intent.putExtra(EXTRA_ID, id);

        int requestCode = requestCodeFor(kind, id);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT
                | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getBroadcast(ctx, requestCode, intent, flags);
    }

    static int requestCodeFor(String kind, long id) {
        int offset = KIND_PAYMENT.equals(kind) ? PAYMENT_REQUEST_OFFSET : EVENT_REQUEST_OFFSET;
        return offset + (int) id;
    }
}
