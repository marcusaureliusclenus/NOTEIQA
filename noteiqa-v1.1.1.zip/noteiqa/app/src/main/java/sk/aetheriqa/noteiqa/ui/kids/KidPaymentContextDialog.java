package sk.aetheriqa.noteiqa.ui.kids;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.util.DateUtils;
import sk.aetheriqa.noteiqa.util.DialogThemes;

/**
 * KidPaymentContextDialog – zobrazí detaily platby s copy-friendly rows.
 *
 * Každý údaj (IBAN, VS, ŠS, správa, hotovosť pre koho) má vedľa seba
 * copy tlačidlo — jeden tap = údaj v schránke, hotový za 10 sekúnd.
 *
 * Tlačidlá dole: "Kopírovať všetko" a "Označiť zaplatené / nezaplatené".
 */
public class KidPaymentContextDialog {

    private KidPaymentContextDialog() {}

    /**
     * Načíta platbu z DB na background threade a potom zobrazí dialog na UI thread.
     */
    public static void show(Context ctx, KidRepository repo, long paymentId) {
        new Thread(() -> {
            KidPayment p = repo.getPaymentSync(paymentId);
            if (p == null) return;
            Kid kid = null;
            for (Kid k : repo.getKidsSync()) if (k.id == p.kidId) { kid = k; break; }
            final Kid finalKid = kid;
            new android.os.Handler(android.os.Looper.getMainLooper()).post(() ->
                    showInternal(ctx, repo, p, finalKid));
        }, "KidPaymentDialog-load").start();
    }

    private static void showInternal(Context ctx, KidRepository repo, KidPayment p, Kid kid) {
        View content = LayoutInflater.from(ctx)
                .inflate(R.layout.dialog_kid_payment_context, null, false);

        TextView title = content.findViewById(R.id.dlg_title);
        TextView amount = content.findViewById(R.id.dlg_amount);
        TextView due = content.findViewById(R.id.dlg_due);
        TextView note = content.findViewById(R.id.dlg_note);
        LinearLayout details = content.findViewById(R.id.dlg_details_container);

        String kidName = kid != null ? kid.name : "";
        title.setText(TextUtils.isEmpty(kidName)
                ? p.title
                : (kidName + ": " + p.title));

        if (p.amountEur != null) {
            amount.setText(String.format(Locale.getDefault(), "%.2f €", p.amountEur)
                    .replace('.', ','));
        } else {
            amount.setVisibility(View.GONE);
        }

        if (p.dueDate > 0L) {
            due.setText(ctx.getString(R.string.kid_payment_dialog_due,
                    DateUtils.formatLongDate(p.dueDate)));
        } else {
            due.setVisibility(View.GONE);
        }

        // Dynamické riadky podľa typu platby
        StringBuilder allText = new StringBuilder();

        if (p.paymentMethod == KidPayment.METHOD_TRANSFER) {
            if (!TextUtils.isEmpty(p.iban)) {
                addRow(details, ctx, "IBAN", p.iban);
                allText.append("IBAN: ").append(p.iban).append('\n');
            }
            if (!TextUtils.isEmpty(p.variableSymbol)) {
                addRow(details, ctx, "Variabilný symbol", p.variableSymbol);
                allText.append("VS: ").append(p.variableSymbol).append('\n');
            }
            if (!TextUtils.isEmpty(p.specificSymbol)) {
                addRow(details, ctx, "Špecifický symbol", p.specificSymbol);
                allText.append("ŠS: ").append(p.specificSymbol).append('\n');
            }
            if (!TextUtils.isEmpty(p.paymentNote)) {
                addRow(details, ctx, "Správa pre príjemcu", p.paymentNote);
                allText.append("Správa: ").append(p.paymentNote).append('\n');
            }
        } else if (p.paymentMethod == KidPayment.METHOD_CASH) {
            if (!TextUtils.isEmpty(p.cashRecipient)) {
                addRow(details, ctx, "Hotovosť pre", p.cashRecipient);
                allText.append("Hotovosť pre: ").append(p.cashRecipient).append('\n');
            }
        }

        if (p.amountEur != null) {
            allText.insert(0, String.format(Locale.getDefault(), "Suma: %.2f €%n",
                    p.amountEur).replace('.', ','));
        }

        if (!TextUtils.isEmpty(p.note)) {
            note.setVisibility(View.VISIBLE);
            note.setText("Poznámka: " + p.note);
        }

        final String allTextFinal = allText.toString().trim();

        String toggleText = p.completed
                ? ctx.getString(R.string.kid_payment_mark_unpaid)
                : ctx.getString(R.string.kid_payment_mark_paid);

        new AlertDialog.Builder(ctx, DialogThemes.LEA)
                .setView(content)
                .setPositiveButton(R.string.kid_payment_copy_all, (d, w) -> {
                    if (!allTextFinal.isEmpty()) {
                        copyToClipboard(ctx, "Platba", allTextFinal);
                        Toast.makeText(ctx, R.string.kid_payment_copied,
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(toggleText, (d, w) -> {
                    repo.setPaymentCompleted(p.id, !p.completed);
                })
                .setNeutralButton("Zavrieť", null)
                .show();
    }

    private static void addRow(LinearLayout container, Context ctx,
                               String label, String value) {
        View row = LayoutInflater.from(ctx)
                .inflate(R.layout.item_kid_payment_detail_row, container, false);
        TextView lblView = row.findViewById(R.id.row_label);
        TextView valView = row.findViewById(R.id.row_value);
        ImageView copyBtn = row.findViewById(R.id.row_copy);

        lblView.setText(label);
        valView.setText(value);
        copyBtn.setOnClickListener(v -> {
            copyToClipboard(ctx, label, value);
            Toast.makeText(ctx, R.string.kid_payment_copied,
                    Toast.LENGTH_SHORT).show();
        });
        container.addView(row);
    }

    private static void copyToClipboard(Context ctx, String label, String value) {
        ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null) return;
        cm.setPrimaryClip(ClipData.newPlainText(label, value));
    }
}
