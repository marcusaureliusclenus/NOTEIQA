package sk.aetheriqa.noteiqa.ui.todo;

import android.content.Context;
import android.graphics.Color;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.data.entity.TaskCategory;
import sk.aetheriqa.noteiqa.util.DateUtils;
import sk.aetheriqa.noteiqa.util.TaskBucketSorter;
import sk.aetheriqa.noteiqa.util.TodoDayMerge;

/**
 * TasksAdapter v3 – pridaný long-press callback pre context menu.
 */
public class TasksAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public interface OnTaskInteractionListener {
        void onTaskClick(Task task);
        void onTaskCheckRequested(Task task);
        /** Long-press na úlohe → otvorí context menu (5 akcií). */
        void onTaskLongPressed(Task task);
        /** v1.0.0 — Klik na šípku hore/dole → swap so susedom v rovnakom buckete. */
        void onTaskMoveRequested(Task task, int direction);
        /** v1.3.6 — osobná platba: tap → platobný lístok. */
        void onPaymentClick(KidPayment payment);
        /** v1.3.6 — osobná platba: zaškrtnutie → zaplatené. */
        void onPaymentPaid(KidPayment payment);
    }

    /** v1.0.0 — direction constants pre onTaskMoveRequested. */
    public static final int MOVE_UP = -1;
    public static final int MOVE_DOWN = 1;

    private static final int VIEW_TYPE_HEADER = 0;
    private static final int VIEW_TYPE_TASK = 1;
    private static final int VIEW_TYPE_KID_EVENT = 2;
    private static final int VIEW_TYPE_PAYMENT = 3;

    private final OnTaskInteractionListener listener;
    private final List<Object> items = new ArrayList<>();
    private Map<Long, TaskCategory> categoriesById = new HashMap<>();

    static final class BucketHeader {
        final TaskBucketSorter.Bucket bucket;
        final int totalCount;
        BucketHeader(TaskBucketSorter.Bucket bucket, int totalCount) {
            this.bucket = bucket;
            this.totalCount = totalCount;
        }
    }

    public TasksAdapter(OnTaskInteractionListener listener) {
        this.listener = listener;
        setHasStableIds(true);
    }

    public void setCategories(List<TaskCategory> categories) {
        Map<Long, TaskCategory> map = new HashMap<>();
        if (categories != null) {
            for (TaskCategory c : categories) map.put(c.id, c);
        }
        this.categoriesById = map;
        notifyDataSetChanged();
    }

    public void submitTasks(List<Task> tasks) {
        submitWithKidEvents(tasks, null);
    }

    /**
     * v1.1.0 — Nový entry point. Ak sú kidEvents non-null, pridajú sa do
     * bucketov podľa svojho startDate. V UI vyzerajú ako "šedšie" tasky
     * s malou ikonou dieťaťa.
     */
    public void submitWithKidEvents(List<Task> tasks, List<KidEventTaskLike> kidEvents) {
        submitAll(tasks, kidEvents, null);
    }

    /**
     * v1.3.6 — úlohy + detské udalosti + osobné platby.
     * Udalosti a platby idú do bucketu podľa dátumu a v ňom pod všetky úlohy svojho dňa,
     * zoradené podľa času začiatku (TodoDayMerge). Poradie úloh sa nemení.
     */
    public void submitAll(List<Task> tasks, List<KidEventTaskLike> kidEvents,
                          List<PaymentTaskLike> payments) {
        items.clear();
        List<Object> extras = new ArrayList<>();
        if (kidEvents != null) extras.addAll(kidEvents);
        if (payments != null) extras.addAll(payments);
        boolean noTasks = tasks == null || tasks.isEmpty();
        if (noTasks && extras.isEmpty()) {
            notifyDataSetChanged();
            return;
        }

        Map<TaskBucketSorter.Bucket, List<Task>> buckets = noTasks
                ? new java.util.LinkedHashMap<>()
                : TaskBucketSorter.bucketize(tasks);

        // Priraď udalosti a platby do bucketov
        Map<TaskBucketSorter.Bucket, List<Object>> extraBuckets = new LinkedHashMap<>();
        for (Object o : extras) {
            TaskBucketSorter.Bucket b = TaskBucketSorter.classifyTimestamp(extraTimestamp(o));
            List<Object> list = extraBuckets.get(b);
            if (list == null) { list = new ArrayList<>(); extraBuckets.put(b, list); }
            list.add(o);
        }

        // Poradie bucketov ostáva ako v enume; iteruj cez všetky.
        for (TaskBucketSorter.Bucket b : TaskBucketSorter.Bucket.values()) {
            List<Task> taskList = buckets.get(b);
            List<Object> extraList = extraBuckets.get(b);
            int count = (taskList != null ? taskList.size() : 0)
                    + (extraList != null ? extraList.size() : 0);
            if (count == 0) continue;

            items.add(new BucketHeader(b, count));
            items.addAll(TodoDayMerge.merge(taskList, extraList, TasksAdapter::extraTimestamp));
        }
        notifyDataSetChanged();
    }

    private static long extraTimestamp(Object o) {
        if (o instanceof KidEventTaskLike) return ((KidEventTaskLike) o).timestamp();
        if (o instanceof PaymentTaskLike) return ((PaymentTaskLike) o).timestamp();
        return 0L;
    }

    @Override
    public int getItemViewType(int position) {
        Object o = items.get(position);
        if (o instanceof BucketHeader) return VIEW_TYPE_HEADER;
        if (o instanceof KidEventTaskLike) return VIEW_TYPE_KID_EVENT;
        if (o instanceof PaymentTaskLike) return VIEW_TYPE_PAYMENT;
        return VIEW_TYPE_TASK;
    }

    @Override
    public long getItemId(int position) {
        Object o = items.get(position);
        if (o instanceof BucketHeader) return -1L - ((BucketHeader) o).bucket.ordinal();
        if (o instanceof KidEventTaskLike) return -100_000L - ((KidEventTaskLike) o).event.id;
        if (o instanceof PaymentTaskLike) return -1_000_000_000L - ((PaymentTaskLike) o).payment.id;
        return ((Task) o).id;
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inf = LayoutInflater.from(parent.getContext());
        if (viewType == VIEW_TYPE_HEADER) {
            return new HeaderVH(inf.inflate(R.layout.item_task_bucket_header, parent, false));
        }
        if (viewType == VIEW_TYPE_KID_EVENT) {
            return new KidEventVH(inf.inflate(R.layout.item_task_kid_event, parent, false));
        }
        // úloha aj osobná platba (v1.3.6) majú rovnaký riadok
        return new TaskVH(inf.inflate(R.layout.item_task, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder h, int position) {
        Object item = items.get(position);
        Context ctx = h.itemView.getContext();
        if (item instanceof BucketHeader) {
            bindHeader((HeaderVH) h, (BucketHeader) item, ctx);
        } else if (item instanceof KidEventTaskLike) {
            bindKidEvent((KidEventVH) h, (KidEventTaskLike) item);
        } else if (item instanceof PaymentTaskLike) {
            bindPayment((TaskVH) h, ((PaymentTaskLike) item).payment, ctx);
        } else {
            bindTask((TaskVH) h, (Task) item, ctx);
        }
    }

    private void bindKidEvent(KidEventVH h, KidEventTaskLike ke) {
        h.title.setText(ke.displayTitle(h.itemView.getContext()));
        // v1.3.6 — druhý riadok "UT 6.10.2026 8:00 · miesto" (čas sa presunul sem z pravej strany)
        h.meta.setText(ke.metaLine());
        h.itemView.setOnClickListener(v -> {
            android.content.Intent intent = sk.aetheriqa.noteiqa.ui.kids
                    .KidEventEditorActivity.newIntent(h.itemView.getContext(),
                            ke.event.id, ke.event.kidIdOrAll());
            h.itemView.getContext().startActivity(intent);
        });
    }

    static class KidEventVH extends RecyclerView.ViewHolder {
        final android.widget.TextView title;
        final android.widget.TextView meta;
        KidEventVH(@NonNull android.view.View item) {
            super(item);
            title = item.findViewById(R.id.task_kid_title);
            meta = item.findViewById(R.id.task_kid_meta);
        }
    }

    /**
     * v1.3.6 — osobná platba ako úloha: názov, pod ním "UT 6.10.2026 · Platba · 25,00 €"
     * (po splatnosti tlmenou červenou). Zaškrtnutie = zaplatené, tap = lístok.
     * Bez šípok poradia — platba nie je úloha v DB.
     */
    private void bindPayment(TaskVH h, KidPayment p, Context ctx) {
        h.title.setText(TextUtils.isEmpty(p.title) ? "—" : p.title);
        h.title.setTextColor(ContextCompat.getColor(ctx, R.color.text_primary));
        h.title.setAlpha(1f);

        StringBuilder meta = new StringBuilder();
        if (p.dueDate > 0L) {
            meta.append(DateUtils.slovakDayShort(p.dueDate).toUpperCase(new Locale("sk")))
                    .append(' ').append(DateUtils.formatLongDate(p.dueDate)).append(" · ");
        }
        meta.append(ctx.getString(R.string.task_category_payment));
        if (p.amountEur != null) {
            meta.append(" · ").append(ctx.getString(R.string.ticket_amount,
                    sk.aetheriqa.noteiqa.util.AmountFormat.format(p.amountEur)));
        }
        boolean overdue = p.dueDate > 0L && TaskBucketSorter.isExpiredTimestamp(p.dueDate);
        h.subtitle.setVisibility(View.VISIBLE);
        h.subtitle.setText(meta.toString());
        h.subtitle.setTextColor(ContextCompat.getColor(ctx,
                overdue ? R.color.thread_overdue : R.color.lea_gold));

        h.priorityIcon.setVisibility(View.GONE);
        h.moveUp.setVisibility(View.GONE);
        h.moveDown.setVisibility(View.GONE);

        h.checkbox.setOnCheckedChangeListener(null);
        h.checkbox.setChecked(false);
        h.checkbox.setOnCheckedChangeListener((v, checked) -> {
            if (checked && listener != null) listener.onPaymentPaid(p);
        });
        h.root.setOnClickListener(v -> {
            if (listener != null) listener.onPaymentClick(p);
        });
        h.root.setOnLongClickListener(null);
        h.root.setLongClickable(false);
    }

    private void bindHeader(HeaderVH h, BucketHeader header, Context ctx) {
        int bgColor;
        boolean lightText;
        int titleRes;

        switch (header.bucket) {
            case TODAY:
                bgColor = R.color.bucket_today;
                lightText = false;
                titleRes = R.string.bucket_today;
                break;
            case TOMORROW:
                bgColor = R.color.bucket_tomorrow;
                lightText = false;
                titleRes = R.string.bucket_tomorrow;
                break;
            case THIS_WEEK:
                bgColor = R.color.bucket_this_week;
                lightText = true;
                titleRes = R.string.bucket_this_week;
                break;
            case THIS_MONTH:
                bgColor = R.color.bucket_this_month;
                lightText = true;
                titleRes = R.string.bucket_this_month;
                break;
            case LATER:
            default:
                bgColor = R.color.bucket_later;
                lightText = true;
                titleRes = R.string.bucket_later;
                break;
        }

        h.root.setBackgroundColor(ContextCompat.getColor(ctx, bgColor));
        int textColor = ContextCompat.getColor(ctx,
                lightText ? R.color.bucket_text_on_dark : R.color.bucket_text_on_light);
        h.name.setText(titleRes);
        h.name.setTextColor(textColor);
        h.count.setText(String.format(Locale.getDefault(), "0/%d", header.totalCount));
        h.count.setTextColor(textColor);
        h.chevron.setColorFilter(textColor);
    }

    private void bindTask(TaskVH h, Task t, Context ctx) {
        boolean expired = TaskBucketSorter.isExpired(t);

        h.title.setText(TextUtils.isEmpty(t.title) ? "—" : t.title);
        if (expired) {
            h.title.setTextColor(ContextCompat.getColor(ctx, R.color.text_disabled));
        } else {
            h.title.setTextColor(ContextCompat.getColor(ctx, R.color.text_primary));
        }
        h.title.setAlpha(1f);

        CharSequence subtitle = buildSubtitle(ctx, t, expired);
        if (TextUtils.isEmpty(subtitle)) {
            h.subtitle.setVisibility(View.GONE);
        } else {
            h.subtitle.setVisibility(View.VISIBLE);
            h.subtitle.setText(subtitle);
        }

        h.priorityIcon.setVisibility(
                t.priority == Task.PRIORITY_IMPORTANT ? View.VISIBLE : View.GONE);
        // v1.3.6 — riadok mohol byť predtým osobná platba (bez šípok)
        h.moveUp.setVisibility(View.VISIBLE);
        h.moveDown.setVisibility(View.VISIBLE);

        h.checkbox.setOnCheckedChangeListener(null);
        h.checkbox.setChecked(false);
        h.checkbox.setOnCheckedChangeListener((v, checked) -> {
            if (checked && listener != null) {
                listener.onTaskCheckRequested(t);
                h.checkbox.setOnCheckedChangeListener(null);
                h.checkbox.setChecked(false);
                h.checkbox.setOnCheckedChangeListener((v2, c2) -> {});
            }
        });

        h.root.setOnClickListener(v -> {
            if (listener != null) listener.onTaskClick(t);
        });

        // Long-press → context menu
        h.root.setOnLongClickListener(v -> {
            if (listener != null) {
                listener.onTaskLongPressed(t);
                return true;
            }
            return false;
        });

        // v1.0.0 — Šípky hore/dole pre manual reorder v buckete
        int adapterPos = h.getBindingAdapterPosition();
        boolean canMoveUp = canMoveTaskUp(adapterPos);
        boolean canMoveDown = canMoveTaskDown(adapterPos);

        h.moveUp.setAlpha(canMoveUp ? 1f : 0.25f);
        h.moveUp.setEnabled(canMoveUp);
        h.moveUp.setOnClickListener(canMoveUp ? v -> {
            if (listener != null) listener.onTaskMoveRequested(t, MOVE_UP);
        } : null);

        h.moveDown.setAlpha(canMoveDown ? 1f : 0.25f);
        h.moveDown.setEnabled(canMoveDown);
        h.moveDown.setOnClickListener(canMoveDown ? v -> {
            if (listener != null) listener.onTaskMoveRequested(t, MOVE_DOWN);
        } : null);
    }

    /**
     * Úloha sa dá posunúť hore, ak je nad ňou v tom istom buckete iná úloha.
     * v1.3.6 — detské udalosti a platby medzi úlohami sa preskakujú.
     */
    private boolean canMoveTaskUp(int adapterPos) {
        for (int i = adapterPos - 1; i >= 0; i--) {
            Object o = items.get(i);
            if (o instanceof BucketHeader) return false;
            if (o instanceof Task) return true;
        }
        return false;
    }

    /** Úloha sa dá posunúť dolu, ak je pod ňou v tom istom buckete iná úloha. */
    private boolean canMoveTaskDown(int adapterPos) {
        if (adapterPos < 0) return false;
        for (int i = adapterPos + 1; i < items.size(); i++) {
            Object o = items.get(i);
            if (o instanceof BucketHeader) return false;
            if (o instanceof Task) return true;
        }
        return false;
    }

    /**
     * v1.0.0 — Po kliknutí šípky na úlohe vráti zoznam taskId celého bucketu
     * v novom poradí (po swape so susednou úlohou). Vráti null ak swap nie je možný.
     * v1.3.6 — bucket je ohraničený hlavičkami; udalosti a platby sa ignorujú.
     *
     * Volá sa z TasksFragment.onTaskMoveRequested(); výsledok sa pošle do
     * TaskRepository.reorderTasks() ktorý zapíše manualSortOrder do DB.
     */
    @androidx.annotation.Nullable
    public List<Long> computeReorderedBucket(Task target, int direction) {
        int targetPos = -1;
        for (int i = 0; i < items.size(); i++) {
            Object o = items.get(i);
            if (o instanceof Task && ((Task) o).id == target.id) {
                targetPos = i;
                break;
            }
        }
        if (targetPos < 0) return null;

        int bucketStart = targetPos;
        while (bucketStart > 0 && !(items.get(bucketStart - 1) instanceof BucketHeader)) {
            bucketStart--;
        }
        int bucketEnd = targetPos;
        while (bucketEnd < items.size() - 1 && !(items.get(bucketEnd + 1) instanceof BucketHeader)) {
            bucketEnd++;
        }

        List<Task> bucket = new ArrayList<>();
        int relPos = -1;
        for (int i = bucketStart; i <= bucketEnd; i++) {
            Object o = items.get(i);
            if (!(o instanceof Task)) continue;
            if (i == targetPos) relPos = bucket.size();
            bucket.add((Task) o);
        }

        int swapWith = relPos + direction;
        if (relPos < 0 || swapWith < 0 || swapWith >= bucket.size()) return null;

        java.util.Collections.swap(bucket, relPos, swapWith);

        List<Long> ids = new ArrayList<>(bucket.size());
        for (Task t : bucket) ids.add(t.id);
        return ids;
    }

    @androidx.annotation.Nullable
    private CharSequence buildSubtitle(Context ctx, Task t, boolean expired) {
        boolean hasDue = t.dueDate != null && t.dueDate != 0L;
        boolean hasCat = t.categoryId != null && categoriesById.containsKey(t.categoryId);
        boolean hasNote = !TextUtils.isEmpty(t.note);

        if (!hasDue && !hasCat && !hasNote) return null;

        StringBuilder meta = new StringBuilder();
        if (hasDue) {
            int dow = DateUtils.isoDayOfWeek(t.dueDate);
            meta.append(DateUtils.slovakDayShort(dow).toUpperCase(new Locale("sk")));
            meta.append(' ');
            meta.append(DateUtils.formatLongDate(t.dueDate));
            if (t.dueTimeMinutes != null) {
                meta.append(' ');
                meta.append(String.format(Locale.getDefault(),
                        "%d:%02d", t.dueTimeMinutes / 60, t.dueTimeMinutes % 60));
            }
        }
        if (hasCat) {
            if (meta.length() > 0) meta.append(" · ");
            meta.append(categoriesById.get(t.categoryId).name);
        }

        SpannableStringBuilder out = new SpannableStringBuilder();
        if (meta.length() > 0) {
            int color = expired
                    ? ContextCompat.getColor(ctx, R.color.text_disabled)
                    : ContextCompat.getColor(ctx, R.color.lea_gold);
            int start = out.length();
            out.append(meta);
            out.setSpan(new ForegroundColorSpan(color), start, out.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }

        if (hasNote) {
            if (out.length() > 0) out.append(" · ");
            int start = out.length();
            int noteColor = expired
                    ? ContextCompat.getColor(ctx, R.color.text_disabled)
                    : Color.WHITE;
            out.append(t.note);
            out.setSpan(new ForegroundColorSpan(noteColor), start, out.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }

        return out;
    }

    static class HeaderVH extends RecyclerView.ViewHolder {
        final LinearLayout root;
        final TextView name, count;
        final ImageView chevron;

        HeaderVH(@NonNull View itemView) {
            super(itemView);
            root = (LinearLayout) itemView;
            name = itemView.findViewById(R.id.bucket_name);
            count = itemView.findViewById(R.id.bucket_count);
            chevron = itemView.findViewById(R.id.bucket_chevron);
        }
    }

    static class TaskVH extends RecyclerView.ViewHolder {
        final LinearLayout root;
        final CheckBox checkbox;
        final TextView title, subtitle;
        final ImageView priorityIcon;
        final ImageView moveUp, moveDown;

        TaskVH(@NonNull View itemView) {
            super(itemView);
            root = (LinearLayout) itemView.findViewById(R.id.task_root);
            checkbox = itemView.findViewById(R.id.task_checkbox);
            title = itemView.findViewById(R.id.task_title);
            subtitle = itemView.findViewById(R.id.task_subtitle);
            priorityIcon = itemView.findViewById(R.id.task_priority_icon);
            moveUp = itemView.findViewById(R.id.task_move_up);
            moveDown = itemView.findViewById(R.id.task_move_down);
        }
    }
}
