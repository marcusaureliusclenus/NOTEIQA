package sk.aetheriqa.noteiqa.data.entity;

import androidx.annotation.Nullable;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/**
 * Task – jedna úloha v To Do liste.
 *
 * Životný cyklus:
 *  archivedAt = 0  → ŽIVÁ úloha (zobrazená v hlavnom To Do liste)
 *  archivedAt > 0  → ARCHIVOVANÁ (zmazaná alebo dokončená; v Archíve, read-only)
 *
 * `completed` = true znamená "dokončená" (dnes v hlavnom liste neukazujeme,
 * lebo po dokončení sa hneď archivuje cez confirm dialóg). Polia ostávajú
 * pre prípad budúcich Drafts/Recurring scenárov.
 *
 * Bucket sa vypočíta runtime z dueDate cez TaskBucketSorter.
 */
@Entity(
    tableName = "tasks",
    indices = {
        @Index("dueDate"),
        @Index("completed"),
        @Index("archivedAt"),
        @Index("categoryId"),
        @Index("priority")
    },
    foreignKeys = @ForeignKey(
        entity = TaskCategory.class,
        parentColumns = "id",
        childColumns = "categoryId",
        onDelete = ForeignKey.SET_NULL
    )
)
public class Task {

    public static final int PRIORITY_NORMAL = 0;
    public static final int PRIORITY_IMPORTANT = 1;

    public static final int REPEAT_NONE = 0;
    public static final int REPEAT_DAILY = 1;
    public static final int REPEAT_WEEKLY = 2;
    public static final int REPEAT_MONTHLY = 3;
    public static final int REPEAT_YEARLY = 4;

    @PrimaryKey(autoGenerate = true)
    public long id;

    @Nullable
    public String title;

    @Nullable
    public String note;

    /**
     * JSON zoznam položiek nákupu pre kategóriu "Nákup".
     * Schéma: [{"text":"vajcia","checked":false}, ...]
     * Pre ostatné kategórie je null a používa sa `note`.
     */
    @Nullable
    public String shoppingItemsJson;

    @Nullable
    public String audioPath;

    @Nullable
    public Long categoryId;

    @Nullable
    public Long dueDate;

    /** "Začiatok úlohy" – minúty od polnoci 0..1439, null = bez času */
    @Nullable
    public Integer dueTimeMinutes;

    public int repeatType = REPEAT_NONE;
    public int repeatDays = 0;
    public int priority = PRIORITY_NORMAL;

    public boolean completed = false;
    public long completedAt = 0L;

    /** Kedy bola úloha presunutá do archívu. 0 = živá, > 0 = archivovaná. */
    public long archivedAt = 0L;

    public long reminderAt = 0L;

    public long createdAt;
    public long updatedAt;
}
