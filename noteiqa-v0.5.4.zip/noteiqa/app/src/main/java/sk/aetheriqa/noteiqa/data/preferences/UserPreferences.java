package sk.aetheriqa.noteiqa.data.preferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * UserPreferences – SharedPreferences pre profil používateľky a quote history.
 *
 * Ukladá:
 *  - displayName     ("Gabika" default)
 *  - photoPath       (absolútna cesta v internal storage, alebo null)
 *  - quotesFilePath  (cesta na importovaný .md súbor v internal storage, alebo null)
 *  - quoteHistoryJson (history použitia viet pre 30-dňový no-repeat algoritmus)
 *
 * Singleton — get() z application contextu.
 */
public class UserPreferences {

    public static final String DEFAULT_NAME = "Gabika";

    private static final String PREF_NAME = "user_profile";
    private static final String KEY_NAME = "displayName";
    private static final String KEY_PHOTO = "photoPath";
    private static final String KEY_QUOTES_FILE = "quotesFilePath";
    private static final String KEY_QUOTE_HISTORY = "quoteHistory";

    private static volatile UserPreferences INSTANCE;

    private final SharedPreferences prefs;

    private UserPreferences(Context ctx) {
        this.prefs = ctx.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static UserPreferences get(Context ctx) {
        if (INSTANCE == null) {
            synchronized (UserPreferences.class) {
                if (INSTANCE == null) {
                    INSTANCE = new UserPreferences(ctx);
                }
            }
        }
        return INSTANCE;
    }

    // ===== Display name =====

    @NonNull
    public String getDisplayName() {
        String n = prefs.getString(KEY_NAME, DEFAULT_NAME);
        return TextUtils.isEmpty(n) ? DEFAULT_NAME : n;
    }

    public void setDisplayName(String name) {
        prefs.edit().putString(KEY_NAME, name == null ? "" : name.trim()).apply();
    }

    /** Iniciálka pre placeholder avatar. Vždy 1 znak veľkými písmenami. */
    @NonNull
    public String getInitial() {
        String name = getDisplayName();
        if (TextUtils.isEmpty(name)) return "?";
        return name.substring(0, 1).toUpperCase();
    }

    // ===== Photo =====

    @Nullable
    public String getPhotoPath() {
        return prefs.getString(KEY_PHOTO, null);
    }

    public void setPhotoPath(@Nullable String path) {
        if (path == null) {
            prefs.edit().remove(KEY_PHOTO).apply();
        } else {
            prefs.edit().putString(KEY_PHOTO, path).apply();
        }
    }

    // ===== Quotes file =====

    @Nullable
    public String getQuotesFilePath() {
        return prefs.getString(KEY_QUOTES_FILE, null);
    }

    public void setQuotesFilePath(@Nullable String path) {
        if (path == null) {
            prefs.edit().remove(KEY_QUOTES_FILE).apply();
        } else {
            prefs.edit().putString(KEY_QUOTES_FILE, path).apply();
        }
    }

    // ===== Quote history (no-repeat 30 days) =====

    /**
     * Vráti map quoteIndex → epoch millis kedy bola naposledy zobrazená.
     * Vety, ktoré nikdy neboli zobrazené, v mape nie sú.
     */
    @NonNull
    public Map<Integer, Long> getQuoteHistory() {
        Map<Integer, Long> out = new HashMap<>();
        String json = prefs.getString(KEY_QUOTE_HISTORY, "[]");
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                int idx = o.optInt("idx", -1);
                long ts = o.optLong("ts", 0L);
                if (idx >= 0 && ts > 0L) out.put(idx, ts);
            }
        } catch (JSONException e) {
            // ignore – vrátime aspoň to, čo sa podarilo
        }
        return out;
    }

    public void recordQuoteShown(int quoteIndex) {
        Map<Integer, Long> history = getQuoteHistory();
        history.put(quoteIndex, System.currentTimeMillis());
        saveHistory(history);
    }

    private void saveHistory(Map<Integer, Long> history) {
        JSONArray arr = new JSONArray();
        try {
            for (Map.Entry<Integer, Long> e : history.entrySet()) {
                JSONObject o = new JSONObject();
                o.put("idx", e.getKey());
                o.put("ts", e.getValue());
                arr.put(o);
            }
        } catch (JSONException ignored) {}
        prefs.edit().putString(KEY_QUOTE_HISTORY, arr.toString()).apply();
    }

    /** Volá sa pri novom importe MD — staré indexy sú irelevantné. */
    public void clearQuoteHistory() {
        prefs.edit().remove(KEY_QUOTE_HISTORY).apply();
    }

    /**
     * Vráti zoznam indexov, ktoré boli zobrazené v posledných {@code days} dňoch.
     * Tieto sa pri ďalšom výbere preskočia.
     */
    @NonNull
    public List<Integer> getRecentlyShownIndexes(int days) {
        long cutoff = System.currentTimeMillis() - days * 24L * 60 * 60 * 1000L;
        Map<Integer, Long> history = getQuoteHistory();
        List<Integer> out = new ArrayList<>();
        for (Map.Entry<Integer, Long> e : history.entrySet()) {
            if (e.getValue() >= cutoff) out.add(e.getKey());
        }
        return out;
    }
}
