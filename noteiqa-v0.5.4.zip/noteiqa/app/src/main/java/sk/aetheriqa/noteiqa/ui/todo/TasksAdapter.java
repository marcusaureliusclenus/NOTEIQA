package sk.aetheriqa.noteiqa.ui.todo;

import android.content.Context;
import android.graphics.Color;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.data.entity.TaskCategory;
import sk.aetheriqa.noteiqa.util.DateUtils;
import sk.aetheriqa.noteiqa.util.TaskBucketSorter;

/**
 * TasksAdapter v3 – pridaný long-press callback pre context menu.
 */
public class TasksAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public interface OnTaskInteractionListener {
        void onTaskClick(Task task);
        void onTaskCheckRequested(Task task);
        /** Long-press na úlohe → otvorí context menu (5 akcií). */
        void onTaskLongPressed(Task task);
    }

    private static final int VIEW_TYPE_HEADER = 0;
    private static final int VIEW_TYPE_TASK = 1;

    private final OnTaskInteractionListener listener;
    private final List<Object> items = new ArrayList<>();
    private Map<Long, TaskCategory> categoriesById = new HashMap<>();

    static final class BucketHeader {
        final TaskBucketSorter.Bucket bucket;
        final int totalCount;
        BucketHeader(TaskBucketSorter.Bucket bucket, int totalCount) {
            this.bucket = bucket;
            this.totalCount = totalCount;
        }
    }

    public TasksAdapter(OnTaskInteractionListener listener) {
        this.listener = listener;
        setHasStableIds(true);
    }

    public void setCategories(List<TaskCategory> categories) {
        Map<Long, TaskCategory> map = new HashMap<>();
        if (categories != null) {
            for (TaskCategory c : categories) map.put(c.id, c);
        }
        this.categoriesById = map;
        notifyDataSetChanged();
    }

    public void submitTasks(List<Task> tasks) {
        items.clear();
        if (tasks == null || tasks.isEmpty()) {
            notifyDataSetChanged();
            return;
        }
        Map<TaskBucketSorter.Bucket, List<Task>> buckets = TaskBucketSorter.bucketize(tasks);
        LinkedHashMap<TaskBucketSorter.Bucket, List<Task>> nonEmpty =
                TaskBucketSorter.nonEmpty(buckets);

        for (Map.Entry<TaskBucketSorter.Bucket, List<Task>> e : nonEmpty.entrySet()) {
            List<Task> list = e.getValue();
            items.add(new BucketHeader(e.getKey(), list.size()));
            items.addAll(list);
        }
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position) instanceof BucketHeader ? VIEW_TYPE_HEADER : VIEW_TYPE_TASK;
    }

    @Override
    public long getItemId(int position) {
        Object o = items.get(position);
        if (o instanceof BucketHeader) return -1L - ((BucketHeader) o).bucket.ordinal();
        return ((Task) o).id;
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inf = LayoutInflater.from(parent.getContext());
        if (viewType == VIEW_TYPE_HEADER) {
            return new HeaderVH(inf.inflate(R.layout.item_task_bucket_header, parent, false));
        }
        return new TaskVH(inf.inflate(R.layout.item_task, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder h, int position) {
        Object item = items.get(position);
        Context ctx = h.itemView.getContext();
        if (item instanceof BucketHeader) {
            bindHeader((HeaderVH) h, (BucketHeader) item, ctx);
        } else {
            bindTask((TaskVH) h, (Task) item, ctx);
        }
    }

    private void bindHeader(HeaderVH h, BucketHeader header, Context ctx) {
        int bgColor;
        boolean lightText;
        int titleRes;

        switch (header.bucket) {
            case TODAY:
                bgColor = R.color.bucket_today;
                lightText = false;
                titleRes = R.string.bucket_today;
                break;
            case TOMORROW:
                bgColor = R.color.bucket_tomorrow;
                lightText = false;
                titleRes = R.string.bucket_tomorrow;
                break;
            case THIS_WEEK:
                bgColor = R.color.bucket_this_week;
                lightText = true;
                titleRes = R.string.bucket_this_week;
                break;
            case THIS_MONTH:
                bgColor = R.color.bucket_this_month;
                lightText = true;
                titleRes = R.string.bucket_this_month;
                break;
            case LATER:
            default:
                bgColor = R.color.bucket_later;
                lightText = true;
                titleRes = R.string.bucket_later;
                break;
        }

        h.root.setBackgroundColor(ContextCompat.getColor(ctx, bgColor));
        int textColor = ContextCompat.getColor(ctx,
                lightText ? R.color.bucket_text_on_dark : R.color.bucket_text_on_light);
        h.name.setText(titleRes);
        h.name.setTextColor(textColor);
        h.count.setText(String.format(Locale.getDefault(), "0/%d", header.totalCount));
        h.count.setTextColor(textColor);
        h.chevron.setColorFilter(textColor);
    }

    private void bindTask(TaskVH h, Task t, Context ctx) {
        boolean expired = TaskBucketSorter.isExpired(t);

        h.title.setText(TextUtils.isEmpty(t.title) ? "—" : t.title);
        if (expired) {
            h.title.setTextColor(ContextCompat.getColor(ctx, R.color.text_disabled));
        } else {
            h.title.setTextColor(ContextCompat.getColor(ctx, R.color.text_primary));
        }
        h.title.setAlpha(1f);

        CharSequence subtitle = buildSubtitle(ctx, t, expired);
        if (TextUtils.isEmpty(subtitle)) {
            h.subtitle.setVisibility(View.GONE);
        } else {
            h.subtitle.setVisibility(View.VISIBLE);
            h.subtitle.setText(subtitle);
        }

        h.priorityIcon.setVisibility(
                t.priority == Task.PRIORITY_IMPORTANT ? View.VISIBLE : View.GONE);

        h.checkbox.setOnCheckedChangeListener(null);
        h.checkbox.setChecked(false);
        h.checkbox.setOnCheckedChangeListener((v, checked) -> {
            if (checked && listener != null) {
                listener.onTaskCheckRequested(t);
                h.checkbox.setOnCheckedChangeListener(null);
                h.checkbox.setChecked(false);
                h.checkbox.setOnCheckedChangeListener((v2, c2) -> {});
            }
        });

        h.root.setOnClickListener(v -> {
            if (listener != null) listener.onTaskClick(t);
        });

        // Long-press → context menu
        h.root.setOnLongClickListener(v -> {
            if (listener != null) {
                listener.onTaskLongPressed(t);
                return true;
            }
            return false;
        });
    }

    @androidx.annotation.Nullable
    private CharSequence buildSubtitle(Context ctx, Task t, boolean expired) {
        boolean hasDue = t.dueDate != null && t.dueDate != 0L;
        boolean hasCat = t.categoryId != null && categoriesById.containsKey(t.categoryId);
        boolean hasNote = !TextUtils.isEmpty(t.note);

        if (!hasDue && !hasCat && !hasNote) return null;

        StringBuilder meta = new StringBuilder();
        if (hasDue) {
            int dow = DateUtils.isoDayOfWeek(t.dueDate);
            meta.append(DateUtils.slovakDayShort(dow).toUpperCase(new Locale("sk")));
            meta.append(' ');
            meta.append(DateUtils.formatLongDate(t.dueDate));
            if (t.dueTimeMinutes != null) {
                meta.append(' ');
                meta.append(String.format(Locale.getDefault(),
                        "%d:%02d", t.dueTimeMinutes / 60, t.dueTimeMinutes % 60));
            }
        }
        if (hasCat) {
            if (meta.length() > 0) meta.append(" · ");
            meta.append(categoriesById.get(t.categoryId).name);
        }

        SpannableStringBuilder out = new SpannableStringBuilder();
        if (meta.length() > 0) {
            int color = expired
                    ? ContextCompat.getColor(ctx, R.color.text_disabled)
                    : ContextCompat.getColor(ctx, R.color.lea_gold);
            int start = out.length();
            out.append(meta);
            out.setSpan(new ForegroundColorSpan(color), start, out.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }

        if (hasNote) {
            if (out.length() > 0) out.append(" · ");
            int start = out.length();
            int noteColor = expired
                    ? ContextCompat.getColor(ctx, R.color.text_disabled)
                    : Color.WHITE;
            out.append(t.note);
            out.setSpan(new ForegroundColorSpan(noteColor), start, out.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }

        return out;
    }

    static class HeaderVH extends RecyclerView.ViewHolder {
        final LinearLayout root;
        final TextView name, count;
        final ImageView chevron;

        HeaderVH(@NonNull View itemView) {
            super(itemView);
            root = (LinearLayout) itemView;
            name = itemView.findViewById(R.id.bucket_name);
            count = itemView.findViewById(R.id.bucket_count);
            chevron = itemView.findViewById(R.id.bucket_chevron);
        }
    }

    static class TaskVH extends RecyclerView.ViewHolder {
        final LinearLayout root;
        final CheckBox checkbox;
        final TextView title, subtitle;
        final ImageView priorityIcon;

        TaskVH(@NonNull View itemView) {
            super(itemView);
            root = (LinearLayout) itemView.findViewById(R.id.task_root);
            checkbox = itemView.findViewById(R.id.task_checkbox);
            title = itemView.findViewById(R.id.task_title);
            subtitle = itemView.findViewById(R.id.task_subtitle);
            priorityIcon = itemView.findViewById(R.id.task_priority_icon);
        }
    }
}
