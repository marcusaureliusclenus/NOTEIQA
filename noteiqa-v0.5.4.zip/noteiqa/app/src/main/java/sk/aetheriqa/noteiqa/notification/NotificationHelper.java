package sk.aetheriqa.noteiqa.notification;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.ui.todo.TaskDetailActivity;

/**
 * NotificationHelper – kanál + zobrazovanie pripomienok.
 *
 * Volá sa raz z {@link sk.aetheriqa.noteiqa.NoteiqaApplication#onCreate()}
 * pre kanál + ad-hoc z {@link ReminderReceiver} pre konkrétnu pripomienku.
 *
 * Žiadne reklamné kanály, žiadne marketing notifikácie – iba pripomienky k úlohám.
 */
public final class NotificationHelper {

    public static final String CHANNEL_REMINDERS = "noteiqa_reminders";

    private NotificationHelper() {}

    public static void createChannels(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        NotificationManager nm = ctx.getSystemService(NotificationManager.class);
        if (nm == null) return;

        NotificationChannel reminders = new NotificationChannel(
                CHANNEL_REMINDERS,
                ctx.getString(R.string.reminder_channel_name),
                NotificationManager.IMPORTANCE_HIGH);
        reminders.setDescription(ctx.getString(R.string.reminder_channel_desc));
        reminders.enableLights(true);
        reminders.enableVibration(true);
        nm.createNotificationChannel(reminders);
    }

    /**
     * Zobrazí pripomienku pre konkrétnu úlohu.
     *
     * Tap → otvorí TaskDetailActivity.
     * Notification ID = (int) taskId, takže opakovaná pripomienka tej istej
     * úlohy nahradí predošlú a nezduplikuje sa.
     */
    public static void showTaskReminder(Context ctx, Task task) {
        if (task == null) return;

        // Tap intent → TaskDetailActivity
        Intent openIntent = TaskDetailActivity.newIntent(ctx, task.id);
        openIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT
                | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    ? PendingIntent.FLAG_IMMUTABLE : 0);

        PendingIntent contentIntent = PendingIntent.getActivity(
                ctx,
                (int) task.id,
                openIntent,
                piFlags);

        String title = TextUtils.isEmpty(task.title)
                ? ctx.getString(R.string.reminder_picker_title)
                : task.title;

        StringBuilder body = new StringBuilder();
        if (task.dueDate != null && task.dueDate != 0L) {
            body.append(sk.aetheriqa.noteiqa.util.DateUtils.formatLongDate(task.dueDate));
        }
        if (task.dueTimeMinutes != null) {
            int h = task.dueTimeMinutes / 60;
            int m = task.dueTimeMinutes % 60;
            if (body.length() > 0) body.append(' ');
            body.append(String.format(java.util.Locale.getDefault(), "%d:%02d", h, m));
        }
        if (!TextUtils.isEmpty(task.note)) {
            if (body.length() > 0) body.append(" — ");
            body.append(task.note);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(ctx, CHANNEL_REMINDERS)
                .setSmallIcon(R.drawable.ic_bell)
                .setColor(0xFFC9A961) // LEA gold
                .setContentTitle(title)
                .setContentText(body.toString())
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body.toString()))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .setDefaults(NotificationCompat.DEFAULT_ALL);

        try {
            NotificationManagerCompat.from(ctx).notify((int) task.id, builder.build());
        } catch (SecurityException e) {
            // Android 13+ POST_NOTIFICATIONS bez povolenia – ignorujeme tichoľko
        }
    }

    /** Cancel-by-id pre prípad, že úlohu archivujeme alebo posunieme. */
    public static void cancel(Context ctx, long taskId) {
        NotificationManagerCompat.from(ctx).cancel((int) taskId);
    }
}
