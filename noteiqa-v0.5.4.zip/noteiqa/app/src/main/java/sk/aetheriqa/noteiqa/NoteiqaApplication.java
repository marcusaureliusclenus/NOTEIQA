package sk.aetheriqa.noteiqa;

import android.app.Application;
import androidx.appcompat.app.AppCompatDelegate;

import sk.aetheriqa.noteiqa.notification.NotificationHelper;
import sk.aetheriqa.noteiqa.util.MotivationalQuotes;

/**
 * NoteiqaApplication
 *
 * Globálny entry-point. Inicializuje:
 *  - Force dark mode (premium gold-on-black aesthetic)
 *  - Notifikačné kanály pre pripomienky
 *  - DB instanciu (lazy via {@link sk.aetheriqa.noteiqa.data.db.AppDatabase#getInstance})
 *
 * Žiadny analytics SDK. Žiadny crash reporter. Žiadne tracking.
 */
public class NoteiqaApplication extends Application {

    private static NoteiqaApplication instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;

        // Defaultne dark mode – téma je čierno-zlatá premium.
        // Light variant existuje len ako fallback pre systém, ktorý si to vynúti.
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);

        // Notifikačné kanály (Android 8+)
        NotificationHelper.createChannels(this);

        // Default motivačné vety v prvom spustení – Marek môže neskôr nahradiť
        // svojím .md cez Nastavenia → Profil → Motivačné vety.
        // Beží na background, lebo IO read z assets nesmie blokovať UI thread.
        new Thread(() -> MotivationalQuotes.ensureDefaultImported(this),
                "DefaultQuotesInit").start();
    }

    public static NoteiqaApplication get() {
        return instance;
    }
}
