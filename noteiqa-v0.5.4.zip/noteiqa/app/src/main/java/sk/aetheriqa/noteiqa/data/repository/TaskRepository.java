package sk.aetheriqa.noteiqa.data.repository;

import android.content.Context;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import sk.aetheriqa.noteiqa.data.db.AppDatabase;
import sk.aetheriqa.noteiqa.data.db.dao.SubtaskDao;
import sk.aetheriqa.noteiqa.data.db.dao.TaskCategoryDao;
import sk.aetheriqa.noteiqa.data.db.dao.TaskDao;
import sk.aetheriqa.noteiqa.data.entity.Subtask;
import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.data.entity.TaskCategory;

/**
 * TaskRepository – business logika pre To Do.
 *
 * Všetky mutating operácie idú cez ExecutorService – nikdy z UI threadu.
 * Pri prvom spustení nasieje default kategórie v poradí:
 *   Nákup, Osobné, Rodina, Zdravie, Domov, Práca, Iné
 */
public class TaskRepository {

    /** Stabilný systémový názov kategórie Nákup. UI naň reaguje špeciálnym workflow. */
    public static final String SHOPPING_CATEGORY_NAME = "Nákup";

    private static volatile TaskRepository INSTANCE;

    private final TaskDao taskDao;
    private final SubtaskDao subtaskDao;
    private final TaskCategoryDao categoryDao;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Context appContext;

    private TaskRepository(Context ctx) {
        AppDatabase db = AppDatabase.getInstance(ctx);
        this.taskDao = db.taskDao();
        this.subtaskDao = db.subtaskDao();
        this.categoryDao = db.taskCategoryDao();
        this.appContext = ctx.getApplicationContext();

        executor.execute(this::seedCategoriesIfEmpty);
    }

    public static TaskRepository getInstance(Context ctx) {
        if (INSTANCE == null) {
            synchronized (TaskRepository.class) {
                if (INSTANCE == null) {
                    INSTANCE = new TaskRepository(ctx.getApplicationContext());
                }
            }
        }
        return INSTANCE;
    }

    // ===== Tasks =====

    public LiveData<List<Task>> observeActive() {
        return taskDao.observeActive();
    }

    public LiveData<List<Task>> observeArchived() {
        return taskDao.observeArchived();
    }

    public LiveData<Integer> observeArchivedCount() {
        return taskDao.observeArchivedCount();
    }

    /**
     * Počet aktívnych úloh, ktoré majú dueDate dnes (lokálny dátum).
     * Pre dashboard "Dnešné úlohy: N".
     */
    public LiveData<Integer> observeTodayCount() {
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.set(java.util.Calendar.HOUR_OF_DAY, 0);
        c.set(java.util.Calendar.MINUTE, 0);
        c.set(java.util.Calendar.SECOND, 0);
        c.set(java.util.Calendar.MILLISECOND, 0);
        long from = c.getTimeInMillis();
        long to = from + 24L * 60 * 60 * 1000;
        return taskDao.observeCountInRange(from, to);
    }

    public LiveData<Task> observeById(long id) {
        return taskDao.observeById(id);
    }

    /** Sync read pre BroadcastReceiver / WorkManager – nikdy z UI threadu. */
    public Task getByIdSync(long id) {
        return taskDao.getById(id);
    }

    public void save(Task task, OnSavedCallback cb) {
        executor.execute(() -> {
            long now = System.currentTimeMillis();
            if (task.createdAt == 0L) task.createdAt = now;
            task.updatedAt = now;

            long id;
            if (task.id == 0L) {
                id = taskDao.insert(task);
            } else {
                taskDao.update(task);
                id = task.id;
            }
            if (cb != null) cb.onSaved(id);
        });
    }

    /**
     * Archivácia (nahradzuje hard delete aj completion).
     * Po archivácii úloha zmizne z hlavného listu a ostane v Archíve.
     */
    public void archive(long taskId) {
        executor.execute(() -> {
            taskDao.archive(taskId, System.currentTimeMillis());
            sk.aetheriqa.noteiqa.notification.ReminderScheduler.cancel(appContext, taskId);
        });
    }

    /** Obnova z archívu späť do živých úloh. Zároveň re-schedule alarm ak má reminderAt v budúcnosti. */
    public void unarchive(long taskId) {
        executor.execute(() -> {
            taskDao.unarchive(taskId, System.currentTimeMillis());
            Task t = taskDao.getById(taskId);
            if (t != null && t.reminderAt > System.currentTimeMillis()) {
                sk.aetheriqa.noteiqa.notification.ReminderScheduler.schedule(appContext, t);
            }
        });
    }

    /** Pre BootReceiver — neskôr push notifikácie. */
    public void getActiveRemindersAsync(OnTasksLoadedCallback cb) {
        executor.execute(() -> {
            List<Task> tasks = taskDao.getWithRemindersAfter(System.currentTimeMillis());
            cb.onLoaded(tasks);
        });
    }

    // ===== Subtasks =====

    public LiveData<List<Subtask>> observeSubtasks(long taskId) {
        return subtaskDao.observeForTask(taskId);
    }

    public void saveSubtasks(long taskId, List<Subtask> subtasks) {
        executor.execute(() -> {
            subtaskDao.deleteAllForTask(taskId);
            long now = System.currentTimeMillis();
            for (int i = 0; i < subtasks.size(); i++) {
                Subtask s = subtasks.get(i);
                s.taskId = taskId;
                s.sortOrder = i;
                if (s.createdAt == 0L) s.createdAt = now;
            }
            subtaskDao.insertAll(subtasks);
        });
    }

    public void toggleSubtask(long subtaskId, boolean completed) {
        executor.execute(() -> subtaskDao.setCompleted(subtaskId, completed));
    }

    // ===== Categories =====

    public LiveData<List<TaskCategory>> observeCategories() {
        return categoryDao.observeAll();
    }

    public TaskCategory getCategoryByIdSync(long id) {
        return categoryDao.getById(id);
    }

    /**
     * Async: nájde poslednú editovanú aktívnu úlohu v danej kategórii (podľa
     * názvu kategórie, typicky "Nákup"). Vráti taskId alebo 0 ak žiadna
     * neexistuje.
     *
     * Používa sa pri Dashboard "Nákup" quick action — ak už nejaký nákup
     * existuje, otvoríme ho v editore namiesto vytvárania nového.
     */
    public void findLastActiveTaskByCategoryName(String categoryName,
                                                 OnTaskIdResolvedCallback cb) {
        if (cb == null) return;
        executor.execute(() -> {
            // 1) Nájdi categoryId podľa názvu
            long categoryId = 0L;
            for (TaskCategory c : categoryDao.getAll()) {
                if (categoryName != null && categoryName.equals(c.name)) {
                    categoryId = c.id;
                    break;
                }
            }
            if (categoryId == 0L) {
                cb.onResolved(0L);
                return;
            }
            // 2) Najnovšia aktívna úloha v tejto kategórii (updatedAt DESC)
            Task t = taskDao.getLastActiveByCategory(categoryId);
            cb.onResolved(t == null ? 0L : t.id);
        });
    }

    /**
     * Default kategórie len pri prvom spustení.
     * Poradie: Nákup, Osobné, Rodina, Zdravie, Domov, Práca, Iné.
     * Nákup je first lebo má špeciálny workflow (checkbox položky).
     */
    private void seedCategoriesIfEmpty() {
        if (categoryDao.count() > 0) return;

        String[] names = {SHOPPING_CATEGORY_NAME, "Osobné", "Rodina", "Zdravie", "Domov", "Práca", "Iné"};
        // LEA gold paleta s rôznymi odtieňmi
        String[] colors = {"#C9A961", "#DDC07A", "#A88A2C", "#E8C865", "#7A6420", "#B8995A", "#8A8580"};

        for (int i = 0; i < names.length; i++) {
            TaskCategory cat = new TaskCategory();
            cat.name = names[i];
            cat.color = colors[i];
            cat.systemCategory = true;
            cat.sortOrder = i;
            categoryDao.insert(cat);
        }
    }

    public interface OnSavedCallback {
        void onSaved(long id);
    }

    public interface OnTasksLoadedCallback {
        void onLoaded(List<Task> tasks);
    }

    /** Vráti taskId alebo 0L ak nič nenašlo. */
    public interface OnTaskIdResolvedCallback {
        void onResolved(long taskId);
    }

    /** Callback pre operácie ktoré reportujú počet zasiahnutých záznamov. */
    public interface OnCountCallback {
        void onCount(int count);
    }

    /**
     * v0.5.4 — permanentne zmaže VŠETKY archivované úlohy.
     *
     * Pred samotným DELETE zruší aj reminderov v AlarmManager-i (defenzívne,
     * keďže archive() to už robí, ale kvôli legacy dátam to môže byť nezhoda).
     * Subtasky sa mažú automaticky cez ON DELETE CASCADE.
     */
    public void deleteAllArchived(OnCountCallback cb) {
        executor.execute(() -> {
            List<Task> archived = taskDao.getArchivedSync();
            for (Task t : archived) {
                sk.aetheriqa.noteiqa.notification.ReminderScheduler.cancel(appContext, t.id);
            }
            int count = taskDao.deleteAllArchived();
            if (cb != null) cb.onCount(count);
        });
    }
}
