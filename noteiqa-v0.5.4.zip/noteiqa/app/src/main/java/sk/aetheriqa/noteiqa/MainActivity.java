package sk.aetheriqa.noteiqa;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import sk.aetheriqa.noteiqa.data.repository.TaskRepository;
import sk.aetheriqa.noteiqa.ui.chudnutie.ChudnutieFragment;
import sk.aetheriqa.noteiqa.ui.home.HomeFragment;
import sk.aetheriqa.noteiqa.ui.more.MoreFragment;
import sk.aetheriqa.noteiqa.ui.notes.NotesFragment;
import sk.aetheriqa.noteiqa.ui.todo.TaskEditorActivity;
import sk.aetheriqa.noteiqa.ui.todo.TasksFragment;

/**
 * MainActivity – host pre 5 hlavných kariet:
 *   Domov · Môj to do list · Poznámky · Váženie · Nastavenia
 *
 * Default tab = Domov (dashboard).
 *
 * Implementuje {@link HomeFragment.OnQuickActionListener} aby quick actions
 * z dashboardu mohli prepnúť tab alebo otvoriť Activity.
 */
public class MainActivity extends AppCompatActivity
        implements HomeFragment.OnQuickActionListener {

    private static final String TAG_HOME = "frag_home";
    private static final String TAG_TODO = "frag_todo";
    private static final String TAG_NOTES = "frag_notes";
    private static final String TAG_CHUDNUTIE = "frag_chudnutie";
    private static final String TAG_SETTINGS = "frag_settings";

    private BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNav = findViewById(R.id.bottom_nav);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                showFragment(TAG_HOME);
                return true;
            } else if (id == R.id.nav_todo) {
                showFragment(TAG_TODO);
                return true;
            } else if (id == R.id.nav_notes) {
                showFragment(TAG_NOTES);
                return true;
            } else if (id == R.id.nav_chudnutie) {
                showFragment(TAG_CHUDNUTIE);
                return true;
            } else if (id == R.id.nav_settings) {
                showFragment(TAG_SETTINGS);
                return true;
            }
            return false;
        });

        if (savedInstanceState == null) {
            // Default tab = Domov (dashboard)
            showFragment(TAG_HOME);
            bottomNav.setSelectedItemId(R.id.nav_home);
        }
    }

    private void showFragment(String tag) {
        FragmentTransaction tx = getSupportFragmentManager().beginTransaction();
        for (String t : new String[]{TAG_HOME, TAG_TODO, TAG_NOTES, TAG_CHUDNUTIE, TAG_SETTINGS}) {
            Fragment f = getSupportFragmentManager().findFragmentByTag(t);
            if (f != null && !f.isHidden()) tx.hide(f);
        }
        Fragment target = getSupportFragmentManager().findFragmentByTag(tag);
        if (target == null) {
            target = createFragment(tag);
            tx.add(R.id.fragment_container, target, tag);
        } else {
            tx.show(target);
        }
        tx.commit();
    }

    private Fragment createFragment(String tag) {
        switch (tag) {
            case TAG_TODO:      return new TasksFragment();
            case TAG_NOTES:     return new NotesFragment();
            case TAG_CHUDNUTIE: return new ChudnutieFragment();
            case TAG_SETTINGS:  return new MoreFragment();
            case TAG_HOME:
            default:            return new HomeFragment();
        }
    }

    /**
     * Implementácia HomeFragment.OnQuickActionListener.
     *
     * Mapping:
     *  - QUICK_TODO     → prepne na tab To do list
     *  - QUICK_SHOPPING → otvorí TaskEditorActivity s pre-vybranou kategóriou Nákup
     *  - QUICK_WEIGHT   → prepne na tab Váženie
     *  - QUICK_NOTES    → prepne na tab Poznámky
     *  - "settings"     → prepne na tab Nastavenia (pre klik na avatar)
     */
    @Override
    public void onQuickAction(String which) {
        switch (which) {
            case HomeFragment.QUICK_TODO:
                bottomNav.setSelectedItemId(R.id.nav_todo);
                break;
            case HomeFragment.QUICK_SHOPPING:
                // Najprv pozri, či už existuje aktívny "Nákup" — ak áno, otvor v editore;
                // ak nie, otvor nový s pre-vybranou kategóriou Nákup.
                TaskRepository.getInstance(getApplicationContext())
                        .findLastActiveTaskByCategoryName(
                                TaskRepository.SHOPPING_CATEGORY_NAME,
                                taskId -> runOnUiThread(() -> {
                                    if (taskId > 0L) {
                                        startActivity(TaskEditorActivity.newIntent(this, taskId));
                                    } else {
                                        Intent shopIntent = TaskEditorActivity.newIntent(this, 0L);
                                        shopIntent.putExtra(
                                                TaskEditorActivity.EXTRA_PRESELECT_CATEGORY,
                                                TaskRepository.SHOPPING_CATEGORY_NAME);
                                        startActivity(shopIntent);
                                    }
                                }));
                break;
            case HomeFragment.QUICK_WEIGHT:
                bottomNav.setSelectedItemId(R.id.nav_chudnutie);
                break;
            case HomeFragment.QUICK_NOTES:
                bottomNav.setSelectedItemId(R.id.nav_notes);
                break;
            case "settings":
                bottomNav.setSelectedItemId(R.id.nav_settings);
                break;
        }
    }
}
