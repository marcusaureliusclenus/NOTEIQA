package sk.aetheriqa.noteiqa.ui.kids;

import android.Manifest;
import android.content.pm.PackageManager;
import android.speech.SpeechRecognizer;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import sk.aetheriqa.noteiqa.R;

/**
 * VoiceDraftLauncher – v1.3.0 — vstup do hlasového návrhu z fragmentu
 * (mic na niti dňa, dlhý stisk FAB v Deťoch). Rieši povolenie RECORD_AUDIO.
 *
 * Musí sa vytvoriť najneskôr v onViewCreated (registerForActivityResult pred onStart).
 */
public final class VoiceDraftLauncher {

    private final Fragment fragment;
    private final ActivityResultLauncher<String> permission;
    private long pendingKidId;

    public VoiceDraftLauncher(Fragment fragment) {
        this.fragment = fragment;
        this.permission = fragment.registerForActivityResult(
                new ActivityResultContracts.RequestPermission(), granted -> {
                    if (!fragment.isAdded()) return;
                    if (granted) {
                        open(pendingKidId);
                    } else {
                        Toast.makeText(fragment.requireContext(), R.string.voice_no_permission,
                                Toast.LENGTH_LONG).show();
                    }
                });
    }

    /** @param defaultKidId dieťa vybrané vo filtri (0 = všetky), použije sa ak ho veta nespomenie */
    public void start(long defaultKidId) {
        if (!fragment.isAdded()) return;
        if (!SpeechRecognizer.isRecognitionAvailable(fragment.requireContext())) {
            Toast.makeText(fragment.requireContext(), R.string.voice_unavailable,
                    Toast.LENGTH_LONG).show();
            return;
        }
        pendingKidId = defaultKidId;
        if (ContextCompat.checkSelfPermission(fragment.requireContext(), Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED) {
            open(defaultKidId);
        } else {
            permission.launch(Manifest.permission.RECORD_AUDIO);
        }
    }

    private void open(long defaultKidId) {
        new VoiceDraftSheet(fragment.requireContext(), defaultKidId).show();
    }
}
