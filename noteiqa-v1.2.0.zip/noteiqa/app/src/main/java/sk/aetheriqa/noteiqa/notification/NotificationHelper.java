package sk.aetheriqa.noteiqa.notification;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.ui.todo.TaskDetailActivity;

/**
 * NotificationHelper – kanál + zobrazovanie pripomienok.
 *
 * Volá sa raz z {@link sk.aetheriqa.noteiqa.NoteiqaApplication#onCreate()}
 * pre kanál + ad-hoc z {@link ReminderReceiver} pre konkrétnu pripomienku.
 *
 * Žiadne reklamné kanály, žiadne marketing notifikácie – iba pripomienky k úlohám.
 */
public final class NotificationHelper {

    public static final String CHANNEL_REMINDERS = "noteiqa_reminders";

    private NotificationHelper() {}

    public static void createChannels(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        NotificationManager nm = ctx.getSystemService(NotificationManager.class);
        if (nm == null) return;

        NotificationChannel reminders = new NotificationChannel(
                CHANNEL_REMINDERS,
                ctx.getString(R.string.reminder_channel_name),
                NotificationManager.IMPORTANCE_HIGH);
        reminders.setDescription(ctx.getString(R.string.reminder_channel_desc));
        reminders.enableLights(true);
        reminders.enableVibration(true);
        nm.createNotificationChannel(reminders);
    }

    /**
     * Zobrazí pripomienku pre konkrétnu úlohu.
     *
     * Tap → otvorí TaskDetailActivity.
     * Notification ID = (int) taskId, takže opakovaná pripomienka tej istej
     * úlohy nahradí predošlú a nezduplikuje sa.
     */
    public static void showTaskReminder(Context ctx, Task task) {
        if (task == null) return;

        // Tap intent → TaskDetailActivity
        Intent openIntent = TaskDetailActivity.newIntent(ctx, task.id);
        openIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT
                | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    ? PendingIntent.FLAG_IMMUTABLE : 0);

        PendingIntent contentIntent = PendingIntent.getActivity(
                ctx,
                (int) task.id,
                openIntent,
                piFlags);

        String title = TextUtils.isEmpty(task.title)
                ? ctx.getString(R.string.reminder_picker_title)
                : task.title;

        StringBuilder body = new StringBuilder();
        if (task.dueDate != null && task.dueDate != 0L) {
            body.append(sk.aetheriqa.noteiqa.util.DateUtils.formatLongDate(task.dueDate));
        }
        if (task.dueTimeMinutes != null) {
            int h = task.dueTimeMinutes / 60;
            int m = task.dueTimeMinutes % 60;
            if (body.length() > 0) body.append(' ');
            body.append(String.format(java.util.Locale.getDefault(), "%d:%02d", h, m));
        }
        if (!TextUtils.isEmpty(task.note)) {
            if (body.length() > 0) body.append(" — ");
            body.append(task.note);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(ctx, CHANNEL_REMINDERS)
                .setSmallIcon(R.drawable.ic_bell)
                .setColor(0xFFC9A961) // LEA gold
                .setContentTitle(title)
                .setContentText(body.toString())
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body.toString()))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .setDefaults(NotificationCompat.DEFAULT_ALL);

        try {
            NotificationManagerCompat.from(ctx).notify((int) task.id, builder.build());
        } catch (SecurityException e) {
            // Android 13+ POST_NOTIFICATIONS bez povolenia – ignorujeme tichoľko
        }
    }

    /** Cancel-by-id pre prípad, že úlohu archivujeme alebo posunieme. */
    public static void cancel(Context ctx, long taskId) {
        NotificationManagerCompat.from(ctx).cancel((int) taskId);
    }

    // ===== v1.1.0 — Deti modul =====

    /**
     * Notifikácia pre blížiacu sa platbu.
     * Tap → otvorí MainActivity a naviguje do Deti tabu → Platby list, kde je platba viditeľná.
     * V1.1.0 zobrazujeme len BigTextStyle s podrobnosťami; copy-friendly dialog s IBAN je
     * v samotnej appke po tapnutí.
     */
    public static void showKidPaymentReminder(Context ctx,
                                              sk.aetheriqa.noteiqa.data.entity.KidPayment payment,
                                              sk.aetheriqa.noteiqa.data.entity.Kid kid) {
        if (payment == null) return;

        Intent open = new Intent(ctx, sk.aetheriqa.noteiqa.MainActivity.class);
        open.setAction(sk.aetheriqa.noteiqa.MainActivity.ACTION_OPEN_KIDS);
        open.putExtra(sk.aetheriqa.noteiqa.MainActivity.EXTRA_OPEN_PAYMENT_ID, payment.id);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT
                | (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M
                    ? PendingIntent.FLAG_IMMUTABLE : 0);

        PendingIntent contentIntent = PendingIntent.getActivity(
                ctx, kidPaymentNotifId(payment.id), open, piFlags);

        String title = (kid != null ? kid.name + ": " : "") + payment.title;

        StringBuilder body = new StringBuilder();
        if (payment.amountEur != null) {
            body.append(String.format(java.util.Locale.getDefault(),
                    "%.2f €", payment.amountEur).replace('.', ','));
        }
        body.append(ctx.getString(R.string.kid_payment_notif_due,
                sk.aetheriqa.noteiqa.util.DateUtils.formatLongDate(payment.dueDate)));
        if (payment.paymentMethod == sk.aetheriqa.noteiqa.data.entity.KidPayment.METHOD_CASH
                && !android.text.TextUtils.isEmpty(payment.cashRecipient)) {
            body.append('\n').append(ctx.getString(R.string.kid_payment_dialog_cash, payment.cashRecipient));
        } else if (payment.paymentMethod == sk.aetheriqa.noteiqa.data.entity.KidPayment.METHOD_TRANSFER
                && !android.text.TextUtils.isEmpty(payment.iban)) {
            body.append('\n').append(ctx.getString(R.string.kid_payment_dialog_iban, payment.iban));
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(ctx, CHANNEL_REMINDERS)
                .setSmallIcon(sk.aetheriqa.noteiqa.R.drawable.ic_bell)
                .setColor(0xFFC9A961)
                .setContentTitle(title)
                .setContentText(body.toString())
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body.toString()))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .setDefaults(NotificationCompat.DEFAULT_ALL);

        // v1.2.0 — akcie: Zaplatené + Kopírovať IBAN (len pri prevode s IBAN)
        builder.addAction(R.drawable.ic_check, ctx.getString(R.string.kid_notif_action_paid),
                kidPaymentActionIntent(ctx, KidPaymentActionReceiver.ACTION_PAID, payment.id,
                        KidPaymentActionReceiver.PAID_REQUEST_OFFSET));
        if (payment.paymentMethod == sk.aetheriqa.noteiqa.data.entity.KidPayment.METHOD_TRANSFER
                && !android.text.TextUtils.isEmpty(payment.iban)) {
            builder.addAction(R.drawable.ic_copy, ctx.getString(R.string.kid_notif_action_copy_iban),
                    kidPaymentActionIntent(ctx, KidPaymentActionReceiver.ACTION_COPY_IBAN, payment.id,
                            KidPaymentActionReceiver.COPY_REQUEST_OFFSET));
        }

        try {
            NotificationManagerCompat.from(ctx).notify(kidPaymentNotifId(payment.id), builder.build());
        } catch (SecurityException ignored) {}
    }

    /**
     * Notifikácia pre udalosť (typicky deň vopred).
     * Tap → Deti tab → Kalendár.
     */
    public static void showKidEventReminder(Context ctx,
                                            sk.aetheriqa.noteiqa.data.entity.KidEvent event,
                                            sk.aetheriqa.noteiqa.data.entity.Kid kid) {
        if (event == null) return;

        Intent open = new Intent(ctx, sk.aetheriqa.noteiqa.MainActivity.class);
        open.setAction(sk.aetheriqa.noteiqa.MainActivity.ACTION_OPEN_KIDS);
        open.putExtra(sk.aetheriqa.noteiqa.MainActivity.EXTRA_OPEN_EVENT_ID, event.id);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT
                | (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M
                    ? PendingIntent.FLAG_IMMUTABLE : 0);

        PendingIntent contentIntent = PendingIntent.getActivity(
                ctx, kidEventNotifId(event.id), open, piFlags);

        String kidLabel = kid != null ? kid.name : ctx.getString(R.string.kids_label_all);
        String title = ctx.getString(R.string.kid_event_notif_title, kidLabel, event.title);

        StringBuilder body = new StringBuilder();
        body.append(sk.aetheriqa.noteiqa.util.DateUtils.formatLongDate(event.startDate));
        if (!event.allDay) {
            java.util.Calendar c = java.util.Calendar.getInstance();
            c.setTimeInMillis(event.startDate);
            body.append(String.format(java.util.Locale.getDefault(),
                    " · %d:%02d", c.get(java.util.Calendar.HOUR_OF_DAY),
                    c.get(java.util.Calendar.MINUTE)));
        }
        if (!android.text.TextUtils.isEmpty(event.location)) {
            body.append("\n").append(event.location);
        }
        if (!android.text.TextUtils.isEmpty(event.note)) {
            body.append("\n").append(event.note);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(ctx, CHANNEL_REMINDERS)
                .setSmallIcon(sk.aetheriqa.noteiqa.R.drawable.ic_bell)
                .setColor(0xFFC9A961)
                .setContentTitle(title)
                .setContentText(body.toString())
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body.toString()))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .setDefaults(NotificationCompat.DEFAULT_ALL);

        try {
            NotificationManagerCompat.from(ctx).notify(kidEventNotifId(event.id), builder.build());
        } catch (SecurityException ignored) {}
    }

    private static PendingIntent kidPaymentActionIntent(Context ctx, String action,
                                                        long paymentId, int requestOffset) {
        Intent i = new Intent(ctx, KidPaymentActionReceiver.class);
        i.setAction(action);
        i.putExtra(KidPaymentActionReceiver.EXTRA_PAYMENT_ID, paymentId);
        // IMMUTABLE — extras sú dané pri vytvorení, systém nič nedopĺňa
        int flags = PendingIntent.FLAG_UPDATE_CURRENT
                | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getBroadcast(ctx,
                KidReminderScheduler.mix(paymentId, requestOffset), i, flags);
    }

    public static void cancelKidPayment(Context ctx, long paymentId) {
        NotificationManagerCompat.from(ctx).cancel(kidPaymentNotifId(paymentId));
    }

    public static void cancelKidEvent(Context ctx, long eventId) {
        NotificationManagerCompat.from(ctx).cancel(kidEventNotifId(eventId));
    }

    private static int kidPaymentNotifId(long id) { return 100_000 + (int) id; }
    private static int kidEventNotifId(long id)   { return 200_000 + (int) id; }
}
