package sk.aetheriqa.noteiqa.ui.home;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.data.entity.WeightEntry;
import sk.aetheriqa.noteiqa.data.preferences.UserPreferences;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.data.repository.TaskRepository;
import sk.aetheriqa.noteiqa.data.repository.WeightRepository;
import sk.aetheriqa.noteiqa.util.DateUtils;
import sk.aetheriqa.noteiqa.util.MotivationalQuotes;
import sk.aetheriqa.noteiqa.util.TaskBucketSorter;

/**
 * HomeFragment – dashboard.
 *
 *  - Avatar kruh (foto z UserPreferences alebo iniciálka mena)
 *  - "Ahoj {name}" v gold serif
 *  - Náhodná motivačná veta z MD súboru (rotácia bez opakovania 30 dní)
 *  - "A ako ti teda pomôžem?" submotto
 *  - 4 quick action pills (To do list, Nákup, Váženie, Poznámky)
 *  - Info panel: dátum, dnešné úlohy, posledné váženie
 *
 * Pozn. motivačná veta sa volí pri každom onResume() (aj keď tab odsunieš a
 * vrátiš sa) — Marekova požiadavka "rotuje aj 5× za deň".
 *
 * Komunikácia s ostatnými tabmi: cez {@link OnQuickActionListener} na hostovi
 * (MainActivity), aby quick actions vedeli prepnúť tab alebo otvoriť activity.
 */
public class HomeFragment extends Fragment {

    public static final String QUICK_TODO = "todo";
    public static final String QUICK_SHOPPING = "shopping";
    public static final String QUICK_WEIGHT = "weight";
    public static final String QUICK_NOTES = "notes";
    public static final String QUICK_KIDS = "kids";

    /** Max počet položiek v riadku Deti, zvyšok ako "+N". */
    private static final int KIDS_ROW_MAX = 2;

    public interface OnQuickActionListener {
        void onQuickAction(String which);
    }

    private OnQuickActionListener listener;

    private FrameView views;

    /** Lightweight container pre child views – aby som nemal milión privátnych polí. */
    private static class FrameView {
        ImageView avatarPhoto;
        TextView avatarInitial;
        View avatarContainer;
        TextView greeting;
        TextView motivational;
        TextView infoDate;
        TextView infoTasks;
        TextView infoWeight;
        // v1.2.0 — Deti
        TextView infoKidEvents;
        TextView infoKidPayments;
        // v1.0.0 — Streaks
        View streaksContainer;
        TextView streakWeight;
        TextView streakTasks;
        TextView streakApp;
        // v1.0.0 — Insight
        TextView insightSummary;
        TextView insightBestDay;
        TextView insightTrend;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnQuickActionListener) {
            listener = (OnQuickActionListener) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        views = new FrameView();
        views.avatarContainer = view.findViewById(R.id.home_avatar_container);
        views.avatarPhoto = view.findViewById(R.id.home_avatar_photo);
        views.avatarInitial = view.findViewById(R.id.home_avatar_initial);
        views.greeting = view.findViewById(R.id.home_greeting);
        views.motivational = view.findViewById(R.id.home_motivational);
        views.infoDate = view.findViewById(R.id.home_info_date);
        views.infoTasks = view.findViewById(R.id.home_info_tasks);
        views.infoWeight = view.findViewById(R.id.home_info_weight);
        views.infoKidEvents = view.findViewById(R.id.home_info_kid_events);
        views.infoKidPayments = view.findViewById(R.id.home_info_kid_payments);
        views.infoKidEvents.setOnClickListener(v -> fire(QUICK_KIDS));
        views.infoKidPayments.setOnClickListener(v -> fire(QUICK_KIDS));

        // v1.0.0 — Streaks
        views.streaksContainer = view.findViewById(R.id.home_streaks);
        views.streakWeight = view.findViewById(R.id.streak_weight);
        views.streakTasks = view.findViewById(R.id.streak_tasks);
        views.streakApp = view.findViewById(R.id.streak_app);

        // v1.0.0 — Insight
        views.insightSummary = view.findViewById(R.id.insight_summary);
        views.insightBestDay = view.findViewById(R.id.insight_best_day);
        views.insightTrend = view.findViewById(R.id.insight_trend);

        // Avatar — klik vedie do Nastavení
        views.avatarContainer.setOnClickListener(v -> {
            if (listener != null) listener.onQuickAction("settings");
        });

        // Quick actions
        view.findViewById(R.id.home_quick_todo).setOnClickListener(v ->
                fire(QUICK_TODO));
        view.findViewById(R.id.home_quick_shopping).setOnClickListener(v ->
                fire(QUICK_SHOPPING));
        view.findViewById(R.id.home_quick_weight).setOnClickListener(v ->
                fire(QUICK_WEIGHT));
        view.findViewById(R.id.home_quick_notes).setOnClickListener(v ->
                fire(QUICK_NOTES));
        view.findViewById(R.id.home_quick_kids).setOnClickListener(v ->
                fire(QUICK_KIDS));

        // Live data observers
        TaskRepository taskRepo = TaskRepository.getInstance(requireContext().getApplicationContext());
        WeightRepository weightRepo = WeightRepository.getInstance(requireContext().getApplicationContext());

        // Dnešné úlohy = aktívne v bucketu DNES (vrátane expirovaných)
        taskRepo.observeActive().observe(getViewLifecycleOwner(), this::renderTodayCount);

        // Posledné váženie
        weightRepo.observeLatest().observe(getViewLifecycleOwner(), this::renderLastWeight);
    }

    @Override
    public void onResume() {
        super.onResume();
        // Refresh personalizovaných údajov pri každom otvorení tabu
        renderProfile();
        renderMotivationalQuote();
        renderDate();
        renderStreaks();
        renderInsight();
        renderKids();
    }

    private void fire(String which) {
        if (listener != null) listener.onQuickAction(which);
    }

    // ===== Renderery =====

    private void renderProfile() {
        UserPreferences prefs = UserPreferences.get(requireContext());
        String name = prefs.getDisplayName();

        views.greeting.setText(getString(R.string.home_greeting_format, name));

        // Avatar: ak existuje foto v internej zložke, zobraz; inak iniciálka
        String photoPath = prefs.getPhotoPath();
        boolean hasPhoto = !TextUtils.isEmpty(photoPath) && new File(photoPath).exists();

        if (hasPhoto) {
            // v1.0.1 — Java BitmapShader robí spoľahlivý circular crop;
            // nezávislé od ShapeableImageView clip ktorý môže na MIUI zlyhať.
            float density = getResources().getDisplayMetrics().density;
            int containerPx = sk.aetheriqa.noteiqa.util.BitmapUtils.dpToPx(120f, density);
            int ringMarginPx = sk.aetheriqa.noteiqa.util.BitmapUtils.dpToPx(3f, density);

            android.graphics.Bitmap circular = sk.aetheriqa.noteiqa.util.BitmapUtils
                    .loadCircular(photoPath, containerPx, ringMarginPx);

            if (circular != null) {
                views.avatarPhoto.setImageBitmap(circular);
                views.avatarPhoto.setVisibility(View.VISIBLE);
                views.avatarInitial.setVisibility(View.GONE);
            } else {
                showInitialFallback(prefs);
            }
        } else {
            showInitialFallback(prefs);
        }
    }

    private void showInitialFallback(UserPreferences prefs) {
        views.avatarPhoto.setVisibility(View.GONE);
        views.avatarPhoto.setImageDrawable(null);
        views.avatarInitial.setVisibility(View.VISIBLE);
        views.avatarInitial.setText(prefs.getInitial());
    }

    private void renderMotivationalQuote() {
        // Idempotentný retry pre prípad, že init z NoteiqaApplication.onCreate
        // ešte nedokončil (race condition pri rýchlom spustení appky)
        sk.aetheriqa.noteiqa.util.MotivationalQuotes.ensureDefaultImported(requireContext());

        String q = MotivationalQuotes.pickQuote(requireContext());
        if (TextUtils.isEmpty(q)) {
            views.motivational.setText(R.string.home_no_quote_placeholder);
            views.motivational.setAlpha(0.6f);
        } else {
            views.motivational.setText(q);
            views.motivational.setAlpha(1f);
        }
    }

    private void renderDate() {
        Locale sk = new Locale("sk", "SK");
        // "nedeľa, 26. apríla 2026"
        SimpleDateFormat fmt = new SimpleDateFormat("EEEE, d. MMMM yyyy", sk);
        views.infoDate.setText(capitalizeFirst(fmt.format(new Date())));
    }

    private String capitalizeFirst(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private void renderTodayCount(@Nullable List<Task> activeTasks) {
        int count = 0;
        if (activeTasks != null) {
            // Spočítaj všetky tasky, ktoré bucketize zaradí do TODAY (zahŕňa expirované)
            java.util.Map<TaskBucketSorter.Bucket, java.util.List<Task>> buckets =
                    TaskBucketSorter.bucketize(activeTasks);
            java.util.List<Task> today = buckets.get(TaskBucketSorter.Bucket.TODAY);
            if (today != null) count = today.size();
        }
        views.infoTasks.setText(getString(R.string.home_info_today_tasks, count));
    }

    private void renderLastWeight(@Nullable WeightEntry latest) {
        if (latest == null) {
            views.infoWeight.setText(R.string.home_info_no_weight);
            return;
        }
        String kg = String.format(Locale.getDefault(), "%.1f", latest.kg).replace('.', ',');
        views.infoWeight.setText(getString(R.string.home_info_last_weight, kg));
    }

    // ===== v1.2.0 — Deti =====

    private void renderKids() {
        Context appCtx = requireContext().getApplicationContext();
        new Thread(() -> {
            KidRepository repo = KidRepository.getInstance(appCtx);
            // Calendar (nie java.time) — minSdk 24 bez desugaringu
            Calendar c = Calendar.getInstance();
            c.set(Calendar.HOUR_OF_DAY, 0);
            c.set(Calendar.MINUTE, 0);
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);
            long dayStart = c.getTimeInMillis();
            c.add(Calendar.DAY_OF_MONTH, 1);
            long dayEnd = c.getTimeInMillis();

            List<Kid> kids = repo.getKidsSync();
            List<KidEvent> events = repo.getEventsInRangeSync(dayStart, dayEnd);
            List<KidPayment> payments = repo.getUnpaidDueBeforeSync(dayEnd);

            new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                if (!isAdded() || views == null) return;
                applyKids(kids, events, payments, dayStart);
            });
        }, "HomeKids").start();
    }

    private void applyKids(List<Kid> kids, List<KidEvent> events,
                           List<KidPayment> payments, long dayStart) {
        List<String> eventParts = new ArrayList<>();
        for (KidEvent e : events) {
            String kidName = kidName(kids, e.kidIdOrAll());
            if (e.allDay || e.startDate < dayStart) {
                eventParts.add(getString(R.string.home_kid_event_item, e.title, kidName));
            } else {
                eventParts.add(getString(R.string.home_kid_event_item_time,
                        e.title, DateUtils.formatTime(e.startDate), kidName));
            }
        }
        bindKidsRow(views.infoKidEvents, eventParts);

        List<String> paymentParts = new ArrayList<>();
        for (KidPayment p : payments) {
            String label = getString(p.dueDate < dayStart
                    ? R.string.home_kid_payment_overdue
                    : R.string.home_kid_payment_due, p.title);
            if (p.amountEur != null) {
                String amount = String.format(Locale.getDefault(), "%.2f", p.amountEur)
                        .replace('.', ',');
                label = getString(R.string.home_kid_payment_amount, label, amount);
            }
            paymentParts.add(label);
        }
        bindKidsRow(views.infoKidPayments, paymentParts);
    }

    private void bindKidsRow(TextView row, List<String> parts) {
        if (parts.isEmpty()) {
            row.setVisibility(View.GONE);
            return;
        }
        StringBuilder sb = new StringBuilder();
        int shown = Math.min(parts.size(), KIDS_ROW_MAX);
        for (int i = 0; i < shown; i++) {
            if (i > 0) sb.append(", ");
            sb.append(parts.get(i));
        }
        if (parts.size() > shown) {
            sb.append(getString(R.string.home_kid_more, parts.size() - shown));
        }
        row.setText(sb.toString());
        row.setVisibility(View.VISIBLE);
    }

    private String kidName(List<Kid> kids, long kidId) {
        if (kidId != KidRepository.KID_ID_ALL && kids != null) {
            for (Kid k : kids) if (k.id == kidId) return k.name;
        }
        return getString(R.string.kids_label_all);
    }

    // ===== v1.0.0 — Streaks =====

    private void renderStreaks() {
        // Compute na background, render na main
        Context appCtx = requireContext().getApplicationContext();
        new Thread(() -> {
            sk.aetheriqa.noteiqa.util.StreakCalculator.Streaks s =
                    sk.aetheriqa.noteiqa.util.StreakCalculator.compute(appCtx);
            new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                if (!isAdded() || views == null) return;
                applyStreaks(s);
            });
        }, "Streaks").start();
    }

    private void applyStreaks(sk.aetheriqa.noteiqa.util.StreakCalculator.Streaks s) {
        boolean any = false;

        if (s.hasWeightStreak()) {
            views.streakWeight.setText("🔥 " + getString(R.string.streak_weight_format, s.weightStreakDays));
            views.streakWeight.setVisibility(View.VISIBLE);
            any = true;
        } else {
            views.streakWeight.setVisibility(View.GONE);
        }

        if (s.hasTasksStreak()) {
            views.streakTasks.setText("✨ " + getString(R.string.streak_tasks_format, s.tasksDoneThisWeek));
            views.streakTasks.setVisibility(View.VISIBLE);
            any = true;
        } else {
            views.streakTasks.setVisibility(View.GONE);
        }

        if (s.hasAppAge()) {
            String text = sk.aetheriqa.noteiqa.util.StreakCalculator.formatAppAge(
                    requireContext(), s.appAgeDays);
            views.streakApp.setText("💪 " + text);
            views.streakApp.setVisibility(View.VISIBLE);
            any = true;
        } else {
            views.streakApp.setVisibility(View.GONE);
        }

        views.streaksContainer.setVisibility(any ? View.VISIBLE : View.GONE);
    }

    // ===== v1.0.0 — Weekly insight =====

    private void renderInsight() {
        sk.aetheriqa.noteiqa.util.WeeklyInsight.loadAsync(requireContext(), result -> {
            if (!isAdded() || views == null) return;
            applyInsight(result);
        });
    }

    private void applyInsight(sk.aetheriqa.noteiqa.util.WeeklyInsight.Result r) {
        // Summary line: "−0,8 kg · 12 hotových úloh · 3 vážené dni"
        String change = sk.aetheriqa.noteiqa.util.WeeklyInsight
                .formatWeightChange(requireContext(), r.weightChangeKg);
        views.insightSummary.setText(getString(R.string.insight_summary_format,
                change, r.tasksCompletedCount, r.weightDaysCount));

        // Najproduktívnejší deň
        if (r.mostProductiveDayOfWeek != null) {
            String day = sk.aetheriqa.noteiqa.util.WeeklyInsight
                    .slovakDayName(r.mostProductiveDayOfWeek);
            views.insightBestDay.setText(getString(R.string.insight_best_day_format, day));
        } else {
            views.insightBestDay.setText(R.string.insight_best_day_none);
        }

        // Trend
        switch (r.trend) {
            case FALLING:
                views.insightTrend.setText(R.string.insight_trend_falling); break;
            case STABLE:
                views.insightTrend.setText(R.string.insight_trend_stable); break;
            case RISING:
                views.insightTrend.setText(R.string.insight_trend_rising); break;
            case NO_DATA:
            default:
                views.insightTrend.setText(R.string.insight_trend_no_data); break;
        }
    }
}
