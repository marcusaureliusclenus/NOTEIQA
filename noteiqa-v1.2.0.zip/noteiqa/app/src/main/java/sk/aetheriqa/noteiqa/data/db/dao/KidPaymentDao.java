package sk.aetheriqa.noteiqa.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import sk.aetheriqa.noteiqa.data.entity.KidPayment;

@Dao
public interface KidPaymentDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(KidPayment payment);

    @Update
    int update(KidPayment payment);

    @Delete
    int delete(KidPayment payment);

    @Query("DELETE FROM kid_payments WHERE id = :id")
    int deleteById(long id);

    @Query("SELECT * FROM kid_payments WHERE id = :id")
    KidPayment getById(long id);

    /** Všetky platby (aj zaplatené) pre konkrétne dieťa, zoradené podľa splatnosti. */
    @Query("SELECT * FROM kid_payments WHERE kidId = :kidId ORDER BY dueDate ASC")
    LiveData<List<KidPayment>> observeByKid(long kidId);

    /** Všetky platby všetkých detí zoradené podľa splatnosti. */
    @Query("SELECT * FROM kid_payments ORDER BY dueDate ASC")
    LiveData<List<KidPayment>> observeAll();

    /** Sync – pre notifikačný scheduler a export. */
    @Query("SELECT * FROM kid_payments")
    List<KidPayment> getAllSync();

    /** Aktívne (nezaplatené) platby s notifyAt > now — pre BootReceiver re-schedule. */
    @Query("SELECT * FROM kid_payments WHERE completed = 0 AND notifyAt > :now")
    List<KidPayment> getUpcomingRemindersSync(long now);

    @Query("UPDATE kid_payments SET completed = :completed, " +
           "completedAt = CASE WHEN :completed THEN :ts ELSE 0 END, updatedAt = :ts WHERE id = :id")
    int setCompleted(long id, boolean completed, long ts);

    /** v1.2.0 — Domov: nezaplatené platby so splatnosťou pred {@code until} (dnes + po termíne). */
    @Query("SELECT * FROM kid_payments WHERE completed = 0 AND dueDate > 0 AND dueDate < :until " +
           "ORDER BY dueDate ASC")
    List<KidPayment> getUnpaidDueBeforeSync(long until);

    /**
     * v1.2.0 — "Tento mesiac ostáva": suma nezaplatených so splatnosťou pred koncom
     * aktuálneho mesiaca (teda tento mesiac + po termíne z minulých mesiacov).
     */
    @Query("SELECT COALESCE(SUM(amountEur), 0) FROM kid_payments " +
           "WHERE completed = 0 AND amountEur IS NOT NULL AND dueDate > 0 AND dueDate < :until")
    LiveData<Double> observeOutstandingBefore(long until);

    @Query("SELECT COALESCE(SUM(amountEur), 0) FROM kid_payments " +
           "WHERE completed = 0 AND amountEur IS NOT NULL AND dueDate > 0 AND dueDate < :until " +
           "AND kidId = :kidId")
    LiveData<Double> observeOutstandingBeforeForKid(long until, long kidId);

    /** v1.2.0 — koľko inštancií už vzniklo z tejto platby (ochrana pred duplicitou pri opakovaní). */
    @Query("SELECT COUNT(*) FROM kid_payments WHERE originPaymentId = :originId")
    int countByOrigin(long originId);
}
