# Noteiqa – ProGuard rules
# Žiadne tracking SDKs, čisté pravidlá

# Room
-keep class androidx.room.** { *; }
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# MPAndroidChart
-keep class com.github.mikephil.charting.** { *; }
-dontwarn com.github.mikephil.charting.**

# Reflection-based JSON serializers (ak by sa neskôr pridali)
-keepattributes Signature
-keepattributes *Annotation*

# Sk lokalizácia – zachovať všetky string resources
-keep class **.R$string { *; }

# v1.2.0 — Backup export/import serializuje Room entity reflexiou podľa názvov
# polí (BackupExporter.entityToJson / BackupImporter.jsonToEntity). R8 nesmie
# polia premenovať ani odstrániť no-arg konštruktor, inak by data.json
# v release builde mal obfuskované kľúče a obnova by nefungovala.
-keep class sk.aetheriqa.noteiqa.data.entity.** { *; }
