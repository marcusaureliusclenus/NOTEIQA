package sk.aetheriqa.noteiqa.data.repository;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.Nullable;
import androidx.lifecycle.LiveData;

import java.util.Calendar;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import sk.aetheriqa.noteiqa.data.db.AppDatabase;
import sk.aetheriqa.noteiqa.data.db.dao.KidDao;
import sk.aetheriqa.noteiqa.data.db.dao.KidEventDao;
import sk.aetheriqa.noteiqa.data.db.dao.KidPaymentDao;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;

/**
 * KidRepository – správa detí, ich platieb a udalostí.
 *
 * Seed pri prvom otvorení: Alex (modrá) + Gabika (ružová).
 * Všetky DB operácie na background threade cez ExecutorService.
 *
 * Notifikácie:
 *  - platby → KidPaymentReminderScheduler.schedule pri save
 *  - udalosti → KidEventReminderScheduler.schedule pri save
 *  - archive/delete → cancel odpovedajúceho reminderu
 */
public class KidRepository {

    /** Special kidId value: udalosť/platba sa týka všetkých detí. */
    public static final long KID_ID_ALL = 0L;

    private static volatile KidRepository INSTANCE;

    public static KidRepository getInstance(Context ctx) {
        if (INSTANCE == null) {
            synchronized (KidRepository.class) {
                if (INSTANCE == null) INSTANCE = new KidRepository(ctx);
            }
        }
        return INSTANCE;
    }

    private final KidDao kidDao;
    private final KidPaymentDao paymentDao;
    private final KidEventDao eventDao;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Context appContext;
    private final AppDatabase db;

    private KidRepository(Context ctx) {
        AppDatabase db = AppDatabase.getInstance(ctx);
        this.db = db;
        this.kidDao = db.kidDao();
        this.paymentDao = db.kidPaymentDao();
        this.eventDao = db.kidEventDao();
        this.appContext = ctx.getApplicationContext();

        executor.execute(this::seedKidsIfEmpty);
    }

    /** Idempotentný seed 2 default detí pri prvom spustení Deti modulu. */
    private void seedKidsIfEmpty() {
        if (kidDao.count() > 0) return;
        long now = System.currentTimeMillis();

        Kid alex = new Kid("Alex", "#5B8DEF", 0);   // modrá
        alex.createdAt = now;
        alex.updatedAt = now;
        kidDao.insert(alex);

        Kid gabika = new Kid("Gabika", "#E39CC4", 1); // jemná ružová
        gabika.createdAt = now;
        gabika.updatedAt = now;
        kidDao.insert(gabika);
    }

    /** v1.2.0 — po obnove zo zálohy bez detí (staršia schéma) znova zaseeduj Alex/Gabika. */
    public void ensureKidsSeeded() {
        executor.execute(this::seedKidsIfEmpty);
    }

    // ===== Kids =====

    public LiveData<List<Kid>> observeKids() {
        return kidDao.observeAll();
    }

    public List<Kid> getKidsSync() {
        return kidDao.getAllSync();
    }

    /** v1.2.0 — premenovanie dieťaťa z Nastavení (farba a poradie ostávajú). */
    public void renameKid(long kidId, String newName, @Nullable Runnable onDone) {
        executor.execute(() -> {
            Kid k = kidDao.getById(kidId);
            if (k == null) return;
            k.name = newName.trim();
            k.updatedAt = System.currentTimeMillis();
            kidDao.update(k);
            if (onDone != null) mainHandler.post(onDone);
        });
    }

    // ===== Payments =====

    public LiveData<List<KidPayment>> observePayments() {
        return paymentDao.observeAll();
    }

    public LiveData<List<KidPayment>> observePaymentsByKid(long kidId) {
        return paymentDao.observeByKid(kidId);
    }

    /**
     * v1.2.0 — súčet nezaplatených platieb so splatnosťou do konca aktuálneho mesiaca.
     * kidId = KID_ID_ALL → všetky deti.
     */
    public LiveData<Double> observeOutstandingThisMonth(long kidId) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.DAY_OF_MONTH, 1);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        c.add(Calendar.MONTH, 1);
        long until = c.getTimeInMillis();
        return kidId == KID_ID_ALL
                ? paymentDao.observeOutstandingBefore(until)
                : paymentDao.observeOutstandingBeforeForKid(until, kidId);
    }

    public void savePayment(KidPayment payment, OnSavedCallback cb) {
        executor.execute(() -> {
            long now = System.currentTimeMillis();
            if (payment.createdAt == 0L) payment.createdAt = now;
            payment.updatedAt = now;

            long id;
            if (payment.id == 0L) {
                id = paymentDao.insert(payment);
                payment.id = id;
            } else {
                paymentDao.update(payment);
                id = payment.id;
            }

            sk.aetheriqa.noteiqa.notification.KidReminderScheduler
                    .schedulePayment(appContext, payment);

            if (cb != null) cb.onSaved(id);
        });
    }

    public void setPaymentCompleted(long id, boolean completed) {
        setPaymentCompleted(id, completed, null);
    }

    /**
     * v1.2.0 — označí platbu (ne)zaplatenú. Pri zaplatení opakovanej platby
     * vytvorí ďalšiu inštanciu (pozri {@link #setPaymentCompletedSync}).
     * Callback beží na main threade; {@code next} je null, ak nová nevznikla.
     */
    public void setPaymentCompleted(long id, boolean completed,
                                    @Nullable OnPaymentCompletedCallback cb) {
        executor.execute(() -> {
            KidPayment next = setPaymentCompletedSync(id, completed);
            if (cb != null) mainHandler.post(() -> cb.onCompleted(next));
        });
    }

    /**
     * Synchrónna verzia — pre BroadcastReceiver (notifikačná akcia „Zaplatené“).
     * Nevolať z UI threadu.
     *
     * Pri completed = true a recurrence != NONE:
     *  1. pôvodná ostane v histórii (completed, completedAt = now)
     *  2. vznikne nová kópia s posunutou splatnosťou (Calendar.add, 31.1. → koniec februára)
     *  3. notifyAt drží rovnaký odstup (dni + čas dňa) ako originál; 0 ostane 0
     *  4. nová platba sa naplánuje
     * Odznačenie ďalšiu inštanciu nemaže. Opätovné označenie novú nevyrobí
     * (kontrola cez originPaymentId).
     *
     * @return novovytvorená ďalšia platba alebo null
     */
    @Nullable
    public KidPayment setPaymentCompletedSync(long id, boolean completed) {
        KidPayment[] next = new KidPayment[1];
        db.runInTransaction(() -> {
            KidPayment p = paymentDao.getById(id);
            if (p == null) return;
            long now = System.currentTimeMillis();
            paymentDao.setCompleted(id, completed, now);
            if (!completed) return;
            if (p.recurrence == KidPayment.RECURRENCE_NONE || p.dueDate <= 0L) return;
            if (paymentDao.countByOrigin(id) > 0) return;

            KidPayment n = buildNextInstance(p, now);
            n.id = paymentDao.insert(n);
            next[0] = n;
        });

        if (completed) {
            sk.aetheriqa.noteiqa.notification.KidReminderScheduler
                    .cancelPayment(appContext, id);
            if (next[0] != null) {
                sk.aetheriqa.noteiqa.notification.KidReminderScheduler
                        .schedulePayment(appContext, next[0]);
            }
        } else {
            KidPayment p = paymentDao.getById(id);
            if (p != null) {
                sk.aetheriqa.noteiqa.notification.KidReminderScheduler
                        .schedulePayment(appContext, p);
            }
        }
        return next[0];
    }

    /** Kópia platby s posunutou splatnosťou podľa recurrence. */
    static KidPayment buildNextInstance(KidPayment p, long now) {
        KidPayment n = new KidPayment();
        n.kidId = p.kidId;
        n.title = p.title;
        n.amountEur = p.amountEur;
        n.paymentMethod = p.paymentMethod;
        n.iban = p.iban;
        n.variableSymbol = p.variableSymbol;
        n.specificSymbol = p.specificSymbol;
        n.paymentNote = p.paymentNote;
        n.cashRecipient = p.cashRecipient;
        n.note = p.note;
        n.recurrence = p.recurrence;
        n.originPaymentId = p.id;
        n.completed = false;
        n.completedAt = 0L;
        n.createdAt = now;
        n.updatedAt = now;
        n.dueDate = shiftByRecurrence(p.dueDate, p.recurrence);

        if (p.notifyAt > 0L) {
            // Rovnaký odstup v kalendárnych dňoch + rovnaký čas dňa (odolné voči DST).
            Calendar due = Calendar.getInstance();
            due.setTimeInMillis(p.dueDate);
            Calendar notify = Calendar.getInstance();
            notify.setTimeInMillis(p.notifyAt);
            int dayDiff = daysBetween(notify, due);

            Calendar nn = Calendar.getInstance();
            nn.setTimeInMillis(n.dueDate);
            nn.add(Calendar.DAY_OF_MONTH, -dayDiff);
            nn.set(Calendar.HOUR_OF_DAY, notify.get(Calendar.HOUR_OF_DAY));
            nn.set(Calendar.MINUTE, notify.get(Calendar.MINUTE));
            nn.set(Calendar.SECOND, 0);
            nn.set(Calendar.MILLISECOND, 0);
            n.notifyAt = nn.getTimeInMillis();
        } else {
            n.notifyAt = 0L;
        }
        return n;
    }

    /** +1 mesiac / +3 mesiace / +1 rok cez Calendar.add (deň sa zarovná na koniec mesiaca). */
    static long shiftByRecurrence(long ts, int recurrence) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ts);
        switch (recurrence) {
            case KidPayment.RECURRENCE_MONTHLY:   c.add(Calendar.MONTH, 1); break;
            case KidPayment.RECURRENCE_QUARTERLY: c.add(Calendar.MONTH, 3); break;
            case KidPayment.RECURRENCE_YEARLY:    c.add(Calendar.YEAR, 1); break;
            default: break;
        }
        return c.getTimeInMillis();
    }

    /** Počet kalendárnych dní od {@code from} do {@code to} (to - from), bez ohľadu na čas. */
    private static int daysBetween(Calendar from, Calendar to) {
        Calendar a = (Calendar) from.clone();
        Calendar b = (Calendar) to.clone();
        for (Calendar c : new Calendar[]{a, b}) {
            c.set(Calendar.HOUR_OF_DAY, 12);
            c.set(Calendar.MINUTE, 0);
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);
        }
        return (int) Math.round((b.getTimeInMillis() - a.getTimeInMillis()) / 86_400_000.0);
    }

    public void deletePayment(long id) {
        executor.execute(() -> {
            sk.aetheriqa.noteiqa.notification.KidReminderScheduler
                    .cancelPayment(appContext, id);
            paymentDao.deleteById(id);
        });
    }

    /** v1.2.0 — Domov: nezaplatené so splatnosťou pred {@code until}. Nevolať z UI threadu. */
    public List<KidPayment> getUnpaidDueBeforeSync(long until) {
        return paymentDao.getUnpaidDueBeforeSync(until);
    }

    /** v1.3.0 — niť dňa (Domov). */
    public LiveData<List<KidPayment>> observeDueByDay(long dayEnd) {
        return paymentDao.observeDueByDay(dayEnd);
    }

    /** v1.3.0 — plagát týždňa / zoznam pre partnera. Nevolať z UI threadu. */
    public List<KidPayment> getUnpaidInRangeSync(long from, long to) {
        return paymentDao.getUnpaidInRangeSync(from, to);
    }

    /** v1.3.0 — hlasový návrh. Nevolať z UI threadu. */
    public List<KidPayment> getUnpaidSync() {
        return paymentDao.getUnpaidSync();
    }

    public KidPayment getPaymentSync(long id) {
        return paymentDao.getById(id);
    }

    // ===== Events =====

    public LiveData<List<KidEvent>> observeEvents() {
        return eventDao.observeAll();
    }

    /** v1.3.0 — niť dňa (Domov): len udalosti zasahujúce do daného dňa. */
    public LiveData<List<KidEvent>> observeDayEvents(long dayStart, long dayEnd) {
        return eventDao.observeDay(dayStart, dayEnd);
    }

    public LiveData<List<KidEvent>> observeEventsByKid(long kidId) {
        return eventDao.observeByKid(kidId);
    }

    public void saveEvent(KidEvent event, OnSavedCallback cb) {
        executor.execute(() -> {
            long now = System.currentTimeMillis();
            if (event.createdAt == 0L) event.createdAt = now;
            event.updatedAt = now;

            long id;
            if (event.id == 0L) {
                id = eventDao.insert(event);
                event.id = id;
            } else {
                eventDao.update(event);
                id = event.id;
            }

            sk.aetheriqa.noteiqa.notification.KidReminderScheduler
                    .scheduleEvent(appContext, event);

            if (cb != null) cb.onSaved(id);
        });
    }

    public void deleteEvent(long id) {
        executor.execute(() -> {
            sk.aetheriqa.noteiqa.notification.KidReminderScheduler
                    .cancelEvent(appContext, id);
            eventDao.deleteById(id);
        });
    }

    public KidEvent getEventSync(long id) {
        return eventDao.getById(id);
    }

    /** Pre injection do To Do listu. */
    public List<KidEvent> getEventsInRangeSync(long fromMillis, long toMillis) {
        return eventDao.getEventsInRangeSync(fromMillis, toMillis);
    }

    /** Pre BootReceiver re-schedule. */
    public void reschedulePendingReminders() {
        executor.execute(() -> {
            long now = System.currentTimeMillis();
            for (KidPayment p : paymentDao.getUpcomingRemindersSync(now)) {
                sk.aetheriqa.noteiqa.notification.KidReminderScheduler
                        .schedulePayment(appContext, p);
            }
            for (KidEvent e : eventDao.getUpcomingRemindersSync(now)) {
                sk.aetheriqa.noteiqa.notification.KidReminderScheduler
                        .scheduleEvent(appContext, e);
            }
        });
    }

    public interface OnSavedCallback {
        void onSaved(long id);
    }

    public interface OnPaymentCompletedCallback {
        /** @param next ďalšia vygenerovaná inštancia alebo null */
        void onCompleted(@Nullable KidPayment next);
    }
}
