package sk.aetheriqa.noteiqa.ui.kids;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.data.repository.TaskRepository;
import sk.aetheriqa.noteiqa.util.DialogThemes;

/**
 * ParentListDialog – v1.3.0 — "Zoznam pre partnera".
 *
 * Jeden tap → čistý text (udalosti detí, nezaplatené platby s IBAN/VS, úlohy
 * kategórie Rodina) do schránky + share text/plain. Žiadne PNG, QR ani upload.
 * Obdobie: Tento týždeň / Budúci týždeň (default — nedeľný večer) / Dnes + zajtra.
 */
final class ParentListDialog {

    static final int PERIOD_THIS_WEEK = 0;
    static final int PERIOD_NEXT_WEEK = 1;
    static final int PERIOD_TODAY_TOMORROW = 2;

    private static final Locale SK = new Locale("sk", "SK");

    private ParentListDialog() {}

    static void show(Context ctx) {
        final int[] period = {PERIOD_NEXT_WEEK};
        new AlertDialog.Builder(ctx, DialogThemes.LEA)
                .setTitle(R.string.parent_list_entry)
                .setSingleChoiceItems(new CharSequence[]{
                        ctx.getString(R.string.parent_list_this_week),
                        ctx.getString(R.string.parent_list_next_week),
                        ctx.getString(R.string.parent_list_today_tomorrow)
                }, period[0], (d, which) -> period[0] = which)
                .setPositiveButton(R.string.parent_list_copy_send, (d, w) -> buildAndShare(ctx, period[0]))
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    private static void buildAndShare(Context ctx, int period) {
        Context app = ctx.getApplicationContext();
        new Thread(() -> {
            String text = build(app, period);
            new Handler(Looper.getMainLooper()).post(() -> {
                ClipboardManager cm = (ClipboardManager) app.getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) {
                    cm.setPrimaryClip(ClipData.newPlainText(
                            app.getString(R.string.parent_list_entry), text));
                }
                Toast.makeText(app, R.string.parent_list_copied, Toast.LENGTH_SHORT).show();

                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, text);
                Intent chooser = Intent.createChooser(send, app.getString(R.string.parent_list_share_chooser));
                if (!(ctx instanceof android.app.Activity)) chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(chooser);
            });
        }, "ParentList").start();
    }

    /** Zostaví text. Nevolať z UI threadu (číta DB). */
    static String build(Context ctx, int period) {
        long from;
        int days;
        if (period == PERIOD_TODAY_TOMORROW) {
            from = startOfToday();
            days = 2;
        } else {
            from = KidsWeekPosterActivity.mondayOf(period == PERIOD_NEXT_WEEK ? 1 : 0);
            days = 7;
        }
        long[] dayStart = new long[days + 1];
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(from);
        for (int i = 0; i <= days; i++) {
            dayStart[i] = c.getTimeInMillis();
            c.add(Calendar.DAY_OF_MONTH, 1);
        }
        long to = dayStart[days];

        KidRepository kidRepo = KidRepository.getInstance(ctx);
        List<Kid> kids = kidRepo.getKidsSync();
        List<KidEvent> events = new ArrayList<>(kidRepo.getEventsInRangeSync(from, to));
        Collections.sort(events, (a, b) -> a.allDay != b.allDay
                ? (a.allDay ? -1 : 1) : Long.compare(a.startDate, b.startDate));
        List<KidPayment> payments = kidRepo.getUnpaidInRangeSync(from, to);
        List<Task> tasks = TaskRepository.getInstance(ctx).getOpenByCategoryInRangeSync(
                TaskRepository.FAMILY_CATEGORY_NAME, from, to);

        StringBuilder sb = new StringBuilder();
        List<String> names = new ArrayList<>();
        for (int i = 0; i < kids.size() && i < 2; i++) names.add(kids.get(i).name);
        String periodLabel = ctx.getString(period == PERIOD_THIS_WEEK ? R.string.parent_list_label_this_week
                : period == PERIOD_NEXT_WEEK ? R.string.parent_list_label_next_week
                : R.string.parent_list_label_today_tomorrow);
        sb.append(ctx.getString(R.string.parent_list_header, TextUtils.join(", ", names),
                periodLabel, rangeLabel(dayStart[0], dayStart[days - 1])));
        sb.append("\n");

        boolean any = false;
        SimpleDateFormat dayName = new SimpleDateFormat("EEEE", SK);
        SimpleDateFormat dayNum = new SimpleDateFormat("d.M.", SK);
        for (int i = 0; i < days; i++) {
            List<String> lines = new ArrayList<>();
            for (KidEvent e : events) {
                if (!e.coversDay(dayStart[i], dayStart[i + 1])) continue;
                String who = kidName(ctx, kids, e.kidIdOrAll());
                String what = TextUtils.isEmpty(e.note) ? e.title
                        : ctx.getString(R.string.parent_list_with_note, e.title, e.note);
                boolean timed = !e.allDay && e.startDate >= dayStart[i];
                lines.add(timed
                        ? ctx.getString(R.string.parent_list_event_time, timeOf(e.startDate), who, what)
                        : ctx.getString(R.string.parent_list_event, who, what));
            }
            for (Task t : tasks) {
                if (t.dueDate == null || t.dueDate < dayStart[i] || t.dueDate >= dayStart[i + 1]) continue;
                String title = t.title == null ? "" : t.title;
                lines.add(t.dueTimeMinutes != null
                        ? ctx.getString(R.string.parent_list_task_time, String.format(Locale.getDefault(),
                                "%d:%02d", t.dueTimeMinutes / 60, t.dueTimeMinutes % 60), title)
                        : ctx.getString(R.string.parent_list_task, title));
            }
            for (KidPayment p : payments) {
                if (p.dueDate < dayStart[i] || p.dueDate >= dayStart[i + 1]) continue;
                lines.add(paymentLine(ctx, kids, p));
            }
            if (lines.isEmpty()) continue;
            any = true;
            Date d = new Date(dayStart[i]);
            String name = dayName.format(d);
            name = name.substring(0, 1).toUpperCase(SK) + name.substring(1);
            sb.append("\n").append(name).append(' ').append(dayNum.format(d)).append("\n");
            for (String l : lines) sb.append(l).append("\n");
        }
        if (!any) sb.append("\n").append(ctx.getString(R.string.parent_list_empty)).append("\n");
        sb.append("\n").append(ctx.getString(R.string.parent_list_footer));
        return sb.toString();
    }

    private static String paymentLine(Context ctx, List<Kid> kids, KidPayment p) {
        String who = kidName(ctx, kids, p.kidId);
        String amount = p.amountEur != null
                ? ctx.getString(R.string.ticket_amount, PaymentTicketBinder.formatAmount(p.amountEur))
                : "";
        String line = ctx.getString(R.string.parent_list_payment, p.title, who, amount).trim();
        List<String> details = new ArrayList<>();
        if (p.paymentMethod == KidPayment.METHOD_TRANSFER) {
            if (!TextUtils.isEmpty(p.iban)) details.add(PaymentTicketBinder.groupIban(p.iban));
            if (!TextUtils.isEmpty(p.variableSymbol)) {
                details.add(ctx.getString(R.string.kid_payment_dialog_vs, p.variableSymbol));
            }
            if (!TextUtils.isEmpty(p.specificSymbol)) {
                details.add(ctx.getString(R.string.kid_payment_dialog_ss, p.specificSymbol));
            }
        } else if (p.paymentMethod == KidPayment.METHOD_CASH && !TextUtils.isEmpty(p.cashRecipient)) {
            details.add(ctx.getString(R.string.ticket_cash_for, p.cashRecipient));
        }
        if (!details.isEmpty()) line += " (" + TextUtils.join(", ", details) + ")";
        return line;
    }

    private static String kidName(Context ctx, List<Kid> kids, long kidId) {
        if (kidId != KidRepository.KID_ID_ALL) {
            for (Kid k : kids) if (k.id == kidId) return k.name;
        }
        return ctx.getString(R.string.kids_label_all);
    }

    /** "13.–19. okt" alebo "29. 9.–5. 10.". */
    private static String rangeLabel(long first, long last) {
        Calendar a = Calendar.getInstance();
        a.setTimeInMillis(first);
        Calendar b = Calendar.getInstance();
        b.setTimeInMillis(last);
        if (a.get(Calendar.MONTH) == b.get(Calendar.MONTH)) {
            String month = new SimpleDateFormat("LLL", SK).format(new Date(last)).replace(".", "");
            return a.get(Calendar.DAY_OF_MONTH) + ".–" + b.get(Calendar.DAY_OF_MONTH) + ". " + month;
        }
        return a.get(Calendar.DAY_OF_MONTH) + ". " + (a.get(Calendar.MONTH) + 1) + ".–"
                + b.get(Calendar.DAY_OF_MONTH) + ". " + (b.get(Calendar.MONTH) + 1) + ".";
    }

    private static String timeOf(long ts) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ts);
        return String.format(Locale.getDefault(), "%d:%02d",
                c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
    }

    private static long startOfToday() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }
}
