package sk.aetheriqa.noteiqa.ui.home;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.MediatorLiveData;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.data.entity.WeightEntry;
import sk.aetheriqa.noteiqa.data.preferences.UserPreferences;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.data.repository.TaskRepository;
import sk.aetheriqa.noteiqa.data.repository.WeightRepository;
import sk.aetheriqa.noteiqa.ui.kids.KidEventEditorActivity;
import sk.aetheriqa.noteiqa.ui.kids.PaymentTicketActivity;
import sk.aetheriqa.noteiqa.ui.kids.VoiceDraftLauncher;
import sk.aetheriqa.noteiqa.ui.todo.TaskDetailActivity;
import sk.aetheriqa.noteiqa.util.DateUtils;
import sk.aetheriqa.noteiqa.util.MotivationalQuotes;
import sk.aetheriqa.noteiqa.util.TaskBucketSorter;

/**
 * HomeFragment – dashboard.
 *
 *  - Avatar kruh (foto z UserPreferences alebo iniciálka mena)
 *  - "Ahoj {name}" v gold serif
 *  - Náhodná motivačná veta z MD súboru (rotácia bez opakovania 30 dní)
 *  - "A ako ti teda pomôžem?" submotto
 *  - 4 quick action pills (To do list, Nákup, Váženie, Poznámky)
 *  - Info panel: dátum, dnešné úlohy, posledné váženie
 *
 * Pozn. motivačná veta sa volí pri každom onResume() (aj keď tab odsunieš a
 * vrátiš sa) — Marekova požiadavka "rotuje aj 5× za deň".
 *
 * Komunikácia s ostatnými tabmi: cez {@link OnQuickActionListener} na hostovi
 * (MainActivity), aby quick actions vedeli prepnúť tab alebo otvoriť activity.
 */
public class HomeFragment extends Fragment {

    public static final String QUICK_TODO = "todo";
    public static final String QUICK_SHOPPING = "shopping";
    public static final String QUICK_WEIGHT = "weight";
    public static final String QUICK_NOTES = "notes";
    public static final String QUICK_KIDS = "kids";

    /** v1.3.0 — max bodov na niti dňa, zvyšok ako "+N ďalších". */
    private static final int THREAD_MAX = 6;

    public interface OnQuickActionListener {
        void onQuickAction(String which);
    }

    private OnQuickActionListener listener;

    private FrameView views;

    /** Lightweight container pre child views – aby som nemal milión privátnych polí. */
    private static class FrameView {
        ImageView avatarPhoto;
        TextView avatarInitial;
        View avatarContainer;
        TextView greeting;
        TextView motivational;
        TextView infoDate;
        TextView infoTasks;
        TextView infoWeight;
        // v1.3.0 — Zlatá niť dňa
        LinearLayout threadRows;
        // v1.0.0 — Streaks
        View streaksContainer;
        TextView streakWeight;
        TextView streakTasks;
        TextView streakApp;
        // v1.0.0 — Insight
        TextView insightSummary;
        TextView insightBestDay;
        TextView insightTrend;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnQuickActionListener) {
            listener = (OnQuickActionListener) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        views = new FrameView();
        views.avatarContainer = view.findViewById(R.id.home_avatar_container);
        views.avatarPhoto = view.findViewById(R.id.home_avatar_photo);
        views.avatarInitial = view.findViewById(R.id.home_avatar_initial);
        views.greeting = view.findViewById(R.id.home_greeting);
        views.motivational = view.findViewById(R.id.home_motivational);
        views.infoDate = view.findViewById(R.id.home_info_date);
        views.infoTasks = view.findViewById(R.id.home_info_tasks);
        views.infoWeight = view.findViewById(R.id.home_info_weight);
        views.threadRows = view.findViewById(R.id.home_thread_rows);
        voice = new VoiceDraftLauncher(this);
        view.findViewById(R.id.home_thread_mic).setOnClickListener(v ->
                voice.start(KidRepository.KID_ID_ALL));

        // v1.0.0 — Streaks
        views.streaksContainer = view.findViewById(R.id.home_streaks);
        views.streakWeight = view.findViewById(R.id.streak_weight);
        views.streakTasks = view.findViewById(R.id.streak_tasks);
        views.streakApp = view.findViewById(R.id.streak_app);

        // v1.0.0 — Insight
        views.insightSummary = view.findViewById(R.id.insight_summary);
        views.insightBestDay = view.findViewById(R.id.insight_best_day);
        views.insightTrend = view.findViewById(R.id.insight_trend);

        // Avatar — klik vedie do Nastavení
        views.avatarContainer.setOnClickListener(v -> {
            if (listener != null) listener.onQuickAction("settings");
        });

        // Quick actions
        view.findViewById(R.id.home_quick_todo).setOnClickListener(v ->
                fire(QUICK_TODO));
        view.findViewById(R.id.home_quick_shopping).setOnClickListener(v ->
                fire(QUICK_SHOPPING));
        view.findViewById(R.id.home_quick_weight).setOnClickListener(v ->
                fire(QUICK_WEIGHT));
        view.findViewById(R.id.home_quick_notes).setOnClickListener(v ->
                fire(QUICK_NOTES));
        view.findViewById(R.id.home_quick_kids).setOnClickListener(v ->
                fire(QUICK_KIDS));

        // Live data observers
        TaskRepository taskRepo = TaskRepository.getInstance(requireContext().getApplicationContext());
        WeightRepository weightRepo = WeightRepository.getInstance(requireContext().getApplicationContext());

        // Dnešné úlohy = aktívne v bucketu DNES (vrátane expirovaných)
        taskRepo.observeActive().observe(getViewLifecycleOwner(), this::renderTodayCount);

        // Posledné váženie
        weightRepo.observeLatest().observe(getViewLifecycleOwner(), this::renderLastWeight);

        // v1.3.0 — Zlatá niť dňa
        subscribeThread();
    }

    @Override
    public void onResume() {
        super.onResume();
        // Refresh personalizovaných údajov pri každom otvorení tabu
        renderProfile();
        renderMotivationalQuote();
        renderDate();
        renderStreaks();
        renderInsight();

        // v1.3.0 — niť: ak medzičasom prešla polnoc, prihlás sa na nový deň
        if (threadDayStart != startOfDay(System.currentTimeMillis())) subscribeThread();
        scheduleMidnightRefresh();
    }

    @Override
    public void onPause() {
        super.onPause();
        midnightHandler.removeCallbacks(midnightRefresh);
    }

    private void fire(String which) {
        if (listener != null) listener.onQuickAction(which);
    }

    // ===== Renderery =====

    private void renderProfile() {
        UserPreferences prefs = UserPreferences.get(requireContext());
        String name = prefs.getDisplayName();

        views.greeting.setText(getString(R.string.home_greeting_format, name));

        // Avatar: ak existuje foto v internej zložke, zobraz; inak iniciálka
        String photoPath = prefs.getPhotoPath();
        boolean hasPhoto = !TextUtils.isEmpty(photoPath) && new File(photoPath).exists();

        if (hasPhoto) {
            // v1.0.1 — Java BitmapShader robí spoľahlivý circular crop;
            // nezávislé od ShapeableImageView clip ktorý môže na MIUI zlyhať.
            float density = getResources().getDisplayMetrics().density;
            int containerPx = sk.aetheriqa.noteiqa.util.BitmapUtils.dpToPx(120f, density);
            int ringMarginPx = sk.aetheriqa.noteiqa.util.BitmapUtils.dpToPx(3f, density);

            android.graphics.Bitmap circular = sk.aetheriqa.noteiqa.util.BitmapUtils
                    .loadCircular(photoPath, containerPx, ringMarginPx);

            if (circular != null) {
                views.avatarPhoto.setImageBitmap(circular);
                views.avatarPhoto.setVisibility(View.VISIBLE);
                views.avatarInitial.setVisibility(View.GONE);
            } else {
                showInitialFallback(prefs);
            }
        } else {
            showInitialFallback(prefs);
        }
    }

    private void showInitialFallback(UserPreferences prefs) {
        views.avatarPhoto.setVisibility(View.GONE);
        views.avatarPhoto.setImageDrawable(null);
        views.avatarInitial.setVisibility(View.VISIBLE);
        views.avatarInitial.setText(prefs.getInitial());
    }

    private void renderMotivationalQuote() {
        // Idempotentný retry pre prípad, že init z NoteiqaApplication.onCreate
        // ešte nedokončil (race condition pri rýchlom spustení appky)
        sk.aetheriqa.noteiqa.util.MotivationalQuotes.ensureDefaultImported(requireContext());

        String q = MotivationalQuotes.pickQuote(requireContext());
        if (TextUtils.isEmpty(q)) {
            views.motivational.setText(R.string.home_no_quote_placeholder);
            views.motivational.setAlpha(0.6f);
        } else {
            views.motivational.setText(q);
            views.motivational.setAlpha(1f);
        }
    }

    private void renderDate() {
        Locale sk = new Locale("sk", "SK");
        // "nedeľa, 26. apríla 2026"
        SimpleDateFormat fmt = new SimpleDateFormat("EEEE, d. MMMM yyyy", sk);
        views.infoDate.setText(capitalizeFirst(fmt.format(new Date())));
    }

    private String capitalizeFirst(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private void renderTodayCount(@Nullable List<Task> activeTasks) {
        int count = 0;
        if (activeTasks != null) {
            // Spočítaj všetky tasky, ktoré bucketize zaradí do TODAY (zahŕňa expirované)
            java.util.Map<TaskBucketSorter.Bucket, java.util.List<Task>> buckets =
                    TaskBucketSorter.bucketize(activeTasks);
            java.util.List<Task> today = buckets.get(TaskBucketSorter.Bucket.TODAY);
            if (today != null) count = today.size();
        }
        views.infoTasks.setText(getString(R.string.home_info_today_tasks, count));
    }

    private void renderLastWeight(@Nullable WeightEntry latest) {
        if (latest == null) {
            views.infoWeight.setText(R.string.home_info_no_weight);
            return;
        }
        String kg = String.format(Locale.getDefault(), "%.1f", latest.kg).replace('.', ',');
        views.infoWeight.setText(getString(R.string.home_info_last_weight, kg));
    }

    // ===== v1.3.0 — Zlatá niť dňa =====

    private VoiceDraftLauncher voice;
    private final Handler midnightHandler = new Handler(Looper.getMainLooper());
    private final Runnable midnightRefresh = () -> {
        if (!isAdded() || views == null) return;
        subscribeThread();
        scheduleMidnightRefresh();
    };
    private MediatorLiveData<Boolean> threadTrigger;
    private long threadDayStart = -1L;

    private List<Task> threadTasks = new ArrayList<>();
    private List<KidEvent> threadEvents = new ArrayList<>();
    private List<KidPayment> threadPayments = new ArrayList<>();
    private List<Kid> threadKids = new ArrayList<>();
    @Nullable private WeightEntry threadWeight;

    /**
     * Prihlási sa na dáta dnešného dňa. Udalosti a platby idú cez úzke DAO dotazy
     * (observeDay / observeDueByDay), nie cez celý dataset. Volá sa pri vytvorení
     * view, po polnoci (Handler) a v onResume, ak sa zmenil deň.
     */
    private void subscribeThread() {
        if (threadTrigger != null) threadTrigger.removeObservers(getViewLifecycleOwner());

        long dayStart = startOfDay(System.currentTimeMillis());
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(dayStart);
        c.add(Calendar.DAY_OF_MONTH, 1);
        long dayEnd = c.getTimeInMillis();
        threadDayStart = dayStart;

        Context appCtx = requireContext().getApplicationContext();
        KidRepository kidRepo = KidRepository.getInstance(appCtx);

        MediatorLiveData<Boolean> m = new MediatorLiveData<>();
        m.addSource(TaskRepository.getInstance(appCtx).observeActive(), t -> {
            threadTasks = t != null ? t : new ArrayList<>();
            m.setValue(Boolean.TRUE);
        });
        m.addSource(kidRepo.observeDayEvents(dayStart, dayEnd), e -> {
            threadEvents = e != null ? e : new ArrayList<>();
            m.setValue(Boolean.TRUE);
        });
        m.addSource(kidRepo.observeDueByDay(dayEnd), p -> {
            threadPayments = p != null ? p : new ArrayList<>();
            m.setValue(Boolean.TRUE);
        });
        m.addSource(kidRepo.observeKids(), k -> {
            threadKids = k != null ? k : new ArrayList<>();
            m.setValue(Boolean.TRUE);
        });
        m.addSource(WeightRepository.getInstance(appCtx).observeLatest(), w -> {
            threadWeight = w;
            m.setValue(Boolean.TRUE);
        });
        threadTrigger = m;
        m.observe(getViewLifecycleOwner(), ignored -> renderThread(dayStart, dayEnd));
    }

    private void scheduleMidnightRefresh() {
        midnightHandler.removeCallbacks(midnightRefresh);
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(startOfDay(System.currentTimeMillis()));
        c.add(Calendar.DAY_OF_MONTH, 1);
        long delay = c.getTimeInMillis() - System.currentTimeMillis() + 1000L;
        midnightHandler.postDelayed(midnightRefresh, Math.max(delay, 1000L));
    }

    private static long startOfDay(long ts) {
        // Calendar (nie java.time) — minSdk 24 bez desugaringu
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ts);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    /** Jeden bod na niti. tier: 0 po splatnosti, 1 celodenné/splatné dnes, 2 s časom, 3 úloha bez času. */
    private static final class ThreadItem {
        int tier;
        long time;
        String timeText;
        String title;
        String subtitle;
        int color;
        View.OnClickListener click;
    }

    private void renderThread(long dayStart, long dayEnd) {
        if (!isAdded() || views == null) return;
        Context ctx = requireContext();
        int gold = ContextCompat.getColor(ctx, R.color.lea_gold);
        int overdue = ContextCompat.getColor(ctx, R.color.thread_overdue);
        List<ThreadItem> items = new ArrayList<>();

        // Úlohy s dnešným dueDate (nezarchivované, nedokončené)
        for (Task t : threadTasks) {
            if (t.completed || t.archivedAt != 0L || t.dueDate == null) continue;
            if (t.dueDate < dayStart || t.dueDate >= dayEnd) continue;
            ThreadItem it = new ThreadItem();
            if (t.dueTimeMinutes != null) {
                it.tier = 2;
                it.time = dayStart + t.dueTimeMinutes * 60_000L;
                it.timeText = String.format(Locale.getDefault(), "%d:%02d",
                        t.dueTimeMinutes / 60, t.dueTimeMinutes % 60);
            } else {
                it.tier = 3;
                it.timeText = "";
            }
            it.title = TextUtils.isEmpty(t.title) ? getString(R.string.thread_task) : t.title;
            it.subtitle = getString(R.string.thread_task);
            it.color = gold;
            final long taskId = t.id;
            it.click = v -> startActivity(TaskDetailActivity.newIntent(ctx, taskId));
            items.add(it);
        }

        // Udalosti detí, ktoré pokrývajú dnešok
        for (KidEvent e : threadEvents) {
            if (!e.coversDay(dayStart, dayEnd)) continue;
            Kid kid = findKid(e.kidIdOrAll());
            ThreadItem it = new ThreadItem();
            boolean allDay = e.allDay || e.startDate < dayStart;
            it.tier = allDay ? 1 : 2;
            it.time = allDay ? dayStart : e.startDate;
            it.timeText = allDay ? getString(R.string.kid_all_day_lower) : DateUtils.formatTime(e.startDate);
            it.title = e.title;
            it.subtitle = kid != null ? kid.name : getString(R.string.kids_label_all);
            it.color = kidColor(kid, gold);
            final long eventId = e.id;
            final long eventKid = e.kidIdOrAll();
            it.click = v -> startActivity(KidEventEditorActivity.newIntent(ctx, eventId, eventKid));
            items.add(it);
        }

        // Nezaplatené platby: dnes alebo po splatnosti
        for (KidPayment p : threadPayments) {
            if (p.completed || p.dueDate <= 0L || p.dueDate >= dayEnd) continue;
            Kid kid = findKid(p.kidId);
            boolean late = p.dueDate < dayStart;
            ThreadItem it = new ThreadItem();
            it.tier = late ? 0 : 1;
            it.time = p.dueDate;
            it.timeText = "";
            it.title = p.amountEur != null
                    ? getString(R.string.thread_payment_title, p.title,
                            String.format(Locale.getDefault(), "%.2f", p.amountEur).replace('.', ','))
                    : p.title;
            String who = kid != null ? kid.name : "";
            it.subtitle = getString(late ? R.string.thread_payment_overdue : R.string.thread_payment_due, who).trim();
            it.color = late ? overdue : kidColor(kid, gold);
            final long paymentId = p.id;
            it.click = v -> startActivity(PaymentTicketActivity.newIntent(ctx, paymentId));
            items.add(it);
        }

        // Posledné váženie — len ak je z dneška
        if (threadWeight != null && threadWeight.measuredAt >= dayStart && threadWeight.measuredAt < dayEnd) {
            ThreadItem it = new ThreadItem();
            it.tier = 2;
            it.time = threadWeight.measuredAt;
            it.timeText = DateUtils.formatTime(threadWeight.measuredAt);
            it.title = getString(R.string.thread_weight_title,
                    String.format(Locale.getDefault(), "%.1f", threadWeight.kg).replace('.', ','));
            it.subtitle = getString(R.string.thread_weight);
            it.color = gold;
            it.click = v -> fire(QUICK_WEIGHT);
            items.add(it);
        }

        Collections.sort(items, (a, b) -> a.tier != b.tier
                ? Integer.compare(a.tier, b.tier) : Long.compare(a.time, b.time));

        LinearLayout rows = views.threadRows;
        rows.removeAllViews();
        LayoutInflater inf = LayoutInflater.from(ctx);
        if (items.isEmpty()) {
            rows.addView(threadNote(ctx, getString(R.string.thread_empty)));
            return;
        }
        int shown = Math.min(items.size(), THREAD_MAX);
        for (int i = 0; i < shown; i++) {
            ThreadItem it = items.get(i);
            View row = inf.inflate(R.layout.item_thread_row, rows, false);
            View dot = row.findViewById(R.id.thread_dot);
            Drawable bg = dot.getBackground().mutate();
            if (bg instanceof GradientDrawable) ((GradientDrawable) bg).setColor(it.color);
            dot.setBackground(bg);
            ((TextView) row.findViewById(R.id.thread_time)).setText(it.timeText);
            ((TextView) row.findViewById(R.id.thread_title)).setText(it.title);
            ((TextView) row.findViewById(R.id.thread_subtitle)).setText(it.subtitle);
            row.setOnClickListener(it.click);
            rows.addView(row);
        }
        if (items.size() > shown) {
            rows.addView(threadNote(ctx, getString(R.string.thread_more, items.size() - shown)));
        }
    }

    private TextView threadNote(Context ctx, String text) {
        TextView tv = new TextView(ctx);
        tv.setText(text);
        tv.setTextColor(ContextCompat.getColor(ctx, R.color.text_secondary));
        tv.setTextSize(13f);
        int pad = (int) (8 * getResources().getDisplayMetrics().density);
        tv.setPadding((int) (36 * getResources().getDisplayMetrics().density), pad, 0, pad);
        return tv;
    }

    @Nullable
    private Kid findKid(long kidId) {
        if (kidId == KidRepository.KID_ID_ALL) return null;
        for (Kid k : threadKids) if (k.id == kidId) return k;
        return null;
    }

    private static int kidColor(@Nullable Kid kid, int fallback) {
        if (kid == null) return fallback;
        try {
            return android.graphics.Color.parseColor(kid.colorHex);
        } catch (IllegalArgumentException e) {
            return fallback;
        }
    }

    // ===== v1.0.0 — Streaks =====

    private void renderStreaks() {
        // Compute na background, render na main
        Context appCtx = requireContext().getApplicationContext();
        new Thread(() -> {
            sk.aetheriqa.noteiqa.util.StreakCalculator.Streaks s =
                    sk.aetheriqa.noteiqa.util.StreakCalculator.compute(appCtx);
            new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                if (!isAdded() || views == null) return;
                applyStreaks(s);
            });
        }, "Streaks").start();
    }

    private void applyStreaks(sk.aetheriqa.noteiqa.util.StreakCalculator.Streaks s) {
        boolean any = false;

        if (s.hasWeightStreak()) {
            views.streakWeight.setText("🔥 " + getString(R.string.streak_weight_format, s.weightStreakDays));
            views.streakWeight.setVisibility(View.VISIBLE);
            any = true;
        } else {
            views.streakWeight.setVisibility(View.GONE);
        }

        if (s.hasTasksStreak()) {
            views.streakTasks.setText("✨ " + getString(R.string.streak_tasks_format, s.tasksDoneThisWeek));
            views.streakTasks.setVisibility(View.VISIBLE);
            any = true;
        } else {
            views.streakTasks.setVisibility(View.GONE);
        }

        if (s.hasAppAge()) {
            String text = sk.aetheriqa.noteiqa.util.StreakCalculator.formatAppAge(
                    requireContext(), s.appAgeDays);
            views.streakApp.setText("💪 " + text);
            views.streakApp.setVisibility(View.VISIBLE);
            any = true;
        } else {
            views.streakApp.setVisibility(View.GONE);
        }

        views.streaksContainer.setVisibility(any ? View.VISIBLE : View.GONE);
    }

    // ===== v1.0.0 — Weekly insight =====

    private void renderInsight() {
        sk.aetheriqa.noteiqa.util.WeeklyInsight.loadAsync(requireContext(), result -> {
            if (!isAdded() || views == null) return;
            applyInsight(result);
        });
    }

    private void applyInsight(sk.aetheriqa.noteiqa.util.WeeklyInsight.Result r) {
        // Summary line: "−0,8 kg · 12 hotových úloh · 3 vážené dni"
        String change = sk.aetheriqa.noteiqa.util.WeeklyInsight
                .formatWeightChange(requireContext(), r.weightChangeKg);
        views.insightSummary.setText(getString(R.string.insight_summary_format,
                change, r.tasksCompletedCount, r.weightDaysCount));

        // Najproduktívnejší deň
        if (r.mostProductiveDayOfWeek != null) {
            String day = sk.aetheriqa.noteiqa.util.WeeklyInsight
                    .slovakDayName(r.mostProductiveDayOfWeek);
            views.insightBestDay.setText(getString(R.string.insight_best_day_format, day));
        } else {
            views.insightBestDay.setText(R.string.insight_best_day_none);
        }

        // Trend
        switch (r.trend) {
            case FALLING:
                views.insightTrend.setText(R.string.insight_trend_falling); break;
            case STABLE:
                views.insightTrend.setText(R.string.insight_trend_stable); break;
            case RISING:
                views.insightTrend.setText(R.string.insight_trend_rising); break;
            case NO_DATA:
            default:
                views.insightTrend.setText(R.string.insight_trend_no_data); break;
        }
    }
}
