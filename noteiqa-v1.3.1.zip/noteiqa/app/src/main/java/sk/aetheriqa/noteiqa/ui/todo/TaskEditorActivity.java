package sk.aetheriqa.noteiqa.ui.todo;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.data.entity.TaskCategory;
import sk.aetheriqa.noteiqa.data.repository.TaskRepository;
import sk.aetheriqa.noteiqa.util.DateUtils;
import sk.aetheriqa.noteiqa.util.ShoppingItems;

/**
 * TaskEditorActivity v2 – polia v poradí požadovanom Marekom:
 *   1. Názov
 *   2. Vyberte kategóriu
 *   3. Poznámka  (alebo Položky nákupu pri kategórii Nákup)
 *   4. Dátum dokončenia úlohy
 *   5. Začiatok úlohy
 *   6. Opakovanie úlohy
 *   7. Pripomenutie úlohy
 *   8. Pridajte podúlohu
 */
public class TaskEditorActivity extends AppCompatActivity {

    public static final String EXTRA_TASK_ID = "taskId";
    /** Voliteľný extras s názvom kategórie ktorú má editor pre-vybrať pri novej úlohe. */
    public static final String EXTRA_PRESELECT_CATEGORY = "preselectCategory";
    private static final long NEW_TASK_ID = 0L;

    private TaskRepository repo;
    private long taskId = NEW_TASK_ID;
    private Task editedTask;
    private boolean fieldsInitialized = false;

    private EditText editTitle;
    private EditText editNote;
    private TextView categoryValue;
    private TextView repeatValue;
    private TextView dueDateValue;
    private TextView dueTimeValue;
    private TextView reminderValue;
    private ImageView btnPriority;

    private LinearLayout rowNote;
    private LinearLayout rowShopping;
    private LinearLayout shoppingItemsContainer;
    private EditText shoppingNewItem;

    private List<TaskCategory> cachedCategories;
    private final List<ShoppingItems.Item> shoppingItems = new ArrayList<>();

    /** Android 13+ POST_NOTIFICATIONS runtime permission launcher. */
    private final androidx.activity.result.ActivityResultLauncher<String> notificationPermLauncher =
            registerForActivityResult(
                    new androidx.activity.result.contract.ActivityResultContracts.RequestPermission(),
                    granted -> {
                        if (granted) {
                            showReminderPickerInternal();
                        } else {
                            Toast.makeText(this, R.string.perm_notifications_required,
                                    Toast.LENGTH_LONG).show();
                        }
                    });

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_editor);

        repo = TaskRepository.getInstance(getApplicationContext());
        editedTask = new Task();
        editedTask.createdAt = System.currentTimeMillis();

        editTitle = findViewById(R.id.edit_title);
        editNote = findViewById(R.id.edit_note);
        categoryValue = findViewById(R.id.category_value);
        repeatValue = findViewById(R.id.repeat_value);
        dueDateValue = findViewById(R.id.due_date_value);
        dueTimeValue = findViewById(R.id.due_time_value);
        reminderValue = findViewById(R.id.reminder_value);
        btnPriority = findViewById(R.id.btn_priority);
        rowNote = findViewById(R.id.row_note);
        rowShopping = findViewById(R.id.row_shopping);
        shoppingItemsContainer = findViewById(R.id.shopping_items_container);
        shoppingNewItem = findViewById(R.id.shopping_new_item);

        MaterialToolbar toolbar = findViewById(R.id.editor_toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        FloatingActionButton btnSave = findViewById(R.id.btn_save_task);
        btnSave.setOnClickListener(v -> saveAndFinish());

        findViewById(R.id.row_category).setOnClickListener(v -> showCategoryPicker());
        findViewById(R.id.row_repeat).setOnClickListener(v -> showRepeatPicker());
        findViewById(R.id.row_due_date).setOnClickListener(v -> showDatePicker());
        findViewById(R.id.row_due_time).setOnClickListener(v -> showTimePicker());
        findViewById(R.id.row_reminder).setOnClickListener(v -> showReminderPicker());

        btnPriority.setOnClickListener(v -> togglePriority());
        findViewById(R.id.shopping_add_button).setOnClickListener(v -> addShoppingItem());

        repo.observeCategories().observe(this, cats -> {
            this.cachedCategories = cats;
            // Pre-select kategórie pre nové úlohy z dashboard quick actions ("Nákup")
            applyPreselectCategoryIfNeeded();
            refreshCategoryLabel();
            refreshShoppingMode();
        });

        taskId = getIntent().getLongExtra(EXTRA_TASK_ID, NEW_TASK_ID);
        if (taskId != NEW_TASK_ID) {
            LiveData<Task> live = repo.observeById(taskId);
            live.observe(this, new Observer<Task>() {
                @Override
                public void onChanged(Task task) {
                    if (task != null && !fieldsInitialized) {
                        editedTask = task;
                        editTitle.setText(task.title == null ? "" : task.title);
                        editNote.setText(task.note == null ? "" : task.note);

                        // Načítaj shopping items ak existujú
                        if (!TextUtils.isEmpty(task.shoppingItemsJson)) {
                            shoppingItems.clear();
                            shoppingItems.addAll(ShoppingItems.parse(task.shoppingItemsJson));
                            renderShoppingItems();
                        }

                        refreshCategoryLabel();
                        refreshRepeatLabel();
                        refreshDueDateLabel();
                        refreshDueTimeLabel();
                        refreshPriorityIcon();
                        refreshShoppingMode();
                        refreshReminderLabel();
                        fieldsInitialized = true;
                    }
                }
            });
        } else {
            fieldsInitialized = true;
        }
    }

    private void saveAndFinish() {
        String title = editTitle.getText().toString().trim();
        String note = editNote.getText().toString().trim();

        if (TextUtils.isEmpty(title)) {
            Toast.makeText(this, R.string.task_title_required, Toast.LENGTH_SHORT).show();
            return;
        }

        editedTask.title = title;

        if (isShoppingCategory()) {
            // Pri Nákupe ukladáme zoznam položiek do shoppingItemsJson, note nepoužívame
            // ale ak ostane v poli textu, dovolme aj poznámku popri zozname
            editedTask.shoppingItemsJson = ShoppingItems.serialize(shoppingItems);
            editedTask.note = TextUtils.isEmpty(note) ? null : note;
        } else {
            editedTask.note = TextUtils.isEmpty(note) ? null : note;
            editedTask.shoppingItemsJson = null;
        }

        sk.aetheriqa.noteiqa.util.ExactAlarmNotice.maybeWarn(this, editedTask.reminderAt);
        repo.save(editedTask, savedId -> {
            // Po úspešnom uložení Task má pridelenú savedId; nastav reminderom na ňu.
            editedTask.id = savedId;
            sk.aetheriqa.noteiqa.notification.ReminderScheduler.schedule(
                    getApplicationContext(), editedTask);
            runOnUiThread(() -> {
                Toast.makeText(this, R.string.task_saved_toast, Toast.LENGTH_SHORT).show();
                finish();
            });
        });
    }

    // ===== Category =====

    private boolean isShoppingCategory() {
        if (editedTask.categoryId == null || cachedCategories == null) return false;
        for (TaskCategory c : cachedCategories) {
            if (c.id == editedTask.categoryId) {
                return TaskRepository.SHOPPING_CATEGORY_NAME.equals(c.name);
            }
        }
        return false;
    }

    /**
     * Ak prišiel intent extra EXTRA_PRESELECT_CATEGORY, nastaví ho na editedTask
     * pri novej úlohe. Volá sa po načítaní kategórií. Aplikuje sa max raz —
     * ak používateľ kategóriu medzitým zmení manuálne, nepretláčame ju späť.
     */
    private boolean preselectApplied = false;

    private void applyPreselectCategoryIfNeeded() {
        if (preselectApplied) return;
        if (taskId != NEW_TASK_ID) return; // Iba pre nové úlohy
        if (cachedCategories == null) return;
        if (editedTask.categoryId != null) return;

        String preselect = getIntent().getStringExtra(EXTRA_PRESELECT_CATEGORY);
        if (TextUtils.isEmpty(preselect)) return;

        for (TaskCategory c : cachedCategories) {
            if (preselect.equals(c.name)) {
                editedTask.categoryId = c.id;
                preselectApplied = true;
                return;
            }
        }
    }

    private void refreshCategoryLabel() {
        if (editedTask.categoryId == null || cachedCategories == null) {
            categoryValue.setText(R.string.task_select_category);
            return;
        }
        for (TaskCategory c : cachedCategories) {
            if (c.id == editedTask.categoryId) {
                categoryValue.setText(c.name);
                return;
            }
        }
        categoryValue.setText(R.string.task_select_category);
    }

    private void refreshShoppingMode() {
        boolean shopping = isShoppingCategory();
        rowShopping.setVisibility(shopping ? View.VISIBLE : View.GONE);
        // Note pole skryjeme, ak je shopping mode (ináč ostáva viditeľné)
        rowNote.setVisibility(shopping ? View.GONE : View.VISIBLE);
        if (shopping) renderShoppingItems();
    }

    private void showCategoryPicker() {
        if (cachedCategories == null || cachedCategories.isEmpty()) {
            Toast.makeText(this, R.string.task_select_category, Toast.LENGTH_SHORT).show();
            return;
        }
        List<String> labels = new ArrayList<>();
        labels.add(getString(R.string.task_no_category));
        for (TaskCategory c : cachedCategories) labels.add(c.name);

        new AlertDialog.Builder(this,
                sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(R.string.task_select_category)
                .setItems(labels.toArray(new CharSequence[0]), (d, which) -> {
                    if (which == 0) {
                        editedTask.categoryId = null;
                    } else {
                        editedTask.categoryId = cachedCategories.get(which - 1).id;
                    }
                    refreshCategoryLabel();
                    refreshShoppingMode();
                })
                .show();
    }

    // ===== Shopping items =====

    private void renderShoppingItems() {
        shoppingItemsContainer.removeAllViews();
        LayoutInflater inf = LayoutInflater.from(this);
        int total = shoppingItems.size();
        for (int i = 0; i < total; i++) {
            final int index = i;
            View row = inf.inflate(R.layout.item_shopping_check, shoppingItemsContainer, false);
            CheckBox cb = row.findViewById(R.id.shopping_check);
            TextView text = row.findViewById(R.id.shopping_text);
            ImageView trash = row.findViewById(R.id.shopping_remove);
            ImageView moveUp = row.findViewById(R.id.shopping_move_up);
            ImageView moveDown = row.findViewById(R.id.shopping_move_down);

            ShoppingItems.Item item = shoppingItems.get(i);
            cb.setChecked(item.checked);
            text.setText(item.text);
            updateShoppingTextStyle(text, item.checked);

            cb.setOnCheckedChangeListener((v, checked) -> {
                shoppingItems.get(index).checked = checked;
                updateShoppingTextStyle(text, checked);
            });

            trash.setOnClickListener(v -> {
                shoppingItems.remove(index);
                renderShoppingItems();
            });

            // Šípky hore/dole — prvá pozícia má disabled hore, posledná disabled dole
            boolean canMoveUp = index > 0;
            boolean canMoveDown = index < total - 1;

            moveUp.setAlpha(canMoveUp ? 1f : 0.25f);
            moveUp.setEnabled(canMoveUp);
            moveUp.setOnClickListener(canMoveUp ? v -> {
                java.util.Collections.swap(shoppingItems, index, index - 1);
                renderShoppingItems();
            } : null);

            moveDown.setAlpha(canMoveDown ? 1f : 0.25f);
            moveDown.setEnabled(canMoveDown);
            moveDown.setOnClickListener(canMoveDown ? v -> {
                java.util.Collections.swap(shoppingItems, index, index + 1);
                renderShoppingItems();
            } : null);

            shoppingItemsContainer.addView(row);
        }
    }

    private void updateShoppingTextStyle(TextView text, boolean checked) {
        if (checked) {
            text.setPaintFlags(text.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            text.setAlpha(0.55f);
        } else {
            text.setPaintFlags(text.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
            text.setAlpha(1f);
        }
    }

    private void addShoppingItem() {
        String text = shoppingNewItem.getText().toString().trim();
        if (TextUtils.isEmpty(text)) return;
        shoppingItems.add(new ShoppingItems.Item(text, false));
        shoppingNewItem.setText("");
        renderShoppingItems();
    }

    // ===== Repeat =====

    private void refreshRepeatLabel() {
        int res;
        switch (editedTask.repeatType) {
            case Task.REPEAT_DAILY:   res = R.string.task_repeat_daily; break;
            case Task.REPEAT_WEEKLY:  res = R.string.task_repeat_weekly; break;
            case Task.REPEAT_MONTHLY: res = R.string.task_repeat_monthly; break;
            case Task.REPEAT_YEARLY:  res = R.string.task_repeat_yearly; break;
            case Task.REPEAT_NONE:
            default:                  res = R.string.task_repeat_none; break;
        }
        repeatValue.setText(res);
    }

    private void showRepeatPicker() {
        CharSequence[] labels = new CharSequence[]{
                getString(R.string.task_repeat_none),
                getString(R.string.task_repeat_daily),
                getString(R.string.task_repeat_weekly),
                getString(R.string.task_repeat_monthly),
                getString(R.string.task_repeat_yearly)
        };
        new AlertDialog.Builder(this,
                sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(R.string.task_repeat_v2)
                .setItems(labels, (d, which) -> {
                    editedTask.repeatType = which;
                    refreshRepeatLabel();
                })
                .show();
    }

    // ===== Date / Time =====

    private void refreshDueDateLabel() {
        if (editedTask.dueDate == null || editedTask.dueDate == 0L) {
            dueDateValue.setText(R.string.task_due_date_unset);
            return;
        }
        String dateStr = DateUtils.formatLongDate(editedTask.dueDate);
        LocalDate due = Instant.ofEpochMilli(editedTask.dueDate)
                .atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate today = LocalDate.now();
        String hint;
        if (due.equals(today)) {
            hint = ", " + getString(R.string.task_today_label).toLowerCase(new Locale("sk"));
        } else if (due.equals(today.plusDays(1))) {
            hint = ", " + getString(R.string.task_tomorrow_label).toLowerCase(new Locale("sk"));
        } else if (due.getMonth() == today.getMonth() && due.getYear() == today.getYear()) {
            hint = ", " + getString(R.string.task_this_month_label);
        } else {
            hint = "";
        }
        dueDateValue.setText(dateStr + hint);
    }

    private void showDatePicker() {
        Calendar cal = Calendar.getInstance();
        if (editedTask.dueDate != null && editedTask.dueDate != 0L) {
            cal.setTimeInMillis(editedTask.dueDate);
        }

        DatePickerDialog dlg = new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    Calendar c = Calendar.getInstance();
                    c.set(Calendar.YEAR, year);
                    c.set(Calendar.MONTH, month);
                    c.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    c.set(Calendar.HOUR_OF_DAY, 0);
                    c.set(Calendar.MINUTE, 0);
                    c.set(Calendar.SECOND, 0);
                    c.set(Calendar.MILLISECOND, 0);
                    editedTask.dueDate = c.getTimeInMillis();
                    refreshDueDateLabel();
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH));

        dlg.setButton(DatePickerDialog.BUTTON_NEUTRAL,
                getString(R.string.task_due_date_unset),
                (d, which) -> {
                    editedTask.dueDate = null;
                    refreshDueDateLabel();
                });
        dlg.show();
    }

    private void refreshDueTimeLabel() {
        if (editedTask.dueTimeMinutes == null) {
            dueTimeValue.setText(R.string.task_due_time_unset);
            return;
        }
        int h = editedTask.dueTimeMinutes / 60;
        int m = editedTask.dueTimeMinutes % 60;
        dueTimeValue.setText(String.format(Locale.getDefault(), "%d:%02d", h, m));
    }

    private void showTimePicker() {
        int h = 9, m = 0;
        if (editedTask.dueTimeMinutes != null) {
            h = editedTask.dueTimeMinutes / 60;
            m = editedTask.dueTimeMinutes % 60;
        }
        TimePickerDialog dlg = new TimePickerDialog(this,
                (view, hourOfDay, minute) -> {
                    editedTask.dueTimeMinutes = hourOfDay * 60 + minute;
                    refreshDueTimeLabel();
                },
                h, m, true);

        dlg.setButton(TimePickerDialog.BUTTON_NEUTRAL,
                getString(R.string.task_due_time_unset),
                (d, which) -> {
                    editedTask.dueTimeMinutes = null;
                    refreshDueTimeLabel();
                });
        dlg.show();
    }

    // ===== Priority =====

    private void togglePriority() {
        editedTask.priority = (editedTask.priority == Task.PRIORITY_IMPORTANT)
                ? Task.PRIORITY_NORMAL : Task.PRIORITY_IMPORTANT;
        refreshPriorityIcon();
        Toast.makeText(this,
                editedTask.priority == Task.PRIORITY_IMPORTANT
                        ? R.string.task_priority_important
                        : R.string.task_priority_normal,
                Toast.LENGTH_SHORT).show();
    }

    private void refreshPriorityIcon() {
        if (editedTask.priority == Task.PRIORITY_IMPORTANT) {
            btnPriority.setColorFilter(getResources().getColor(R.color.priority_important, getTheme()));
            btnPriority.setAlpha(1f);
        } else {
            btnPriority.clearColorFilter();
            btnPriority.setAlpha(0.5f);
        }
    }

    // ===== Reminder picker =====

    /**
     * Vypočíta absolútny čas pripomienky pre Task. Vráti 0 ak Task nemá
     * dueDate (a usermode = relatívne offset).
     */
    private long computeAbsoluteReminderForOffset(long minutesBefore) {
        if (editedTask.dueDate == null || editedTask.dueDate == 0L) return 0L;
        long taskTimeMillis = editedTask.dueDate;
        if (editedTask.dueTimeMinutes != null) {
            taskTimeMillis += editedTask.dueTimeMinutes * 60_000L;
        }
        return taskTimeMillis - minutesBefore * 60_000L;
    }

    private void showReminderPicker() {
        // Android 13+ — kontrola POST_NOTIFICATIONS permission
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            int granted = androidx.core.content.ContextCompat.checkSelfPermission(
                    this, android.Manifest.permission.POST_NOTIFICATIONS);
            if (granted != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                notificationPermLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS);
                return;
            }
        }
        // Android 12+ — kontrola SCHEDULE_EXACT_ALARM (informačná, nie blocking)
        if (sk.aetheriqa.noteiqa.notification.ReminderScheduler.needsExactAlarmPermission(this)) {
            new AlertDialog.Builder(this, sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                    .setTitle(R.string.reminder_picker_title)
                    .setMessage(R.string.perm_exact_alarm_required)
                    .setPositiveButton(R.string.perm_open_settings, (d, w) -> {
                        android.content.Intent i = sk.aetheriqa.noteiqa.notification
                                .ReminderScheduler.buildExactAlarmSettingsIntent(this);
                        if (i != null) startActivity(i);
                    })
                    .setNegativeButton(R.string.action_cancel, (d, w) ->
                            showReminderPickerInternal())
                    .show();
            return;
        }
        showReminderPickerInternal();
    }

    private void showReminderPickerInternal() {
        // Položky: žiadna, 5/15/30 min, 1h, 2h, 1d, vlastný
        java.util.List<CharSequence> options = new java.util.ArrayList<>();
        java.util.List<Long> offsets = new java.util.ArrayList<>(); // -1 = vlastný, 0 = žiadna

        options.add(getString(R.string.reminder_option_none));   offsets.add(0L);
        options.add(getString(R.string.reminder_option_5min));   offsets.add(5L);
        options.add(getString(R.string.reminder_option_15min));  offsets.add(15L);
        options.add(getString(R.string.reminder_option_30min));  offsets.add(30L);
        options.add(getString(R.string.reminder_option_1hour));  offsets.add(60L);
        options.add(getString(R.string.reminder_option_2hours)); offsets.add(120L);
        options.add(getString(R.string.reminder_option_1day));   offsets.add(60L * 24);
        options.add(getString(R.string.reminder_option_custom)); offsets.add(-1L);

        new AlertDialog.Builder(this, sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(R.string.reminder_picker_title)
                .setItems(options.toArray(new CharSequence[0]), (d, which) -> {
                    long off = offsets.get(which);
                    if (off == 0L) {
                        // Žiadna pripomienka
                        editedTask.reminderAt = 0L;
                        refreshReminderLabel();
                        Toast.makeText(this, R.string.reminder_cleared_toast,
                                Toast.LENGTH_SHORT).show();
                    } else if (off == -1L) {
                        showCustomReminderDateTime();
                    } else {
                        // Relatívny offset → potrebujeme dueDate aj dueTimeMinutes
                        if (editedTask.dueDate == null || editedTask.dueDate == 0L
                                || editedTask.dueTimeMinutes == null) {
                            Toast.makeText(this, R.string.reminder_needs_due_time,
                                    Toast.LENGTH_LONG).show();
                            return;
                        }
                        long absMillis = computeAbsoluteReminderForOffset(off);
                        if (absMillis <= System.currentTimeMillis()) {
                            Toast.makeText(this, R.string.reminder_must_be_future,
                                    Toast.LENGTH_LONG).show();
                            return;
                        }
                        editedTask.reminderAt = absMillis;
                        refreshReminderLabel();
                        Toast.makeText(this, R.string.reminder_set_toast,
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void showCustomReminderDateTime() {
        // 2-step picker: dátum → čas
        java.util.Calendar cal = java.util.Calendar.getInstance();
        if (editedTask.reminderAt > System.currentTimeMillis()) {
            cal.setTimeInMillis(editedTask.reminderAt);
        } else if (editedTask.dueDate != null && editedTask.dueDate > 0L) {
            cal.setTimeInMillis(editedTask.dueDate);
            if (editedTask.dueTimeMinutes != null) {
                cal.set(Calendar.HOUR_OF_DAY, editedTask.dueTimeMinutes / 60);
                cal.set(Calendar.MINUTE, editedTask.dueTimeMinutes % 60);
            }
        }

        new android.app.DatePickerDialog(this,
                (dateView, year, month, dayOfMonth) -> {
                    java.util.Calendar dateCal = java.util.Calendar.getInstance();
                    dateCal.set(year, month, dayOfMonth);

                    int initialH = dateCal.get(Calendar.HOUR_OF_DAY);
                    int initialM = dateCal.get(Calendar.MINUTE);

                    new android.app.TimePickerDialog(this,
                            (timeView, hourOfDay, minute) -> {
                                java.util.Calendar finalCal = java.util.Calendar.getInstance();
                                finalCal.set(year, month, dayOfMonth, hourOfDay, minute, 0);
                                finalCal.set(Calendar.MILLISECOND, 0);
                                long abs = finalCal.getTimeInMillis();
                                if (abs <= System.currentTimeMillis()) {
                                    Toast.makeText(this, R.string.reminder_must_be_future,
                                            Toast.LENGTH_LONG).show();
                                    return;
                                }
                                editedTask.reminderAt = abs;
                                refreshReminderLabel();
                                Toast.makeText(this, R.string.reminder_set_toast,
                                        Toast.LENGTH_SHORT).show();
                            },
                            initialH, initialM, true).show();
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void refreshReminderLabel() {
        if (editedTask.reminderAt <= 0L) {
            reminderValue.setText(R.string.task_reminder);
            return;
        }
        String date = sk.aetheriqa.noteiqa.util.DateUtils.formatLongDate(editedTask.reminderAt);
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.setTimeInMillis(editedTask.reminderAt);
        String time = String.format(Locale.getDefault(),
                "%d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
        reminderValue.setText(getString(R.string.reminder_value_format, date, time));
    }

    public static Intent newIntent(Context ctx, long taskId) {
        Intent i = new Intent(ctx, TaskEditorActivity.class);
        if (taskId != NEW_TASK_ID) i.putExtra(EXTRA_TASK_ID, taskId);
        return i;
    }
}
