package sk.aetheriqa.noteiqa.data.repository;

import android.content.Context;

import androidx.lifecycle.LiveData;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import sk.aetheriqa.noteiqa.data.db.AppDatabase;
import sk.aetheriqa.noteiqa.data.db.dao.ChecklistDao;
import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.db.dao.NoteDao;
import sk.aetheriqa.noteiqa.data.db.dao.TagDao;
import sk.aetheriqa.noteiqa.data.db.dao.TagWithCount;
import sk.aetheriqa.noteiqa.data.db.dao.TemplateDao;
import sk.aetheriqa.noteiqa.data.entity.ChecklistItem;
import sk.aetheriqa.noteiqa.data.entity.Note;
import sk.aetheriqa.noteiqa.data.entity.NoteTagCrossRef;
import sk.aetheriqa.noteiqa.data.entity.Tag;
import sk.aetheriqa.noteiqa.data.entity.Template;
import sk.aetheriqa.noteiqa.util.DiacriticsUtils;
import sk.aetheriqa.noteiqa.util.ImageStorage;

/**
 * NoteRepository – business logika nad NoteDao.
 *
 * Centralizuje:
 *  - Predprípravu searchIndex pri save (DiacriticsUtils)
 *  - Spúšťanie DB operácií na background thread (Executor)
 *  - Pre ViewModely vystavuje LiveData
 *
 * ViewModel nikdy nevolá DAO priamo – ide cez Repository.
 */
public class NoteRepository {

    private static volatile NoteRepository INSTANCE;

    private final NoteDao noteDao;
    private final ChecklistDao checklistDao;
    private final TagDao tagDao;
    private final TemplateDao templateDao;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    /** v1.2.0 — kôš sa po 30 dňoch vyprázdni (cleanup pri štarte appky). */
    public static final long TRASH_TTL_MILLIS = 30L * 24 * 60 * 60 * 1000;

    private NoteRepository(Context ctx) {
        AppDatabase db = AppDatabase.getInstance(ctx);
        this.noteDao = db.noteDao();
        this.checklistDao = db.checklistDao();
        this.tagDao = db.tagDao();
        this.templateDao = db.templateDao();
    }

    public static NoteRepository getInstance(Context ctx) {
        if (INSTANCE == null) {
            synchronized (NoteRepository.class) {
                if (INSTANCE == null) {
                    INSTANCE = new NoteRepository(ctx.getApplicationContext());
                }
            }
        }
        return INSTANCE;
    }

    // ===== Observable streams =====

    public LiveData<List<Note>> observeActive() {
        return noteDao.observeActive();
    }

    public LiveData<List<Note>> observeArchived() {
        return noteDao.observeArchived();
    }

    public LiveData<List<Note>> observeTrashed() {
        return noteDao.observeTrashed();
    }

    public LiveData<Note> observeById(long id) {
        return noteDao.observeById(id);
    }

    public LiveData<List<Note>> search(String userQuery) {
        String normalized = DiacriticsUtils.stripDiacritics(userQuery);
        if (normalized != null) normalized = normalized.toLowerCase();
        return noteDao.search(normalized == null ? "" : normalized);
    }

    // ===== Mutations (background) =====

    public void save(Note note, OnSavedCallback cb) {
        executor.execute(() -> {
            long now = System.currentTimeMillis();
            if (note.createdAt == 0L) note.createdAt = now;
            note.updatedAt = now;
            note.searchIndex = DiacriticsUtils.buildSearchIndex(note.title, note.body);

            long id = note.id == 0 ? noteDao.insert(note) : (noteDao.update(note) > 0 ? note.id : -1);
            if (cb != null) cb.onSaved(id);
        });
    }

    public void archive(long noteId) {
        executor.execute(() -> noteDao.archive(noteId, System.currentTimeMillis()));
    }

    public void unarchive(long noteId) {
        executor.execute(() -> noteDao.unarchive(noteId, System.currentTimeMillis()));
    }

    public void trash(long noteId) {
        executor.execute(() -> noteDao.trash(noteId, System.currentTimeMillis()));
    }

    public void restoreFromTrash(long noteId) {
        executor.execute(() -> noteDao.restoreFromTrash(noteId));
    }

    public void setPinned(long noteId, boolean pinned) {
        executor.execute(() -> noteDao.setPinned(noteId, pinned));
    }

    /** v1.2.0 — volá sa pri štarte appky (NoteiqaApplication); zmaže aj prílohy. */
    public void purgeOldTrashed() {
        executor.execute(() -> {
            long cutoff = System.currentTimeMillis() - TRASH_TTL_MILLIS;
            for (String path : noteDao.getOldTrashedAttachmentsSync(cutoff)) {
                ImageStorage.deleteIfExists(path);
            }
            noteDao.purgeOldTrashed(cutoff);
        });
    }

    /** v1.2.0 — trvalé zmazanie jednej poznámky z koša (aj s prílohou). */
    public void deletePermanently(long noteId) {
        executor.execute(() -> {
            Note n = noteDao.getById(noteId);
            if (n == null) return;
            ImageStorage.deleteIfExists(n.attachmentImagePath);
            noteDao.deleteById(noteId);
        });
    }

    public LiveData<List<Note>> observeActiveByTag(long tagId) {
        return noteDao.observeActiveByTag(tagId);
    }

    // ===== v1.2.0 — Štítky =====

    public LiveData<List<TagWithCount>> observeTagsWithCounts() {
        return tagDao.observeWithCounts();
    }

    /** Všetky štítky + id štítkov danej poznámky (0 = nová poznámka). Callback na executor threade. */
    public void loadTagsForEditor(long noteId, OnTagsLoadedCallback cb) {
        executor.execute(() -> {
            List<Tag> all = tagDao.getAllSync();
            List<Long> selected = noteId > 0L
                    ? tagDao.getTagIdsForNoteSync(noteId) : new ArrayList<>();
            cb.onLoaded(all, selected);
        });
    }

    /** Vytvorí štítok (alebo vráti existujúci s rovnakým menom). Callback na executor threade. */
    public void createTag(String name, OnSavedCallback cb) {
        executor.execute(() -> {
            String trimmed = name.trim();
            Tag existing = tagDao.findByName(trimmed);
            long id;
            if (existing != null) {
                id = existing.id;
            } else {
                Tag t = new Tag();
                t.name = trimmed;
                id = tagDao.insert(t);
                if (id <= 0L) {
                    Tag again = tagDao.findByName(trimmed);
                    id = again != null ? again.id : -1L;
                }
            }
            if (cb != null) cb.onSaved(id);
        });
    }

    /** Nahradí štítky poznámky daným zoznamom. */
    public void setNoteTags(long noteId, Collection<Long> tagIds) {
        if (noteId <= 0L) return;
        List<Long> copy = new ArrayList<>(tagIds);
        executor.execute(() -> {
            tagDao.clearTagsForNote(noteId);
            for (Long tagId : copy) {
                if (tagId != null && tagId > 0L) tagDao.linkNoteTag(new NoteTagCrossRef(noteId, tagId));
            }
        });
    }

    // ===== v1.2.0 — Šablóny =====

    public LiveData<List<Template>> observeTemplates() {
        return templateDao.observeAll();
    }

    /** Seed 3 systémových šablón pri prvom spustení, ak je tabuľka prázdna. */
    public void ensureTemplatesSeeded(Context ctx) {
        Context app = ctx.getApplicationContext();
        executor.execute(() -> {
            if (!templateDao.getAllSync().isEmpty()) return;
            long now = System.currentTimeMillis();
            int[][] seed = {
                    {R.string.template_shopping, R.string.template_shopping_body},
                    {R.string.template_kids_sizes, R.string.template_kids_sizes_body},
                    {R.string.template_travel, R.string.template_travel_body},
            };
            for (int i = 0; i < seed.length; i++) {
                Template t = new Template();
                t.name = app.getString(seed[i][0]);
                t.title = t.name;
                t.body = app.getString(seed[i][1]);
                t.type = Note.TYPE_TEXT;
                t.systemTemplate = true;
                t.sortOrder = i;
                t.createdAt = now;
                templateDao.insert(t);
            }
        });
    }

    // ===== Checklist API =====

    public LiveData<List<ChecklistItem>> observeChecklistItems(long noteId) {
        return checklistDao.observeForNote(noteId);
    }

    public List<ChecklistItem> getChecklistItemsSync(long noteId) {
        return checklistDao.getForNote(noteId);
    }

    /** Synchronizuje zoznam checklistu s DB (DELETE + INSERT). */
    public void saveChecklistItems(long noteId, List<ChecklistItem> items) {
        executor.execute(() -> {
            checklistDao.deleteAllForNote(noteId);
            long now = System.currentTimeMillis();
            for (int i = 0; i < items.size(); i++) {
                ChecklistItem item = items.get(i);
                item.noteId = noteId;
                item.sortOrder = i;
                if (item.createdAt == 0L) item.createdAt = now;
                item.updatedAt = now;
            }
            checklistDao.insertAll(items);
        });
    }

    public void toggleChecklistItem(long itemId, boolean checked) {
        executor.execute(() -> checklistDao.setChecked(itemId, checked, System.currentTimeMillis()));
    }

    /**
     * v0.5.4 — permanentne zmaže VŠETKY archivované poznámky.
     * ChecklistItemy + tag väzby sa mažú kaskádou cez FK ON DELETE CASCADE.
     */
    public void deleteAllArchived(OnCountCallback cb) {
        executor.execute(() -> {
            int count = noteDao.deleteAllArchived();
            if (cb != null) cb.onCount(count);
        });
    }

    public interface OnSavedCallback {
        void onSaved(long id);
    }

    public interface OnTagsLoadedCallback {
        void onLoaded(List<Tag> allTags, List<Long> selectedTagIds);
    }

    /** Callback pre operácie ktoré reportujú počet zasiahnutých záznamov. */
    public interface OnCountCallback {
        void onCount(int count);
    }
}
