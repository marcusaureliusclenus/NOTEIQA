package sk.aetheriqa.noteiqa.ui.kids;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.mlkit.common.MlKitException;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.util.DateUtils;
import sk.aetheriqa.noteiqa.util.DialogThemes;
import sk.aetheriqa.noteiqa.util.ExactAlarmNotice;
import sk.aetheriqa.noteiqa.util.ImageStorage;
import sk.aetheriqa.noteiqa.util.PaperDraftParser;
import sk.aetheriqa.noteiqa.util.VoiceDraftParser;

/**
 * PhotoDraftActivity – v1.3.0 — "Lístok z fotky".
 *
 * Fotka (TakePicture / GetContent) → dočasná kópia v appke → ML Kit OCR on-device
 * (Google Play Services, model sa stiahne pri inštalácii / prvom použití) →
 * PaperDraftParser → náhľad s upraviteľnými poľami. Uloží sa až cez FAB "done".
 * Fotka sa k záznamu neukladá a po zatvorení sa zmaže.
 */
public class PhotoDraftActivity extends AppCompatActivity {

    private static final String EXTRA_KID_ID = "kidId";
    private static final String STATE_PHOTO = "photoPath";
    private static final String STATE_PHOTO_IS_ATTACHMENT = "photoIsAttachment";

    private KidRepository repo;
    private long defaultKidId;
    private final List<Kid> kids = new ArrayList<>();

    @Nullable private File photo;
    /** true = kópia cez ImageStorage (galéria), false = cache/ocr (kamera). */
    private boolean photoIsAttachment;
    @Nullable private TextRecognizer recognizer;

    private long dayStart = -1L;
    private int minutes = -1;

    private ImageView thumb;
    private TextView status;
    private MaterialButtonToggleGroup kindGroup, kidGroup;
    private MaterialButton kidA, kidB, kidAll, dateBtn, timeBtn;
    private EditText title, amount, iban, vs, ss;
    private View paymentFields;

    private final ActivityResultLauncher<Uri> takePicture =
            registerForActivityResult(new ActivityResultContracts.TakePicture(), ok -> {
                if (ok != null && ok && photo != null) onPhoto();
                else finishAndCleanup();
            });

    private final ActivityResultLauncher<String> pickImage =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri == null) {
                    finishAndCleanup();
                    return;
                }
                new Thread(() -> {
                    // kópia do appky — cudziu cestu nečítame natrvalo
                    String path = ImageStorage.importImage(getApplicationContext(), uri);
                    runOnUiThread(() -> {
                        if (path == null) {
                            Toast.makeText(this, R.string.photo_draft_read_failed, Toast.LENGTH_SHORT).show();
                            finishAndCleanup();
                            return;
                        }
                        photo = new File(path);
                        photoIsAttachment = true;
                        onPhoto();
                    });
                }, "PhotoDraftCopy").start();
            });

    public static Intent newIntent(Context ctx, long defaultKidId) {
        Intent i = new Intent(ctx, PhotoDraftActivity.class);
        i.putExtra(EXTRA_KID_ID, defaultKidId);
        return i;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_draft);
        repo = KidRepository.getInstance(this);
        defaultKidId = getIntent().getLongExtra(EXTRA_KID_ID, KidRepository.KID_ID_ALL);

        MaterialToolbar tb = findViewById(R.id.photo_toolbar);
        tb.setNavigationOnClickListener(v -> finishAndCleanup());
        thumb = findViewById(R.id.photo_thumb);
        status = findViewById(R.id.photo_status);
        kindGroup = findViewById(R.id.photo_kind_group);
        kidGroup = findViewById(R.id.photo_kid_group);
        kidA = findViewById(R.id.photo_kid_a);
        kidB = findViewById(R.id.photo_kid_b);
        kidAll = findViewById(R.id.photo_kid_all);
        title = findViewById(R.id.photo_title);
        amount = findViewById(R.id.photo_amount);
        iban = findViewById(R.id.photo_iban);
        vs = findViewById(R.id.photo_vs);
        ss = findViewById(R.id.photo_ss);
        paymentFields = findViewById(R.id.photo_payment_fields);
        dateBtn = findViewById(R.id.photo_date);
        timeBtn = findViewById(R.id.photo_time);

        kindGroup.addOnButtonCheckedListener((g, id, checked) -> { if (checked) applyKindUi(); });
        kindGroup.check(R.id.photo_kind_event);
        dateBtn.setOnClickListener(v -> pickDate());
        timeBtn.setOnClickListener(v -> pickTime());
        findViewById(R.id.photo_fab_save).setOnClickListener(v -> save());
        refreshDateTime();
        loadKids();

        getOnBackPressedDispatcher().addCallback(this, new androidx.activity.OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() { finishAndCleanup(); }
        });

        if (savedInstanceState != null && savedInstanceState.getString(STATE_PHOTO) != null) {
            photo = new File(savedInstanceState.getString(STATE_PHOTO));
            photoIsAttachment = savedInstanceState.getBoolean(STATE_PHOTO_IS_ATTACHMENT);
            showThumb();
        } else if (savedInstanceState == null) {
            askSource();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (photo != null) {
            outState.putString(STATE_PHOTO, photo.getAbsolutePath());
            outState.putBoolean(STATE_PHOTO_IS_ATTACHMENT, photoIsAttachment);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (recognizer != null) recognizer.close();
        if (isFinishing()) deletePhoto();
    }

    // ===== Zdroj fotky =====

    private void askSource() {
        new AlertDialog.Builder(this, DialogThemes.LEA)
                .setTitle(R.string.photo_draft_entry)
                .setItems(new CharSequence[]{
                        getString(R.string.photo_source_camera),
                        getString(R.string.photo_source_gallery)
                }, (d, which) -> {
                    if (which == 0) openCamera();
                    else pickImage.launch("image/*");
                })
                .setOnCancelListener(d -> finishAndCleanup())
                .show();
    }

    private void openCamera() {
        try {
            File dir = new File(getCacheDir(), "ocr");
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("ocr dir");
            photo = new File(dir, "ocr_" + System.currentTimeMillis() + ".jpg");
            photoIsAttachment = false;
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photo);
            takePicture.launch(uri);
        } catch (IOException | IllegalArgumentException | android.content.ActivityNotFoundException e) {
            Toast.makeText(this, R.string.photo_draft_read_failed, Toast.LENGTH_SHORT).show();
            finishAndCleanup();
        }
    }

    // ===== OCR =====

    private void onPhoto() {
        showThumb();
        status.setText(R.string.photo_draft_reading);
        InputImage image;
        try {
            image = InputImage.fromFilePath(this, Uri.fromFile(photo));
        } catch (IOException e) {
            status.setText(R.string.photo_draft_read_failed);
            return;
        }
        if (recognizer == null) {
            recognizer = TextRecognition.getClient(new TextRecognizerOptions.Builder().build());
        }
        recognizer.process(image)
                .addOnSuccessListener(text -> {
                    if (isFinishing()) return;
                    applyResult(PaperDraftParser.parse(text.getText(), kidRefs(), Calendar.getInstance()));
                })
                .addOnFailureListener(e -> {
                    if (isFinishing()) return;
                    boolean modelMissing = e instanceof MlKitException
                            && ((MlKitException) e).getErrorCode() == MlKitException.UNAVAILABLE;
                    // model ešte nie je stiahnutý cez Google Play — polia ostanú na ručné vyplnenie
                    status.setText(modelMissing ? R.string.photo_draft_model_missing
                            : R.string.photo_draft_read_failed);
                });
    }

    private void showThumb() {
        if (photo == null || !photo.exists()) return;
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inSampleSize = 4;
        Bitmap b = BitmapFactory.decodeFile(photo.getAbsolutePath(), o);
        if (b != null) thumb.setImageBitmap(b);
    }

    private void applyResult(PaperDraftParser.Result r) {
        if (r.empty) {
            status.setText(R.string.photo_draft_no_text);
            return;
        }
        status.setText(r.iban != null && !r.ibanValid
                ? R.string.photo_draft_check_iban : R.string.photo_draft_check);
        kindGroup.check(r.payment ? R.id.photo_kind_payment : R.id.photo_kind_event);
        if (r.title != null) title.setText(r.title);
        if (r.amount != null) amount.setText(r.amount.toPlainString().replace('.', ','));
        if (r.iban != null) iban.setText(PaymentTicketBinder.groupIban(r.iban));
        if (r.variableSymbol != null) vs.setText(r.variableSymbol);
        if (r.specificSymbol != null) ss.setText(r.specificSymbol);
        if (r.dayStart > 0L) dayStart = r.dayStart;
        if (r.minutes >= 0) minutes = r.minutes;
        if (r.kidId >= 0) checkKid(r.kidId);
        refreshDateTime();
    }

    // ===== Polia =====

    private void loadKids() {
        new Thread(() -> {
            List<Kid> all = repo.getKidsSync();
            runOnUiThread(() -> {
                kids.clear();
                for (int i = 0; i < all.size() && i < 2; i++) kids.add(all.get(i));
                if (kids.size() >= 2) {
                    kidA.setText(kids.get(0).name);
                    kidB.setText(kids.get(1).name);
                    checkKid(defaultKidId);
                } else {
                    kidGroup.setVisibility(View.GONE);
                }
            });
        }, "PhotoDraftKids").start();
    }

    private List<VoiceDraftParser.KidRef> kidRefs() {
        List<VoiceDraftParser.KidRef> out = new ArrayList<>();
        for (Kid k : kids) out.add(new VoiceDraftParser.KidRef(k.id, k.name));
        return out;
    }

    private void checkKid(long kidId) {
        if (kids.size() < 2) return;
        if (kidId == kids.get(0).id) kidGroup.check(R.id.photo_kid_a);
        else if (kidId == kids.get(1).id) kidGroup.check(R.id.photo_kid_b);
        else if (kidId == KidRepository.KID_ID_ALL && kidAll.isEnabled()) kidGroup.check(R.id.photo_kid_all);
    }

    private void applyKindUi() {
        boolean payment = kindGroup.getCheckedButtonId() == R.id.photo_kind_payment;
        paymentFields.setVisibility(payment ? View.VISIBLE : View.GONE);
        timeBtn.setVisibility(payment ? View.GONE : View.VISIBLE);
        kidAll.setEnabled(!payment); // platba musí mať konkrétne dieťa
        if (payment && kidGroup.getCheckedButtonId() == R.id.photo_kid_all) kidGroup.clearChecked();
    }

    private void refreshDateTime() {
        dateBtn.setText(dayStart > 0L ? DateUtils.formatNumericDate(dayStart) : getString(R.string.kid_pick_date));
        timeBtn.setText(minutes >= 0
                ? String.format(Locale.getDefault(), "%d:%02d", minutes / 60, minutes % 60)
                : getString(R.string.voice_no_time));
    }

    private void pickDate() {
        Calendar c = Calendar.getInstance();
        if (dayStart > 0L) c.setTimeInMillis(dayStart);
        new DatePickerDialog(this, (view, y, m, d) -> {
            Calendar picked = Calendar.getInstance();
            picked.clear();
            picked.set(y, m, d, 0, 0, 0);
            dayStart = picked.getTimeInMillis();
            refreshDateTime();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void pickTime() {
        int h = minutes >= 0 ? minutes / 60 : 9;
        int m = minutes >= 0 ? minutes % 60 : 0;
        TimePickerDialog dlg = new TimePickerDialog(this, (view, hh, mm) -> {
            minutes = hh * 60 + mm;
            refreshDateTime();
        }, h, m, true);
        dlg.setButton(TimePickerDialog.BUTTON_NEUTRAL, getString(R.string.voice_no_time), (d, w) -> {
            minutes = -1;
            refreshDateTime();
        });
        dlg.show();
    }

    private long selectedKidId(boolean allowAll) {
        int checked = kidGroup.getCheckedButtonId();
        if (kids.size() >= 2) {
            if (checked == R.id.photo_kid_a) return kids.get(0).id;
            if (checked == R.id.photo_kid_b) return kids.get(1).id;
        }
        return allowAll ? KidRepository.KID_ID_ALL : -1L;
    }

    // ===== Uloženie =====

    private void save() {
        String t = title.getText().toString().trim();
        if (t.isEmpty()) {
            Toast.makeText(this, R.string.voice_title_missing, Toast.LENGTH_SHORT).show();
            return;
        }
        long now = System.currentTimeMillis();
        if (kindGroup.getCheckedButtonId() == R.id.photo_kind_payment) {
            long kidId = selectedKidId(false);
            if (kidId <= 0L) {
                Toast.makeText(this, R.string.kid_payment_error_kid, Toast.LENGTH_SHORT).show();
                return;
            }
            if (dayStart <= 0L) {
                Toast.makeText(this, R.string.kid_payment_error_due, Toast.LENGTH_SHORT).show();
                return;
            }
            KidPayment p = new KidPayment();
            p.kidId = kidId;
            p.title = t;
            p.amountEur = parseAmount(amount.getText().toString());
            String ib = iban.getText().toString().replace(" ", "").toUpperCase(Locale.ROOT);
            p.iban = ib.isEmpty() ? null : ib;
            p.paymentMethod = p.iban != null ? KidPayment.METHOD_TRANSFER : KidPayment.METHOD_OTHER;
            p.variableSymbol = emptyToNull(vs.getText().toString());
            p.specificSymbol = emptyToNull(ss.getText().toString());
            p.dueDate = dayStart;
            long notify = atNine(dayStart, -2);
            p.notifyAt = notify > now ? notify : 0L;
            ExactAlarmNotice.maybeWarn(this, p.notifyAt);
            repo.savePayment(p, id -> runOnUiThread(() -> {
                Toast.makeText(this, R.string.kid_payment_saved, Toast.LENGTH_SHORT).show();
                startActivity(PaymentTicketActivity.newIntent(this, id));
                finishAndCleanup();
            }));
        } else {
            if (dayStart <= 0L) {
                Toast.makeText(this, R.string.kid_event_error_start, Toast.LENGTH_SHORT).show();
                return;
            }
            KidEvent e = new KidEvent();
            long kidId = selectedKidId(true);
            e.assignKid(kidId);
            e.title = t;
            e.allDay = minutes < 0;
            e.startDate = minutes < 0 ? dayStart : dayStart + minutes * 60_000L;
            long notify = atNine(dayStart, -1);
            e.notifyAt = notify > now ? notify : 0L;
            ExactAlarmNotice.maybeWarn(this, e.notifyAt);
            repo.saveEvent(e, id -> runOnUiThread(() -> {
                Toast.makeText(this, R.string.kid_event_saved, Toast.LENGTH_SHORT).show();
                startActivity(KidEventEditorActivity.newIntent(this, id, kidId));
                finishAndCleanup();
            }));
        }
    }

    private static long atNine(long day, int dayOffset) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(day);
        c.add(Calendar.DAY_OF_MONTH, dayOffset);
        c.set(Calendar.HOUR_OF_DAY, 9);
        c.set(Calendar.MINUTE, 0);
        return c.getTimeInMillis();
    }

    @Nullable
    private static Double parseAmount(String s) {
        String v = s.trim().replace(" ", "").replace(',', '.');
        if (v.isEmpty()) return null;
        try {
            return new BigDecimal(v).doubleValue();
        } catch (NumberFormatException e) {
            return null;
        }
    }

    @Nullable
    private static String emptyToNull(String s) {
        String v = s.trim();
        return v.isEmpty() ? null : v;
    }

    // ===== Upratovanie =====

    private void finishAndCleanup() {
        deletePhoto();
        finish();
    }

    private void deletePhoto() {
        if (photo == null) return;
        if (photoIsAttachment) {
            ImageStorage.deleteIfExists(photo.getAbsolutePath());
        } else {
            //noinspection ResultOfMethodCallIgnored
            photo.delete();
        }
        photo = null;
    }
}
