package sk.aetheriqa.noteiqa.data.entity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/**
 * KidEvent – udalosť v kalendári dieťaťa.
 *
 * Príklady:
 *  - Školský výlet do Bratislavy (Alex, 15.5.2026 8:00–18:00)
 *  - Návšteva divadla (Gabika, 22.5.2026 17:00)
 *  - Sústredenie karate (Alex, 20.–22.6.2026)
 *  - Jarné prázdniny (Alex + Gabika, 2.–6.3.2026 celý deň)
 *  - Lekárska prehliadka (Gabika, 10.4.2026 14:30)
 *
 * Udalosť sa **automaticky injectuje aj do Môj to do listu** cez
 * `TaskAdapter.mergeKidEvents` — vytvorí sa syntetický TaskLike
 * bez zápisu do tabuľky `tasks`, len na render (šedší štýl + baby icon).
 *
 * Notifikácia deň vopred cez `KidEventReminderScheduler`.
 */
@Entity(
        tableName = "kid_events",
        foreignKeys = @ForeignKey(
                entity = Kid.class,
                parentColumns = "id",
                childColumns = "kidId",
                onDelete = ForeignKey.CASCADE),
        indices = {@Index("kidId"), @Index("startDate")})
public class KidEvent {

    public static final int TYPE_SCHOOL = 0;      // škola, výlet, exkurzia
    public static final int TYPE_SPORT = 1;       // tréning, zápas, sústredenie
    public static final int TYPE_HEALTH = 2;      // lekár, dentista, kontrola
    public static final int TYPE_CULTURE = 3;     // divadlo, kino, koncert
    public static final int TYPE_HOLIDAY = 4;     // prázdniny, sviatky
    public static final int TYPE_OTHER = 5;

    @PrimaryKey(autoGenerate = true)
    public long id;

    /**
     * FK na Kid.
     *   > 0  = konkrétne dieťa
     *   NULL = udalosť sa týka VŠETKÝCH detí (napr. prázdniny)
     *
     * v1.2.0 — predtým 0L, čo padalo na FK (dieťa s id=0 neexistuje).
     * NULL FK SQLite nekontroluje a zmazanie dieťaťa spoločné udalosti nezmaže.
     * V UI sa pracuje s {@link #kidIdOrAll()} / {@link #assignKid(long)}, kde 0 = všetky.
     */
    @Nullable
    public Long kidId;

    @NonNull
    @ColumnInfo(defaultValue = "")
    public String title = "";

    public int type = TYPE_OTHER;

    /** Začiatok udalosti (00:00 ak `allDay = true`). */
    public long startDate;

    /**
     * Koniec udalosti. 0 = jednodňová (koniec = koniec dňa startDate).
     * Pre viacdňové udalosti (sústredenie 3 dní, prázdniny týždeň) = koniec.
     */
    public long endDate = 0L;

    /** Ak true, ignoruje sa čas — zobrazuje sa ako "celý deň". */
    public boolean allDay = false;

    /** Miesto / lokalita (voliteľné). */
    @Nullable
    public String location;

    @Nullable
    public String note;

    /** Kedy poslať notifikáciu deň vopred. 0 = žiadna. */
    public long notifyAt;

    public long createdAt;
    public long updatedAt;

    public KidEvent() {}

    /** kidId pre UI: 0 = všetky deti (KidRepository.KID_ID_ALL). */
    public long kidIdOrAll() {
        return kidId != null ? kidId : 0L;
    }

    /** Nastaví dieťa z UI hodnoty; 0 (alebo menej) = všetky deti → NULL. */
    public void assignKid(long uiKidId) {
        kidId = uiKidId > 0L ? uiKidId : null;
    }

    /** True ak udalosť pokrýva daný deň (start ≤ day < end alebo start = day pri jednodňovej). */
    public boolean coversDay(long dayStartMillis, long dayEndMillis) {
        if (endDate == 0L) {
            // Jednodňová: startDate patrí do [dayStart, dayEnd)
            return startDate >= dayStartMillis && startDate < dayEndMillis;
        }
        // Multi-day: prekrytie intervalov
        return startDate < dayEndMillis && endDate >= dayStartMillis;
    }
}
