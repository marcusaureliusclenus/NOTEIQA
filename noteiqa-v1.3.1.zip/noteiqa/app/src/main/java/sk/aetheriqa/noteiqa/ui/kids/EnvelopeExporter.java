package sk.aetheriqa.noteiqa.ui.kids;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.util.PaymentQr;

/**
 * EnvelopeExporter – v1.3.0 — "Obálka pre druhého rodiča".
 *
 * Ten istý lístok ako na obrazovke (view_payment_ticket) + QR z PayBySquare +
 * "Naskenuj v banke", ako PNG cez ACTION_SEND (image/png). Žiadny link do Noteiqy,
 * appka nič nikam neposiela — kam to pôjde, vyberá používateľ v share sheete.
 *
 * Len prevod s IBAN a sumou a len ak PayBySquare prešiel referenčným vektorom
 * (PaymentQr.canRender). Inak nič — zlý QR by v banke rozbil príkaz.
 */
final class EnvelopeExporter {

    private static final int OUTPUT_WIDTH_PX = 1080;
    private static final int BACKGROUND = Color.parseColor("#0A0A0A");

    private EnvelopeExporter() {}

    static void share(Activity activity, KidPayment p, @Nullable Kid kid) {
        if (!PaymentQr.canRender(p)) return;

        Bitmap bmp = render(activity, p, kid);
        if (bmp == null) {
            Toast.makeText(activity, R.string.ticket_send_failed, Toast.LENGTH_SHORT).show();
            return;
        }

        new Thread(() -> {
            Uri uri = null;
            try {
                File dir = new File(activity.getCacheDir(), "share");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("share dir");
                File file = new File(dir, "noteiqa_platba_" + p.id + ".png");
                try (FileOutputStream out = new FileOutputStream(file)) {
                    // PNG — zlatý rám a QR moduly ostanú ostré (JPG by ich rozmazal)
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
                }
                uri = FileProvider.getUriForFile(activity,
                        activity.getPackageName() + ".fileprovider", file);
            } catch (IOException | IllegalArgumentException e) {
                uri = null;
            } finally {
                bmp.recycle();
            }
            final Uri shareUri = uri;
            activity.runOnUiThread(() -> {
                if (activity.isFinishing()) return;
                if (shareUri == null) {
                    Toast.makeText(activity, R.string.ticket_send_failed, Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("image/png");
                send.putExtra(Intent.EXTRA_STREAM, shareUri);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                activity.startActivity(Intent.createChooser(send,
                        activity.getString(R.string.ticket_send_chooser)));
            });
        }, "EnvelopeExport").start();
    }

    /** Offscreen render karty: šírka 420 dp, výstup zväčšený na 1080 px. */
    @Nullable
    private static Bitmap render(Activity activity, KidPayment p, @Nullable Kid kid) {
        int cardWidth = PaymentTicketBinder.dp(activity, 420);
        int margin = PaymentTicketBinder.dp(activity, 20);
        float scale = OUTPUT_WIDTH_PX / (float) (cardWidth + 2 * margin);

        FrameLayout root = new FrameLayout(activity);
        View card = LayoutInflater.from(activity).inflate(R.layout.view_payment_ticket, root, false);
        root.addView(card, new FrameLayout.LayoutParams(cardWidth, FrameLayout.LayoutParams.WRAP_CONTENT));

        // QR bitmapu rovno vo výstupnom rozlíšení, aby sa nemusela zväčšovať
        int qrPx = Math.round(PaymentTicketBinder.dp(activity, 240) * scale);
        PaymentTicketBinder.bind(card, p, kid, true, qrPx);
        if (card.findViewById(R.id.ticket_qr_box).getVisibility() != View.VISIBLE) return null;

        card.measure(View.MeasureSpec.makeMeasureSpec(cardWidth, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        card.layout(0, 0, card.getMeasuredWidth(), card.getMeasuredHeight());

        int outW = OUTPUT_WIDTH_PX;
        int outH = Math.round((card.getMeasuredHeight() + 2 * margin) * scale);
        Bitmap bmp;
        try {
            bmp = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
        } catch (OutOfMemoryError e) {
            return null;
        }
        Canvas c = new Canvas(bmp);
        c.drawColor(BACKGROUND);
        c.scale(scale, scale);
        c.translate(margin, margin);
        card.draw(c);
        return bmp;
    }
}
