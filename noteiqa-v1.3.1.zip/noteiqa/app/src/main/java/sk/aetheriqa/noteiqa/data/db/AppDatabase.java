package sk.aetheriqa.noteiqa.data.db;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import sk.aetheriqa.noteiqa.data.db.dao.ChecklistDao;
import sk.aetheriqa.noteiqa.data.db.dao.NoteDao;
import sk.aetheriqa.noteiqa.data.db.dao.ReminderDao;
import sk.aetheriqa.noteiqa.data.db.dao.KidDao;
import sk.aetheriqa.noteiqa.data.db.dao.KidEventDao;
import sk.aetheriqa.noteiqa.data.db.dao.KidPaymentDao;
import sk.aetheriqa.noteiqa.data.db.dao.SubtaskDao;
import sk.aetheriqa.noteiqa.data.db.dao.TagDao;
import sk.aetheriqa.noteiqa.data.db.dao.TaskCategoryDao;
import sk.aetheriqa.noteiqa.data.db.dao.TaskDao;
import sk.aetheriqa.noteiqa.data.db.dao.TemplateDao;
import sk.aetheriqa.noteiqa.data.db.dao.WeightDao;
import sk.aetheriqa.noteiqa.data.entity.ChecklistItem;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.entity.Note;
import sk.aetheriqa.noteiqa.data.entity.NoteTagCrossRef;
import sk.aetheriqa.noteiqa.data.entity.Reminder;
import sk.aetheriqa.noteiqa.data.entity.Subtask;
import sk.aetheriqa.noteiqa.data.entity.Tag;
import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.data.entity.TaskCategory;
import sk.aetheriqa.noteiqa.data.entity.Template;
import sk.aetheriqa.noteiqa.data.entity.WeightEntry;
import sk.aetheriqa.noteiqa.data.entity.WeightGoal;

/**
 * AppDatabase – Room database singleton.
 *
 * Verzia 2 – pridané: tasks, task_categories, subtasks (To Do modul).
 * Migrácia z v1 → v2 zachováva všetky existujúce poznámky a váženia.
 */
@Database(
    version = AppDatabase.VERSION,
    exportSchema = true,
    entities = {
        Note.class,
        Tag.class,
        NoteTagCrossRef.class,
        ChecklistItem.class,
        Reminder.class,
        WeightEntry.class,
        WeightGoal.class,
        Template.class,
        // v2 – To Do
        Task.class,
        TaskCategory.class,
        Subtask.class,
        // v7 – Deti modul
        Kid.class,
        KidPayment.class,
        KidEvent.class
    }
)
public abstract class AppDatabase extends RoomDatabase {

    /**
     * v1.2.0 — jediné miesto s verziou schémy. Používa ju @Database aj
     * BackupExporter/BackupImporter (schema_version v zálohe).
     */
    public static final int VERSION = 8;

    public static final String DB_NAME = "noteiqa.db";
    private static volatile AppDatabase INSTANCE;

    public abstract NoteDao noteDao();
    public abstract TagDao tagDao();
    public abstract ChecklistDao checklistDao();
    public abstract ReminderDao reminderDao();
    public abstract WeightDao weightDao();
    public abstract TemplateDao templateDao();
    public abstract TaskDao taskDao();
    public abstract TaskCategoryDao taskCategoryDao();
    public abstract SubtaskDao subtaskDao();
    // v7 – Deti modul
    public abstract KidDao kidDao();
    public abstract KidPaymentDao kidPaymentDao();
    public abstract KidEventDao kidEventDao();

    public static AppDatabase getInstance(Context ctx) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                            ctx.getApplicationContext(),
                            AppDatabase.class,
                            DB_NAME)
                        .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8)
                        .fallbackToDestructiveMigrationOnDowngrade()
                        .build();
                }
            }
        }
        return INSTANCE;
    }

    /**
     * v1 → v2: pridanie 3 nových tabuliek pre To Do modul.
     * Existujúce dáta (Notes, Weights, ...) sa neovplyvnia.
     */
    static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase db) {
            // 1) task_categories
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `task_categories` (" +
                "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`name` TEXT NOT NULL, " +
                "`color` TEXT, " +
                "`sortOrder` INTEGER NOT NULL, " +
                "`systemCategory` INTEGER NOT NULL)"
            );
            db.execSQL(
                "CREATE UNIQUE INDEX IF NOT EXISTS `index_task_categories_name` " +
                "ON `task_categories` (`name`)"
            );

            // 2) tasks
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `tasks` (" +
                "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`title` TEXT, " +
                "`note` TEXT, " +
                "`audioPath` TEXT, " +
                "`categoryId` INTEGER, " +
                "`dueDate` INTEGER, " +
                "`dueTimeMinutes` INTEGER, " +
                "`repeatType` INTEGER NOT NULL, " +
                "`repeatDays` INTEGER NOT NULL, " +
                "`priority` INTEGER NOT NULL, " +
                "`completed` INTEGER NOT NULL, " +
                "`completedAt` INTEGER NOT NULL, " +
                "`reminderAt` INTEGER NOT NULL, " +
                "`createdAt` INTEGER NOT NULL, " +
                "`updatedAt` INTEGER NOT NULL, " +
                "FOREIGN KEY(`categoryId`) REFERENCES `task_categories`(`id`) " +
                "ON UPDATE NO ACTION ON DELETE SET NULL)"
            );
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_tasks_dueDate` ON `tasks` (`dueDate`)");
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_tasks_completed` ON `tasks` (`completed`)");
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_tasks_categoryId` ON `tasks` (`categoryId`)");
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_tasks_priority` ON `tasks` (`priority`)");

            // 3) subtasks
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `subtasks` (" +
                "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`taskId` INTEGER NOT NULL, " +
                "`text` TEXT NOT NULL, " +
                "`completed` INTEGER NOT NULL, " +
                "`sortOrder` INTEGER NOT NULL, " +
                "`createdAt` INTEGER NOT NULL, " +
                "FOREIGN KEY(`taskId`) REFERENCES `tasks`(`id`) " +
                "ON UPDATE NO ACTION ON DELETE CASCADE)"
            );
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_subtasks_taskId` ON `subtasks` (`taskId`)");
        }
    };

    /**
     * v2 → v3: pridanie archivedAt a shoppingItemsJson na tasks.
     * Existujúce úlohy ostávajú s archivedAt = 0 (živé).
     */
    static final Migration MIGRATION_2_3 = new Migration(2, 3) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase db) {
            db.execSQL("ALTER TABLE `tasks` ADD COLUMN `archivedAt` INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE `tasks` ADD COLUMN `shoppingItemsJson` TEXT");
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_tasks_archivedAt` ON `tasks` (`archivedAt`)");
        }
    };

    /**
     * v3 → v4: pridanie attachmentImagePath na notes pre pripojené obrázky.
     */
    static final Migration MIGRATION_3_4 = new Migration(3, 4) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase db) {
            db.execSQL("ALTER TABLE `notes` ADD COLUMN `attachmentImagePath` TEXT");
        }
    };

    /**
     * v4 → v5: pridanie moodFlags na weight_entries.
     * Bitmask 7 mood flagov (menzes, po cvičení, málo spánku, ...).
     * Existujúce váženia ostávajú s moodFlags = 0.
     */
    static final Migration MIGRATION_4_5 = new Migration(4, 5) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase db) {
            db.execSQL("ALTER TABLE `weight_entries` ADD COLUMN `moodFlags` INTEGER NOT NULL DEFAULT 0");
        }
    };

    /**
     * v5 → v6: pridanie manualSortOrder na tasks pre šípky hore/dole.
     * Existujúce úlohy ostanú s manualSortOrder = 0 → fallback na čas-based sort.
     */
    static final Migration MIGRATION_5_6 = new Migration(5, 6) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase db) {
            db.execSQL("ALTER TABLE `tasks` ADD COLUMN `manualSortOrder` INTEGER NOT NULL DEFAULT 0");
        }
    };

    /**
     * v6 → v7: Deti modul.
     * Nové tabuľky: kids, kid_payments, kid_events.
     * Existujúce dáta (poznámky, úlohy, váženia) sa nemenia.
     * Seed sa spraví z NoteiqaApplication pri prvom spustení modulu.
     */
    static final Migration MIGRATION_6_7 = new Migration(6, 7) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase db) {
            // Kids
            db.execSQL("CREATE TABLE IF NOT EXISTS `kids` (" +
                    "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                    "`name` TEXT NOT NULL DEFAULT '', " +
                    "`colorHex` TEXT NOT NULL DEFAULT '#C9A961', " +
                    "`sortOrder` INTEGER NOT NULL DEFAULT 0, " +
                    "`createdAt` INTEGER NOT NULL DEFAULT 0, " +
                    "`updatedAt` INTEGER NOT NULL DEFAULT 0)");

            // Kid payments
            db.execSQL("CREATE TABLE IF NOT EXISTS `kid_payments` (" +
                    "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                    "`kidId` INTEGER NOT NULL, " +
                    "`title` TEXT NOT NULL DEFAULT '', " +
                    "`amountEur` REAL, " +
                    "`paymentMethod` INTEGER NOT NULL DEFAULT 0, " +
                    "`iban` TEXT, " +
                    "`variableSymbol` TEXT, " +
                    "`specificSymbol` TEXT, " +
                    "`paymentNote` TEXT, " +
                    "`cashRecipient` TEXT, " +
                    "`dueDate` INTEGER NOT NULL DEFAULT 0, " +
                    "`notifyAt` INTEGER NOT NULL DEFAULT 0, " +
                    "`recurrence` INTEGER NOT NULL DEFAULT 0, " +
                    "`completed` INTEGER NOT NULL DEFAULT 0, " +
                    "`completedAt` INTEGER NOT NULL DEFAULT 0, " +
                    "`note` TEXT, " +
                    "`createdAt` INTEGER NOT NULL DEFAULT 0, " +
                    "`updatedAt` INTEGER NOT NULL DEFAULT 0, " +
                    "FOREIGN KEY(`kidId`) REFERENCES `kids`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)");
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_kid_payments_kidId` ON `kid_payments` (`kidId`)");
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_kid_payments_dueDate` ON `kid_payments` (`dueDate`)");

            // Kid events
            db.execSQL("CREATE TABLE IF NOT EXISTS `kid_events` (" +
                    "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                    "`kidId` INTEGER NOT NULL, " +
                    "`title` TEXT NOT NULL DEFAULT '', " +
                    "`type` INTEGER NOT NULL DEFAULT 5, " +
                    "`startDate` INTEGER NOT NULL DEFAULT 0, " +
                    "`endDate` INTEGER NOT NULL DEFAULT 0, " +
                    "`allDay` INTEGER NOT NULL DEFAULT 0, " +
                    "`location` TEXT, " +
                    "`note` TEXT, " +
                    "`notifyAt` INTEGER NOT NULL DEFAULT 0, " +
                    "`createdAt` INTEGER NOT NULL DEFAULT 0, " +
                    "`updatedAt` INTEGER NOT NULL DEFAULT 0, " +
                    "FOREIGN KEY(`kidId`) REFERENCES `kids`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)");
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_kid_events_kidId` ON `kid_events` (`kidId`)");
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_kid_events_startDate` ON `kid_events` (`startDate`)");
        }
    };

    /**
     * v7 → v8 (v1.2.0):
     *  - kid_events.kidId je nullable; NULL = udalosť pre všetky deti.
     *    Staré riadky s kidId = 0 (ak by nejaké prešli) sa prepíšu na NULL.
     *    FK ostáva pre konkrétne deti (CASCADE), NULL SQLite nekontroluje,
     *    takže zmazanie dieťaťa spoločné udalosti nezmaže.
     *  - kid_payments.originPaymentId — z ktorej platby vznikla ďalšia
     *    inštancia pri opakovaní (len na debug / históriu).
     */
    static final Migration MIGRATION_7_8 = new Migration(7, 8) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS `kid_events_new` (" +
                    "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                    "`kidId` INTEGER, " +
                    "`title` TEXT NOT NULL DEFAULT '', " +
                    "`type` INTEGER NOT NULL DEFAULT 5, " +
                    "`startDate` INTEGER NOT NULL DEFAULT 0, " +
                    "`endDate` INTEGER NOT NULL DEFAULT 0, " +
                    "`allDay` INTEGER NOT NULL DEFAULT 0, " +
                    "`location` TEXT, " +
                    "`note` TEXT, " +
                    "`notifyAt` INTEGER NOT NULL DEFAULT 0, " +
                    "`createdAt` INTEGER NOT NULL DEFAULT 0, " +
                    "`updatedAt` INTEGER NOT NULL DEFAULT 0, " +
                    "FOREIGN KEY(`kidId`) REFERENCES `kids`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)");
            db.execSQL("INSERT INTO `kid_events_new` (`id`, `kidId`, `title`, `type`, " +
                    "`startDate`, `endDate`, `allDay`, `location`, `note`, `notifyAt`, " +
                    "`createdAt`, `updatedAt`) " +
                    "SELECT `id`, CASE WHEN `kidId` > 0 THEN `kidId` ELSE NULL END, `title`, `type`, " +
                    "`startDate`, `endDate`, `allDay`, `location`, `note`, `notifyAt`, " +
                    "`createdAt`, `updatedAt` FROM `kid_events`");
            db.execSQL("DROP TABLE `kid_events`");
            db.execSQL("ALTER TABLE `kid_events_new` RENAME TO `kid_events`");
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_kid_events_kidId` ON `kid_events` (`kidId`)");
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_kid_events_startDate` ON `kid_events` (`startDate`)");

            db.execSQL("ALTER TABLE `kid_payments` ADD COLUMN `originPaymentId` INTEGER");
        }
    };
}
