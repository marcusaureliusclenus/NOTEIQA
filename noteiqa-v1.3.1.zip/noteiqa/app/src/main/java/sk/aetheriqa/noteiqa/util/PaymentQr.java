package sk.aetheriqa.noteiqa.util;

import android.text.TextUtils;

import androidx.annotation.Nullable;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import sk.aetheriqa.noteiqa.data.entity.KidPayment;

/**
 * PaymentQr – v1.3.0 — most medzi KidPayment a PayBySquare.
 * QR len pre prevod s IBAN a sumou a len ak PayBySquare prešiel referenčným vektorom.
 */
public final class PaymentQr {

    private PaymentQr() {}

    public static boolean canRender(KidPayment p) {
        return p != null
                && p.paymentMethod == KidPayment.METHOD_TRANSFER
                && !TextUtils.isEmpty(p.iban)
                && p.amountEur != null && p.amountEur > 0d
                && PayBySquare.isVerified();
    }

    /** PAY by square reťazec alebo null (nedá sa / chyba). */
    @Nullable
    public static String code(KidPayment p) {
        if (!canRender(p)) return null;
        PayBySquare.Input in = new PayBySquare.Input();
        in.amount = BigDecimal.valueOf(p.amountEur);
        long due = p.dueDate > 0L ? p.dueDate : System.currentTimeMillis();
        in.dueDate = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date(due));
        in.variableSymbol = p.variableSymbol;
        in.specificSymbol = p.specificSymbol;
        in.paymentNote = p.paymentNote;
        in.iban = p.iban;
        // Príjemcu entita nemá — podľa zadania názov platby (max 70, bez diakritiky)
        in.beneficiaryName = p.title;
        try {
            return PayBySquare.generate(in);
        } catch (Exception e) {
            return null;
        }
    }
}
