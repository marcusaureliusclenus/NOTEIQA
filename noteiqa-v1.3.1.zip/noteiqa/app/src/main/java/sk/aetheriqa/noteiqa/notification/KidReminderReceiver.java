package sk.aetheriqa.noteiqa.notification;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;

import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;

/**
 * KidReminderReceiver – prijíma alarm trigger pre platby aj udalosti.
 *
 * Používa EXTRA_KIND na rozlíšenie payment vs event, potom asynchrónne
 * načíta z DB a delegateuje na NotificationHelper.showKidPaymentReminder /
 * showKidEventReminder.
 */
public class KidReminderReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;

        final String kind = intent.getStringExtra(KidReminderScheduler.EXTRA_KIND);
        final long id = intent.getLongExtra(KidReminderScheduler.EXTRA_ID, 0L);
        if (kind == null || id == 0L) return;

        final Context appCtx = context.getApplicationContext();
        new Thread(() -> {
            KidRepository repo = KidRepository.getInstance(appCtx);
            java.util.List<Kid> kids = repo.getKidsSync();

            if (KidReminderScheduler.KIND_PAYMENT.equals(kind)) {
                KidPayment payment = repo.getPaymentSync(id);
                if (payment == null || payment.completed) return;
                Kid kid = findKid(kids, payment.kidId);
                final Kid finalKid = kid;
                new Handler(Looper.getMainLooper()).post(() ->
                        NotificationHelper.showKidPaymentReminder(appCtx, payment, finalKid));
            } else if (KidReminderScheduler.KIND_EVENT.equals(kind)) {
                KidEvent event = repo.getEventSync(id);
                if (event == null) return;
                Kid kid = findKid(kids, event.kidIdOrAll());
                final Kid finalKid = kid;
                new Handler(Looper.getMainLooper()).post(() ->
                        NotificationHelper.showKidEventReminder(appCtx, event, finalKid));
            }
        }, "KidReminderReceiver").start();
    }

    private static Kid findKid(java.util.List<Kid> kids, long kidId) {
        for (Kid k : kids) if (k.id == kidId) return k;
        return null; // 0 = "všetky deti" alebo neexistuje
    }
}
