package sk.aetheriqa.noteiqa.ui.kids;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.util.DateUtils;
import sk.aetheriqa.noteiqa.util.PaymentQr;
import sk.aetheriqa.noteiqa.util.QrBitmap;

/**
 * PaymentTicketBinder – v1.3.0 — naplní view_payment_ticket.xml dátami platby.
 * Rovnaký kód pre obrazovku (PaymentTicketActivity) aj obálku (EnvelopeExporter).
 */
final class PaymentTicketBinder {

    private static final int GOLD = 0xFFC9A961;

    private PaymentTicketBinder() {}

    /**
     * @param envelope true = PNG pre druhého rodiča: bez pečiatky a gest, s "Naskenuj v banke"
     * @param qrPx     veľkosť QR bitmapy v px
     */
    static void bind(View card, KidPayment p, @Nullable Kid kid, boolean envelope, int qrPx) {
        bind(card, p, kid, null, envelope, qrPx);
    }

    /** @param event v1.3.3 — udalosť podľa p.eventId (riadok „K udalosti“), alebo null */
    static void bind(View card, KidPayment p, @Nullable Kid kid, @Nullable KidEvent event,
                     boolean envelope, int qrPx) {
        Context ctx = card.getContext();

        ((TextView) card.findViewById(R.id.ticket_title)).setText(p.title);

        TextView kidView = card.findViewById(R.id.ticket_kid);
        if (kid != null) {
            kidView.setText(kid.name);
            kidView.setVisibility(View.VISIBLE);
            Drawable bg = kidView.getBackground();
            if (bg != null) {
                bg = bg.mutate();
                if (bg instanceof GradientDrawable) {
                    ((GradientDrawable) bg).setStroke(dp(ctx, 2), kidColor(kid));
                }
                kidView.setBackground(bg);
            }
            kidView.setTextColor(kidColor(kid));
        } else {
            kidView.setVisibility(View.GONE);
        }

        TextView eventLine = card.findViewById(R.id.ticket_event);
        if (event != null) {
            eventLine.setText(ctx.getString(R.string.ticket_for_event, event.title,
                    DateUtils.formatNumericDate(event.startDate)));
            eventLine.setVisibility(View.VISIBLE);
        } else {
            eventLine.setVisibility(View.GONE);
        }

        TextView amount = card.findViewById(R.id.ticket_amount);
        if (p.amountEur != null) {
            amount.setText(ctx.getString(R.string.ticket_amount, formatAmount(p.amountEur)));
            amount.setVisibility(View.VISIBLE);
        } else {
            amount.setVisibility(View.GONE);
        }

        TextView due = card.findViewById(R.id.ticket_due);
        if (p.dueDate > 0L) {
            due.setText(ctx.getString(R.string.ticket_due, DateUtils.formatNumericDate(p.dueDate)));
            due.setVisibility(View.VISIBLE);
        } else {
            due.setVisibility(View.GONE);
        }

        LinearLayout details = card.findViewById(R.id.ticket_details);
        details.removeAllViews();
        if (p.paymentMethod == KidPayment.METHOD_TRANSFER) {
            addRow(details, ctx.getString(R.string.kid_payment_label_beneficiary), p.beneficiaryName, false);
            addRow(details, ctx.getString(R.string.kid_payment_iban_hint), groupIban(p.iban), true);
            addRow(details, ctx.getString(R.string.kid_payment_label_vs), p.variableSymbol, false);
            addRow(details, ctx.getString(R.string.kid_payment_label_ss), p.specificSymbol, false);
            addRow(details, ctx.getString(R.string.kid_payment_label_msg), p.paymentNote, false);
        } else if (p.paymentMethod == KidPayment.METHOD_CASH) {
            if (!TextUtils.isEmpty(p.cashRecipient)) {
                addRow(details, ctx.getString(R.string.kid_method_short_cash),
                        ctx.getString(R.string.ticket_cash_for, p.cashRecipient), false);
            }
            addRow(details, ctx.getString(R.string.kid_payment_label_beneficiary), p.beneficiaryName, false);
        } else {
            addRow(details, ctx.getString(R.string.kid_payment_label_beneficiary), p.beneficiaryName, false);
        }
        addRow(details, ctx.getString(R.string.kid_payment_note_hint), p.note, false);
        details.setVisibility(details.getChildCount() > 0 ? View.VISIBLE : View.GONE);

        // QR — len prevod s IBAN a sumou a len ak PayBySquare prešiel referenčným vektorom
        // v1.3.2 — celý blok (QR, "Naskenuj v banke", Poslať) je viditeľný alebo gone naraz
        View qrBlock = card.findViewById(R.id.ticket_qr_block);
        ImageView qr = card.findViewById(R.id.ticket_qr);
        String code = PaymentQr.code(p);
        Bitmap qrBmp = code != null ? QrBitmap.render(code, qrPx) : null;
        if (qrBmp != null) {
            BitmapDrawable d = new BitmapDrawable(ctx.getResources(), qrBmp);
            d.setFilterBitmap(false); // ostré moduly aj pri škálovaní
            d.setAntiAlias(false);
            qr.setImageDrawable(d);
            qrBlock.setVisibility(View.VISIBLE);
        } else {
            qr.setImageDrawable(null);
            qrBlock.setVisibility(View.GONE);
        }
        card.findViewById(R.id.ticket_qr_missing).setVisibility(
                !envelope && qrBmp == null && PaymentQr.missingBeneficiary(p) ? View.VISIBLE : View.GONE);

        // obálka: "Naskenuj v banke", bez Poslať; obrazovka: Poslať, bez hintu
        card.findViewById(R.id.ticket_scan_hint).setVisibility(envelope ? View.VISIBLE : View.GONE);
        card.findViewById(R.id.ticket_send).setVisibility(envelope ? View.GONE : View.VISIBLE);
        card.findViewById(R.id.ticket_stamp)
                .setVisibility(!envelope && p.completed ? View.VISIBLE : View.GONE);
        card.findViewById(R.id.ticket_next_due).setVisibility(View.GONE);
    }

    static String formatAmount(double eur) {
        return String.format(Locale.US, "%.2f", eur).replace('.', ',');
    }

    static int kidColor(@Nullable Kid kid) {
        if (kid == null) return GOLD;
        try {
            return Color.parseColor(kid.colorHex);
        } catch (IllegalArgumentException e) {
            return GOLD;
        }
    }

    /** "SK8975000000000012345671" → "SK89 7500 0000 0000 1234 5671" (len zobrazenie). */
    static String groupIban(@Nullable String iban) {
        if (TextUtils.isEmpty(iban)) return iban;
        String raw = iban.replace(" ", "").toUpperCase(Locale.ROOT);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < raw.length(); i++) {
            if (i > 0 && i % 4 == 0) sb.append(' ');
            sb.append(raw.charAt(i));
        }
        return sb.toString();
    }

    private static void addRow(LinearLayout parent, String label, @Nullable String value,
                               boolean monospace) {
        if (TextUtils.isEmpty(value)) return;
        View row = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_ticket_detail_row, parent, false);
        ((TextView) row.findViewById(R.id.ticket_row_label)).setText(label);
        TextView v = row.findViewById(R.id.ticket_row_value);
        v.setText(value);
        if (monospace) v.setTypeface(Typeface.MONOSPACE);
        parent.addView(row);
    }

    static int dp(Context ctx, float v) {
        return Math.round(v * ctx.getResources().getDisplayMetrics().density);
    }
}
