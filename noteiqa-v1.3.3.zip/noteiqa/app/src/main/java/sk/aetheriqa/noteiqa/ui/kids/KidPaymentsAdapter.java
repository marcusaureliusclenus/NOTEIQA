package sk.aetheriqa.noteiqa.ui.kids;

import android.graphics.Color;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.util.DateUtils;

/**
 * KidPaymentsAdapter – jednoduchý zoznam platieb.
 *
 * Ako priradzujeme kid meno / farbu: prijímame List<Kid> cez setKids() z rodiča
 * (SubFragment), aby sme sa vyhli N-krát DB lookup pri každom bind.
 */
public class KidPaymentsAdapter extends RecyclerView.Adapter<KidPaymentsAdapter.VH> {

    public interface Listener {
        void onClick(KidPayment p);
        void onLongPress(KidPayment p);
        void onCheck(KidPayment p, boolean checked);
    }

    private final List<KidPayment> items = new ArrayList<>();
    private List<Kid> kids = new ArrayList<>();
    private final Listener listener;

    public KidPaymentsAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<KidPayment> newItems) {
        items.clear();
        if (newItems != null) items.addAll(newItems);
        notifyDataSetChanged();
    }

    public void setKids(List<Kid> kids) {
        this.kids = kids != null ? kids : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_kid_payment, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        KidPayment p = items.get(position);
        Kid kid = findKid(p.kidId);
        android.content.Context ctx = h.itemView.getContext();

        h.title.setText(p.title);
        h.kidName.setText(kid != null ? kid.name : "");
        h.kidName.setVisibility(kid != null ? View.VISIBLE : View.GONE);

        // Farebný chip
        int color;
        try {
            color = kid != null ? Color.parseColor(kid.colorHex) : 0xFFC9A961;
        } catch (IllegalArgumentException ex) {
            color = 0xFFC9A961;
        }
        h.colorChip.setBackgroundColor(color);

        // Amount
        if (p.amountEur != null) {
            h.amount.setText(String.format(Locale.getDefault(), "%.2f €", p.amountEur)
                    .replace('.', ','));
        } else {
            h.amount.setText("—");
        }

        // Meta: splatnosť + spôsob
        StringBuilder meta = new StringBuilder();
        if (p.dueDate > 0L) {
            meta.append(ctx.getString(R.string.kid_payment_meta_due, DateUtils.formatShortDate(p.dueDate)));
        }
        String methodLabel = methodLabel(ctx, p.paymentMethod);
        if (!methodLabel.isEmpty()) {
            if (meta.length() > 0) meta.append(" · ");
            meta.append(methodLabel);
        }
        if (p.recurrence != KidPayment.RECURRENCE_NONE) {
            String rec = recurrenceLabel(ctx, p);
            if (!rec.isEmpty()) meta.append(" · ").append(rec);
        }
        h.meta.setText(meta.toString());

        // Completed → suma (aj názov) prečiarknutá, alpha 0.45
        if (p.completed) {
            h.title.setPaintFlags(h.title.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            h.amount.setPaintFlags(h.amount.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            h.title.setAlpha(0.45f);
            h.amount.setAlpha(0.45f);
        } else {
            h.title.setPaintFlags(h.title.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
            h.amount.setPaintFlags(h.amount.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
            h.title.setAlpha(1.0f);
            h.amount.setAlpha(1.0f);
        }

        // Checkbox — bez triggeru na re-bind
        h.check.setOnCheckedChangeListener(null);
        h.check.setChecked(p.completed);
        h.check.setOnCheckedChangeListener((btn, checked) -> listener.onCheck(p, checked));

        h.itemView.setOnClickListener(v -> listener.onClick(p));
        h.itemView.setOnLongClickListener(v -> { listener.onLongPress(p); return true; });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private Kid findKid(long kidId) {
        for (Kid k : kids) if (k.id == kidId) return k;
        return null;
    }

    private static String methodLabel(android.content.Context ctx, int method) {
        switch (method) {
            case KidPayment.METHOD_TRANSFER: return ctx.getString(R.string.kid_method_short_transfer);
            case KidPayment.METHOD_CASH: return ctx.getString(R.string.kid_method_short_cash);
            case KidPayment.METHOD_OTHER: return ctx.getString(R.string.kid_method_short_other);
            default: return "";
        }
    }

    static String recurrenceLabel(android.content.Context ctx, KidPayment p) {
        switch (p.recurrence) {
            case KidPayment.RECURRENCE_MONTHLY: return ctx.getString(R.string.kid_recurrence_short_monthly);
            case KidPayment.RECURRENCE_QUARTERLY: return ctx.getString(R.string.kid_recurrence_short_quarterly);
            case KidPayment.RECURRENCE_SEMIANNUAL: return ctx.getString(R.string.kid_recurrence_short_semiannual);
            case KidPayment.RECURRENCE_YEARLY: return ctx.getString(R.string.kid_recurrence_short_yearly);
            case KidPayment.RECURRENCE_EXACT:
                return p.exactDueDate > 0L
                        ? ctx.getString(R.string.kid_recurrence_short_exact, formatDayMonth(p.exactDueDate))
                        : "";
            default: return "";
        }
    }

    /** v1.3.3 — "12. 11." */
    static String formatDayMonth(long ts) {
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.setTimeInMillis(ts);
        return c.get(java.util.Calendar.DAY_OF_MONTH) + ". " + (c.get(java.util.Calendar.MONTH) + 1) + ".";
    }

    /** v1.3.3 — "12. 11. 2026" */
    static String formatDayMonthYear(long ts) {
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.setTimeInMillis(ts);
        return formatDayMonth(ts) + " " + c.get(java.util.Calendar.YEAR);
    }

    static class VH extends RecyclerView.ViewHolder {
        final View colorChip;
        final TextView kidName, title, meta, amount;
        final CheckBox check;

        VH(@NonNull View item) {
            super(item);
            colorChip = item.findViewById(R.id.kid_color_chip);
            kidName = item.findViewById(R.id.kid_payment_kid_name);
            title = item.findViewById(R.id.kid_payment_title);
            meta = item.findViewById(R.id.kid_payment_meta);
            amount = item.findViewById(R.id.kid_payment_amount);
            check = item.findViewById(R.id.kid_payment_check);
        }
    }
}
