package sk.aetheriqa.noteiqa.data.entity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/**
 * KidPayment – jednotlivá platba naviazaná na dieťa.
 *
 * Príklady:
 *  - ŠKD (mesačne, SEPA prevod, IBAN SK12...)
 *  - Tréning karate (mesačne, hotovosť trénerovi Novákovi)
 *  - Školské knihy (jednorazovo, SEPA prevod)
 *  - Výlet do Vysokých Tatier (jednorazovo, hotovosť triednej)
 *
 * Notifikácia sa naplánuje na `notifyAt` (X dní pred splatnosťou),
 * pri triggeri sa zobrazí `KidPaymentContextDialog` s copy-friendly
 * IBAN / hotovosť detailmi.
 */
@Entity(
        tableName = "kid_payments",
        foreignKeys = @ForeignKey(
                entity = Kid.class,
                parentColumns = "id",
                childColumns = "kidId",
                onDelete = ForeignKey.CASCADE),
        indices = {@Index("kidId"), @Index("dueDate")})
public class KidPayment {

    public static final int METHOD_TRANSFER = 0; // SEPA prevod / IBAN
    public static final int METHOD_CASH = 1;     // hotovosť
    public static final int METHOD_OTHER = 2;    // karta, poštová poukážka…

    public static final int RECURRENCE_NONE = 0;
    public static final int RECURRENCE_MONTHLY = 1;
    public static final int RECURRENCE_QUARTERLY = 2;
    public static final int RECURRENCE_YEARLY = 3;
    /** v1.3.3 — +6 mesiacov. */
    public static final int RECURRENCE_SEMIANNUAL = 5;
    /** v1.3.3 — jeden skok na presný dátum {@link #exactDueDate}, potom bez opakovania. */
    public static final int RECURRENCE_EXACT = 6;

    @PrimaryKey(autoGenerate = true)
    public long id;

    public long kidId;

    /** Krátky názov: "ŠKD", "Karate", "Školské knihy". */
    @NonNull
    @ColumnInfo(defaultValue = "")
    public String title = "";

    /** Suma v EUR (napr. 25.50). Null ak variabilná. */
    @Nullable
    public Double amountEur;

    /** METHOD_TRANSFER / METHOD_CASH / METHOD_OTHER. */
    public int paymentMethod = METHOD_TRANSFER;

    /** IBAN pre METHOD_TRANSFER. Bez medzier v UI (Room ukládá ako user zadal). */
    @Nullable
    public String iban;

    /** Variabilný symbol pre METHOD_TRANSFER. */
    @Nullable
    public String variableSymbol;

    /** Špecifický symbol pre METHOD_TRANSFER. */
    @Nullable
    public String specificSymbol;

    /** Správa pre príjemcu pri prevode. */
    @Nullable
    public String paymentNote;

    /**
     * Pre METHOD_CASH: komu sa hotovosť odovzdáva
     * (napr. "Tréner Novák" alebo "Triedna Kováčová").
     */
    @Nullable
    public String cashRecipient;

    /** Splatnosť. */
    public long dueDate;

    /** Kedy poslať notifikáciu. 0 = žiadna. */
    public long notifyAt;

    /** RECURRENCE_NONE = jednorazová, ostatné = periodická. */
    public int recurrence = RECURRENCE_NONE;

    /** Ak completed = true → do UI ako "zaplatené" (šedý strikethrough). */
    public boolean completed = false;
    public long completedAt = 0L;

    /** Poznámka od používateľa. */
    @Nullable
    public String note;

    public long createdAt;
    public long updatedAt;

    /**
     * v1.2.0 — id platby, z ktorej táto inštancia vznikla pri opakovaní
     * (označenie zaplatené → ďalšia splatnosť). NULL = pôvodná / ručne zadaná.
     */
    @Nullable
    public Long originPaymentId;

    /** v1.3.3 — meno / názov príjemcu (Pay by Square ho vyžaduje). */
    @Nullable
    public String beneficiaryName;

    /** v1.3.3 — udalosť, ku ktorej platba patrí (switch „Platba / poplatok“). NULL = žiadna. */
    @Nullable
    public Long eventId;

    /** v1.3.3 — pre RECURRENCE_EXACT: splatnosť ďalšej inštancie. 0 = nič. */
    @ColumnInfo(defaultValue = "0")
    public long exactDueDate = 0L;

    public KidPayment() {}
}
