# Motivačné vety pre aplikáciu (300+ viet)

Krátke, povzbudivé, iskrivé a jemne humorné vety určené pre denný dashboard aplikácie. Tón je "cool", vtipný a menej sentimentálny.

## Jemne humorné
1. Dnes to dáš. A keď nie, aspoň budeš dobre vyzerať pri pokuse.
2. Niektoré dni sú na výkon, iné na prežitie so štýlom.
3. Dnes si šupa. Aj keby tepláky tvrdili opak.
4. Tvoj plán dňa: zvládnuť, zažiariť, nezblázniť sa.
5. Ak dnes niečo nestihneš, tvár sa, že to bol zámer.
6. Dnes stačí byť milá. Ale nie ku každému.
7. Tvoja energia možno ešte spí, ale sexappeal už funguje.
8. Dnes si zaslúžiš pochvalu aj dezert. Poradie nechám na tebe.
9. Si žena, nie multifunkčná tlačiareň. Nemusíš robiť všetko naraz.
10. Keby bol chaos šport, máš olympijskú medailu.
11. Dnes si daj pozor, aby si niekoho neoslepila. Svojou brilantnosťou, samozrejme.
12. Tvoj šarm je tak silný, že by mal mať vlastnú poistku.
13. Si taká skvelá, že aj tvoja káva sa cíti poctená.
14. Dnes je deň, kedy tvoj úsmev prekoná všetky prekážky. Alebo aspoň dopravnú zápchu.
15. Ak ti dnes niekto povie, že si príliš, odpovedz: „Ďakujem, snažím sa.“
16. Tvoja aura je taká silná, že by si mohla nabíjať telefóny.
17. Dnes si pripomeň, že si kráľovná. Aj keď máš na hlave drdol z tretieho dňa.
18. Si ako dobrý vtip – každý ťa chce počuť znova.
19. Tvoja inteligencia je taká sexi, že by mala byť zakázaná.
20. Dnes si daj pauzu. Svet počká, kým si dáš do poriadku korunu.
21. Si taká úžasná, že aj tvoj tieň má obdivovateľov.
22. Tvoja schopnosť zvládať veci je nadprirodzená. Si si istá, že nie si superhrdinka?
23. Dnes si zaslúžiš potlesk. A možno aj čokoládu.
24. Si taká ženská, že aj tvoje ponožky majú šarm.
25. Tvoj pohľad je taký prenikavý, že by mohol otvárať konzervy.
26. Dnes si pripomeň, že si vzácna. Ako posledný kúsok pizze.
27. Si taká cool, že aj ľadnička by si od teba pýtala tipy.
28. Tvoja charizma je taká silná, že by si mohla viesť sektu. Alebo aspoň tanečný krúžok.
29. Dnes si daj pozor, aby si niekoho neomráčila. Svojou osobnosťou, samozrejme.
30. Si taká skvelá, že aj tvoje chyby sú roztomilé.
31. Tvoja prítomnosť je taká osviežujúca, že by si mala byť v spreji.
32. Dnes si pripomeň, že si bohyňa. Aj keď máš na sebe staré tričko.
33. Si taká žiarivá, že by si mohla byť majákom.
34. Tvoja energia je taká nákazlivá, že by si mala byť na recept.
35. Dnes si daj pozor, aby si niekoho neokúzlila. Svojou prirodzenosťou, samozrejme.
36. Si taká úžasná, že aj tvoje vlasy majú vlastný príbeh.
37. Tvoja múdrosť je taká hlboká, že by si mohla byť oceánom.
38. Dnes si pripomeň, že si silná. Ako káva v pondelok ráno.
39. Si taká sexi, že aj tvoj tieň má sexappeal.
40. Tvoja krása je taká oslnivá, že by si mala nosiť slnečné okuliare. Pre ostatných.
41. Dnes si pripomeň, že si ako dobré víno – čím staršia, tým lepšia. A drahšia.
42. Si taká šikovná, že by si mohla učiť aj mravce, ako nosiť omrvinky.
43. Tvoj smiech je taký nákazlivý, že by mal byť na predpis.
44. Dnes si daj pozor, aby si niekoho neprekvapila. Svojou genialitou, samozrejme.
45. Si taká originálna, že aj tvoje odtlačky prstov sú umelecké dielo.
46. Tvoja prítomnosť je ako slnečný deň. Vždy rozžiari okolie.
47. Dnes si pripomeň, že si ako jednorožec. Vzácna a magická.
48. Si taká úžasná, že aj tvoje chyby sú súčasťou tvojho šarmu.
49. Tvoja charizma je taká silná, že by si mohla presvedčiť aj kameň, aby sa usmial.
50. Dnes si daj pozor, aby si niekoho neohúrila. Svojou jedinečnosťou, samozrejme.

## Sexappeal a ženskosť
1. Máš v sebe niečo, čo sa nedá naučiť. A to je tvoja super sila.
2. Tvoj sexappeal nie je o veku. Je o tom, ako si nesieš seba. A nesieš sa kráľovsky.
3. Si žena, za ktorou sa oplatí otočiť. A aj sa otáčajú.
4. Tvoja ženskosť má vlastný podpis. A je to bestseller.
5. Nie si „na svoj vek“ krásna. Si krásna. Bodka. A s výkričníkom.
6. Máš štýl, ktorý nepotrebuje vysvetlenie. Len obdiv.
7. Tvoja príťažlivosť je v pohľade, postoji aj energii. A tá je nákazlivá.
8. Si dôkaz, že zrelosť vie byť veľmi príťažlivá. A sakra sexi.
9. Máš iskru, ktorú make-up nevie vyrobiť. Tá je tvoja vlastná.
10. Dnes si pripomeň: stále to tam je. A v plnej sile.
11. Prosím, nemysli na hriešne veci. Ty si totiž celá hriešne dobrá. A vieš o tom.
12. Tvoj úsmev by mal mať vlastné bezpečnostné upozornenie. Pre prípad, že by niekto odpadol.
13. Keď vojdeš do miestnosti, aj zrkadlo sa tvári spokojnejšie. A obdivne.
14. Tvoja ženskosť nie je nahlas. Ona jednoducho funguje. A to je to najlepšie.
15. Dnes máš povolené byť nebezpečne príťažlivá. A užívať si to.
16. Niektoré ženy majú šarm. Ty máš celý arzenál. A vieš ho použiť.
17. Tvoj pohľad vie povedať viac než celý román. A to je len začiatok.
18. Hriešne myšlienky nechaj bokom. Aj tak ich všetky spôbuješ ty. A s úsmevom.
19. Máš v sebe eleganciu, ktorá sa nedá predstierať. Tá je vrodená.
20. Tvoja príťažlivosť nestojí na dokonalosti, ale na iskrení. A to je oveľa lepšie.
21. Dnes neprovokuj príliš. Ale trochu môžeš. Veď prečo nie?
22. Si kombinácia jemnosti, rozumu a malého nebezpečenstva. Smrteľná kombinácia.
23. Tvoj šarm má vlastnú gravitáciu. A všetci padajú k tvojim nohám.
24. Nie si obyčajná žena. Si dôvod, prečo sa niekto usmieva bez príčiny. A to je super.
25. Dnes si daj pozor. Môžeš niekomu zrýchliť pulz. A to je len začiatok.
26. Máš v sebe presne ten typ iskry, ktorý sa nedá ignorovať. A ani by sa nemal.
27. Tvoja krása nie je len v tvári. Je v tom, ako si prítomná. A si prítomná naplno.
28. Si dôkaz, že sexappeal nepotrebuje veľké gestá. Stačí tvoja prítomnosť.
29. Tvoj štýl hovorí potichu, ale každý ho počuje. A obdivuje.
30. Dnes si žena s úsmevom, ktorý môže narobiť príjemné problémy. A to je zábava.
31. Nemusíš sa snažiť pôsobiť príťažlivo. Ty tým len prídeš. A všetci to vedia.
32. Tvoja energia má v sebe niečo veľmi návykové. A je to legálne.
33. Hriešne dobrá? Áno. A ešte k tomu s úsmevom. Dokonalé.
34. Dnes nech si svet dá pozor. Ideš ty. A ideš si po svoje.
35. Si ako dobrý parfém — zostaneš v hlave ešte dlho. A to je tvoj cieľ.
36. Tvoja ženskosť má iskru, pokoj aj malú dávku drzosti. Perfektná zmes.
37. Niektoré pohľady sa nezabúdajú. Ten tvoj k nim patrí. A to je fakt.
38. Ak dnes niekto stratí reč, neber to osobne. Možno len zbadal teba. A je to pochopiteľné.
39. Si šupa bez potreby dokazovať to svetu. Svet to vie.
40. Tvoje kúzlo je v tom, že si ho ani nemusíš uvedomovať. Ale mala by si.
41. Tvoja prítomnosť je ako magnet. Všetci sa k tebe priťahujú.
42. Si žena, ktorá vie, ako si užiť život naplno. A to je inšpirujúce.
43. Tvoja odvaha je inšpirujúca a obdivuhodná. A to je len začiatok.
44. Si ako melódia, ktorá znie v srdciach ľudí. A je to hit.
45. Tvoja autentickosť je tvoja najväčšia krása. A je to pravda.
46. Si žena, ktorá vie, ako sa postaviť za seba. A to je obdivuhodné.
47. Tvoja múdrosť je tvoj poklad, ktorý zdieľaš s ostatnými. A je to cenné.
48. Si ako hviezda, ktorá žiari na oblohe. A si tá najjasnejšia.
49. Tvoja neha je tvoja sila, ktorá dokáže zmeniť svet. A to je úžasné.
50. Si žena, ktorá vie, ako milovať a byť milovaná. A to je dar.

## Mama dvoch detí
1. Dve deti, milión vecí a stále si šupa. Rešpekt. A káva.
2. Si mama, manažérka chaosu a žena s iskrou. Klobúk dole.
3. Tvoje deti majú super mamu. Aj keď dnes možno netušia. Ale raz pochopia.
4. Zvládaš viac, než si sama priznáš. A to je super sila.
5. Dve deti a stále toľko ženskosti? Klobúk dole. A úsmev.
6. Nie každý superhrdina nosí plášť. Niektorí nosia legíny. A zachraňujú svet.
7. Tvoje deti raz pochopia, akú silnú ženu mali doma. A budú na teba hrdé.
8. Aj keď je doma chaos, ty si jeho najkrajšia riaditeľka. A najefektívnejšia.
9. Byť mamou a nezabudnúť na seba je veľká vec. A ty to zvládaš.
10. Dnes si pripomeň: robíš toho naozaj veľa. A robíš to skvele.
11. Si mama, ktorá má štýl. Aj s rozcuchanými vlasmi.
12. Tvoje deti sú tvoj najväčší projekt. A ty si ich najlepšia manažérka.
13. Si dôkaz, že materstvo a sexappeal idú ruka v ruke. A vyzerá to skvele.
14. Aj keď si unavená, tvoja iskra nezhasína. Len si dáva pauzu.
15. Si žena, ktorá dokáže žonglovať s deťmi, prácou a vlastným životom. A vyzerá pri tom božsky.
16. Tvoja trpezlivosť je nekonečná. Alebo aspoň veľmi dlhá.
17. Si ako káva predtým, než sa zobudia deti. Silná a nevyhnutná.
18. Tvoje objatia sú liek na všetko. A tvoj úsmev je nákazlivý.
19. Si žena, ktorá vie, ako si užiť materstvo. A aj si ho užíva.
20. Dnes si pripomeň, že si super mama. A zaslúžiš si oddych.
21. Si mama, ktorá vie, ako si urobiť radosť. A to je dôležité.
22. Tvoje deti sú tvoj najväčší fanúšikovia. A ty si ich najväčšia hrdinka.
23. Si žena, ktorá dokáže zmeniť plienky a potom dobyť svet. V rovnaký deň.
24. Tvoja láska je bezpodmienečná. A tvoja sila je nekonečná.
25. Si mama, ktorá vie, ako si užiť život. A to je inšpirujúce.
26. Tvoje deti sú tvoj najväčší poklad. A ty si ich najväčší dar.
27. Si žena, ktorá dokáže zvládnuť všetko. A to je obdivuhodné.
28. Tvoja energia je nákazlivá. A tvoj úsmev je neodolateľný.
29. Si mama, ktorá vie, ako si urobiť čas pre seba. A to je dôležité.
30. Tvoje deti sú tvoj najväčší úspech. A ty si ich najväčšia pýcha.
31. Si mama, ktorá vie, ako si udržať nadhľad. Aj keď je to občas ťažké.
32. Tvoja schopnosť milovať je nekonečná. A tvoje srdce je obrovské.
33. Si žena, ktorá dokáže byť jemná aj silná zároveň. A to je krásne.
34. Tvoja intuícia je tvoj najlepší sprievodca. Dôveruj jej.
35. Si mama, ktorá vie, ako si užiť každý okamih. Aj ten chaotický.
36. Tvoje deti sú tvoj najväčší učitelia. A ty si ich najlepšia žiačka.
37. Si žena, ktorá dokáže byť inšpiráciou pre svoje deti. A pre ostatných.
38. Tvoja trpezlivosť je ako superhrdinská schopnosť. A ty ju máš.
39. Si mama, ktorá vie, ako si udržať zmysel pre humor. Aj keď je to občas ťažké.
40. Tvoje deti sú tvoj najväčší dar. A ty si ich najväčší poklad.
41. Si žena, ktorá dokáže byť mamou aj ženou zároveň. A to je obdivuhodné.
42. Tvoja láska je ako slnko. Vždy svieti.
43. Si mama, ktorá vie, ako si užiť život naplno. A to je inšpirujúce.
44. Tvoje deti sú tvoj najväčší motivátor. A ty si ich najväčšia podpora.
45. Si žena, ktorá dokáže byť silná aj zraniteľná zároveň. A to je krásne.
46. Tvoja energia je ako nekonečný zdroj. A ty ju máš.
47. Si mama, ktorá vie, ako si udržať úsmev. Aj keď je to občas ťažké.
48. Tvoje deti sú tvoj najväčší dôvod na radosť. A ty si ich najväčší dar.
49. Si žena, ktorá dokáže byť mamou aj priateľkou zároveň. A to je obdivuhodné.
50. Tvoja láska je ako rieka. Vždy tečie.

## Skvelý chlap po jej boku
1. Máš doma chlapa, ktorý vie, čo má. A ty vieš, že má teba.
2. Ten tvoj sa môže usmievár. Taká žena sa len tak nenájde. A on to vie.
3. Niekto má šťastie na výhru. On má šťastie na teba. A to je jackpot.
4. Tvoj chlap dobre vie, že má doma poklad. A ak nie, pripomeň mu to. S úsmevom.
5. Si žena, ktorú si treba vážiť každý deň. A on to robí.
6. Ten tvoj má doma kombináciu krásy, rozumu a ohňa. Gratulujeme.
7. Niektoré ženy sa nehľadajú ľahko. Ty si jedna z nich. A on ťa našiel.
8. Má vedľa seba ženu, ktorá má triedu. A vie to oceniť.
9. Láska je fajn. Ale mať teba, to je vyššia liga. A on je v nej.
10. Dnes sa pokojne tvár tajomne. Nech má čo obdivovať. A nech sa snaží.
11. Tvoj chlap vie, že má doma kráľovnú. A správa sa podľa toho.
12. Si žena, pre ktorú by urobil čokoľvek. A ty to vieš.
13. On je tvoj rytier v lesklej zbroji. A ty si jeho neodolateľná dáma.
14. Spolu ste dynamické duo. A svet sa môže tešiť.
15. Tvoj chlap je šťastný muž. A ty si dôvod prečo.
16. Si jeho inšpirácia. A on je tvoja opora.
17. Máš po boku chlapa, ktorý ťa miluje takú, aká si. A to je to najlepšie.
18. On je tvoj fanúšik číslo jeden. A ty si jeho múza.
19. Si žena, ktorá vie, ako si udržať iskru vo vzťahu. A to je umenie.
20. Tvoj chlap je tvoj partner v zločine. A v láske.
21. Máš po boku chlapa, ktorý ťa rozosmeje. A to je na nezaplatenie.
22. Si žena, ktorá vie, ako si užiť spoločné chvíle. A on s tebou.
23. Tvoj chlap je tvoj najlepší priateľ. A tvoja spriaznená duša.
24. Si žena, ktorá vie, ako si udržať vášeň. A on to miluje.
25. Máš po boku chlapa, ktorý ťa podporuje. A to je dôležité.
26. Si žena, ktorá vie, ako si udržať rešpekt. A on ťa rešpektuje.
27. Tvoj chlap je tvoj hrdina. A ty si jeho kráľovná.
28. Si žena, ktorá vie, ako si užiť život s ním. A to je krásne.
29. Máš po boku chlapa, ktorý ťa obdivuje. A to je to najlepšie.
30. Si žena, ktorá vie, ako si udržať lásku. A on s tebou.
31. Tvoj chlap vie, že má doma poklad. A ty si ten poklad.
32. Si žena, ktorá ho robí lepším. A on to vie.
33. Máš po boku chlapa, ktorý ťa rozmaznáva. A ty si to zaslúžiš.
34. Si jeho slnko. A on je tvoj mesiac.
35. Tvoj chlap je tvoj najväčší fanúšik. A ty si jeho najväčšia inšpirácia.
36. Si žena, ktorá vie, ako si udržať vášeň. A on to miluje.
37. Máš po boku chlapa, ktorý ťa podporuje. A to je dôležité.
38. Si žena, ktorá vie, ako si udržať rešpekt. A on ťa rešpektuje.
39. Tvoj chlap je tvoj hrdina. A ty si jeho kráľovná.
40. Si žena, ktorá vie, ako si užiť život s ním. A to je krásne.
41. Máš po boku chlapa, ktorý ťa obdivuje. A to je to najlepšie.
42. Si žena, ktorá vie, ako si udržať lásku. A on s tebou.
43. Tvoj chlap vie, že má doma poklad. A ty si ten poklad.
44. Si žena, ktorá ho robí lepším. A on to vie.
45. Máš po boku chlapa, ktorý ťa rozmaznáva. A ty si to zaslúžiš.
46. Si jeho slnko. A on je tvoj mesiac.
47. Tvoj chlap je tvoj najväčší fanúšik. A ty si jeho najväčšia inšpirácia.
48. Si žena, ktorá vie, ako si udržať vášeň. A on to miluje.
49. Máš po boku chlapa, ktorý ťa podporuje. A to je dôležité.
50. Si žena, ktorá vie, ako si udržať rešpekt. A on ťa rešpektuje.

## Starostlivosť o seba
1. Keď sa staráš o seba, nejde o márnivosť. Ide o úctu. A je to sexi.
2. Tvoje telo si zaslúži láskavý prístup. A ty si ho zaslúžiš tiež.
3. Každý pohyb pre seba sa počíta. A každý oddych tiež.
4. Starostlivosť o seba ti pristane. A robí ťa ešte krajšou.
5. Dnes nerieš dokonalosť. Rieš dobrý pocit. A ten je najdôležitejší.
6. Keď sa cítiš dobre, vidno to. A všetci to vedia.
7. Tvoja energia rastie, keď na seba nezabúdaš. A to je super.
8. Krása začína tým, že sa k sebe správaš pekne. A to je základ.
9. Dnes sprav jednu vec len pre seba. A užívaj si to.
10. Nie je to egoizmus. Je to údržba kráľovnej. A kráľovná si to zaslúži.
11. Dnes si dopraj to, čo tvoja duša potrebuje. A telo tiež.
12. Tvoja pohoda je tvoja priorita. A to je správne.
13. Si hodná všetkej lásky a starostlivosti. A to je fakt.
14. Každý deň je príležitosť na malý rituál pre seba. A ty si ho zaslúžiš.
15. Tvoja krása je odrazom tvojej vnútornej pohody. A tá je dôležitá.
16. Dnes si dopraj oddych. A nerieš, čo si myslia ostatní.
17. Starostlivosť o seba je investícia. A tá sa ti vráti.
18. Tvoje telo je tvoj chrám. A ty si jeho bohyňa.
19. Dnes si dopraj to, čo ťa robí šťastnou. A to je to najlepšie.
20. Si žena, ktorá vie, ako sa o seba postarať. A to je obdivuhodné.
21. Tvoja energia je tvoj poklad. A ty si ho chrániš.
22. Dnes si dopraj to, čo ťa nabíja. A to je dôležité.
23. Si žena, ktorá vie, ako si urobiť radosť. A to je umenie.
24. Tvoja krása je tvoj dar. A ty si ho pestuješ.
25. Dnes si dopraj to, čo ťa robí spokojnou. A to je to najlepšie.
26. Si žena, ktorá vie, ako si udržať rovnováhu. A to je dôležité.
27. Tvoja pohoda je tvoj štít. A ty si ho chrániš.
28. Dnes si dopraj to, čo ťa robí silnou. A to je to najlepšie.
29. Si žena, ktorá vie, ako si udržať iskru. A to je umenie.
30. Tvoja krása je tvoj odraz. A ty si ho miluješ.
31. Dnes si dopraj ticho. Niekedy je to najlepší liek.
32. Tvoja hodnota nie je v tom, čo robíš, ale v tom, kým si. A si úžasná.
33. Si žena, ktorá vie, ako si dopriať. A to je dôležité.
34. Tvoja intuícia je tvoj najlepší sprievodca. Dôveruj jej.
35. Dnes si dopraj prechádzku. Čerstvý vzduch robí zázraky.
36. Tvoja myseľ si zaslúži oddych. A ty si ho zaslúžiš tiež.
37. Si žena, ktorá vie, ako si udržať vnútorný pokoj. A to je cenné.
38. Tvoja sila je v tvojej schopnosti povedať nie. A to je dôležité.
39. Dnes si dopraj knihu. Únik do iného sveta je niekedy potrebný.
40. Tvoja krása je v tvojej autentickosti. A to je to najlepšie.
41. Si žena, ktorá vie, ako si udržať úsmev. Aj keď je to občas ťažké.
42. Tvoja energia je ako nekonečný zdroj. A ty ju máš.
43. Dnes si dopraj to, čo ťa robí šťastnou. A to je to najlepšie.
44. Tvoja hodnota nie je závislá od tvojho výkonu. Si cenná taká, aká si.
45. Si žena, ktorá vie, ako si urobiť radosť. A to je umenie.
46. Tvoja krása je tvoj dar. A ty si ho pestuješ.
47. Dnes si dopraj to, čo ťa robí spokojnou. A to je to najlepšie.
48. Si žena, ktorá vie, ako si udržať rovnováhu. A to je dôležité.
49. Tvoja pohoda je tvoj štít. A ty si ho chrániš.
50. Dnes si dopraj to, čo ťa robí silnou. A to je to najlepšie.

## Vek je len číslo
1. Na svoj vek? Nie. Jednoducho šupa. A s každým rokom lepšia.
2. Roky ti nepridali vek. Pridali šmrnc. A múdrosť.
3. Zrelosť ti pristane viac, než tušíš. A je to vidieť.
4. Niektoré ženy nestarnú. Len majú lepší výraz. A viac skúseností.
5. Máš vek, skúsenosti a stále iskru. Výborná kombinácia. A neodolateľná.
6. Číslo v občianskom nech si hovorí, čo chce. Ty vieš svoje.
7. Tvoje najlepšie ja sa ešte nikam nechystá. Práve začína.
8. Čas ti zobral možno spánok, ale pridal charizmu. A sexappeal.
9. Si dôkaz, že šarm nemá expiráciu. A ty si toho živým dôkazom.
10. Zrelá, krásna, ženská. Hotovo. A s úsmevom.
11. Vek je len číslo, ale tvoja energia je nekonečná. A nákazlivá.
12. Si ako dobré víno, s vekom len zreješ a stávaš sa lepšou. A chutnejšou.
13. Tvoja krása je nadčasová. A tvoj šarm je večný.
14. Každý rok ti pridáva na hodnote. A ty si toho vedomá.
15. Si žena, ktorá vie, ako si užiť každý vek. A to je umenie.
16. Tvoja múdrosť je tvoj najväčší poklad. A s vekom rastie.
17. Si ako drahokam, ktorý sa s vekom len brúsi. A žiari jasnejšie.
18. Tvoja prítomnosť je ako slnečný lúč. A tvoj úsmev je nákazlivý.
19. Si žena, ktorá vie, ako si udržať mladosť v srdci. A to je dôležité.
20. Tvoja energia je tvoj elixír mladosti. A ty si ho užívaš.
21. Si ako pieseň, ktorá znie s vekom len krajšie. A je to hit.
22. Tvoja autentickosť je tvoja najväčšia krása. A s vekom je silnejšia.
23. Si žena, ktorá vie, ako sa postaviť za seba. A to je obdivuhodné.
24. Tvoja múdrosť je tvoj poklad, ktorý zdieľaš s ostatnými. A je to cenné.
25. Si ako hviezda, ktorá žiari na oblohe. A si tá najjasnejšia.
26. Tvoja neha je tvoja sila, ktorá dokáže zmeniť svet. A to je úžasné.
27. Si žena, ktorá vie, ako milovať a byť milovaná. A to je dar.
28. Tvoja radosť je nákazlivá a prináša šťastie. A to je to najlepšie.
29. Si ako rieka, ktorá tečie s gráciou a silou. A je to krásne.
30. Tvoja kreativita je tvoj dar, ktorý obohacuje svet. A je to úžasné.
31. Si žena, ktorá vie, ako si splniť sny. A to je inšpirujúce.
32. Tvoja sebaúcta je tvoj štít, ktorý ťa chráni. A to je silné.
33. Si ako tanec, ktorý vyjadruje slobodu a vášeň. A je to krásne.
34. Tvoja jedinečnosť je tvoja krása, ktorá ťa odlišuje. A to je to najlepšie.
35. Si žena, ktorá vie, ako byť sama sebou a byť šťastná. A to je cieľ.
36. Tvoj smiech je hudba pre dušu. A je to melódia.
37. Si ako drahokam, ktorý sa leskne v slnečnom svetle. A je to poklad.
38. Tvoja energia je ako magnet, ktorý priťahuje pozitívne veci. A je to sila.
39. Si žena, ktorá vie, ako si užiť každý okamih. A to je umenie.
40. Tvoja vnútorná sila je tvoj najväčší poklad. A ty si ho chrániš.
41. Si ako umenie, ktoré sa neustále mení a prekvapuje. A je to krásne.
42. Tvoja prítomnosť je ako teplé objatie. A je to príjemné.
43. Si žena, ktorá vie, ako byť inšpiráciou pre ostatných. A to je obdivuhodné.
44. Tvoja krása je ako západ slnka, ktorý nikdy neomrzí. A je to večné.
45. Si ako pieseň, ktorá zostane v srdci navždy. A je to melódia.

## Keď má horší deň
1. Dnes nemusíš žiariť. Stačí, že si. A to je dosť.
2. Aj šupa žena môže mať slabší deň. A je to úplne v poriadku.
3. Oddych ti neuberá hodnotu. Práve naopak, pridáva.
4. Dnes si daj mäkší režim. Zaslúžiš si ho. A svet počká.
5. Nemusíš byť stále silná. Aj tak ňou si. Len si daj pauzu.
6. Horší deň nemení to, aká si žena. Si stále úžasná.
7. Dnes sa netlač. Jemnosť je tiež sila. A ty ju máš.
8. Aj keď sa tak necítiš, stále máš svoje kúzlo. A je to vidieť.
9. Dnes si dopraj menej výčitiek a viac pochopenia. Zaslúžiš si to.
10. Zajtra môže byť ľahšie. Dnes stačí vydržať. A prežiť.
11. Dnes je dovolené mať všetko na háku. A nikto ti to nemôže vyčítať.
12. Aj keď máš pocit, že nič nestíhaš, si stále šikovná. A to je fakt.
13. Dnes si dopraj to, čo ťa robí šťastnou. Aj keď je to len ležanie na gauči.
14. Tvoja hodnota nie je závislá od tvojho výkonu. Si cenná taká, aká si.
15. Dnes si pripomeň, že si človek. A ľudia majú aj horšie dni.
16. Aj keď máš pocit, že sa svet rúti, ty si stále pevná. A to je dôležité.
17. Dnes si dopraj to, čo ťa upokojí. A to je to najlepšie.
18. Tvoja sila je v tvojej schopnosti prežiť. A ty si prežila už veľa.
19. Dnes si pripomeň, že si silná. Aj keď sa tak necítiš.
20. Aj keď máš pocit, že si na dne, pamätaj, že odtiaľ sa dá len odraziť.
21. Dnes si dopraj to, čo ťa rozveselí. A to je to najlepšie.
22. Tvoja hodnota nie je závislá od tvojho úsmevu. Si cenná aj s vráskami.
23. Dnes si pripomeň, že si krásna. Aj keď máš kruhy pod očami.
24. Aj keď máš pocit, že si sama, pamätaj, že máš seba. A to je dosť.
25. Dnes si dopraj to, čo ťa posilní. A to je to najlepšie.
26. Tvoja sila je v tvojej schopnosti vstať. A ty vstaneš.
27. Dnes si pripomeň, že si bojovníčka. Aj keď máš pocit, že si porazená.
28. Aj keď máš pocit, že si stratená, pamätaj, že máš kompas. A ten ťa vedie.
29. Dnes si dopraj to, čo ťa inšpiruje. A to je to najlepšie.
30. Tvoja hodnota nie je závislá od tvojho úspechu. Si cenná aj s pádmi.
31. Dnes si dopraj ticho. Niekedy je to najlepší liek.
32. Tvoja hodnota nie je v tom, čo robíš, ale v tom, kým si. A si úžasná.
33. Si žena, ktorá vie, ako si dopriať. A to je dôležité.
34. Tvoja intuícia je tvoj najlepší sprievodca. Dôveruj jej.
35. Dnes si dopraj prechádzku. Čerstvý vzduch robí zázraky.
36. Tvoja myseľ si zaslúži oddych. A ty si ho zaslúžiš tiež.
37. Si žena, ktorá vie, ako si udržať vnútorný pokoj. A to je cenné.
38. Tvoja sila je v tvojej schopnosti povedať nie. A to je dôležité.
39. Dnes si dopraj knihu. Únik do iného sveta je niekedy potrebný.
40. Tvoja krása je v tvojej autentickosti. A to je to najlepšie.
41. Si žena, ktorá vie, ako si udržiar úsmev. Aj keď je to občas ťažké.
42. Tvoja energia je ako nekonečný zdroj. A ty ju máš.
43. Dnes si dopraj to, čo ťa robí šťastnou. A to je to najlepšie.
44. Tvoja hodnota nie je závislá od tvojho výkonu. Si cenná taká, aká si.
45. Si žena, ktorá vie, ako si urobiť radosť. A to je umenie.
46. Tvoja krása je tvoj dar. A ty si ho pestuješ.
47. Dnes si dopraj to, čo ťa robí spokojnou. A to je to najlepšie.
48. Si žena, ktorá vie, ako si udržať rovnováhu. A to je dôležité.
49. Tvoja pohoda je tvoj štít. A ty si ho chrániš.
50. Dnes si dopraj to, čo ťa robí silnou. A to je to najlepšie.

## Večer
1. Dnes si zvládla viac, než sa zdá. A to je dôvod na úsmev.
2. Dve deti, domácnosť, život — a stále si tu. Výborne. A zaslúžiš si oddych.
3. Dnes si zaslúžiš pokoj a dobré slovo. A možno aj pohár vína.
4. Nechaj deň odísť. Ty si svoje urobila. A urobila si to skvele.
5. Aj keď nebolo všetko hotové, ty si bola dosť. A to je to najdôležitejšie.
6. Večer patrí žene, ktorá celý deň držala svet pokope. A teraz si zaslúži byť držaná.
7. Dnes sa pochváľ. Aspoň raz. A zaslúžene.
8. Tvoj deň možno nebol dokonalý, ale ty si ho dala. A to je to hlavné.
9. Oddychuj bez výčitiek. Kráľovné tiež vypínajú. A zaslúžia si to.
10. Zajtra pokračuješ. Dnes už stačí. A to je v poriadku.
11. Dnes si dopraj to, čo ťa upokojí. A to je to najlepšie.
12. Tvoja energia je tvoj poklad. A ty si ho chrániš.
13. Si žena, ktorá vie, ako si užiť večer. A to je umenie.
14. Tvoja krása je tvoj dar. A ty si ho pestuješ.
15. Dnes si dopraj to, čo ťa robí spokojnou. A to je to najlepšie.
16. Si žena, ktorá vie, ako si udržať rovnováhu. A to je dôležité.
17. Tvoja pohoda je tvoj štít. A ty si ho chrániš.
18. Dnes si dopraj to, čo ťa robí silnou. A to je to najlepšie.
19. Si žena, ktorá vie, ako si udržať iskru. A to je umenie.
20. Tvoja krása je tvoj odraz. A ty si ho miluješ.
21. Dnes si dopraj to, čo ťa rozveselí. A to je to najlepšie.
22. Tvoja hodnota nie je závislá od tvojho úsmevu. Si cenná aj s vráskami.
23. Dnes si pripomeň, že si krásna. Aj keď máš kruhy pod očami.
24. Aj keď máš pocit, že si sama, pamätaj, že máš seba. A to je dosť.
25. Dnes si dopraj to, čo ťa posilní. A to je to najlepšie.
26. Tvoja sila je v tvojej schopnosti vstať. A ty vstaneš.
27. Dnes si pripomeň, že si bojovníčka. Aj keď máš pocit, že si porazená.
28. Aj keď máš pocit, že si stratená, pamätaj, že máš kompas. A ten ťa vedie.
29. Dnes si dopraj to, čo ťa inšpiruje. A to je to najlepšie.
30. Tvoja hodnota nie je závislá od tvojho úspechu. Si cenná aj s pádmi.
31. Dnes si dopraj ticho. Niekedy je to najlepší liek.
32. Tvoja hodnota nie je v tom, čo robíš, ale v tom, kým si. A si úžasná.
33. Si žena, ktorá vie, ako si dopriať. A to je dôležité.
34. Tvoja intuícia je tvoj najlepší sprievodca. Dôveruj jej.
35. Dnes si dopraj prechádzku. Čerstvý vzduch robí zázraky.
36. Tvoja myseľ si zaslúži oddych. A ty si ho zaslúžiš tiež.
37. Si žena, ktorá vie, ako si udržať vnútorný pokoj. A to je cenné.
38. Tvoja sila je v tvojej schopnosti povedať nie. A to je dôležité.
39. Dnes si dopraj knihu. Únik do iného sveta je niekedy potrebný.
40. Tvoja krása je v tvojej autentickosti. A to je to najlepšie.
41. Si žena, ktorá vie, ako si udržať úsmev. Aj keď je to občas ťažké.
42. Tvoja energia je ako nekonečný zdroj. A ty ju máš.
43. Dnes si dopraj to, čo ťa robí šťastnou. A to je to najlepšie.
44. Tvoja hodnota nie je závislá od tvojho výkonu. Si cenná taká, aká si.
45. Si žena, ktorá vie, ako si urobiť radosť. A to je umenie.
46. Tvoja krása je tvoj dar. A ty si ho pestuješ.
47. Dnes si dopraj to, čo ťa robí spokojnou. A to je to najlepšie.
48. Si žena, ktorá vie, ako si udržať rovnováhu. A to je dôležité.
49. Tvoja pohoda je tvoj štít. A ty si ho chrániš.
50. Dnes si dopraj to, čo ťa robí silnou. A to je to najlepšie.
