package sk.aetheriqa.noteiqa.security;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.biometric.BiometricManager;

/**
 * AppLock – v1.2.0 — voliteľný zámok celej appky (Nastavenia → Systém).
 *
 * Pravidlá:
 *  - vypnuté = nič sa nedeje (default)
 *  - studený štart procesu → zámok
 *  - návrat z pozadia po viac ako {@link #TIMEOUT_MS} → zámok
 *  - odomyká {@link LockActivity} cez BiometricPrompt (biometria alebo PIN/vzor/heslo zariadenia)
 *
 * Sleduje sa počet spustených aktivít cez ActivityLifecycleCallbacks
 * (bez lifecycle-process závislosti). Per-note Note.locked sa v 1.2.0 nerieši.
 */
public final class AppLock implements Application.ActivityLifecycleCallbacks {

    public static final long TIMEOUT_MS = 30_000L;

    /** BIOMETRIC_WEAK | DEVICE_CREDENTIAL je podporené na všetkých API úrovniach. */
    public static final int AUTHENTICATORS =
            BiometricManager.Authenticators.BIOMETRIC_WEAK
                    | BiometricManager.Authenticators.DEVICE_CREDENTIAL;

    private static final String PREFS = "noteiqa_security";
    private static final String KEY_ENABLED = "appLockEnabled";

    private static volatile AppLock INSTANCE;

    private final SharedPreferences prefs;
    private int startedActivities = 0;
    private long backgroundAt = 0L;
    private boolean unlocked = false;

    private AppLock(Context ctx) {
        prefs = ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static AppLock get(Context ctx) {
        if (INSTANCE == null) {
            synchronized (AppLock.class) {
                if (INSTANCE == null) INSTANCE = new AppLock(ctx);
            }
        }
        return INSTANCE;
    }

    /** Volá NoteiqaApplication.onCreate. */
    public static void install(Application app) {
        app.registerActivityLifecycleCallbacks(get(app));
    }

    public boolean isEnabled() {
        return prefs.getBoolean(KEY_ENABLED, false);
    }

    public void setEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_ENABLED, enabled).apply();
        // Zapnutie prebieha v odomknutej appke — nezamykaj hneď.
        unlocked = true;
    }

    /** Má zariadenie nastavenú biometriu alebo zámok obrazovky? Inak zámok nemá zmysel. */
    public static boolean canAuthenticate(Context ctx) {
        return BiometricManager.from(ctx).canAuthenticate(AUTHENTICATORS)
                == BiometricManager.BIOMETRIC_SUCCESS;
    }

    void markUnlocked() {
        unlocked = true;
    }

    // ===== Lifecycle =====

    @Override
    public void onActivityStarted(@NonNull Activity activity) {
        boolean cameFromBackground = startedActivities == 0;
        startedActivities++;
        if (!cameFromBackground || activity instanceof LockActivity) return;
        if (!isEnabled()) return;

        long now = System.currentTimeMillis();
        if (unlocked && backgroundAt > 0L && now - backgroundAt <= TIMEOUT_MS) return;
        if (!canAuthenticate(activity)) return; // zámok obrazovky zrušený → nezamkni navždy

        unlocked = false;
        Intent lock = new Intent(activity, LockActivity.class);
        lock.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        activity.startActivity(lock);
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {
        startedActivities = Math.max(0, startedActivities - 1);
        if (startedActivities == 0) backgroundAt = System.currentTimeMillis();
    }

    @Override public void onActivityCreated(@NonNull Activity a, @Nullable Bundle b) {}
    @Override public void onActivityResumed(@NonNull Activity a) {}
    @Override public void onActivityPaused(@NonNull Activity a) {}
    @Override public void onActivitySaveInstanceState(@NonNull Activity a, @NonNull Bundle b) {}
    @Override public void onActivityDestroyed(@NonNull Activity a) {}
}
