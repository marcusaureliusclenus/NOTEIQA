package sk.aetheriqa.noteiqa.util;

import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.Locale;

/**
 * DateUtils – pomocné metódy pre prácu s dátumami.
 *
 * Slovenská lokalizácia (skratky dní v týždni: po/ut/st/št/pi/so/ne).
 * Period ranges pre modul Chudnutie (7d / 30d / 90d / 1Y / Všetko).
 */
public final class DateUtils {

    /** Slovenské skratky dní – index 0 = Po, 6 = Ne. */
    private static final String[] SK_DAY_SHORT = {"po", "ut", "st", "št", "pi", "so", "ne"};

    /** Locale pre formátovanie. */
    private static final Locale SK = new Locale("sk", "SK");

    private static final ZoneId ZONE = ZoneId.systemDefault();

    private DateUtils() {}

    // ===== Day of week =====

    /** Z millis vytiahne deň v týždni v ISO formáte (1=Po, 7=Ne). */
    public static int isoDayOfWeek(long epochMillis) {
        return Instant.ofEpochMilli(epochMillis)
                .atZone(ZONE)
                .toLocalDate()
                .getDayOfWeek()
                .getValue();
    }

    /** Slovenská skratka dňa: 1→"po", 2→"ut", … 7→"ne". */
    public static String slovakDayShort(int isoDayOfWeek) {
        if (isoDayOfWeek < 1 || isoDayOfWeek > 7) return "";
        return SK_DAY_SHORT[isoDayOfWeek - 1];
    }

    public static String slovakDayShort(long epochMillis) {
        return slovakDayShort(isoDayOfWeek(epochMillis));
    }

    // ===== Formátovanie =====

    /** Formátuje millis ako "10.3." (deň.mesiac.) */
    public static String formatShortDate(long epochMillis) {
        return new SimpleDateFormat("d.M.", SK).format(new Date(epochMillis));
    }

    /** Formátuje millis ako "15. 11. 2026" (v1.2.0 — toast ďalšej splatnosti) */
    public static String formatNumericDate(long epochMillis) {
        return new SimpleDateFormat("d. M. yyyy", SK).format(new Date(epochMillis));
    }

    /** Formátuje millis ako "10.3.2026" */
    public static String formatLongDate(long epochMillis) {
        return new SimpleDateFormat("d.M.yyyy", SK).format(new Date(epochMillis));
    }

    /** Formátuje millis ako "10.3. (po) 19:08" – formát ako tvoje váhové záznamy. */
    public static String formatWeightTimestamp(long epochMillis) {
        String date = new SimpleDateFormat("d.M.", SK).format(new Date(epochMillis));
        String day = slovakDayShort(epochMillis);
        String time = new SimpleDateFormat("HH:mm", SK).format(new Date(epochMillis));
        return date + " (" + day + ") " + time;
    }

    /** Iba čas, napr. "19:08" */
    public static String formatTime(long epochMillis) {
        return new SimpleDateFormat("HH:mm", SK).format(new Date(epochMillis));
    }

    // ===== Period ranges pre graf =====

    public enum Period {
        DAYS_7,
        DAYS_30,
        DAYS_90,
        YEAR_1,
        ALL
    }

    /** Vráti dolnú hranicu obdobia (epoch millis); pre ALL vráti 0. */
    public static long startOfPeriod(Period period, long now) {
        LocalDateTime n = LocalDateTime.ofInstant(Instant.ofEpochMilli(now), ZONE);
        LocalDateTime start;
        switch (period) {
            case DAYS_7:  start = n.minusDays(7); break;
            case DAYS_30: start = n.minusDays(30); break;
            case DAYS_90: start = n.minusDays(90); break;
            case YEAR_1:  start = n.minusYears(1); break;
            case ALL:
            default:      return 0L;
        }
        return start.atZone(ZONE).toInstant().toEpochMilli();
    }

    /** Vráti počet dní medzi dvoma timestampmi (zaokrúhlene nahor). */
    public static long daysBetween(long fromMillis, long toMillis) {
        if (toMillis <= fromMillis) return 0;
        long diff = toMillis - fromMillis;
        return (diff + 86_400_000L - 1) / 86_400_000L;
    }

    /** "Dnes" o 00:00:00. */
    public static long startOfToday() {
        return LocalDate.now(ZONE).atStartOfDay(ZONE).toInstant().toEpochMilli();
    }
}
