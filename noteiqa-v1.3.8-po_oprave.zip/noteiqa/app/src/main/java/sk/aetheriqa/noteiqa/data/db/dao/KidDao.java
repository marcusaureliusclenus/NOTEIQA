package sk.aetheriqa.noteiqa.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import sk.aetheriqa.noteiqa.data.entity.Kid;

@Dao
public interface KidDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(Kid kid);

    @Update
    int update(Kid kid);

    @Delete
    int delete(Kid kid);

    @Query("SELECT * FROM kids ORDER BY sortOrder ASC, id ASC")
    LiveData<List<Kid>> observeAll();

    @Query("SELECT * FROM kids ORDER BY sortOrder ASC, id ASC")
    List<Kid> getAllSync();

    @Query("SELECT * FROM kids WHERE id = :id")
    Kid getById(long id);

    @Query("SELECT COUNT(*) FROM kids")
    int count();
}
