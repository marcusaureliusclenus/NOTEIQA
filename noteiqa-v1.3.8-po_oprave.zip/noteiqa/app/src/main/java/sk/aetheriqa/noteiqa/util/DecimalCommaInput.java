package sk.aetheriqa.noteiqa.util;

import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.method.DigitsKeyListener;
import android.widget.EditText;

/**
 * DecimalCommaInput – v1.3.5 — pole sumy s desatinnou čiarkou.
 *
 * inputType="numberDecimal" s predvoleným DigitsKeyListenerom prijme na mnohých
 * zariadeniach len bodku — čiarka z klávesnice sa zahodí. Tu: listener prijme
 * číslice, čiarku aj bodku, klávesnica ostane číselná a bodka sa hneď zmení na čiarku
 * (AmountFormat.normalizeTyping). Uložená hodnota sa číta cez AmountFormat.parse.
 */
public final class DecimalCommaInput {

    private DecimalCommaInput() {}

    /** Suma v EUR: najviac 2 desatinné miesta. */
    public static void attach(EditText field) {
        attach(field, 2);
    }

    public static void attach(EditText field, int maxDecimals) {
        // poradie: najprv listener (ten si nastaví vlastný inputType), potom číselná klávesnica
        field.setKeyListener(DigitsKeyListener.getInstance("0123456789,."));
        field.setRawInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        field.addTextChangedListener(new TextWatcher() {
            private boolean self;

            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (self) return;
                String now = s.toString();
                String fixed = AmountFormat.normalizeTyping(now, maxDecimals);
                if (fixed.equals(now)) return;
                self = true;
                s.replace(0, s.length(), fixed);
                self = false;
            }
        });
    }
}
