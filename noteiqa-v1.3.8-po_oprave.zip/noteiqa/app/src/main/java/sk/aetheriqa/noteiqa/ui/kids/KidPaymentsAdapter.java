package sk.aetheriqa.noteiqa.ui.kids;

import android.graphics.Color;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.util.DateUtils;

/**
 * KidPaymentsAdapter – zoznam platieb.
 *
 * v1.3.5 — rovnaký vizuál ako Kalendár udalostí (KidEventsAdapter):
 *  - hlavička dňa podľa splatnosti ("PONDELOK · 5. OKTÓBRA 2026"), platby v rámčekoch pod ňou
 *  - rámček: hore malým "Alex · Prevod", pod tým výrazne názov a vpravo suma,
 *    dole splatnosť a opakovanie; vpravo zaškrtnutie "zaplatené"
 *
 * Ako priradzujeme kid meno / farbu: prijímame List<Kid> cez setKids() z rodiča
 * (SubFragment), aby sme sa vyhli N-krát DB lookup pri každom bind.
 */
public class KidPaymentsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public interface Listener {
        void onClick(KidPayment p);
        void onLongPress(KidPayment p);
        void onCheck(KidPayment p, boolean checked);
    }

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_PAYMENT = 1;
    private static final Locale SK = new Locale("sk", "SK");

    private final SimpleDateFormat headerFmt = new SimpleDateFormat("EEEE · d. MMMM yyyy", SK);

    /** String = hlavička dňa, KidPayment = platba (zoradené podľa splatnosti z DAO). */
    private final List<Object> items = new ArrayList<>();
    private List<Kid> kids = new ArrayList<>();
    private final Listener listener;

    public KidPaymentsAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<KidPayment> newItems) {
        items.clear();
        if (newItems != null) {
            long lastDay = Long.MIN_VALUE;
            for (KidPayment p : newItems) {
                long dayKey = p.dueDate > 0L ? dayKey(p.dueDate) : -1L;
                if (dayKey != lastDay) {
                    items.add(p.dueDate > 0L
                            ? headerFmt.format(new java.util.Date(p.dueDate)).toUpperCase(SK)
                            : null); // bez splatnosti — text doplní bind (potrebuje Context)
                    lastDay = dayKey;
                }
                items.add(p);
            }
        }
        notifyDataSetChanged();
    }

    public void setKids(List<Kid> kids) {
        this.kids = kids != null ? kids : new ArrayList<>();
        notifyDataSetChanged();
    }

    private static long dayKey(long ts) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ts);
        return c.get(Calendar.YEAR) * 1000L + c.get(Calendar.DAY_OF_YEAR);
    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position) instanceof KidPayment ? TYPE_PAYMENT : TYPE_HEADER;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inf = LayoutInflater.from(parent.getContext());
        if (viewType == TYPE_HEADER) {
            return new HeaderVH(inf.inflate(R.layout.item_kid_event_day_header, parent, false));
        }
        return new VH(inf.inflate(R.layout.item_kid_payment, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Object o = items.get(position);
        if (holder instanceof HeaderVH) {
            TextView t = ((HeaderVH) holder).text;
            t.setText(o != null ? (String) o
                    : t.getContext().getString(R.string.kid_payment_no_due_header));
            return;
        }
        VH h = (VH) holder;
        KidPayment p = (KidPayment) o;
        Kid kid = findKid(p.kidIdOrZero());
        android.content.Context ctx = h.itemView.getContext();

        // Farebný pruh dieťaťa
        int color;
        try {
            color = kid != null ? Color.parseColor(kid.colorHex) : 0xFFC9A961;
        } catch (IllegalArgumentException ex) {
            color = 0xFFC9A961;
        }
        h.colorChip.setBackgroundColor(color);

        // Riadok 1 (malý): "Alex · Prevod"
        String methodLabel = methodLabel(ctx, p.paymentMethod);
        String kidLabel = kid != null ? kid.name : "";
        if (kidLabel.isEmpty()) h.metaTop.setText(methodLabel);
        else if (methodLabel.isEmpty()) h.metaTop.setText(kidLabel);
        else h.metaTop.setText(ctx.getString(R.string.kid_meta_join, kidLabel, methodLabel));

        // Riadok 2 (výrazný): názov + suma vpravo
        h.title.setText(p.title);
        if (p.amountEur != null) {
            h.amount.setText(String.format(Locale.getDefault(), "%.2f €", p.amountEur)
                    .replace('.', ','));
        } else {
            h.amount.setText("—");
        }

        // Riadok 3: splatnosť + opakovanie
        StringBuilder meta = new StringBuilder();
        if (p.dueDate > 0L) {
            meta.append(ctx.getString(R.string.kid_payment_meta_due, DateUtils.formatShortDate(p.dueDate)));
        }
        String rec = recurrenceLabel(ctx, p);
        if (!rec.isEmpty()) {
            if (meta.length() > 0) meta.append(" · ");
            meta.append(rec);
        }
        h.meta.setText(meta.toString());
        h.meta.setVisibility(meta.length() > 0 ? View.VISIBLE : View.GONE);

        // Completed → suma (aj názov) prečiarknutá, alpha 0.45
        if (p.completed) {
            h.title.setPaintFlags(h.title.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            h.amount.setPaintFlags(h.amount.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            h.title.setAlpha(0.45f);
            h.amount.setAlpha(0.45f);
        } else {
            h.title.setPaintFlags(h.title.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
            h.amount.setPaintFlags(h.amount.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
            h.title.setAlpha(1.0f);
            h.amount.setAlpha(1.0f);
        }

        // Checkbox — bez triggeru na re-bind
        h.check.setOnCheckedChangeListener(null);
        h.check.setChecked(p.completed);
        h.check.setOnCheckedChangeListener((btn, checked) -> listener.onCheck(p, checked));

        h.itemView.setOnClickListener(v -> listener.onClick(p));
        h.itemView.setOnLongClickListener(v -> { listener.onLongPress(p); return true; });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private Kid findKid(long kidId) {
        for (Kid k : kids) if (k.id == kidId) return k;
        return null;
    }

    private static String methodLabel(android.content.Context ctx, int method) {
        switch (method) {
            case KidPayment.METHOD_TRANSFER: return ctx.getString(R.string.kid_method_short_transfer);
            case KidPayment.METHOD_CASH: return ctx.getString(R.string.kid_method_short_cash);
            case KidPayment.METHOD_OTHER: return ctx.getString(R.string.kid_method_short_other);
            default: return "";
        }
    }

    static String recurrenceLabel(android.content.Context ctx, KidPayment p) {
        switch (p.recurrence) {
            case KidPayment.RECURRENCE_MONTHLY: return ctx.getString(R.string.kid_recurrence_short_monthly);
            case KidPayment.RECURRENCE_QUARTERLY: return ctx.getString(R.string.kid_recurrence_short_quarterly);
            case KidPayment.RECURRENCE_SEMIANNUAL: return ctx.getString(R.string.kid_recurrence_short_semiannual);
            case KidPayment.RECURRENCE_YEARLY: return ctx.getString(R.string.kid_recurrence_short_yearly);
            case KidPayment.RECURRENCE_EXACT:
                return p.exactDueDate > 0L
                        ? ctx.getString(R.string.kid_recurrence_short_exact, formatDayMonth(p.exactDueDate))
                        : "";
            default: return "";
        }
    }

    /** v1.3.3 — "12. 11." */
    static String formatDayMonth(long ts) {
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.setTimeInMillis(ts);
        return c.get(java.util.Calendar.DAY_OF_MONTH) + ". " + (c.get(java.util.Calendar.MONTH) + 1) + ".";
    }

    /** v1.3.3 — "12. 11. 2026" */
    static String formatDayMonthYear(long ts) {
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.setTimeInMillis(ts);
        return formatDayMonth(ts) + " " + c.get(java.util.Calendar.YEAR);
    }

    static class HeaderVH extends RecyclerView.ViewHolder {
        final TextView text;
        HeaderVH(@NonNull View item) {
            super(item);
            text = (TextView) item;
        }
    }

    static class VH extends RecyclerView.ViewHolder {
        final View colorChip;
        final TextView metaTop, title, meta, amount;
        final CheckBox check;

        VH(@NonNull View item) {
            super(item);
            colorChip = item.findViewById(R.id.kid_color_chip);
            metaTop = item.findViewById(R.id.kid_payment_meta_top);
            title = item.findViewById(R.id.kid_payment_title);
            meta = item.findViewById(R.id.kid_payment_meta);
            amount = item.findViewById(R.id.kid_payment_amount);
            check = item.findViewById(R.id.kid_payment_check);
        }
    }
}
