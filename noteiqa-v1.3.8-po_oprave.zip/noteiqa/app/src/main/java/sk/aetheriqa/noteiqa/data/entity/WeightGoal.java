package sk.aetheriqa.noteiqa.data.entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * WeightGoal – cieľ chudnutia (voliteľný).
 *
 * Iba jeden aktívny cieľ naraz (v module je single profile podľa
 * špecifikácie). Pri zmene cieľa sa starý označí active=false a vytvorí sa nový.
 *
 * Slúži na:
 *  - Progress bar v UI ("ostáva 2,3 kg · 45 dní")
 *  - Horizontálnu čiaru cieľa v grafe
 *  - Výpočet trendu (či ide po krivke smerom k cieľu)
 */
@Entity(tableName = "weight_goals")
public class WeightGoal {

    @PrimaryKey(autoGenerate = true)
    public long id;

    /** Hmotnosť na štarte (kg) – referenčný bod pre progress. */
    public double startKg;

    /** Cieľová hmotnosť (kg). */
    public double targetKg;

    /** Cieľový dátum (unix epoch millis), 0 = bez deadline. */
    public long targetDate = 0L;

    /** Kedy bol cieľ založený. */
    public long startedAt;

    /** Iba jeden cieľ má active=true v jednom okamihu. */
    public boolean active = true;
}
