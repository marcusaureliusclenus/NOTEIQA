package sk.aetheriqa.noteiqa.ui.todo;

import androidx.appcompat.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.data.repository.TaskRepository;
import sk.aetheriqa.noteiqa.util.IcsExporter;
import sk.aetheriqa.noteiqa.util.ShoppingItems;

import android.text.TextUtils;

import java.util.List;
import java.util.Locale;

import sk.aetheriqa.noteiqa.util.DateUtils;

/**
 * TaskContextMenu – jednoduchý dialog s 5 akciami pre úlohu.
 *
 * Otvára sa pri long-press na úlohe v TasksFragmente. Akcie sú totožné s
 * tými v TaskDetailActivity (Marekova požiadavka).
 *
 * Pre-archive Vymazať otvára confirm dialóg "Vymazať? Áno/Nie".
 */
public final class TaskContextMenu {

    private TaskContextMenu() {}

    public static void show(Context ctx, Task task, MoveDialogProvider mover) {
        TaskRepository repo = TaskRepository.getInstance(ctx.getApplicationContext());

        CharSequence[] options = new CharSequence[]{
                ctx.getString(R.string.task_action_move),
                ctx.getString(R.string.task_action_change),
                ctx.getString(R.string.task_action_share_v2),
                ctx.getString(R.string.task_action_to_calendar),
                ctx.getString(R.string.task_action_remove)
        };

        new AlertDialog.Builder(ctx,
                sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(TextUtils.isEmpty(task.title) ? "—" : task.title)
                .setItems(options, (d, which) -> {
                    switch (which) {
                        case 0: // Presuň
                            if (mover != null) mover.showMoveDialog(task);
                            break;
                        case 1: // Zmeniť
                            ctx.startActivity(TaskEditorActivity.newIntent(ctx, task.id));
                            break;
                        case 2: // Zdieľať
                            shareTask(ctx, task);
                            break;
                        case 3: // .ics
                            sendToCalendar(ctx, task);
                            break;
                        case 4: // Vymazať s confirm
                            confirmAndArchive(ctx, repo, task);
                            break;
                    }
                })
                .show();
    }

    public static void confirmAndArchive(Context ctx, TaskRepository repo, Task task) {
        new AlertDialog.Builder(ctx,
                sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(R.string.task_complete_confirm_title)
                .setMessage(R.string.task_complete_confirm_msg)
                .setPositiveButton(R.string.action_yes, (d, w) -> {
                    repo.archive(task.id);
                    Toast.makeText(ctx, R.string.task_archived_toast, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(R.string.action_no, null)
                .show();
    }

    private static void shareTask(Context ctx, Task task) {
        StringBuilder sb = new StringBuilder();
        if (!TextUtils.isEmpty(task.title)) sb.append(task.title);
        if (task.dueDate != null && task.dueDate != 0L) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(DateUtils.formatLongDate(task.dueDate));
        }
        if (task.dueTimeMinutes != null) {
            int h = task.dueTimeMinutes / 60;
            int m = task.dueTimeMinutes % 60;
            sb.append(' ').append(String.format(Locale.getDefault(), "%d:%02d", h, m));
        }
        if (!TextUtils.isEmpty(task.note)) {
            sb.append("\n\n").append(task.note);
        }
        if (!TextUtils.isEmpty(task.shoppingItemsJson)) {
            List<ShoppingItems.Item> items = ShoppingItems.parse(task.shoppingItemsJson);
            if (!items.isEmpty()) {
                sb.append("\n\n");
                for (ShoppingItems.Item it : items) {
                    sb.append(it.checked ? "[x] " : "[ ] ").append(it.text).append('\n');
                }
            }
        }

        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, sb.toString().trim());
        Intent chooser = Intent.createChooser(send, ctx.getString(R.string.task_action_share_v2));
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(chooser);
    }

    private static void sendToCalendar(Context ctx, Task task) {
        Intent intent = IcsExporter.buildShareIntent(ctx, task);
        if (intent == null) {
            Toast.makeText(ctx,
                    task.dueDate == null
                            ? R.string.ics_export_no_date
                            : R.string.ics_export_failed,
                    Toast.LENGTH_LONG).show();
            return;
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(intent);
    }

    /**
     * Volajúci kontext (Fragment alebo Activity) musí dodať implementáciu
     * Move dialógu, lebo pre Move treba date/time picker, ktoré sú spojené
     * s jeho lifecycle-om.
     */
    public interface MoveDialogProvider {
        void showMoveDialog(Task task);
    }
}
