package sk.aetheriqa.noteiqa.data.entity;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Kid – dieťa v rodine. Jednoduchá lookup entita, do ktorej sa naviaže
 * KidPayment a KidEvent.
 *
 * Zaseedované pri prvom spuštení Deti modulu:
 *  - id=1 name="Alex"
 *  - id=2 name="Gabika"
 *
 * Marek si môže neskôr pridať ďalšie deti cez editor v Nastaveniach
 * (v1.1.0 UI pre pridanie ešte nie je — 2 deti sú fixné). Alebo cez
 * DB import zo zálohy pri prenose zariadenia.
 */
@Entity(tableName = "kids")
public class Kid {

    @PrimaryKey(autoGenerate = true)
    public long id;

    @NonNull
    @ColumnInfo(defaultValue = "")
    public String name = "";

    /** Farba pre chip v UI. Alex = modrá, Gabika = ružová. Hex string. */
    @NonNull
    @ColumnInfo(defaultValue = "#C9A961")
    public String colorHex = "#C9A961";

    /** Poradie pre zobrazenie v segment toggle. */
    public int sortOrder = 0;

    public long createdAt;
    public long updatedAt;

    public Kid() {}

    public Kid(@NonNull String name, @NonNull String colorHex, int sortOrder) {
        this.name = name;
        this.colorHex = colorHex;
        this.sortOrder = sortOrder;
        long now = System.currentTimeMillis();
        this.createdAt = now;
        this.updatedAt = now;
    }
}
