package sk.aetheriqa.noteiqa.util;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * ShoppingItems – serialization helper pre kategóriu Nákup.
 *
 * V Task entity ukladáme ako shoppingItemsJson (string), formát:
 *   [{"text":"vajcia","checked":false}, {"text":"chlieb","checked":true}, ...]
 *
 * V UI sa zobrazia ako checkbox items s preškrtnutím pri checked=true.
 */
public final class ShoppingItems {

    public static final class Item {
        @NonNull public String text;
        public boolean checked;

        public Item(@NonNull String text, boolean checked) {
            this.text = text;
            this.checked = checked;
        }
    }

    private ShoppingItems() {}

    @NonNull
    public static List<Item> parse(@Nullable String json) {
        List<Item> out = new ArrayList<>();
        if (json == null || json.isEmpty()) return out;
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String text = o.optString("text", "");
                boolean checked = o.optBoolean("checked", false);
                if (!text.isEmpty()) out.add(new Item(text, checked));
            }
        } catch (JSONException e) {
            // ignore – vrátime to čo sa podarilo
        }
        return out;
    }

    @NonNull
    public static String serialize(@Nullable List<Item> items) {
        if (items == null || items.isEmpty()) return "[]";
        JSONArray arr = new JSONArray();
        try {
            for (Item it : items) {
                JSONObject o = new JSONObject();
                o.put("text", it.text);
                o.put("checked", it.checked);
                arr.put(o);
            }
        } catch (JSONException e) {
            return "[]";
        }
        return arr.toString();
    }
}
