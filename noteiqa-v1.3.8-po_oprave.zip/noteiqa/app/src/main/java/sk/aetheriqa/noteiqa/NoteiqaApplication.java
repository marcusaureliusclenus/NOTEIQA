package sk.aetheriqa.noteiqa;

import android.app.Application;
import androidx.appcompat.app.AppCompatDelegate;

import sk.aetheriqa.noteiqa.notification.NotificationHelper;
import sk.aetheriqa.noteiqa.util.MotivationalQuotes;

/**
 * NoteiqaApplication
 *
 * Globálny entry-point. Inicializuje:
 *  - Force dark mode (premium gold-on-black aesthetic)
 *  - Notifikačné kanály pre pripomienky
 *  - DB instanciu (lazy via {@link sk.aetheriqa.noteiqa.data.db.AppDatabase#getInstance})
 *
 * Žiadny analytics SDK. Žiadny crash reporter. Žiadne tracking.
 */
public class NoteiqaApplication extends Application {

    private static NoteiqaApplication instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;

        // Defaultne dark mode – téma je čierno-zlatá premium.
        // Light variant existuje len ako fallback pre systém, ktorý si to vynúti.
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);

        // v1.2.0 — voliteľný zámok appky (vypnutý = nič nerobí)
        sk.aetheriqa.noteiqa.security.AppLock.install(this);

        // Notifikačné kanály (Android 8+)
        NotificationHelper.createChannels(this);

        // Default motivačné vety v prvom spustení – Marek môže neskôr nahradiť
        // svojím .md cez Nastavenia → Profil → Motivačné vety.
        // Beží na background, lebo IO read z assets nesmie blokovať UI thread.
        new Thread(() -> MotivationalQuotes.ensureDefaultImported(this),
                "DefaultQuotesInit").start();

        // v1.0.0 — zaznamenaj prvé spustenie pre streak "X dní s appkou"
        sk.aetheriqa.noteiqa.data.preferences.UserPreferences.get(this)
                .recordFirstLaunchIfNeeded();

        // v1.2.0 — kôš: poznámky zmazané pred > 30 dňami preč (Room executor, nie UI thread)
        // + seed 3 šablón, ak je tabuľka prázdna
        sk.aetheriqa.noteiqa.data.repository.NoteRepository repo =
                sk.aetheriqa.noteiqa.data.repository.NoteRepository.getInstance(this);
        repo.purgeOldTrashed();
        repo.ensureTemplatesSeeded(this);
    }

    public static NoteiqaApplication get() {
        return instance;
    }
}
