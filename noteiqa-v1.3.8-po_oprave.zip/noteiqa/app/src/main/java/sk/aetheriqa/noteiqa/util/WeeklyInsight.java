package sk.aetheriqa.noteiqa.util;

import android.content.Context;

import androidx.annotation.NonNull;

import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.db.AppDatabase;
import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.data.entity.WeightEntry;

/**
 * WeeklyInsight – agreguje dáta tohto týždňa pre dashboard insight card.
 *
 * Polia:
 *   - weightChangeKg     (nullable Double): rozdiel posledné meranie vs prvé v týždni
 *   - tasksCompletedCount: počet hotových úloh
 *   - weightDaysCount:    počet unikátnych dní s vážením v týždni
 *   - mostProductiveDay:  deň v týždni s najvyšším počtom completed tasks
 *   - trend:              FALLING / STABLE / RISING / NO_DATA
 *
 * Trend: porovnám priemer **prvých 3 meraní** s priemerom **posledných 3 meraní**
 * v poslednom mesiaci. Ak |delta| < 0.15 kg → STABLE.
 *
 * Volaj len z background threadu (cez `loadAsync`).
 */
public final class WeeklyInsight {

    public enum Trend { FALLING, STABLE, RISING, NO_DATA }

    public static class Result {
        public Double weightChangeKg; // null ak nie sú v týždni aspoň 2 váženia
        public int tasksCompletedCount;
        public int weightDaysCount;
        public Integer mostProductiveDayOfWeek; // Calendar.MONDAY..SUNDAY, null ak žiadny
        public Trend trend = Trend.NO_DATA;
    }

    public interface Callback {
        void onLoaded(@NonNull Result result);
    }

    private WeeklyInsight() {}

    public static void loadAsync(Context ctx, Callback cb) {
        Context appCtx = ctx.getApplicationContext();
        new Thread(() -> {
            Result r = computeSync(appCtx);
            new android.os.Handler(android.os.Looper.getMainLooper())
                    .post(() -> cb.onLoaded(r));
        }, "WeeklyInsight").start();
    }

    @NonNull
    static Result computeSync(Context ctx) {
        Result out = new Result();
        AppDatabase db = AppDatabase.getInstance(ctx);

        long[] week = StreakCalculator.currentWeekRange();
        long weekStart = week[0];
        long weekEnd = week[1];

        // 1) Hotové úlohy v týždni
        List<Task> completedThisWeek = db.taskDao().getCompletedInRange(weekStart, weekEnd);
        out.tasksCompletedCount = completedThisWeek.size();

        // 2) Najproduktívnejší deň
        out.mostProductiveDayOfWeek = computeMostProductiveDay(completedThisWeek);

        // 3) Váženia v týždni — change + počet dní
        List<WeightEntry> weightsThisWeek = db.weightDao().getInRangeSync(weekStart, weekEnd);
        if (weightsThisWeek.size() >= 2) {
            // Prvé je ASC, takže [0] je najstaršie
            double first = weightsThisWeek.get(0).kg;
            double last = weightsThisWeek.get(weightsThisWeek.size() - 1).kg;
            out.weightChangeKg = last - first;
        }

        // Počet unikátnych dní s vážením
        Set<Integer> distinctDays = new HashSet<>();
        for (WeightEntry w : weightsThisWeek) {
            distinctDays.add(dayKey(w.measuredAt));
        }
        out.weightDaysCount = distinctDays.size();

        // 4) Trend váhy — porovnaj priemer prvých 3 vs posledných 3 v poslednom mesiaci
        out.trend = computeTrend(db);

        return out;
    }

    @NonNull
    private static Trend computeTrend(AppDatabase db) {
        // Posledných 30 dní
        long now = System.currentTimeMillis();
        long fromMillis = now - 30L * 24 * 60 * 60 * 1000;
        List<WeightEntry> recent = db.weightDao().getInRangeSync(fromMillis, now + 1);

        if (recent.size() < 6) return Trend.NO_DATA;

        // ASC zoradenie
        double firstAvg = (recent.get(0).kg + recent.get(1).kg + recent.get(2).kg) / 3.0;
        int n = recent.size();
        double lastAvg = (recent.get(n - 1).kg + recent.get(n - 2).kg + recent.get(n - 3).kg) / 3.0;

        double delta = lastAvg - firstAvg;
        if (Math.abs(delta) < 0.15) return Trend.STABLE;
        return delta < 0 ? Trend.FALLING : Trend.RISING;
    }

    private static Integer computeMostProductiveDay(List<Task> tasks) {
        if (tasks.isEmpty()) return null;
        Map<Integer, Integer> counts = new HashMap<>();
        Calendar c = Calendar.getInstance(TimeZone.getDefault());
        for (Task t : tasks) {
            c.setTimeInMillis(t.completedAt);
            int dow = c.get(Calendar.DAY_OF_WEEK);
            counts.put(dow, counts.getOrDefault(dow, 0) + 1);
        }
        int bestDay = -1;
        int bestCount = -1;
        for (Map.Entry<Integer, Integer> e : counts.entrySet()) {
            if (e.getValue() > bestCount) {
                bestCount = e.getValue();
                bestDay = e.getKey();
            }
        }
        return bestDay == -1 ? null : bestDay;
    }

    private static int dayKey(long millis) {
        Calendar c = Calendar.getInstance(TimeZone.getDefault());
        c.setTimeInMillis(millis);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return (int) (c.getTimeInMillis() / (24L * 60 * 60 * 1000));
    }

    /** Slovenský dlhý názov dňa. */
    @NonNull
    public static String slovakDayName(int calendarDayOfWeek) {
        switch (calendarDayOfWeek) {
            case Calendar.MONDAY: return "pondelok";
            case Calendar.TUESDAY: return "utorok";
            case Calendar.WEDNESDAY: return "streda";
            case Calendar.THURSDAY: return "štvrtok";
            case Calendar.FRIDAY: return "piatok";
            case Calendar.SATURDAY: return "sobota";
            case Calendar.SUNDAY: return "nedeľa";
            default: return "";
        }
    }

    /** Sformátuje weightChangeKg ako "−0.8 kg" / "+0.3 kg" / "stabilná". */
    @NonNull
    public static String formatWeightChange(Context ctx, Double kg) {
        if (kg == null) return ctx.getString(R.string.insight_weight_change_na);
        if (Math.abs(kg) < 0.05) return ctx.getString(R.string.insight_weight_change_zero);
        String formatted = String.format(Locale.getDefault(), "%.1f", Math.abs(kg))
                .replace('.', ',');
        return kg < 0
                ? ctx.getString(R.string.insight_weight_change_down, formatted)
                : ctx.getString(R.string.insight_weight_change_up, formatted);
    }
}
