package sk.aetheriqa.noteiqa.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * MotivationProvider – načíta motivačné vety z assets/motivation_lines.md
 * a vyberie 1 vetu pre dnešný deň podľa pravidiel:
 *
 *  - Veta sa nesmie zopakovať 30 dní (anti-repeat window).
 *  - V rámci jedného dňa sa môže veta meniť (napr. ak app reštartuješ),
 *    ale stále z toho istého "neopakovateľného" poolu.
 *  - Ak by sa všetky vety už použili v posledných 30 dňoch (ojedinelé pri
 *    malom súbore), uvoľníme najstaršiu z histórie.
 *
 * Stav (kedy bola veta naposledy použitá) ukladáme v SharedPreferences ako
 * jednoduchý "lineHash → epochDay" map.
 */
public final class MotivationProvider {

    private static final String TAG = "MotivationProvider";
    private static final String ASSET_FILE = "motivation_lines.md";
    private static final String PREFS_NAME = "noteiqa_motivation";

    /** Mapa lineHash → epochDay posledného použitia. */
    private static final String KEY_USAGE_PREFIX = "usage_";

    /** Anti-repeat okno v dňoch – Marek si želá min 30. */
    private static final int ANTI_REPEAT_DAYS = 30;

    private MotivationProvider() {}

    /** Vráti vetu pre tento deň. Side effect: zaznamená použitie do prefs. */
    @NonNull
    public static String pickForToday(@NonNull Context ctx) {
        List<String> lines = loadLines(ctx);
        if (lines.isEmpty()) return "";

        SharedPreferences prefs = ctx.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        long todayEpochDay = todayEpochDay();

        // 1) Skús nájsť vetu, ktorá sa nepoužila v posledných ANTI_REPEAT_DAYS
        List<String> candidates = new ArrayList<>();
        for (String line : lines) {
            long lastUsedDay = prefs.getLong(KEY_USAGE_PREFIX + hashKey(line), -1L);
            if (lastUsedDay < 0 || (todayEpochDay - lastUsedDay) >= ANTI_REPEAT_DAYS) {
                candidates.add(line);
            }
        }

        // 2) Ak nič nezostalo (treba ku 30+ vetám), najstaršie použitia uvoľni.
        // Berieme top 50% lineov s najmenšou recent usage.
        if (candidates.isEmpty()) {
            Log.w(TAG, "All lines exhausted in 30-day window — falling back to oldest");
            // Trie ich stable podľa lastUsedDay ASC
            Map<String, Long> byUsage = new LinkedHashMap<>();
            for (String line : lines) {
                byUsage.put(line, prefs.getLong(KEY_USAGE_PREFIX + hashKey(line), 0L));
            }
            // Vyberieme line s najmenším epochDay (najstarší použitie = najmenej "fresh")
            String oldest = null;
            long oldestDay = Long.MAX_VALUE;
            for (Map.Entry<String, Long> e : byUsage.entrySet()) {
                if (e.getValue() < oldestDay) {
                    oldestDay = e.getValue();
                    oldest = e.getKey();
                }
            }
            if (oldest == null) oldest = lines.get(0);
            candidates.add(oldest);
        }

        // 3) Náhodný výber z candidates
        Random rnd = new Random();
        String picked = candidates.get(rnd.nextInt(candidates.size()));

        // 4) Zaznamenaj použitie
        prefs.edit()
                .putLong(KEY_USAGE_PREFIX + hashKey(picked), todayEpochDay)
                .apply();

        return picked;
    }

    /**
     * Verzia, ktorá vracia rovnakú vetu, kým je dnešný deň – nemení sa
     * pri každom otvorení Home fragmentu. Odporúčaná pre dashboard.
     */
    @NonNull
    public static String pickForTodayCached(@NonNull Context ctx) {
        SharedPreferences prefs = ctx.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        long todayEpochDay = todayEpochDay();

        long cacheDay = prefs.getLong("cache_day", -1L);
        String cacheLine = prefs.getString("cache_line", null);

        if (cacheDay == todayEpochDay && !TextUtils.isEmpty(cacheLine)) {
            return cacheLine;
        }

        String fresh = pickForToday(ctx);
        prefs.edit()
                .putLong("cache_day", todayEpochDay)
                .putString("cache_line", fresh)
                .apply();
        return fresh;
    }

    /** Iba pre debug/test: prepiše cache a vyberie inú vetu. */
    public static void clearCache(@NonNull Context ctx) {
        SharedPreferences prefs = ctx.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove("cache_day").remove("cache_line").apply();
    }

    // ===== Private =====

    @NonNull
    private static List<String> loadLines(@NonNull Context ctx) {
        List<String> out = new ArrayList<>();
        try (InputStream is = ctx.getAssets().open(ASSET_FILE);
             BufferedReader r = new BufferedReader(
                     new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                String trimmed = line.trim();
                if (TextUtils.isEmpty(trimmed)) continue;
                if (trimmed.startsWith("#")) continue; // komentáre
                out.add(trimmed);
            }
        } catch (IOException e) {
            Log.e(TAG, "Failed to load motivation lines", e);
        }
        return out;
    }

    /** Stabilný hash pre line – kratšie ako line samotná, dobre pre prefs key. */
    private static String hashKey(String line) {
        return Integer.toHexString(line.hashCode());
    }

    /** Počet dní od epochy v lokálnom timezone — robust against TZ shifts. */
    private static long todayEpochDay() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis() / (24L * 60 * 60 * 1000);
    }
}
