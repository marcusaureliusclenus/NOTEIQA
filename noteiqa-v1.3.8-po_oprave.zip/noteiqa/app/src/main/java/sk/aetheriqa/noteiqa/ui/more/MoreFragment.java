package sk.aetheriqa.noteiqa.ui.more;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import java.util.List;

import sk.aetheriqa.noteiqa.BuildConfig;
import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.preferences.UserPreferences;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.notification.ReminderScheduler;
import sk.aetheriqa.noteiqa.security.AppLock;
import sk.aetheriqa.noteiqa.ui.notes.ArchivedNotesActivity;
import sk.aetheriqa.noteiqa.ui.notes.NoteCollectionActivity;
import sk.aetheriqa.noteiqa.ui.todo.ArchivedTasksActivity;
import sk.aetheriqa.noteiqa.util.BackupExporter;
import sk.aetheriqa.noteiqa.util.BackupImporter;
import sk.aetheriqa.noteiqa.util.DialogThemes;
import sk.aetheriqa.noteiqa.util.ImageStorage;
import sk.aetheriqa.noteiqa.util.MotivationalQuotes;

/**
 * MoreFragment / Nastavenia – v0.5.0 pridaná sekcia Profil:
 *  - Tvoje meno
 *  - Profilové foto
 *  - Motivačné vety (.md import)
 */
public class MoreFragment extends Fragment {

    /** Photo picker — kópia do internej zložky cez ImageStorage. */
    private final ActivityResultLauncher<String> pickPhoto =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) onPhotoPicked(uri);
            });

    /** Quotes .md picker. */
    private final ActivityResultLauncher<String> pickQuotes =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) onQuotesFilePicked(uri);
            });

    /** v1.2.0 — SAF picker pre obnovu zo ZIP zálohy. */
    private final ActivityResultLauncher<String[]> pickBackup =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
                if (uri != null) confirmRestore(uri);
            });

    private TextView nameValueView;
    private TextView photoValueView;
    private TextView quotesValueView;
    // v1.2.0
    private TextView appLockValueView;
    private TextView exactAlarmsValueView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_more, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // ===== Sekcia Profil =====
        bindRow(view, R.id.row_profile_name,
                R.drawable.ic_profile, R.string.profile_name_label,
                v -> showNameEditor());
        bindRow(view, R.id.row_profile_photo,
                R.drawable.ic_attachment, R.string.profile_photo_label,
                v -> showPhotoMenu());
        bindRow(view, R.id.row_profile_quotes,
                R.drawable.ic_note, R.string.profile_quotes_label,
                v -> pickQuotes.launch("text/*"));

        // Cache references na value TextViews aby sme ich vedeli refresh-ovať
        nameValueView = findValueView(view, R.id.row_profile_name);
        photoValueView = findValueView(view, R.id.row_profile_photo);
        quotesValueView = findValueView(view, R.id.row_profile_quotes);

        // ===== Sekcia Organizácia =====
        bindRow(view, R.id.row_archive_tasks, R.drawable.ic_archive, R.string.archive_title,
                v -> startActivity(ArchivedTasksActivity.newIntent(requireContext())));
        bindRow(view, R.id.row_archive_notes, R.drawable.ic_archive, R.string.archive_notes_title,
                v -> startActivity(ArchivedNotesActivity.newIntent(requireContext())));
        // v1.2.0 — Kôš / Štítky / Šablóny už nie sú "Pripravujeme"
        bindRow(view, R.id.row_trash, R.drawable.ic_trash, R.string.more_trash,
                v -> startActivity(NoteCollectionActivity.newIntent(requireContext(),
                        NoteCollectionActivity.MODE_TRASH)));
        bindRow(view, R.id.row_tags, R.drawable.ic_tag, R.string.more_tags,
                v -> startActivity(NoteCollectionActivity.newIntent(requireContext(),
                        NoteCollectionActivity.MODE_TAGS)));
        bindRow(view, R.id.row_templates, R.drawable.ic_template, R.string.more_templates,
                v -> startActivity(NoteCollectionActivity.newIntent(requireContext(),
                        NoteCollectionActivity.MODE_TEMPLATES)));

        // ===== Sekcia Systém =====
        bindRow(view, R.id.row_app_lock, R.drawable.ic_lock, R.string.more_app_lock,
                v -> toggleAppLock());
        bindRow(view, R.id.row_exact_alarms, R.drawable.ic_bell, R.string.more_exact_alarms,
                v -> openExactAlarmSettings());
        appLockValueView = findValueView(view, R.id.row_app_lock);
        exactAlarmsValueView = findValueView(view, R.id.row_exact_alarms);

        bindRow(view, R.id.row_export, R.drawable.ic_export, R.string.more_export,
                v -> showBackupMenu());
        bindRow(view, R.id.row_about, R.drawable.ic_info, R.string.more_about,
                v -> showAbout());

        TextView version = view.findViewById(R.id.more_version);
        if (version != null) {
            version.setText(getString(R.string.more_version_format, BuildConfig.VERSION_NAME));
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshProfileSubtitles();
        refreshSystemRows();
        refreshKidRows();
    }

    // ===== v1.2.0 — Systém: zámok + presné pripomienky =====

    private void refreshSystemRows() {
        if (appLockValueView != null) {
            appLockValueView.setText(AppLock.get(requireContext()).isEnabled()
                    ? R.string.more_state_on : R.string.more_state_off);
            appLockValueView.setVisibility(View.VISIBLE);
        }
        if (exactAlarmsValueView != null) {
            exactAlarmsValueView.setText(ReminderScheduler.needsExactAlarmPermission(requireContext())
                    ? R.string.more_state_disabled : R.string.more_state_allowed);
            exactAlarmsValueView.setVisibility(View.VISIBLE);
        }
    }

    private void toggleAppLock() {
        AppLock lock = AppLock.get(requireContext());
        if (lock.isEnabled()) {
            lock.setEnabled(false);
        } else if (!AppLock.canAuthenticate(requireContext())) {
            Toast.makeText(requireContext(), R.string.app_lock_unavailable, Toast.LENGTH_LONG).show();
            return;
        } else {
            lock.setEnabled(true);
            Toast.makeText(requireContext(), R.string.app_lock_enabled_toast, Toast.LENGTH_LONG).show();
        }
        refreshSystemRows();
    }

    private void openExactAlarmSettings() {
        android.content.Intent intent = ReminderScheduler.buildExactAlarmSettingsIntent(requireContext());
        if (intent == null) {
            Toast.makeText(requireContext(), R.string.exact_alarms_always_on, Toast.LENGTH_LONG).show();
            return;
        }
        try {
            startActivity(intent);
        } catch (android.content.ActivityNotFoundException e) {
            Toast.makeText(requireContext(), R.string.exact_alarms_always_on, Toast.LENGTH_LONG).show();
        }
    }

    // ===== v1.2.0 — Deti: premenovanie (len 2 deti, bez pridávania ďalších) =====

    private void refreshKidRows() {
        if (getView() == null) return;
        Context appCtx = requireContext().getApplicationContext();
        new Thread(() -> {
            List<Kid> kids = KidRepository.getInstance(appCtx).getKidsSync();
            android.app.Activity act = getActivity();
            if (act == null) return;
            act.runOnUiThread(() -> {
                if (!isAdded() || getView() == null) return;
                bindKidRow(getView(), R.id.row_kid_a, kids.size() > 0 ? kids.get(0) : null);
                bindKidRow(getView(), R.id.row_kid_b, kids.size() > 1 ? kids.get(1) : null);
            });
        }, "MoreKids").start();
    }

    private void bindKidRow(View root, int rowId, @Nullable Kid kid) {
        View row = root.findViewById(rowId);
        if (row == null) return;
        if (kid == null) {
            row.setVisibility(View.GONE);
            return;
        }
        row.setVisibility(View.VISIBLE);
        ImageView icon = row.findViewById(R.id.icon);
        TextView title = row.findViewById(R.id.title);
        TextView subtitle = row.findViewById(R.id.subtitle);
        if (icon != null) icon.setImageResource(R.drawable.ic_kids);
        if (title != null) title.setText(kid.name);
        if (subtitle != null) {
            subtitle.setText(R.string.more_kid_rename_hint);
            subtitle.setVisibility(View.VISIBLE);
        }
        row.setOnClickListener(v -> showKidRename(kid));
    }

    private void showKidRename(Kid kid) {
        EditText input = new EditText(requireContext());
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        input.setHint(R.string.kid_rename_hint);
        input.setText(kid.name);
        input.setSelection(input.getText().length());

        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        android.widget.FrameLayout container = new android.widget.FrameLayout(requireContext());
        container.setPadding(pad, pad, pad, 0);
        container.addView(input);

        new AlertDialog.Builder(requireContext(), DialogThemes.LEA)
                .setTitle(R.string.kid_rename_title)
                .setView(container)
                .setPositiveButton(R.string.action_save, (d, w) -> {
                    String value = input.getText().toString().trim();
                    if (value.isEmpty()) return; // prázdne meno = ponechaj pôvodné
                    KidRepository.getInstance(requireContext())
                            .renameKid(kid.id, value, () -> { if (isAdded()) refreshKidRows(); });
                })
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    private void refreshProfileSubtitles() {
        UserPreferences prefs = UserPreferences.get(requireContext());

        if (nameValueView != null) {
            nameValueView.setText(prefs.getDisplayName());
            nameValueView.setVisibility(View.VISIBLE);
        }

        if (photoValueView != null) {
            String photo = prefs.getPhotoPath();
            if (photo == null || photo.isEmpty()) {
                photoValueView.setVisibility(View.GONE);
            } else {
                photoValueView.setText(R.string.profile_photo_set);
                photoValueView.setVisibility(View.VISIBLE);
            }
        }

        if (quotesValueView != null) {
            Integer count = MotivationalQuotes.countQuotes(requireContext());
            if (count == null) {
                quotesValueView.setText(R.string.profile_quotes_none);
            } else {
                quotesValueView.setText(getString(R.string.profile_quotes_imported, count));
            }
            quotesValueView.setVisibility(View.VISIBLE);
        }
    }

    // ===== Photo =====

    private void showPhotoMenu() {
        UserPreferences prefs = UserPreferences.get(requireContext());
        boolean hasPhoto = prefs.getPhotoPath() != null && !prefs.getPhotoPath().isEmpty();

        if (!hasPhoto) {
            // Bez fota → rovno picker
            pickPhoto.launch("image/*");
            return;
        }

        // S fotom → ponuka zmeniť / odstrániť
        new AlertDialog.Builder(requireContext(), DialogThemes.LEA)
                .setTitle(R.string.profile_photo_label)
                .setItems(new CharSequence[]{
                        getString(R.string.profile_photo_change),
                        getString(R.string.profile_photo_remove)
                }, (d, which) -> {
                    if (which == 0) {
                        pickPhoto.launch("image/*");
                    } else {
                        ImageStorage.deleteIfExists(prefs.getPhotoPath());
                        prefs.setPhotoPath(null);
                        refreshProfileSubtitles();
                    }
                })
                .show();
    }

    private void onPhotoPicked(Uri uri) {
        new Thread(() -> {
            String path = ImageStorage.importImage(requireContext(), uri);
            if (path == null) {
                requireActivity().runOnUiThread(() ->
                        Toast.makeText(requireContext(), R.string.profile_photo_import_failed,
                                Toast.LENGTH_SHORT).show());
                return;
            }
            UserPreferences prefs = UserPreferences.get(requireContext());
            String old = prefs.getPhotoPath();
            if (old != null && !old.equals(path)) ImageStorage.deleteIfExists(old);
            prefs.setPhotoPath(path);
            requireActivity().runOnUiThread(this::refreshProfileSubtitles);
        }).start();
    }

    // ===== Quotes =====

    private void onQuotesFilePicked(Uri uri) {
        new Thread(() -> {
            int count = MotivationalQuotes.importFromUri(requireContext(), uri);
            requireActivity().runOnUiThread(() -> {
                if (count < 0) {
                    Toast.makeText(requireContext(), R.string.profile_quotes_failed,
                            Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(requireContext(),
                            getString(R.string.profile_quotes_imported_toast, count),
                            Toast.LENGTH_SHORT).show();
                    refreshProfileSubtitles();
                }
            });
        }).start();
    }

    // ===== Name editor =====

    private void showNameEditor() {
        UserPreferences prefs = UserPreferences.get(requireContext());

        EditText input = new EditText(requireContext());
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        input.setHint(R.string.profile_name_hint);
        input.setText(prefs.getDisplayName());
        input.setSelection(input.getText().length());

        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        android.widget.FrameLayout container = new android.widget.FrameLayout(requireContext());
        container.setPadding(pad, pad, pad, 0);
        container.addView(input);

        new AlertDialog.Builder(requireContext(), DialogThemes.LEA)
                .setTitle(R.string.profile_name_dialog_title)
                .setView(container)
                .setPositiveButton(R.string.action_save, (d, w) -> {
                    String value = input.getText().toString().trim();
                    if (value.isEmpty()) value = UserPreferences.DEFAULT_NAME;
                    prefs.setDisplayName(value);
                    refreshProfileSubtitles();
                })
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    // ===== Helpers =====

    private void bindRow(View root, int rowId,
                         @DrawableRes int iconRes,
                         @StringRes int titleRes,
                         View.OnClickListener click) {
        View row = root.findViewById(rowId);
        if (row == null) return;
        ImageView icon = row.findViewById(R.id.icon);
        TextView title = row.findViewById(R.id.title);
        if (icon != null) icon.setImageResource(iconRes);
        if (title != null) title.setText(titleRes);
        row.setOnClickListener(click);
    }

    /**
     * Vráti TextView pre 2. riadok (subtitle) v item_more_row, ak existuje.
     * Tým pádom môžeme ukázať aktuálnu hodnotu pod titulkom.
     */
    @Nullable
    private TextView findValueView(View root, int rowId) {
        View row = root.findViewById(rowId);
        if (row == null) return null;
        return row.findViewById(R.id.subtitle);
    }

    /** v1.2.0 — Export / Backup: vytvoriť zálohu alebo obnoviť zo zálohy. */
    private void showBackupMenu() {
        new AlertDialog.Builder(requireContext(), DialogThemes.LEA)
                .setTitle(R.string.export_dialog_title)
                .setItems(new CharSequence[]{
                        getString(R.string.backup_menu_export),
                        getString(R.string.backup_menu_restore)
                }, (d, which) -> {
                    if (which == 0) {
                        showExportDialog();
                    } else {
                        pickBackup.launch(new String[]{"application/zip", "*/*"});
                    }
                })
                .show();
    }

    private void confirmRestore(Uri uri) {
        new AlertDialog.Builder(requireContext(), DialogThemes.LEA)
                .setTitle(R.string.restore_confirm_title)
                .setMessage(R.string.restore_confirm_message)
                .setPositiveButton(R.string.restore_confirm_button, (d, w) -> runRestore(uri))
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    private void runRestore(Uri uri) {
        AlertDialog progress = new AlertDialog.Builder(requireContext(), DialogThemes.LEA)
                .setTitle(R.string.backup_menu_restore)
                .setMessage(R.string.restore_in_progress)
                .setCancelable(false)
                .show();

        BackupImporter.importAsync(requireContext(), uri, new BackupImporter.OnImportListener() {
            @Override
            public void onSuccess(BackupImporter.ImportStats stats) {
                if (!isAdded()) return;
                progress.dismiss();
                String summary = getString(R.string.restore_done_summary,
                        stats.taskCount, stats.noteCount, stats.weightCount,
                        stats.kidPaymentCount, stats.kidEventCount, stats.attachmentCount);
                new AlertDialog.Builder(requireContext(), DialogThemes.LEA)
                        .setTitle(R.string.restore_done_title)
                        .setMessage(summary)
                        .setCancelable(false)
                        // Refresh — meno, foto, quotes a deti z obnovenej zálohy
                        .setPositiveButton(R.string.action_ok, (d, w) -> {
                            refreshProfileSubtitles();
                            refreshSystemRows();
                            refreshKidRows();
                        })
                        .show();
            }

            @Override
            public void onError(String message) {
                if (!isAdded()) return;
                progress.dismiss();
                new AlertDialog.Builder(requireContext(), DialogThemes.LEA)
                        .setTitle(R.string.backup_menu_restore)
                        .setMessage(getString(R.string.restore_failed, message))
                        .setPositiveButton(R.string.action_close, null)
                        .show();
            }
        });
    }

    private void showExportDialog() {
        new AlertDialog.Builder(requireContext(), DialogThemes.LEA)
                .setTitle(R.string.export_dialog_title)
                .setMessage(R.string.export_dialog_message)
                .setPositiveButton(R.string.export_dialog_button, (d, w) -> runExport())
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    private void runExport() {
        // Progress dialog
        AlertDialog progress = new AlertDialog.Builder(requireContext(), DialogThemes.LEA)
                .setTitle(R.string.export_dialog_title)
                .setMessage(R.string.export_in_progress)
                .setCancelable(false)
                .show();

        BackupExporter.exportAsync(requireContext(), new BackupExporter.OnExportListener() {
            @Override
            public void onSuccess(java.io.File zipFile, BackupExporter.ExportStats stats) {
                if (!isAdded()) return;
                progress.dismiss();
                showExportDoneDialog(zipFile, stats);
            }

            @Override
            public void onError(String message) {
                if (!isAdded()) return;
                progress.dismiss();
                Toast.makeText(requireContext(),
                        getString(R.string.export_failed, message),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private void showExportDoneDialog(java.io.File zipFile, BackupExporter.ExportStats stats) {
        String summary = getString(R.string.export_done_summary,
                stats.taskCount, stats.noteCount, stats.weightCount,
                stats.attachmentCount,
                BackupExporter.formatBytes(stats.zipSizeBytes));

        new AlertDialog.Builder(requireContext(), DialogThemes.LEA)
                .setTitle(R.string.export_done_title)
                .setMessage(summary)
                .setPositiveButton(R.string.export_share_button, (d, w) -> shareBackup(zipFile))
                .setNegativeButton(R.string.action_close, null)
                .show();
    }

    private void shareBackup(java.io.File zipFile) {
        try {
            android.net.Uri uri = androidx.core.content.FileProvider.getUriForFile(
                    requireContext(),
                    requireContext().getPackageName() + ".fileprovider",
                    zipFile);
            android.content.Intent intent = new android.content.Intent(
                    android.content.Intent.ACTION_SEND);
            intent.setType("application/zip");
            intent.putExtra(android.content.Intent.EXTRA_STREAM, uri);
            intent.putExtra(android.content.Intent.EXTRA_SUBJECT,
                    getString(R.string.export_share_subject, zipFile.getName()));
            intent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(android.content.Intent.createChooser(intent,
                    getString(R.string.export_share_chooser)));
        } catch (Exception e) {
            Toast.makeText(requireContext(),
                    getString(R.string.export_share_failed, e.getMessage()),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void showAbout() {
        new AlertDialog.Builder(requireContext(), DialogThemes.LEA)
                .setTitle(R.string.more_about)
                .setMessage(getString(R.string.about_text, BuildConfig.VERSION_NAME))
                .setPositiveButton(R.string.action_close, null)
                .show();
    }
}
