package sk.aetheriqa.noteiqa.ui.kids;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.TextView;
import android.view.animation.DecelerateInterpolator;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.util.DialogThemes;
import sk.aetheriqa.noteiqa.util.DateUtils;

/**
 * PaymentTicketActivity – v1.3.0 — platba ako tmavý "divadelný lístok".
 *
 *  - ťahni doprava / ZAPLATENÉ → zaplatené (pečiatka, potom zavrieť); pri zaplatenej späť na nezaplatené
 *  - ťahni doľava / KOPÍROVAŤ → suma, IBAN, VS, ŠS, správa do schránky
 *  - overflow: Poslať (obálka s QR, len ak QR ide zložiť), Upraviť, Zmazať
 *
 * KidPaymentContextDialog ostáva ako fallback (zostava textu pre kopírovanie je spoločná).
 */
public class PaymentTicketActivity extends AppCompatActivity {

    public static final String EXTRA_PAYMENT_ID = "paymentId";

    private static final long ANIM_MS = 240L;
    private static final float SWIPE_THRESHOLD = 0.3f;

    private KidRepository repo;
    private long paymentId;
    @Nullable private KidPayment payment;
    @Nullable private Kid kid;

    private View card;
    private MaterialToolbar toolbar;
    private MaterialButton btnPaid;
    private View btnRepeat;
    private boolean busy = false;

    public static Intent newIntent(Context ctx, long paymentId) {
        Intent i = new Intent(ctx, PaymentTicketActivity.class);
        i.putExtra(EXTRA_PAYMENT_ID, paymentId);
        return i;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_ticket);

        repo = KidRepository.getInstance(this);
        paymentId = getIntent().getLongExtra(EXTRA_PAYMENT_ID, 0L);

        toolbar = findViewById(R.id.ticket_toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
        toolbar.setOnMenuItemClickListener(this::onMenuItem);

        card = findViewById(R.id.ticket_include);
        limitCardWidth();
        installSwipe();

        btnPaid = findViewById(R.id.ticket_btn_paid);
        btnPaid.setOnClickListener(v -> togglePaid());
        findViewById(R.id.ticket_btn_copy).setOnClickListener(v -> copyAll());
        // v1.3.4 — Opakovať: nová platba predvyplnená z tejto (pôvodná ostane zaplatená)
        btnRepeat = findViewById(R.id.ticket_btn_repeat);
        btnRepeat.setOnClickListener(v -> {
            if (payment != null) {
                startActivity(KidPaymentEditorActivity.newRepeatIntent(this, payment.id));
            }
        });
        // v1.3.2 — Poslať je pri QR na karte (rovnaká cesta ako predtým v overflow)
        card.findViewById(R.id.ticket_send).setOnClickListener(v -> {
            if (payment != null) EnvelopeExporter.share(this, payment, kid);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        load(); // aj po návrate z editora
    }

    private void load() {
        new Thread(() -> {
            KidPayment p = repo.getPaymentSync(paymentId);
            Kid k = null;
            if (p != null) {
                for (Kid c : repo.getKidsSync()) if (c.id == p.kidIdOrZero()) { k = c; break; }
            }
            final Kid fk = k;
            // v1.3.3 — riadok „K udalosti“ pod menom dieťaťa
            final KidEvent ev = p != null && p.eventId != null ? repo.getEventSync(p.eventId) : null;
            runOnUiThread(() -> {
                if (isFinishing()) return;
                if (p == null) { finish(); return; } // zmazaná medzičasom
                payment = p;
                kid = fk;
                PaymentTicketBinder.bind(card, p, fk, ev, false,
                        PaymentTicketBinder.dp(this, 240));
                btnPaid.setText(p.completed ? R.string.ticket_btn_unpaid : R.string.ticket_btn_paid);
                btnRepeat.setVisibility(p.completed ? View.VISIBLE : View.GONE);
            });
        }, "TicketLoad").start();
    }

    /** Karta max 420 dp, centrovaná (na tabletoch / na šírku). */
    private void limitCardWidth() {
        int max = PaymentTicketBinder.dp(this, 420);
        int screen = getResources().getDisplayMetrics().widthPixels
                - PaymentTicketBinder.dp(this, 32);
        if (screen > max) {
            ViewGroup.LayoutParams lp = card.getLayoutParams();
            lp.width = max;
            card.setLayoutParams(lp);
        }
    }

    // ===== Gestá =====

    @SuppressLint("ClickableViewAccessibility")
    private void installSwipe() {
        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        card.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            boolean dragging;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (busy || payment == null) return false;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        dragging = false;
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (!dragging && Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy)) {
                            dragging = true;
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                        }
                        if (dragging) {
                            v.setTranslationX(dx);
                            v.setRotation(dx / v.getWidth() * 4f);
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: {
                        float dx = e.getRawX() - downX;
                        boolean commit = dragging && e.getActionMasked() == MotionEvent.ACTION_UP
                                && Math.abs(dx) > v.getWidth() * SWIPE_THRESHOLD;
                        springBack(null);
                        if (commit) {
                            if (dx > 0) togglePaid(); else copyAll();
                        }
                        dragging = false;
                        return true;
                    }
                    default:
                        return false;
                }
            }
        });
    }

    private void springBack(@Nullable Runnable end) {
        card.animate().translationX(0f).rotation(0f).setDuration(ANIM_MS)
                .setInterpolator(new DecelerateInterpolator())
                .setListener(new AnimatorListenerAdapter() {
                    @Override public void onAnimationEnd(Animator animation) {
                        card.animate().setListener(null);
                        if (end != null) end.run();
                    }
                })
                .start();
    }

    // ===== Akcie =====

    private void togglePaid() {
        KidPayment p = payment;
        if (p == null || busy) return;
        if (!p.completed) {
            busy = true;
            KidPaymentContextDialog.setCompletedWithToast(this, repo, p.id, true);
            showStampThenFinish();
        } else {
            // späť na nezaplatené — prekresli až po zápise do DB
            repo.setPaymentCompleted(p.id, false, next -> {
                Toast.makeText(this, R.string.kid_payment_marked_unpaid, Toast.LENGTH_SHORT).show();
                if (!isFinishing()) load();
            });
        }
    }

    private void showStampThenFinish() {
        View stamp = card.findViewById(R.id.ticket_stamp);
        stamp.setAlpha(0f);
        stamp.setScaleX(1.4f);
        stamp.setScaleY(1.4f);
        stamp.setVisibility(View.VISIBLE);
        stamp.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260L)
                .setInterpolator(new DecelerateInterpolator()).start();

        // v1.3.2 — pod pečiatkou "Ďalšia splatnosť …" pri opakovanej platbe;
        // dátum rovnako ako repository posúva ďalšiu inštanciu (Calendar.add)
        KidPayment p = payment;
        if (p != null && p.recurrence != KidPayment.RECURRENCE_NONE && p.dueDate > 0L
                && (p.recurrence != KidPayment.RECURRENCE_EXACT || p.exactDueDate > p.dueDate)) {
            TextView next = card.findViewById(R.id.ticket_next_due);
            long nextDue = KidRepository.nextDueDate(p);
            next.setText(getString(R.string.ticket_next_due, DateUtils.formatNumericDate(nextDue)));
            next.setAlpha(0f);
            next.setVisibility(View.VISIBLE);
            next.animate().alpha(1f).setStartDelay(160L).setDuration(240L).start();
        }
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (!isFinishing()) finish();
        }, 900L);
    }

    private void copyAll() {
        if (payment == null) return;
        if (KidPaymentContextDialog.copyAll(this, payment)) {
            Toast.makeText(this, R.string.kid_payment_copied, Toast.LENGTH_SHORT).show();
        }
    }

    private boolean onMenuItem(MenuItem item) {
        KidPayment p = payment;
        if (p == null) return false;
        int id = item.getItemId();
        if (id == R.id.ticket_action_edit) {
            startActivity(KidPaymentEditorActivity.newIntent(this, p.id, p.kidIdOrZero()));
            return true;
        }
        if (id == R.id.ticket_action_delete) {
            new AlertDialog.Builder(this, DialogThemes.LEA)
                    .setTitle(R.string.kid_delete_confirm_title)
                    .setMessage(R.string.kid_delete_confirm_message)
                    .setPositiveButton(R.string.action_yes, (d, w) -> {
                        repo.deletePayment(p.id);
                        Toast.makeText(this, R.string.kid_payment_deleted, Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .setNegativeButton(R.string.action_no, null)
                    .show();
            return true;
        }
        return false;
    }
}
