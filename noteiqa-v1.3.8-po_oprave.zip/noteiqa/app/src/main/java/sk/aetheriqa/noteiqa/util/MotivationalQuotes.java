package sk.aetheriqa.noteiqa.util;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import sk.aetheriqa.noteiqa.data.preferences.UserPreferences;

/**
 * MotivationalQuotes – parser pre .md súbor s číslovanými vetami a
 * 30-dňový rotation algoritmus.
 *
 * Formát parserovaný:
 *   1. Si ako šampanské — bublinkavá, drahá a rozveseľuješ každú párty.
 *   2. Tvoj úsmev je horúcejší než káva v pondelok ráno.
 *   ...
 *
 * Akceptujeme aj formáty:
 *   1) ...
 *   1: ...
 *
 * Riadky bez čísla sa preskočia.
 *
 * Storage cesta: /data/data/{pkg}/files/motivational_quotes.md
 */
public final class MotivationalQuotes {

    private static final String INTERNAL_FILENAME = "motivational_quotes.md";
    private static final String ASSET_DEFAULT_FILENAME = "default_quotes.md";
    private static final int NO_REPEAT_DAYS = 30;
    private static final Random RANDOM = new Random();

    /** Číslovaný riadok: voliteľný whitespace, číslo, ".") ":", potom medzera, potom text */
    private static final Pattern NUMBERED_LINE =
            Pattern.compile("^\\s*\\d+\\s*[\\.\\):]\\s*(.+?)\\s*$");

    private MotivationalQuotes() {}

    /**
     * Pri prvom volaní (alebo ak používateľ vymazal súbor) sa skopíruje default
     * MD z assets do internej zložky. Tým máme vždy "rozumný default" bez
     * toho, aby Marek musel po inštalácii nič ručne nahrávať.
     *
     * Volá sa idempotentne — ak je súbor už v internej zložke, nič nerobí.
     * Aj keď používateľ nahrá vlastný .md cez Nastavenia, ten sa zapíše na
     * tú istú cestu (INTERNAL_FILENAME) a default sa už ďalej nepoužije.
     */
    public static void ensureDefaultImported(Context ctx) {
        File target = new File(ctx.getFilesDir(), INTERNAL_FILENAME);
        if (target.exists() && target.length() > 0) return;

        try (java.io.InputStream in = ctx.getAssets().open(ASSET_DEFAULT_FILENAME);
             FileOutputStream out = new FileOutputStream(target)) {
            byte[] buffer = new byte[8 * 1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            out.flush();
        } catch (IOException e) {
            // Asset chýba alebo iná IO chyba — vrátime sa, pickQuote vráti null
            return;
        }

        UserPreferences.get(ctx).setQuotesFilePath(target.getAbsolutePath());
        // History sa NEČISTÍ — pri prvom volaní je aj tak prázdna; pri obnove
        // defaultu by čistenie zmazalo recent history aj keď používateľ
        // používal default už predtým.
    }

    /**
     * Skopíruje obsah z používateľom zvoleného Uri do internej zložky.
     * Vráti počet úspešne sparsovaných viet, alebo -1 pri chybe.
     */
    public static int importFromUri(Context ctx, Uri sourceUri) {
        File target = new File(ctx.getFilesDir(), INTERNAL_FILENAME);

        try (InputStream in = ctx.getContentResolver().openInputStream(sourceUri);
             FileOutputStream out = new FileOutputStream(target)) {
            if (in == null) return -1;
            byte[] buffer = new byte[8 * 1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            out.flush();
        } catch (IOException e) {
            return -1;
        }

        // Po importe sa rátanie histórie reštartuje (staré indexy by boli irelevantné)
        UserPreferences.get(ctx).clearQuoteHistory();
        UserPreferences.get(ctx).setQuotesFilePath(target.getAbsolutePath());

        List<String> quotes = parseFile(target);
        return quotes.size();
    }

    /** Existuje importovaný .md súbor a obsahuje aspoň 1 vetu? */
    public static boolean hasImportedQuotes(Context ctx) {
        String path = UserPreferences.get(ctx).getQuotesFilePath();
        if (TextUtils.isEmpty(path)) return false;
        File f = new File(path);
        return f.exists() && f.length() > 0;
    }

    /**
     * Vráti počet sparsovaných viet z aktuálne importovaného súboru.
     * Nullable = nie je nahraný, 0 = sparsované 0 (neplatný formát).
     */
    @Nullable
    public static Integer countQuotes(Context ctx) {
        String path = UserPreferences.get(ctx).getQuotesFilePath();
        if (TextUtils.isEmpty(path)) return null;
        File f = new File(path);
        if (!f.exists()) return null;
        return parseFile(f).size();
    }

    /**
     * Vráti náhodnú vetu, ktorá nebola zobrazená v posledných 30 dňoch.
     * Ak všetky boli – vráti najmenej nedávno použitú (LRU fallback).
     * Po výbere sa záznam zapíše do UserPreferences.quoteHistory.
     *
     * Vracia null ak nie je importovaný žiadny súbor alebo súbor neobsahuje vety.
     */
    @Nullable
    public static String pickQuote(Context ctx) {
        String path = UserPreferences.get(ctx).getQuotesFilePath();
        if (TextUtils.isEmpty(path)) return null;
        File f = new File(path);
        if (!f.exists()) return null;

        List<String> quotes = parseFile(f);
        if (quotes.isEmpty()) return null;

        UserPreferences prefs = UserPreferences.get(ctx);
        Set<Integer> recentlyShown = new HashSet<>(prefs.getRecentlyShownIndexes(NO_REPEAT_DAYS));

        // Kandidáti = indexy, ktoré nie sú v recentlyShown
        List<Integer> candidates = new ArrayList<>();
        for (int i = 0; i < quotes.size(); i++) {
            if (!recentlyShown.contains(i)) candidates.add(i);
        }

        int chosenIdx;
        if (!candidates.isEmpty()) {
            chosenIdx = candidates.get(RANDOM.nextInt(candidates.size()));
        } else {
            // Všetky vety boli použité v posledných 30 dňoch — fallback na LRU
            chosenIdx = pickLeastRecentlyUsed(prefs.getQuoteHistory(), quotes.size());
        }

        prefs.recordQuoteShown(chosenIdx);
        return quotes.get(chosenIdx);
    }

    private static int pickLeastRecentlyUsed(Map<Integer, Long> history, int totalCount) {
        int oldestIdx = 0;
        long oldestTs = Long.MAX_VALUE;
        for (int i = 0; i < totalCount; i++) {
            Long ts = history.get(i);
            long t = ts == null ? 0L : ts;
            if (t < oldestTs) {
                oldestTs = t;
                oldestIdx = i;
            }
        }
        return oldestIdx;
    }

    /**
     * Sparsuje súbor a vráti vety v poradí, v ktorom sa objavili. Index v
     * tomto liste = index v UserPreferences history.
     *
     * Pozor: ak sa súbor zmení (used file replaced), staré indexy v
     * history už nemusia odpovedať tým istým vetám — preto pri importe
     * voláme clearQuoteHistory().
     */
    @NonNull
    private static List<String> parseFile(File f) {
        List<String> out = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                Matcher m = NUMBERED_LINE.matcher(line);
                if (m.matches()) {
                    String text = m.group(1);
                    if (text != null && !text.isEmpty()) out.add(text);
                }
            }
        } catch (IOException e) {
            return Collections.emptyList();
        }
        return out;
    }
}
