package sk.aetheriqa.noteiqa.ui.chudnutie;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.WeightEntry;
import sk.aetheriqa.noteiqa.util.DateUtils;

/**
 * WeightHistoryAdapter – posledných N záznamov váženia.
 * Delta sa vypočíta voči predchádzajúcemu záznamu (chronologicky starší).
 */
public class WeightHistoryAdapter extends ListAdapter<WeightEntry, WeightHistoryAdapter.WeightVH> {

    public interface OnWeightLongClickListener {
        void onLongClick(WeightEntry entry);
    }

    private final OnWeightLongClickListener longClickListener;
    /** Cacheovaný zoznam zoradený od najnovšieho po najstarší (ako dostávame z DB). */
    private List<WeightEntry> sortedDesc;

    public WeightHistoryAdapter(OnWeightLongClickListener longClickListener) {
        super(DIFF);
        this.longClickListener = longClickListener;
    }

    @Override
    public void submitList(@androidx.annotation.Nullable List<WeightEntry> list) {
        this.sortedDesc = list;
        super.submitList(list);
    }

    @NonNull
    @Override
    public WeightVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_entry, parent, false);
        return new WeightVH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightVH h, int position) {
        WeightEntry e = getItem(position);
        Context ctx = h.itemView.getContext();

        h.date.setText(DateUtils.formatWeightTimestamp(e.measuredAt));
        h.kg.setText(String.format(Locale.getDefault(), "%.1f kg", e.kg)
                .replace('.', ','));

        // Mood flagy + voľný text z poznámky pod dátumom
        java.util.List<String> moodLabels =
                sk.aetheriqa.noteiqa.util.MoodFlags.activeLabels(ctx, e.moodFlags);
        StringBuilder moodLine = new StringBuilder();
        if (!moodLabels.isEmpty()) {
            moodLine.append(android.text.TextUtils.join(" · ", moodLabels));
        }
        if (!android.text.TextUtils.isEmpty(e.note)) {
            if (moodLine.length() > 0) moodLine.append(" · ");
            moodLine.append(e.note);
        }
        if (moodLine.length() == 0) {
            h.moods.setVisibility(View.GONE);
        } else {
            h.moods.setVisibility(View.VISIBLE);
            h.moods.setText(moodLine.toString());
        }

        // Delta voči predchádzajúcemu (starší = nasledujúci index v desc zozname)
        WeightEntry prev = (sortedDesc != null && position + 1 < sortedDesc.size())
                ? sortedDesc.get(position + 1) : null;

        if (prev == null) {
            h.delta.setText("");
            h.delta.setTextColor(ContextCompat.getColor(ctx, R.color.text_secondary));
        } else {
            double d = e.kg - prev.kg;
            String formatted;
            int color;
            if (Math.abs(d) < 0.05) {
                formatted = ctx.getString(R.string.weight_change_zero);
                color = R.color.text_secondary;
            } else if (d < 0) {
                formatted = ctx.getString(R.string.weight_change_neg, Math.abs(d));
                color = R.color.success;
            } else {
                formatted = ctx.getString(R.string.weight_change_pos, d);
                color = R.color.warning;
            }
            h.delta.setText(formatted.replace('.', ','));
            h.delta.setTextColor(ContextCompat.getColor(ctx, color));
        }

        h.itemView.setOnLongClickListener(v -> {
            if (longClickListener != null) longClickListener.onLongClick(e);
            return true;
        });
    }

    static class WeightVH extends RecyclerView.ViewHolder {
        final TextView date;
        final TextView moods;
        final TextView kg;
        final TextView delta;

        WeightVH(@NonNull View itemView) {
            super(itemView);
            date = itemView.findViewById(R.id.wh_date);
            moods = itemView.findViewById(R.id.wh_moods);
            kg = itemView.findViewById(R.id.wh_kg);
            delta = itemView.findViewById(R.id.wh_delta);
        }
    }

    private static final DiffUtil.ItemCallback<WeightEntry> DIFF =
            new DiffUtil.ItemCallback<WeightEntry>() {
                @Override
                public boolean areItemsTheSame(@NonNull WeightEntry a, @NonNull WeightEntry b) {
                    return a.id == b.id;
                }

                @Override
                public boolean areContentsTheSame(@NonNull WeightEntry a, @NonNull WeightEntry b) {
                    return a.kg == b.kg
                            && a.measuredAt == b.measuredAt
                            && a.moodFlags == b.moodFlags
                            && android.text.TextUtils.equals(a.note, b.note);
                }
            };
}
