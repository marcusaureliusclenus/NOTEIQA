package sk.aetheriqa.noteiqa.util;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import sk.aetheriqa.noteiqa.BuildConfig;
import sk.aetheriqa.noteiqa.data.db.AppDatabase;
import sk.aetheriqa.noteiqa.data.preferences.UserPreferences;

/**
 * BackupExporter – kompletný export všetkých dát aplikácie do jedného .zip
 * súboru, ktorý si používateľ môže poslať mailom, uložiť do Google Drive,
 * alebo skopírovať na PC.
 *
 * Obsah .zip archívu:
 *   data.json                  — všetky entity zo všetkých tabuliek
 *   photos/profile.<ext>       — profilové foto z Nastavení (ak nahrané)
 *   quotes/quotes.md           — používateľský .md s motivačnými vetami
 *   attachments/<filename>     — všetky obrázky v poznámkach
 *
 * data.json štruktúra:
 *   {
 *     "format_version": 1,
 *     "app_version": "0.5.3",
 *     "schema_version": 5,
 *     "exported_at": 1714766400000,
 *     "tasks": [...],
 *     "categories": [...],
 *     "subtasks": [...],
 *     "notes": [...],
 *     "checklist_items": [...],
 *     "tags": [...],
 *     "note_tags": [...],
 *     "reminders": [...],
 *     "weight_entries": [...],
 *     "weight_goals": [...],
 *     "templates": [...]
 *   }
 *
 * Beží na background threade — DB read + ZIP write trvajú stovky ms.
 */
public final class BackupExporter {

    public static final int FORMAT_VERSION = 1;
    /** v1.2.0 — drží sa v súlade s @Database(version) cez AppDatabase.VERSION. */
    public static final int SCHEMA_VERSION = AppDatabase.VERSION;

    public interface OnExportListener {
        void onSuccess(File zipFile, ExportStats stats);
        void onError(String message);
    }

    public static class ExportStats {
        public int taskCount;
        public int noteCount;
        public int weightCount;
        public int attachmentCount;
        public long zipSizeBytes;
    }

    private BackupExporter() {}

    /**
     * Spustí export v background threade. Callbacks sa volajú na main threade.
     */
    public static void exportAsync(Context ctx, OnExportListener listener) {
        Context appCtx = ctx.getApplicationContext();
        new Thread(() -> {
            Handler ui = new Handler(Looper.getMainLooper());
            try {
                ExportResult result = doExport(appCtx);
                ui.post(() -> listener.onSuccess(result.file, result.stats));
            } catch (Exception e) {
                String msg = e.getMessage() == null
                        ? e.getClass().getSimpleName()
                        : e.getMessage();
                ui.post(() -> listener.onError(msg));
            }
        }, "BackupExporter").start();
    }

    private static class ExportResult {
        File file;
        ExportStats stats;
    }

    /**
     * v1.2.0 — synchrónny export (bez UI callbackov). Používa ho BackupImporter
     * na bezpečnostnú zálohu tesne pred prepísaním dát. Nevolať z UI threadu.
     */
    public static File exportSync(Context ctx) throws IOException, JSONException {
        return doExport(ctx.getApplicationContext()).file;
    }

    private static ExportResult doExport(Context ctx) throws IOException, JSONException {
        AppDatabase db = AppDatabase.getInstance(ctx);

        // 1) Build JSON payload
        JSONObject root = new JSONObject();
        root.put("format_version", FORMAT_VERSION);
        root.put("app_version", BuildConfig.VERSION_NAME);
        root.put("schema_version", SCHEMA_VERSION);
        root.put("exported_at", System.currentTimeMillis());

        ExportStats stats = new ExportStats();

        List<?> tasks = db.taskDao().getAllSync();
        stats.taskCount = tasks.size();
        root.put("tasks", entitiesToJsonArray(tasks));

        root.put("categories", entitiesToJsonArray(db.taskCategoryDao().getAll()));
        root.put("subtasks", entitiesToJsonArray(db.subtaskDao().getAllSync()));

        // v1.1.0 — Deti modul
        root.put("kids", entitiesToJsonArray(db.kidDao().getAllSync()));
        root.put("kid_payments", entitiesToJsonArray(db.kidPaymentDao().getAllSync()));
        root.put("kid_events", entitiesToJsonArray(db.kidEventDao().getAllSync()));

        List<?> notes = db.noteDao().getAllSync();
        stats.noteCount = notes.size();
        root.put("notes", entitiesToJsonArray(notes));

        root.put("checklist_items", entitiesToJsonArray(db.checklistDao().getAllSync()));
        root.put("tags", entitiesToJsonArray(db.tagDao().getAllSync()));
        root.put("note_tags", entitiesToJsonArray(db.tagDao().getAllNoteTagsSync()));
        root.put("reminders", entitiesToJsonArray(db.reminderDao().getAllSync()));

        List<?> weights = db.weightDao().getAllSync();
        stats.weightCount = weights.size();
        root.put("weight_entries", entitiesToJsonArray(weights));

        root.put("weight_goals", entitiesToJsonArray(db.weightDao().getAllGoalsSync()));
        root.put("templates", entitiesToJsonArray(db.templateDao().getAllSync()));

        // Tiež zálohujeme používateľské preferencie (meno, foto cesta, atď.)
        UserPreferences prefs = UserPreferences.get(ctx);
        JSONObject prefsJson = new JSONObject();
        prefsJson.put("displayName", prefs.getDisplayName());
        prefsJson.put("hasPhoto", prefs.getPhotoPath() != null);
        prefsJson.put("hasCustomQuotes", prefs.getQuotesFilePath() != null);
        root.put("preferences", prefsJson);

        String jsonText = root.toString(2); // pretty-printed pre čitateľnosť

        // 2) Vyrob názov ZIP a zapíš do cache (FileProvider má cache_path)
        File backupDir = new File(ctx.getCacheDir(), "backup");
        if (!backupDir.exists() && !backupDir.mkdirs()) {
            throw new IOException("Nepodarilo sa vytvoriť backup zložku");
        }
        // Cleanup starých záloh — necháme len posledné 3
        cleanupOldBackups(backupDir, 3);

        String stamp = new SimpleDateFormat("yyyy-MM-dd_HHmm",
                new Locale("sk", "SK")).format(new Date());
        File zipFile = new File(backupDir, "noteiqa-backup-" + stamp + ".zip");

        try (ZipOutputStream zos = new ZipOutputStream(
                new FileOutputStream(zipFile))) {

            // 2.1) data.json
            zos.putNextEntry(new ZipEntry("data.json"));
            zos.write(jsonText.getBytes("UTF-8"));
            zos.closeEntry();

            // 2.2) Profilové foto
            String photoPath = prefs.getPhotoPath();
            if (photoPath != null) {
                File photo = new File(photoPath);
                if (photo.exists()) {
                    String ext = extensionOf(photo.getName());
                    addFileToZip(zos, photo, "photos/profile" + ext);
                }
            }

            // 2.3) Motivačné vety .md
            String quotesPath = prefs.getQuotesFilePath();
            if (quotesPath != null) {
                File quotes = new File(quotesPath);
                if (quotes.exists()) {
                    addFileToZip(zos, quotes, "quotes/quotes.md");
                }
            }

            // 2.4) Note attachments — všetky obrázky pripojené k poznámkam
            File attachmentsDir = new File(ctx.getFilesDir(), "note_attachments");
            if (attachmentsDir.isDirectory()) {
                File[] files = attachmentsDir.listFiles();
                if (files != null) {
                    for (File f : files) {
                        if (f.isFile()) {
                            addFileToZip(zos, f, "attachments/" + f.getName());
                            stats.attachmentCount++;
                        }
                    }
                }
            }

            zos.flush();
        }

        stats.zipSizeBytes = zipFile.length();

        ExportResult res = new ExportResult();
        res.file = zipFile;
        res.stats = stats;
        return res;
    }

    /**
     * Cez reflexiu serializuje POJO entity (Room @Entity) do JSON.
     * Berie len public, nie static, nie transient polia.
     */
    @NonNull
    private static JSONArray entitiesToJsonArray(List<?> entities) throws JSONException {
        JSONArray arr = new JSONArray();
        if (entities == null) return arr;

        for (Object e : entities) {
            if (e == null) continue;
            JSONObject obj = entityToJson(e);
            arr.put(obj);
        }
        return arr;
    }

    @NonNull
    private static JSONObject entityToJson(Object e) throws JSONException {
        JSONObject out = new JSONObject();
        Class<?> klass = e.getClass();
        for (Field f : klass.getDeclaredFields()) {
            int mods = f.getModifiers();
            if (Modifier.isStatic(mods)) continue;
            if (Modifier.isTransient(mods)) continue;
            if (!Modifier.isPublic(mods)) continue;

            try {
                Object value = f.get(e);
                if (value == null) {
                    out.put(f.getName(), JSONObject.NULL);
                } else {
                    out.put(f.getName(), value);
                }
            } catch (IllegalAccessException ignored) {
                // skip
            }
        }
        return out;
    }

    private static void addFileToZip(ZipOutputStream zos, File source, String entryName)
            throws IOException {
        if (!source.exists() || !source.isFile()) return;
        zos.putNextEntry(new ZipEntry(entryName));
        try (FileInputStream fis = new FileInputStream(source)) {
            byte[] buf = new byte[8 * 1024];
            int read;
            while ((read = fis.read(buf)) != -1) {
                zos.write(buf, 0, read);
            }
        }
        zos.closeEntry();
    }

    private static String extensionOf(String fileName) {
        int dot = fileName.lastIndexOf('.');
        if (dot < 0) return "";
        return fileName.substring(dot);
    }

    /** Necháme len {@code keep} najnovších záloh, ostatné zmažeme. */
    private static void cleanupOldBackups(File dir, int keep) {
        File[] files = dir.listFiles((d, name) ->
                name.startsWith("noteiqa-backup-") && name.endsWith(".zip"));
        if (files == null || files.length <= keep) return;
        // Sort descending by lastModified
        java.util.Arrays.sort(files, (a, b) ->
                Long.compare(b.lastModified(), a.lastModified()));
        for (int i = keep; i < files.length; i++) {
            //noinspection ResultOfMethodCallIgnored
            files[i].delete();
        }
    }

    @Nullable
    public static String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(Locale.getDefault(),
                "%.1f kB", bytes / 1024.0);
        return String.format(Locale.getDefault(), "%.2f MB",
                bytes / (1024.0 * 1024.0));
    }
}
