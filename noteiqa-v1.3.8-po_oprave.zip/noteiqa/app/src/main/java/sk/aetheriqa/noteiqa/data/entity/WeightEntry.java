package sk.aetheriqa.noteiqa.data.entity;

import androidx.annotation.Nullable;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/**
 * WeightEntry – jeden záznam váženia v module Chudnutie.
 *
 * Auto-vyplnené pri zázname (ak používateľ explicitne nezadá iný čas):
 *  - measuredAt (timestamp)
 *  - dayOfWeek (po/ut/st/št/pi/so/ne) – odvodené z measuredAt cez DateUtils
 *
 * Note pole je voľný text (napr. "menzes !", "po tréningu", "ráno nalačno") –
 * tak ako to máš v poznámke "Vaha" v starej appke.
 *
 * Indexy na measuredAt a dayOfWeek pre rýchle dotazy pri grafe (range queries
 * 7d / 30d / 90d / 1Y).
 */
@Entity(
    tableName = "weight_entries",
    indices = {@Index("measuredAt"), @Index("dayOfWeek")}
)
public class WeightEntry {

    @PrimaryKey(autoGenerate = true)
    public long id;

    /** Hmotnosť v kilogramoch (s presnosťou na 0.1 kg). */
    public double kg;

    /** Unix epoch millis – kedy bolo váženie. */
    public long measuredAt;

    /**
     * Deň v týždni: 1=Po, 2=Ut, 3=St, 4=Št, 5=Pi, 6=So, 7=Ne (ISO).
     * Cachované pre rýchle filtrovanie a štatistiky.
     */
    public int dayOfWeek;

    @Nullable
    public String note;

    /**
     * Bitmask 7 mood flagov pre Marekovu manželku:
     *  bit 0 (1)   = menzes
     *  bit 1 (2)   = po cvičení
     *  bit 2 (4)   = málo spánku
     *  bit 3 (8)   = včera prejedená
     *  bit 4 (16)  = včera alkohol
     *  bit 5 (32)  = zapečená
     *  bit 6 (64)  = málo vody
     *
     * 0 = žiadne flagy aktívne.
     */
    public int moodFlags = 0;

    /** Pre prípad, že chceme rozlišovať ručný vs hlasový vstup. */
    @Nullable
    public String source;

    public long createdAt;

    public WeightEntry() {}

    public WeightEntry(double kg, long measuredAt, int dayOfWeek, @Nullable String note) {
        this.kg = kg;
        this.measuredAt = measuredAt;
        this.dayOfWeek = dayOfWeek;
        this.note = note;
        this.createdAt = System.currentTimeMillis();
    }
}
