package sk.aetheriqa.noteiqa.ui.notes;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Note;
import sk.aetheriqa.noteiqa.data.repository.NoteRepository;
import sk.aetheriqa.noteiqa.util.DateUtils;

/**
 * ArchivedNotesActivity – read-only zoznam archivovaných poznámok a zoznamov.
 * Klik → akcia "obnoviť" cez dialóg.
 */
public class ArchivedNotesActivity extends AppCompatActivity {

    private NoteRepository repo;
    private ArchivedNotesAdapter adapter;
    private View emptyState;
    private RecyclerView list;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_archived_notes);

        MaterialToolbar tb = findViewById(R.id.archive_notes_toolbar);
        tb.setNavigationOnClickListener(v -> finish());
        tb.inflateMenu(R.menu.archive_menu);
        tb.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.action_clear_archive) {
                confirmAndClearArchive();
                return true;
            }
            return false;
        });

        repo = NoteRepository.getInstance(getApplicationContext());

        list = findViewById(R.id.archive_notes_list);
        emptyState = findViewById(R.id.archive_notes_empty_state);

        adapter = new ArchivedNotesAdapter(this::confirmRestore);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);

        repo.observeArchived().observe(this, notes -> {
            adapter.submitList(notes);
            boolean empty = notes == null || notes.isEmpty();
            emptyState.setVisibility(empty ? View.VISIBLE : View.GONE);
            list.setVisibility(empty ? View.GONE : View.VISIBLE);
        });
    }

    private void confirmRestore(Note note) {
        new AlertDialog.Builder(this,
                sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(TextUtils.isEmpty(note.title) ? "—" : note.title)
                .setMessage("Obnoviť túto poznámku do hlavného zoznamu?")
                .setPositiveButton(R.string.action_yes, (d, w) -> repo.unarchive(note.id))
                .setNegativeButton(R.string.action_no, null)
                .show();
    }

    /**
     * v0.5.4 — toolbar overflow "Vymazať archív".
     * Zobrazí Áno/Nie potvrdenie a po potvrdení permanentne zmaže
     * všetky archivované poznámky.
     */
    private void confirmAndClearArchive() {
        new androidx.appcompat.app.AlertDialog.Builder(this,
                sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(R.string.archive_clear_confirm_title)
                .setMessage(R.string.archive_clear_notes_message)
                .setPositiveButton(R.string.action_yes, (d, w) ->
                        repo.deleteAllArchived(count -> runOnUiThread(() ->
                                android.widget.Toast.makeText(this,
                                        getString(R.string.archive_clear_done, count),
                                        android.widget.Toast.LENGTH_SHORT).show())))
                .setNegativeButton(R.string.action_no, null)
                .show();
    }

    public static Intent newIntent(Context ctx) {
        return new Intent(ctx, ArchivedNotesActivity.class);
    }

    static class ArchivedNotesAdapter extends ListAdapter<Note, ArchivedNotesAdapter.VH> {

        interface OnClick { void onClick(Note n); }
        private final OnClick clickListener;

        ArchivedNotesAdapter(OnClick listener) {
            super(DIFF);
            this.clickListener = listener;
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_archived_task, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            Note n = getItem(position);
            h.title.setText(TextUtils.isEmpty(n.title) ? "—" : n.title);
            h.meta.setText("archivované " + DateUtils.formatLongDate(n.updatedAt));
            h.itemView.setOnClickListener(v -> clickListener.onClick(n));
        }

        static class VH extends RecyclerView.ViewHolder {
            final TextView title, meta;
            VH(View v) {
                super(v);
                title = v.findViewById(R.id.archived_title);
                meta = v.findViewById(R.id.archived_meta);
            }
        }

        private static final DiffUtil.ItemCallback<Note> DIFF = new DiffUtil.ItemCallback<Note>() {
            @Override public boolean areItemsTheSame(@NonNull Note a, @NonNull Note b) { return a.id == b.id; }
            @Override public boolean areContentsTheSame(@NonNull Note a, @NonNull Note b) {
                return a.updatedAt == b.updatedAt && TextUtils.equals(a.title, b.title);
            }
        };
    }
}
