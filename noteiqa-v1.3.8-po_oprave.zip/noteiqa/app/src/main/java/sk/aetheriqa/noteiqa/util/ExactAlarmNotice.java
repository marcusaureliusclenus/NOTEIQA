package sk.aetheriqa.noteiqa.util;

import android.content.Context;
import android.widget.Toast;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.notification.ReminderScheduler;

/**
 * ExactAlarmNotice – v1.2.0 — ak sú presné alarmy (Android 12+) vypnuté,
 * pri uložení položky s pripomienkou raz za beh appky upozorní, že môže
 * prísť neskoro. Toast (nie dialóg), lebo editor sa po uložení hneď zatvára.
 * Zapnúť sa dajú v Nastavenia → Presné pripomienky.
 */
public final class ExactAlarmNotice {

    private static volatile boolean shownThisProcess = false;

    private ExactAlarmNotice() {}

    public static void maybeWarn(Context ctx, long triggerAt) {
        if (shownThisProcess) return;
        if (triggerAt <= System.currentTimeMillis()) return;
        if (!ReminderScheduler.needsExactAlarmPermission(ctx)) return;
        shownThisProcess = true;
        Toast.makeText(ctx.getApplicationContext(), R.string.exact_alarms_late_warning,
                Toast.LENGTH_LONG).show();
    }
}
