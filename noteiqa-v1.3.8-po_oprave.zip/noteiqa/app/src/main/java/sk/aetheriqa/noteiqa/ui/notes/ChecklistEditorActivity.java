package sk.aetheriqa.noteiqa.ui.notes;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;

import com.google.android.flexbox.FlexboxLayout;
import com.google.android.material.appbar.MaterialToolbar;

import java.util.ArrayList;
import java.util.List;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.ChecklistItem;
import sk.aetheriqa.noteiqa.data.entity.Note;
import sk.aetheriqa.noteiqa.data.repository.NoteRepository;

/**
 * ChecklistEditorActivity – editor pre TYPE_CHECKLIST poznámky (Zoznam).
 *
 *  - Zlatý serif názov
 *  - Dynamický zoznam položiek s checkbox + edit text + trash
 *  - Pri checked sa text preškrtne a stmavne
 *  - Pridanie cez "Pridať položku" + tlačidlo (+)
 *  - Pill buttons dole: Archivovať, Zdieľať, Vymazať
 *
 * Persistencia: pri zmene checkboxu sa item okamžite ukladá cez
 * repo.toggleChecklistItem. Pri save (back/menu) sa všetky položky
 * synchronizujú cez repo.saveChecklistItems (DELETE+INSERT pattern).
 */
public class ChecklistEditorActivity extends AppCompatActivity {

    public static final String EXTRA_NOTE_ID = "noteId";
    private static final long NEW_NOTE_ID = 0L;

    private NoteRepository repo;
    private long noteId = NEW_NOTE_ID;
    private Note editedNote;
    private boolean fieldsInitialized = false;

    private EditText editTitle;
    private EditText newItemEdit;
    private MaterialToolbar toolbar;
    private LinearLayout itemsContainer;
    private FlexboxLayout actionsLayout;

    /** Lokálny working set položiek. Persists pri save / back. */
    private final List<ChecklistItem> workingItems = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checklist_editor);

        repo = NoteRepository.getInstance(getApplicationContext());

        editTitle = findViewById(R.id.checklist_title);
        newItemEdit = findViewById(R.id.checklist_new_item);
        itemsContainer = findViewById(R.id.checklist_items_container);
        actionsLayout = findViewById(R.id.checklist_actions);

        MaterialToolbar tb = findViewById(R.id.checklist_toolbar);
        tb.setNavigationOnClickListener(v -> handleBack());
        toolbar = tb;
        tb.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.action_save) {
                saveChecklist();
                finish();
                return true;
            }
            if (item.getItemId() == R.id.action_pin) { togglePin(); return true; }
            if (item.getItemId() == R.id.action_save_template) { saveAsTemplate(); return true; }
            return false;
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                handleBack();
            }
        });

        findViewById(R.id.checklist_add_button).setOnClickListener(v -> addNewItem());

        editedNote = new Note();
        editedNote.type = Note.TYPE_CHECKLIST;

        noteId = getIntent().getLongExtra(EXTRA_NOTE_ID, NEW_NOTE_ID);
        if (noteId != NEW_NOTE_ID) {
            // Načítaj note + items
            repo.observeById(noteId).observe(this, new Observer<Note>() {
                @Override
                public void onChanged(Note n) {
                    if (n != null && !fieldsInitialized) {
                        editedNote = n;
                        editTitle.setText(n.title == null ? "" : n.title);
                        loadChecklistItems();
                        refreshPinTitle();
                        fieldsInitialized = true;
                    }
                }
            });
        } else {
            fieldsInitialized = true;
        }

        buildActionPills();
    }

    private void loadChecklistItems() {
        // Načítame raz na background a zobrazíme – ďalšie zmeny sú lokálne v workingItems
        new Thread(() -> {
            List<ChecklistItem> dbItems = repo.getChecklistItemsSync(noteId);
            runOnUiThread(() -> {
                workingItems.clear();
                if (dbItems != null) workingItems.addAll(dbItems);
                renderItems();
            });
        }).start();
    }

    private void buildActionPills() {
        actionsLayout.removeAllViews();
        addPill(R.string.checklist_action_archive, v -> confirmArchive());
        addPill(R.string.notes_action_share, v -> shareChecklist());
        addPill(R.string.task_action_remove, v -> confirmDelete());
    }

    private void addPill(int textRes, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(textRes);
        b.setAllCaps(false);
        b.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_lea_outlined_pill));
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(13f);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(18), dp(8), dp(18), dp(8));
        b.setOnClickListener(click);

        FlexboxLayout.LayoutParams lp = new FlexboxLayout.LayoutParams(
                FlexboxLayout.LayoutParams.WRAP_CONTENT,
                FlexboxLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), dp(8), dp(4));
        b.setLayoutParams(lp);

        actionsLayout.addView(b);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    // ===== Items =====

    private void renderItems() {
        itemsContainer.removeAllViews();
        LayoutInflater inf = LayoutInflater.from(this);
        for (int i = 0; i < workingItems.size(); i++) {
            final int idx = i;
            ChecklistItem item = workingItems.get(i);
            View row = inf.inflate(R.layout.item_checklist_edit_row, itemsContainer, false);

            CheckBox cb = row.findViewById(R.id.checklist_check);
            EditText text = row.findViewById(R.id.checklist_text);
            ImageView trash = row.findViewById(R.id.checklist_remove);

            cb.setOnCheckedChangeListener(null);
            cb.setChecked(item.checked);
            text.setText(item.text);
            applyCheckedStyle(text, item.checked);

            cb.setOnCheckedChangeListener((v, checked) -> {
                workingItems.get(idx).checked = checked;
                applyCheckedStyle(text, checked);
            });

            text.addTextChangedListener(new SimpleTextWatcher() {
                @Override
                public void afterChanged(String s) {
                    workingItems.get(idx).text = s;
                }
            });

            trash.setOnClickListener(v -> {
                workingItems.remove(idx);
                renderItems();
            });

            itemsContainer.addView(row);
        }
    }

    private void applyCheckedStyle(TextView text, boolean checked) {
        if (checked) {
            text.setPaintFlags(text.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            text.setAlpha(0.55f);
        } else {
            text.setPaintFlags(text.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
            text.setAlpha(1f);
        }
    }

    private void addNewItem() {
        String t = newItemEdit.getText().toString().trim();
        if (TextUtils.isEmpty(t)) return;
        ChecklistItem item = new ChecklistItem();
        item.text = t;
        item.checked = false;
        workingItems.add(item);
        newItemEdit.setText("");
        renderItems();
    }

    // ===== Save / Back =====

    private void handleBack() {
        // Ukladaj iba ak má názov alebo nejaké položky
        String t = editTitle.getText().toString().trim();
        boolean hasContent = !TextUtils.isEmpty(t) || !workingItems.isEmpty();
        if (hasContent) saveChecklist();
        finish();
    }

    private void saveChecklist() {
        editedNote.title = editTitle.getText().toString().trim();
        editedNote.type = Note.TYPE_CHECKLIST;
        editedNote.body = null; // Pre checklist body nepoužívame

        repo.save(editedNote, savedId -> {
            // Po uložení note vieme ID — ulož items
            // Filter prázdne riadky
            List<ChecklistItem> filtered = new ArrayList<>();
            for (ChecklistItem it : workingItems) {
                if (!TextUtils.isEmpty(it.text)) filtered.add(it);
            }
            repo.saveChecklistItems(savedId, filtered);
        });
    }

    // ===== v1.3.4 — Pripnúť / Uložiť ako šablónu =====

    private void togglePin() {
        editedNote.pinned = !editedNote.pinned;
        if (editedNote.id > 0L) repo.setPinned(editedNote.id, editedNote.pinned);
        refreshPinTitle();
        Toast.makeText(this, editedNote.pinned ? R.string.note_pinned_toast : R.string.note_unpinned_toast,
                Toast.LENGTH_SHORT).show();
    }

    private void refreshPinTitle() {
        android.view.MenuItem pin = toolbar.getMenu().findItem(R.id.action_pin);
        if (pin != null) pin.setTitle(editedNote.pinned ? R.string.notes_action_unpin : R.string.notes_action_pin);
    }

    /** Šablóna je text: názov + položky po riadkoch (checklist ako text položiek). */
    private void saveAsTemplate() {
        String t = editTitle.getText().toString().trim();
        StringBuilder body = new StringBuilder();
        for (ChecklistItem it : workingItems) {
            if (TextUtils.isEmpty(it.text)) continue;
            if (body.length() > 0) body.append('\n');
            body.append(it.text.trim());
        }
        if (TextUtils.isEmpty(t) && body.length() == 0) {
            Toast.makeText(this, R.string.note_template_empty, Toast.LENGTH_SHORT).show();
            return;
        }
        String name = !TextUtils.isEmpty(t) ? t : getString(R.string.note_template_default_name);
        repo.saveAsTemplate(name, t.isEmpty() ? null : t, body.length() == 0 ? null : body.toString(), () ->
                Toast.makeText(this, R.string.note_template_saved, Toast.LENGTH_SHORT).show());
    }

    // ===== Actions =====

    private void confirmArchive() {
        new AlertDialog.Builder(this,
                sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(R.string.notes_archive_confirm_title)
                .setMessage(R.string.notes_archive_confirm_msg)
                .setPositiveButton(R.string.action_yes, (d, w) -> {
                    if (noteId != NEW_NOTE_ID) {
                        saveChecklist();
                        repo.archive(noteId);
                        Toast.makeText(this, R.string.notes_archived_toast, Toast.LENGTH_SHORT).show();
                    }
                    finish();
                })
                .setNegativeButton(R.string.action_no, null)
                .show();
    }

    private void shareChecklist() {
        StringBuilder sb = new StringBuilder();
        String t = editTitle.getText().toString().trim();
        if (!t.isEmpty()) sb.append(t).append("\n\n");
        for (ChecklistItem it : workingItems) {
            if (TextUtils.isEmpty(it.text)) continue;
            sb.append(it.checked ? "[x] " : "[ ] ").append(it.text).append('\n');
        }
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, sb.toString().trim());
        if (!t.isEmpty()) send.putExtra(Intent.EXTRA_SUBJECT, t);
        startActivity(Intent.createChooser(send, getString(R.string.notes_action_share)));
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this,
                sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(R.string.notes_delete_confirm_title)
                .setMessage(R.string.notes_delete_confirm_msg)
                .setPositiveButton(R.string.action_yes, (d, w) -> {
                    if (noteId != NEW_NOTE_ID) {
                        repo.trash(noteId);
                        Toast.makeText(this, R.string.notes_deleted_toast, Toast.LENGTH_SHORT).show();
                    }
                    finish();
                })
                .setNegativeButton(R.string.action_no, null)
                .show();
    }

    public static Intent newIntent(Context ctx, long noteId) {
        Intent i = new Intent(ctx, ChecklistEditorActivity.class);
        if (noteId != NEW_NOTE_ID) i.putExtra(EXTRA_NOTE_ID, noteId);
        return i;
    }

    /** Lightweight TextWatcher pre EditText. */
    private static abstract class SimpleTextWatcher implements android.text.TextWatcher {
        @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
        @Override public void afterTextChanged(android.text.Editable s) { afterChanged(s.toString()); }
        public abstract void afterChanged(String s);
    }
}
