package sk.aetheriqa.noteiqa.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * PaperDraftParser – v1.3.0 — "Lístok z fotky": z textu, ktorý vrátilo OCR,
 * navrhne platbu alebo udalosť. Pravidlá, nič sa neukladá bez potvrdenia.
 *
 *  - IBAN: SK + 22 číslic (medzery povolené), cyrilské dvojníky (С, К, О…) a O/I v číslach
 *    sa opravia; IBAN sa overí kontrolným súčtom mod 97 (ibanValid)
 *  - suma: "25,00 €", "25.00 EUR", "€ 25,00"; prednosť má suma pri "suma / k úhrade / spolu"
 *  - VS / ŠS: "VS", "variabilný symbol", "ŠS", "špecifický symbol" + do 10 číslic
 *  - dátum: d.M.yyyy, d. M. yyyy, d.M. (prednosť pri slove "splatnosť")
 *  - čas: HH:mm
 *  - dieťa podľa mena v texte
 *  - IBAN alebo suma → platba, inak udalosť
 *  - názov: prvý zmysluplný riadok, ktorý nie je IBAN, suma ani symbol (max 80)
 *
 * Čistá Java — testuje PaperDraftParserTest.
 */
public final class PaperDraftParser {

    public static final class Result {
        public String iban;
        public boolean ibanValid;
        public BigDecimal amount;
        public String variableSymbol;
        public String specificSymbol;
        public long dayStart = -1L;
        public int minutes = -1;
        public long kidId = -1L;
        public String title;
        /** true = IBAN alebo suma → návrh platby; inak udalosť. */
        public boolean payment;
        /** OCR nenašlo žiadny text. */
        public boolean empty;
    }

    private static final Pattern P_IBAN_START = Pattern.compile("SK\\s?\\d");
    private static final String AMOUNT_NUM = "(\\d{1,3}(?:[ .]\\d{3})+|\\d+)[.,](\\d{2})";
    private static final Pattern P_AMOUNT_AFTER = Pattern.compile(AMOUNT_NUM + "\\s*(?:€|EUR\\b)",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern P_AMOUNT_BEFORE = Pattern.compile("(?:€|EUR)\\s*" + AMOUNT_NUM,
            Pattern.CASE_INSENSITIVE);
    private static final Pattern P_VS = Pattern.compile(
            "(?:\\bV\\.?\\s?S\\.?|variabiln\\w*\\s+symbol\\w*)\\s*[:.\\-]?\\s*(\\d{1,10})\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern P_SS = Pattern.compile(
            "(?:\\bS\\.?\\s?S\\.?|specifick\\w*\\s+symbol\\w*)\\s*[:.\\-]?\\s*(\\d{1,10})\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern P_DATE_FULL = Pattern.compile(
            "\\b(\\d{1,2})\\.\\s?(\\d{1,2})\\.\\s?(\\d{4})\\b");
    private static final Pattern P_DATE_SHORT = Pattern.compile(
            "\\b(\\d{1,2})\\.\\s?(\\d{1,2})\\.(?!\\s?\\d)");
    private static final Pattern P_TIME = Pattern.compile("\\b([01]?\\d|2[0-3]):([0-5]\\d)\\b");

    private PaperDraftParser() {}

    public static Result parse(String ocrText, List<VoiceDraftParser.KidRef> kids, Calendar now) {
        Result r = new Result();
        String raw = ocrText == null ? "" : ocrText;
        if (raw.trim().isEmpty()) {
            r.empty = true;
            return r;
        }
        String latin = fixCyrillic(raw);
        // Diakritika preč len pre kľúčové slová; čísla a riadky ostávajú
        String plain = DiacriticsUtils.stripDiacritics(latin);
        if (plain == null) plain = latin;

        parseIban(plain.toUpperCase(Locale.ROOT), r);
        r.amount = parseAmount(plain);
        Matcher m = P_VS.matcher(plain);
        if (m.find()) r.variableSymbol = m.group(1);
        m = P_SS.matcher(plain);
        if (m.find()) r.specificSymbol = m.group(1);
        parseDate(plain, now, r);
        m = P_TIME.matcher(plain);
        if (m.find()) r.minutes = Integer.parseInt(m.group(1)) * 60 + Integer.parseInt(m.group(2));
        r.kidId = findKid(plain, kids);
        r.title = pickTitle(latin, r);
        r.payment = r.iban != null || r.amount != null;
        return r;
    }

    // ===== IBAN =====

    private static void parseIban(String upper, Result r) {
        Matcher m = P_IBAN_START.matcher(upper);
        while (m.find()) {
            StringBuilder digits = new StringBuilder();
            int i = m.start() + 2;
            // 22 číslic po "SK" (2 kontrolné + 20), medzery a OCR zámeny O→0, I/L/|→1
            while (i < upper.length() && digits.length() < 22) {
                char c = upper.charAt(i);
                if (Character.isDigit(c)) digits.append(c);
                else if (c == 'O') digits.append('0');
                else if (c == 'I' || c == 'L' || c == '|') digits.append('1');
                else if (c != ' ') break;
                i++;
            }
            if (digits.length() == 22) {
                String iban = "SK" + digits;
                r.iban = iban;
                r.ibanValid = isValidIban(iban);
                if (r.ibanValid) return; // prvý platný vyhráva
            }
        }
    }

    /** ISO 13616 mod 97. */
    static boolean isValidIban(String iban) {
        if (iban == null || iban.length() < 15) return false;
        String rearranged = iban.substring(4) + iban.substring(0, 4);
        StringBuilder num = new StringBuilder();
        for (char c : rearranged.toCharArray()) {
            if (Character.isDigit(c)) num.append(c);
            else if (c >= 'A' && c <= 'Z') num.append(c - 'A' + 10);
            else return false;
        }
        return new BigInteger(num.toString()).mod(BigInteger.valueOf(97)).intValue() == 1;
    }

    /** OCR občas vráti cyrilské dvojníky latinských písmen — nahradíme ich. */
    static String fixCyrillic(String s) {
        String from = "АВЕКМНОРСТХУаеорсухк";
        String to = "ABEKMHOPCTXYaeopcyxk";
        StringBuilder sb = new StringBuilder(s.length());
        for (char c : s.toCharArray()) {
            int idx = from.indexOf(c);
            sb.append(idx >= 0 ? to.charAt(idx) : c);
        }
        return sb.toString();
    }

    // ===== Suma / dátum =====

    private static BigDecimal parseAmount(String plain) {
        BigDecimal first = null;
        String lower = plain.toLowerCase(Locale.ROOT);
        for (Pattern p : new Pattern[]{P_AMOUNT_AFTER, P_AMOUNT_BEFORE}) {
            Matcher m = p.matcher(plain);
            while (m.find()) {
                BigDecimal v = toAmount(m.group(1), m.group(2));
                if (v == null) continue;
                int from = Math.max(0, m.start() - 30);
                String before = lower.substring(from, m.start());
                if (before.contains("suma") || before.contains("k uhrade") || before.contains("spolu")
                        || before.contains("celkom")) {
                    return v;
                }
                if (first == null) first = v;
            }
        }
        return first;
    }

    private static BigDecimal toAmount(String whole, String cents) {
        try {
            return new BigDecimal(whole.replace(" ", "").replace(".", "") + "." + cents);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static void parseDate(String plain, Calendar now, Result r) {
        String lower = plain.toLowerCase(Locale.ROOT);
        long firstFound = -1L;
        for (Pattern p : new Pattern[]{P_DATE_FULL, P_DATE_SHORT}) {
            Matcher m = p.matcher(plain);
            while (m.find()) {
                int dd = Integer.parseInt(m.group(1));
                int mm = Integer.parseInt(m.group(2)) - 1;
                int yy = m.groupCount() >= 3 && m.group(3) != null ? Integer.parseInt(m.group(3)) : -1;
                if (dd < 1 || dd > 31 || mm < 0 || mm > 11) continue;
                long ts = dayOf(now, dd, mm, yy);
                int from = Math.max(0, m.start() - 25);
                if (lower.substring(from, m.start()).contains("splatn")) {
                    r.dayStart = ts;
                    return;
                }
                if (firstFound < 0) firstFound = ts;
            }
            if (firstFound >= 0) break; // plný dátum má prednosť pred krátkym
        }
        r.dayStart = firstFound;
    }

    private static long dayOf(Calendar now, int dd, int mm, int yy) {
        Calendar c = (Calendar) now.clone();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        Calendar today = (Calendar) c.clone();
        c.set(Calendar.DAY_OF_MONTH, 1);
        if (yy > 0) c.set(Calendar.YEAR, yy);
        c.set(Calendar.MONTH, mm);
        c.set(Calendar.DAY_OF_MONTH, Math.min(dd, c.getActualMaximum(Calendar.DAY_OF_MONTH)));
        if (yy <= 0 && c.before(today)) c.add(Calendar.YEAR, 1);
        return c.getTimeInMillis();
    }

    // ===== Dieťa / názov =====

    private static long findKid(String plain, List<VoiceDraftParser.KidRef> kids) {
        String n = VoiceDraftParser.normalize(plain);
        long found = -1L;
        for (VoiceDraftParser.KidRef k : kids) {
            String stem = VoiceDraftParser.normalize(k.name);
            if (stem.length() > 3 && "aeiouy".indexOf(stem.charAt(stem.length() - 1)) >= 0) {
                stem = stem.substring(0, stem.length() - 1);
            }
            if (stem.isEmpty()) continue;
            for (String token : n.split("[^a-z0-9]+")) {
                if (token.startsWith(stem)) {
                    if (found >= 0 && found != k.id) return 0L;
                    found = k.id;
                }
            }
        }
        return found;
    }

    private static String pickTitle(String latin, Result r) {
        for (String line : latin.split("\\r?\\n")) {
            String t = line.trim();
            if (t.length() < 3) continue;
            String plain = DiacriticsUtils.stripDiacritics(t);
            String up = plain == null ? t.toUpperCase(Locale.ROOT) : plain.toUpperCase(Locale.ROOT);
            if (P_IBAN_START.matcher(up).find() && up.replaceAll("[^0-9]", "").length() >= 10) continue;
            if (P_AMOUNT_AFTER.matcher(t).find() || P_AMOUNT_BEFORE.matcher(t).find()) continue;
            if (P_VS.matcher(plain == null ? t : plain).find()
                    || P_SS.matcher(plain == null ? t : plain).find()) continue;
            if (up.startsWith("IBAN")) continue;
            int letters = 0;
            for (char c : t.toCharArray()) if (Character.isLetter(c)) letters++;
            if (letters < 3) continue; // samé čísla / dátum
            return t.length() > 80 ? t.substring(0, 80).trim() : t;
        }
        return null;
    }
}
