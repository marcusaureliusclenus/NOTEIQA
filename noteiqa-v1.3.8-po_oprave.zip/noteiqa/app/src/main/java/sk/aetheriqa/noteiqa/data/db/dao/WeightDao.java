package sk.aetheriqa.noteiqa.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import sk.aetheriqa.noteiqa.data.entity.WeightEntry;
import sk.aetheriqa.noteiqa.data.entity.WeightGoal;

/**
 * WeightDao – DAO pre modul Chudnutie.
 *
 * Kľúčové query na podporu grafu:
 *  - getInRange: pre 7d / 30d / 90d / 1Y / Všetko
 *  - getStats: min, max, avg za obdobie (jeden round-trip namiesto 3)
 *  - getLastN: posledných N záznamov pre históriu
 */
@Dao
public interface WeightDao {

    // ===== WeightEntry =====

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(WeightEntry entry);

    @Update
    int update(WeightEntry entry);

    @Delete
    int delete(WeightEntry entry);

    @Query("SELECT * FROM weight_entries ORDER BY measuredAt DESC")
    LiveData<List<WeightEntry>> observeAll();

    /** Pre graf v zvolenom časovom okne. */
    @Query("SELECT * FROM weight_entries WHERE measuredAt >= :fromMillis " +
           "AND measuredAt <= :toMillis ORDER BY measuredAt ASC")
    LiveData<List<WeightEntry>> observeInRange(long fromMillis, long toMillis);

    /** Pre históriu pod grafom – posledných N. */
    @Query("SELECT * FROM weight_entries ORDER BY measuredAt DESC LIMIT :limit")
    LiveData<List<WeightEntry>> observeLastN(int limit);

    @Query("SELECT * FROM weight_entries WHERE id = :id")
    WeightEntry getById(long id);

    @Query("SELECT MIN(kg) FROM weight_entries WHERE measuredAt >= :from AND measuredAt <= :to")
    LiveData<Double> observeMin(long from, long to);

    @Query("SELECT MAX(kg) FROM weight_entries WHERE measuredAt >= :from AND measuredAt <= :to")
    LiveData<Double> observeMax(long from, long to);

    @Query("SELECT AVG(kg) FROM weight_entries WHERE measuredAt >= :from AND measuredAt <= :to")
    LiveData<Double> observeAvg(long from, long to);

    /** Najnovšie a najstaršie pre výpočet "zmena" v zvolenom období. */
    @Query("SELECT kg FROM weight_entries WHERE measuredAt >= :from AND measuredAt <= :to " +
           "ORDER BY measuredAt ASC LIMIT 1")
    LiveData<Double> observeFirstInRange(long from, long to);

    @Query("SELECT kg FROM weight_entries WHERE measuredAt >= :from AND measuredAt <= :to " +
           "ORDER BY measuredAt DESC LIMIT 1")
    LiveData<Double> observeLastInRange(long from, long to);

    // ===== WeightGoal =====

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insertGoal(WeightGoal goal);

    @Update
    int updateGoal(WeightGoal goal);

    @Query("SELECT * FROM weight_goals WHERE active = 1 LIMIT 1")
    LiveData<WeightGoal> observeActiveGoal();

    @Query("UPDATE weight_goals SET active = 0")
    void deactivateAllGoals();

    /** Pre Export/Backup — sync read všetkých záznamov. */
    @Query("SELECT * FROM weight_entries")
    List<WeightEntry> getAllSync();

    /** Pre Export/Backup — sync read všetkých cieľov. */
    @Query("SELECT * FROM weight_goals")
    List<WeightGoal> getAllGoalsSync();

    /** v1.0.0 — sync read pre Streak a WeeklyInsight (chronologicky DESC). */
    @Query("SELECT * FROM weight_entries ORDER BY measuredAt DESC")
    List<WeightEntry> getAllSyncDesc();

    /** v1.0.0 — sync read v rozsahu pre WeeklyInsight (napr. tento týždeň). */
    @Query("SELECT * FROM weight_entries WHERE measuredAt >= :fromMillis " +
           "AND measuredAt < :toMillis ORDER BY measuredAt ASC")
    List<WeightEntry> getInRangeSync(long fromMillis, long toMillis);
}
