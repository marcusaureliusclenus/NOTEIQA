package sk.aetheriqa.noteiqa.util;

import android.graphics.Bitmap;

import androidx.annotation.Nullable;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import java.util.EnumMap;
import java.util.Map;

/**
 * QrBitmap – v1.3.0 — QR (ZXing core, korekcia M) ako čierne moduly na krémovom
 * pozadí #F4EFE4. Nie biely na tmavom — invertovaný QR mnohé bankové appky neprečítajú.
 */
public final class QrBitmap {

    public static final int CREAM = 0xFFF4EFE4;
    public static final int INK = 0xFF000000;

    private QrBitmap() {}

    /** @param sizePx strana štvorca vrátane tichej zóny; null pri chybe. */
    @Nullable
    public static Bitmap render(String text, int sizePx) {
        Map<EncodeHintType, Object> hints = new EnumMap<>(EncodeHintType.class);
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
        hints.put(EncodeHintType.MARGIN, 2);
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
        try {
            BitMatrix m = new QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, sizePx, sizePx, hints);
            int w = m.getWidth();
            int h = m.getHeight();
            int[] px = new int[w * h];
            for (int y = 0; y < h; y++) {
                int row = y * w;
                for (int x = 0; x < w; x++) {
                    px[row + x] = m.get(x, y) ? INK : CREAM;
                }
            }
            Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            bmp.setPixels(px, 0, w, 0, 0, w, h);
            return bmp;
        } catch (WriterException | IllegalArgumentException e) {
            return null;
        }
    }
}
