package sk.aetheriqa.noteiqa.notification;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;

import sk.aetheriqa.noteiqa.data.entity.Task;

/**
 * ReminderScheduler – tenký wrapper nad AlarmManager pre Task pripomienky.
 *
 * Používanie:
 *   ReminderScheduler.schedule(ctx, task)   – po save úlohy s reminderAt > 0
 *   ReminderScheduler.cancel(ctx, taskId)   – po archive / delete / clear reminderu
 *
 * Pre konkrétnu task ID máme len JEDNU pripomienku v čase – PendingIntent
 * sa identifikuje cez requestCode = (int) taskId, takže opakovaný schedule
 * nahradí predošlý.
 *
 * Android 12+ (API 31): pre exact alarm potrebuje SCHEDULE_EXACT_ALARM
 * permission. Ak ho nemá, padá na inexact (lepšie ako nič).
 */
public final class ReminderScheduler {

    public static final String EXTRA_TASK_ID = "taskId";

    private ReminderScheduler() {}

    /**
     * Naplánuje pripomienku. Ak reminderAt nie je v budúcnosti, nič nerobí
     * (a starú pripomienku ku tej istej úlohe radšej zruší pre istotu).
     */
    public static void schedule(Context ctx, Task task) {
        if (task == null) return;
        cancel(ctx, task.id);

        if (task.reminderAt <= System.currentTimeMillis()) return;
        if (task.archivedAt > 0) return; // archivované úlohy nikdy nezvonia

        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        PendingIntent pi = buildPendingIntent(ctx, task.id);

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // Android 12+ — exact alarm vyžaduje permission, fallback na inexact
                if (am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP, task.reminderAt, pi);
                } else {
                    am.setAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP, task.reminderAt, pi);
                }
            } else {
                am.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP, task.reminderAt, pi);
            }
        } catch (SecurityException e) {
            // Bezpečný fallback – inexact, žiadny crash
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, task.reminderAt, pi);
        }
    }

    /** Zruší naplánovanú pripomienku + zatvorí prípadne zobrazenú notifikáciu. */
    public static void cancel(Context ctx, long taskId) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            PendingIntent pi = buildPendingIntent(ctx, taskId);
            am.cancel(pi);
            pi.cancel();
        }
        NotificationHelper.cancel(ctx, taskId);
    }

    /**
     * Pre Settings UI – Android 12+ niekedy treba poslať používateľa do
     * systému, aby povolil "Alarms & reminders" pre exact alarms.
     */
    public static boolean needsExactAlarmPermission(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false;
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        return am != null && !am.canScheduleExactAlarms();
    }

    public static Intent buildExactAlarmSettingsIntent(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return null;
        return new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                .setData(android.net.Uri.parse("package:" + ctx.getPackageName()))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    }

    private static PendingIntent buildPendingIntent(Context ctx, long taskId) {
        Intent intent = new Intent(ctx, ReminderReceiver.class);
        intent.putExtra(EXTRA_TASK_ID, taskId);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT
                | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    ? PendingIntent.FLAG_IMMUTABLE : 0);

        return PendingIntent.getBroadcast(
                ctx, (int) taskId, intent, flags);
    }
}
