package sk.aetheriqa.noteiqa.ui.kids;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.google.android.material.appbar.MaterialToolbar;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Calendar;
import java.util.List;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;

/**
 * KidsWeekPosterActivity – v1.3.0 — Plagát týždňa detí (vstup z hlavičky Deti).
 *
 * Šípky prepínajú týždne. FAB "Uložiť týždeň" uloží PNG (nie JPG — zlatý rám by
 * sa rozpadol) do Obrázky/Noteiqa cez MediaStore (Android 10+), na starších do
 * cache appky, a otvorí share sheet "Poslať plagát". Žiadny upload.
 */
public class KidsWeekPosterActivity extends AppCompatActivity {

    private static final String STATE_OFFSET = "weekOffset";
    /** v1.3.2 — naposledy zobrazený týždeň (pondelok 00:00 v millis). */
    private static final String PREFS = "noteiqa_kids";
    private static final String KEY_WEEK_START = "posterWeekStart";
    private static final long WEEK_MS = 7L * 24 * 60 * 60 * 1000;

    private ImageView image;
    private int weekOffset = 0;
    @Nullable private Bitmap current;
    private boolean saving = false;

    public static Intent newIntent(Context ctx) {
        return new Intent(ctx, KidsWeekPosterActivity.class);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kids_week_poster);
        if (savedInstanceState != null) {
            weekOffset = savedInstanceState.getInt(STATE_OFFSET, 0);
        } else {
            weekOffset = restoreOffset(); // default bez uloženia = tento týždeň
        }

        MaterialToolbar tb = findViewById(R.id.poster_toolbar);
        tb.setNavigationOnClickListener(v -> finish());
        image = findViewById(R.id.poster_image);

        findViewById(R.id.poster_prev).setOnClickListener(v -> { weekOffset--; persistWeek(); renderAsync(); });
        findViewById(R.id.poster_next).setOnClickListener(v -> { weekOffset++; persistWeek(); renderAsync(); });
        findViewById(R.id.poster_fab_save).setOnClickListener(v -> save());

        renderAsync();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(STATE_OFFSET, weekOffset);
    }

    private void persistWeek() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putLong(KEY_WEEK_START, mondayOf(weekOffset)).apply();
    }

    /** Uložený pondelok → posun voči tomuto týždňu (zaokrúhlene, odolné voči letnému času). */
    private int restoreOffset() {
        long saved = getSharedPreferences(PREFS, MODE_PRIVATE).getLong(KEY_WEEK_START, 0L);
        if (saved <= 0L) return 0;
        return (int) Math.round((saved - mondayOf(0)) / (double) WEEK_MS);
    }

    /** Pondelok 00:00 aktuálneho týždňa + offset. */
    static long mondayOf(int weekOffset) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        int dow = c.get(Calendar.DAY_OF_WEEK);               // nedeľa = 1
        int sinceMonday = (dow + 5) % 7;                      // pondelok = 0
        c.add(Calendar.DAY_OF_MONTH, -sinceMonday + 7 * weekOffset);
        return c.getTimeInMillis();
    }

    private void renderAsync() {
        final int offset = weekOffset;
        Context app = getApplicationContext();
        new Thread(() -> {
            KidRepository repo = KidRepository.getInstance(app);
            WeekPosterRenderer.Data d = new WeekPosterRenderer.Data();
            d.weekStart = mondayOf(offset);
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(d.weekStart);
            c.add(Calendar.DAY_OF_MONTH, 7);
            long weekEnd = c.getTimeInMillis();

            List<Kid> kids = repo.getKidsSync(); // zoradené podľa sortOrder
            for (int i = 0; i < kids.size() && i < 2; i++) d.kids.add(kids.get(i));
            d.events.addAll(repo.getEventsInRangeSync(d.weekStart, weekEnd));
            d.payments.addAll(repo.getUnpaidInRangeSync(d.weekStart, weekEnd));

            Bitmap bmp;
            try {
                bmp = new WeekPosterRenderer(this).render(d);
            } catch (OutOfMemoryError e) {
                bmp = null;
            }
            final Bitmap result = bmp;
            runOnUiThread(() -> {
                if (isFinishing() || offset != weekOffset) {
                    if (result != null) result.recycle();
                    return;
                }
                if (result == null) {
                    Toast.makeText(this, R.string.poster_failed, Toast.LENGTH_SHORT).show();
                    return;
                }
                Bitmap old = current;
                current = result;
                image.setImageBitmap(result);
                // počas ukladania sa stará bitmapa ešte zapisuje — nerecykluj ju
                if (old != null && old != result && !saving) old.recycle();
            });
        }, "WeekPoster").start();
    }

    private void save() {
        Bitmap bmp = current;
        if (bmp == null || saving) return;
        saving = true;
        new Thread(() -> {
            Uri uri = null;
            boolean inGallery = false;
            String name = "noteiqa_tyzden_" + mondayOf(weekOffset) + ".png";
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    uri = saveToMediaStore(bmp, name);
                    inGallery = uri != null;
                }
                if (uri == null) uri = saveToCache(bmp, name);
            } catch (IOException | RuntimeException e) {
                uri = null;
            }
            final Uri shareUri = uri;
            final boolean gallery = inGallery;
            runOnUiThread(() -> {
                saving = false;
                if (isFinishing()) return;
                if (shareUri == null) {
                    Toast.makeText(this, R.string.poster_failed, Toast.LENGTH_SHORT).show();
                    return;
                }
                if (gallery) Toast.makeText(this, R.string.poster_saved, Toast.LENGTH_SHORT).show();
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("image/png");
                send.putExtra(Intent.EXTRA_STREAM, shareUri);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(send, getString(R.string.poster_share_chooser)));
            });
        }, "WeekPosterSave").start();
    }

    /** Android 10+: Obrázky/Noteiqa bez povolenia na úložisko. */
    @Nullable
    private Uri saveToMediaStore(Bitmap bmp, String name) throws IOException {
        ContentResolver cr = getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
        v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Noteiqa");
        v.put(MediaStore.Images.Media.IS_PENDING, 1);
        Uri uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
        if (uri == null) return null;
        try (OutputStream out = cr.openOutputStream(uri)) {
            if (out == null || !bmp.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                cr.delete(uri, null, null);
                return null;
            }
        }
        ContentValues done = new ContentValues();
        done.put(MediaStore.Images.Media.IS_PENDING, 0);
        cr.update(uri, done, null, null);
        return uri;
    }

    /** Starší Android: cache appky + FileProvider (bez povolenia na úložisko). */
    private Uri saveToCache(Bitmap bmp, String name) throws IOException {
        File dir = new File(getCacheDir(), "share");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("share dir");
        File file = new File(dir, name);
        try (FileOutputStream out = new FileOutputStream(file)) {
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
        }
        return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
    }
}
