package sk.aetheriqa.noteiqa.data.entity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/**
 * Template – šablóna pre rýchle vytvorenie poznámky.
 *
 * Built-in šablóny (systemTemplate=true, nemažú sa):
 *  - Nákupný zoznam (prázdny checklist)
 *  - Deti — rozmery (predvyplnené: meno, dĺžka chodidla, obvod hlavy, výška, dátum)
 *  - Cestovný checklist
 *  - Zápisnica
 *
 * Custom šablóny si používateľ vytvára z existujúcej poznámky cez
 * "Uložiť ako šablónu". Tie majú systemTemplate=false.
 */
@Entity(tableName = "templates", indices = {@Index("sortOrder")})
public class Template {

    @PrimaryKey(autoGenerate = true)
    public long id;

    @NonNull
    public String name = "";

    /**
     * Typ obsahu (zhodný s Note.TYPE_*) – TEXT, CHECKLIST, TABLE.
     */
    public int type;

    @Nullable
    public String title;

    @Nullable
    public String body;

    /**
     * JSON serializovaný obsah pre CHECKLIST a TABLE typy.
     * Schéma checklistu: { "items": [{"text": "...", "checked": false}, ...] }
     */
    @Nullable
    public String contentJson;

    /** Hex farba ikony šablóny. */
    @Nullable
    public String iconColor;

    public boolean systemTemplate = false;

    public int sortOrder = 0;

    public long createdAt;
}
