package sk.aetheriqa.noteiqa.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import sk.aetheriqa.noteiqa.data.entity.KidEvent;

@Dao
public interface KidEventDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(KidEvent event);

    @Update
    int update(KidEvent event);

    @Delete
    int delete(KidEvent event);

    @Query("DELETE FROM kid_events WHERE id = :id")
    int deleteById(long id);

    @Query("SELECT * FROM kid_events WHERE id = :id")
    KidEvent getById(long id);

    /** Filter podľa dieťaťa: jeho udalosti + spoločné (kidId IS NULL = všetky deti). */
    @Query("SELECT * FROM kid_events WHERE (kidId = :kidId OR kidId IS NULL) ORDER BY startDate ASC")
    LiveData<List<KidEvent>> observeByKid(long kidId);

    /** Všetky udalosti všetkých detí. */
    @Query("SELECT * FROM kid_events ORDER BY startDate ASC")
    LiveData<List<KidEvent>> observeAll();

    /** Sync — pre injection do To Do listu, notification scheduler, export. */
    @Query("SELECT * FROM kid_events")
    List<KidEvent> getAllSync();

    /** Udalosti prekrývajúce zadaný interval — pre To Do injection. */
    @Query("SELECT * FROM kid_events WHERE " +
           "(endDate = 0 AND startDate >= :fromMillis AND startDate < :toMillis) OR " +
           "(endDate > 0 AND startDate < :toMillis AND endDate >= :fromMillis) " +
           "ORDER BY startDate ASC")
    List<KidEvent> getEventsInRangeSync(long fromMillis, long toMillis);

    /**
     * v1.3.0 — Zlatá niť dňa: udalosti, ktoré zasahujú do [dayStart, dayEnd).
     * Úzky dotaz cez index startDate — Domov nečíta celý dataset.
     */
    @Query("SELECT * FROM kid_events WHERE " +
           "(startDate >= :dayStart AND startDate < :dayEnd) " +
           "OR (endDate > 0 AND startDate < :dayEnd AND endDate >= :dayStart) " +
           "ORDER BY allDay DESC, startDate ASC")
    LiveData<List<KidEvent>> observeDay(long dayStart, long dayEnd);

    /** BootReceiver re-schedule aktívnych notifikácií. */
    @Query("SELECT * FROM kid_events WHERE notifyAt > :now")
    List<KidEvent> getUpcomingRemindersSync(long now);
}
