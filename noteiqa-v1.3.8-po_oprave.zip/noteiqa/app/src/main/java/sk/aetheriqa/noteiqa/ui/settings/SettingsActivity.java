package sk.aetheriqa.noteiqa.ui.settings;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;

import sk.aetheriqa.noteiqa.R;

/**
 * SettingsActivity – full-screen hostiteľ pre MoreFragment.
 *
 * v1.1.0: Nastavenia sa presunuli z bottom nav (bola tam pôvodne ako 5. tab)
 * do gear ikony v pravom hornom rohu MainActivity. Klik na gear otvorí túto
 * Activity ako klasické full-screen okno s toolbar → space šetríme pre 5
 * hlavných tabov (Domov, To do, Poznámky, Váženie, Deti).
 */
public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        MaterialToolbar tb = findViewById(R.id.settings_toolbar);
        tb.setNavigationOnClickListener(v -> finish());
    }

    public static Intent newIntent(Context ctx) {
        return new Intent(ctx, SettingsActivity.class);
    }
}
