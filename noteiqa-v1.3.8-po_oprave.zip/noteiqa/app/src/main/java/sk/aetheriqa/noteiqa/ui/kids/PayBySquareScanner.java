package sk.aetheriqa.noteiqa.ui.kids;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.LuminanceSource;
import com.google.zxing.RGBLuminanceSource;
import com.google.zxing.common.GlobalHistogramBinarizer;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.QRCodeReader;

import java.io.InputStream;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.util.DialogThemes;

/**
 * PayBySquareScanner – v1.3.5 — načítanie QR (PAY by square) do platby.
 *
 *  - Kamerou: Google code scanner (Play služby, beží na zariadení, appka nepotrebuje
 *    povolenie kamery — obrazovku skenera ukazujú Play služby)
 *  - Z obrázka: snímka obrazovky / fotka faktúry → ZXing (core už v projekte), offline
 *
 * Vytvoriť v onCreate (registerForActivityResult). Výsledok je surový text QR;
 * dekódovanie a vyplnenie polí rieši volajúci cez PayBySquare.parse.
 */
final class PayBySquareScanner {

    interface Callback {
        void onCode(String raw);
    }

    /** Dlhšia strana obrázka pre dekódovanie — malé QR na faktúre ešte prečíta, RAM unesie. */
    private static final int MAX_SIDE = 2000;

    private final AppCompatActivity activity;
    private final Callback callback;
    private final ActivityResultLauncher<String> pickImage;
    private final Handler main = new Handler(Looper.getMainLooper());

    PayBySquareScanner(AppCompatActivity activity, Callback callback) {
        this.activity = activity;
        this.callback = callback;
        this.pickImage = activity.registerForActivityResult(
                new ActivityResultContracts.GetContent(), uri -> {
                    if (uri != null) decodeImage(uri);
                });
    }

    /** Výber: kamera alebo obrázok. */
    void start() {
        new AlertDialog.Builder(activity, DialogThemes.LEA)
                .setTitle(R.string.qr_scan_title)
                .setItems(new CharSequence[]{
                        activity.getString(R.string.qr_scan_camera),
                        activity.getString(R.string.qr_scan_image)
                }, (d, which) -> {
                    if (which == 0) scanCamera();
                    else pickImage.launch("image/*");
                })
                .show();
    }

    private void scanCamera() {
        GmsBarcodeScannerOptions opts = new GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                .build();
        GmsBarcodeScanning.getClient(activity, opts).startScan()
                .addOnSuccessListener(barcode -> {
                    String raw = barcode.getRawValue();
                    if (raw == null || raw.isEmpty()) {
                        toast(R.string.qr_scan_not_found);
                    } else {
                        callback.onCode(raw);
                    }
                })
                // zrušenie používateľom = ticho; chyba (napr. chýbajú Play služby) = rada skúsiť obrázok
                .addOnFailureListener(e -> toast(R.string.qr_scan_camera_failed));
    }

    private void decodeImage(Uri uri) {
        Context app = activity.getApplicationContext();
        new Thread(() -> {
            String text = null;
            try {
                Bitmap bmp = loadSampled(app, uri);
                if (bmp != null) {
                    text = decode(bmp);
                    bmp.recycle();
                }
            } catch (Exception | OutOfMemoryError ignored) {
                text = null;
            }
            final String result = text;
            main.post(() -> {
                if (activity.isFinishing()) return;
                if (result == null) toast(R.string.qr_scan_not_found);
                else callback.onCode(result);
            });
        }, "QrFromImage").start();
    }

    @Nullable
    private static Bitmap loadSampled(Context ctx, Uri uri) throws Exception {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = ctx.getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(in, null, bounds);
        }
        int sample = 1;
        while (Math.max(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        try (InputStream in = ctx.getContentResolver().openInputStream(uri)) {
            return BitmapFactory.decodeStream(in, null, opts);
        }
    }

    /** QR z bitmapy: HybridBinarizer, potom GlobalHistogram (iné osvetlenie fotky). */
    @Nullable
    private static String decode(Bitmap bmp) {
        int w = bmp.getWidth();
        int h = bmp.getHeight();
        int[] px = new int[w * h];
        bmp.getPixels(px, 0, w, 0, 0, w, h);
        LuminanceSource src = new RGBLuminanceSource(w, h, px);

        Map<DecodeHintType, Object> hints = new EnumMap<>(DecodeHintType.class);
        hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
        hints.put(DecodeHintType.POSSIBLE_FORMATS, Collections.singletonList(BarcodeFormat.QR_CODE));

        QRCodeReader reader = new QRCodeReader();
        BinaryBitmap[] attempts = {
                new BinaryBitmap(new HybridBinarizer(src)),
                new BinaryBitmap(new GlobalHistogramBinarizer(src)),
                new BinaryBitmap(new HybridBinarizer(src.invert()))
        };
        for (BinaryBitmap b : attempts) {
            try {
                return reader.decode(b, hints).getText();
            } catch (Exception notHere) {
                reader.reset();
            }
        }
        return null;
    }

    private void toast(int res) {
        Toast.makeText(activity, res, Toast.LENGTH_LONG).show();
    }
}
