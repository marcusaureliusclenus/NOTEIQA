package sk.aetheriqa.noteiqa.security;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import sk.aetheriqa.noteiqa.R;

/**
 * LockActivity – v1.2.0 — obrazovka zámku nad appkou.
 * BiometricPrompt s biometriou alebo PIN/vzorom/heslom zariadenia.
 * Späť = appka ide do pozadia (obsah pod zámkom sa neukáže).
 */
public class LockActivity extends AppCompatActivity {

    private boolean prompting = false;
    private BiometricPrompt prompt;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lock);

        // BiometricPrompt sa vytvára v onCreate (odporúčanie androidx.biometric kvôli rotácii)
        prompt = new BiometricPrompt(this,
                ContextCompat.getMainExecutor(this),
                new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(
                            @NonNull BiometricPrompt.AuthenticationResult result) {
                        prompting = false;
                        AppLock.get(LockActivity.this).markUnlocked();
                        finish();
                    }

                    @Override
                    public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                        // Zrušené / chyba — ostávame na zámku, tlačidlo "Odomknúť" skúsi znova
                        prompting = false;
                    }
                });

        findViewById(R.id.lock_unlock_button).setOnClickListener(v -> showPrompt());

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                moveTaskToBack(true);
            }
        });

        // Automaticky raz pri otvorení; ďalšie pokusy cez tlačidlo (bez slučky po zrušení)
        if (savedInstanceState == null) {
            getWindow().getDecorView().post(this::showPrompt);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        showPrompt();
    }

    private void showPrompt() {
        if (prompting || isFinishing()) return;
        prompting = true;

        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle(getString(R.string.app_lock_prompt_title))
                .setSubtitle(getString(R.string.app_lock_prompt_subtitle))
                .setAllowedAuthenticators(AppLock.AUTHENTICATORS)
                .build();
        prompt.authenticate(info);
    }
}
