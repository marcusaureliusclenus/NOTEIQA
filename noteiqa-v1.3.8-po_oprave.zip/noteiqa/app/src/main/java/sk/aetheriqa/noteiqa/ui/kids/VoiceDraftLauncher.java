package sk.aetheriqa.noteiqa.ui.kids;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

import sk.aetheriqa.noteiqa.R;

/**
 * VoiceDraftLauncher – v1.3.0 — vstup do hlasového návrhu z fragmentu
 * (mic na niti dňa, dlhý stisk FAB v Deťoch). Rieši povolenie RECORD_AUDIO.
 *
 * v1.3.1 — fallback: ak SpeechRecognizer v sheete zlyhá (napr. predvolená služba
 * výrobcu nepozná slovenčinu), otvorí sa hlasový dialóg systému (Google)
 * a rozpoznaný text ide rovno do karty "Rozumel som".
 *
 * Musí sa vytvoriť najneskôr v onViewCreated (registerForActivityResult pred onStart).
 */
public final class VoiceDraftLauncher {

    private final Fragment fragment;
    private final ActivityResultLauncher<String> permission;
    private final ActivityResultLauncher<Intent> systemDialog;
    private long pendingKidId;

    public VoiceDraftLauncher(Fragment fragment) {
        this.fragment = fragment;
        this.permission = fragment.registerForActivityResult(
                new ActivityResultContracts.RequestPermission(), granted -> {
                    if (!fragment.isAdded()) return;
                    if (granted) {
                        open(pendingKidId);
                    } else {
                        Toast.makeText(fragment.requireContext(), R.string.voice_no_permission,
                                Toast.LENGTH_LONG).show();
                    }
                });
        this.systemDialog = fragment.registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), this::onSystemResult);
    }

    /** @param defaultKidId dieťa vybrané vo filtri (0 = všetky), použije sa ak ho veta nespomenie */
    public void start(long defaultKidId) {
        if (!fragment.isAdded()) return;
        pendingKidId = defaultKidId;
        if (ContextCompat.checkSelfPermission(fragment.requireContext(), Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED) {
            open(defaultKidId);
        } else {
            permission.launch(Manifest.permission.RECORD_AUDIO);
        }
    }

    private void open(long defaultKidId) {
        if (!SpeechRecognizer.isRecognitionAvailable(fragment.requireContext())) {
            openSystemDialog(); // žiadna služba pre SpeechRecognizer → skús dialóg systému
            return;
        }
        new VoiceDraftSheet(fragment.requireContext(), defaultKidId, null,
                this::openSystemDialog).show();
    }

    private void openSystemDialog() {
        if (!fragment.isAdded()) return;
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "sk-SK");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, fragment.getString(R.string.voice_listening));
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        try {
            systemDialog.launch(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(fragment.requireContext(), R.string.voice_unavailable,
                    Toast.LENGTH_LONG).show();
        }
    }

    private void onSystemResult(ActivityResult result) {
        if (!fragment.isAdded()) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) return;
        ArrayList<String> list = result.getData()
                .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if (list == null || list.isEmpty() || list.get(0).trim().isEmpty()) {
            Toast.makeText(fragment.requireContext(), R.string.voice_nothing_heard_short,
                    Toast.LENGTH_SHORT).show();
            return;
        }
        // rovno karta "Rozumel som" — bez ďalšieho fallbacku (nič by nepočúvalo)
        new VoiceDraftSheet(fragment.requireContext(), pendingKidId, list.get(0), null).show();
    }
}
