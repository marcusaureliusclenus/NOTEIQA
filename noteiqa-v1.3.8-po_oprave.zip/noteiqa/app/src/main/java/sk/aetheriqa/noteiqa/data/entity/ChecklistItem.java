package sk.aetheriqa.noteiqa.data.entity;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/**
 * ChecklistItem – jedna položka v checklist poznámke.
 *
 * Patrí k Note cez noteId (CASCADE delete).
 * Order určuje poradie v zozname (drag-and-drop reorder).
 */
@Entity(
    tableName = "checklist_items",
    indices = {@Index("noteId")},
    foreignKeys = @ForeignKey(
        entity = Note.class,
        parentColumns = "id",
        childColumns = "noteId",
        onDelete = ForeignKey.CASCADE
    )
)
public class ChecklistItem {

    @PrimaryKey(autoGenerate = true)
    public long id;

    public long noteId;

    @NonNull
    public String text = "";

    public boolean checked = false;

    /** Poradie v rámci checklistu (0 = prvý). */
    public int sortOrder = 0;

    public long createdAt;
    public long updatedAt;
}
