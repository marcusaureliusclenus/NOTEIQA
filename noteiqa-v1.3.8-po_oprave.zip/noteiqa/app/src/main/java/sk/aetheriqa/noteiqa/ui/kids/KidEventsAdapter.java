package sk.aetheriqa.noteiqa.ui.kids;

import android.graphics.Color;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;

/**
 * KidEventsAdapter – zoznam udalostí s day headers.
 *
 * items je flat list Object[] kde:
 *   - String = header (dátum ako "PIATOK · 15. MÁJ 2026")
 *   - KidEvent = udalosť
 *
 * Header sa vloží pred prvú udalosť každého nového dňa (ostrik na startDate).
 * Pre viacdňové udalosti sa header zobrazí len raz — pri jej startDate.
 */
public class KidEventsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public interface Listener {
        void onClick(KidEvent e);
        void onLongPress(KidEvent e);
    }

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_EVENT = 1;

    private final SimpleDateFormat headerFmt = new SimpleDateFormat("EEEE · d. MMMM yyyy",
            new Locale("sk", "SK"));

    private final List<Object> items = new ArrayList<>();
    private List<Kid> kids = new ArrayList<>();
    /** v1.3.3 — eventId → suma naviazanej platby (switch „Platba / poplatok“). */
    private final java.util.Map<Long, Double> amountsByEvent = new java.util.HashMap<>();
    private final Listener listener;

    public KidEventsAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<KidEvent> events) {
        items.clear();
        if (events != null && !events.isEmpty()) {
            long lastDay = -1L;
            for (KidEvent e : events) {
                long dayKey = dayKey(e.startDate);
                if (dayKey != lastDay) {
                    items.add(headerFmt.format(new java.util.Date(e.startDate)).toUpperCase(
                            new Locale("sk", "SK")));
                    lastDay = dayKey;
                }
                items.add(e);
            }
        }
        notifyDataSetChanged();
    }

    public void setKids(List<Kid> kids) {
        this.kids = kids != null ? kids : new ArrayList<>();
        notifyDataSetChanged();
    }

    /** v1.3.3 — platby s eventId; pri udalosti sa ukáže malá suma. */
    public void setEventPayments(List<KidPayment> payments) {
        amountsByEvent.clear();
        amountsByEvent.putAll(eventAmounts(payments));
        notifyDataSetChanged();
    }

    /** eventId → súčet súm naviazaných platieb (platby bez sumy sa nerátajú). */
    public static java.util.Map<Long, Double> eventAmounts(List<KidPayment> payments) {
        java.util.Map<Long, Double> m = new java.util.HashMap<>();
        if (payments == null) return m;
        for (KidPayment p : payments) {
            if (p.eventId == null || p.amountEur == null) continue;
            Double prev = m.get(p.eventId);
            m.put(p.eventId, (prev != null ? prev : 0d) + p.amountEur);
        }
        return m;
    }

    private static long dayKey(long ts) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ts);
        return c.get(Calendar.YEAR) * 1000L + c.get(Calendar.DAY_OF_YEAR);
    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position) instanceof KidEvent ? TYPE_EVENT : TYPE_HEADER;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inf = LayoutInflater.from(parent.getContext());
        if (viewType == TYPE_HEADER) {
            View v = inf.inflate(R.layout.item_kid_event_day_header, parent, false);
            return new HeaderVH(v);
        }
        View v = inf.inflate(R.layout.item_kid_event, parent, false);
        return new EventVH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Object o = items.get(position);
        if (holder instanceof HeaderVH) {
            ((HeaderVH) holder).text.setText((String) o);
        } else if (holder instanceof EventVH) {
            EventVH h = (EventVH) holder;
            KidEvent e = (KidEvent) o;
            Kid kid = findKid(e.kidIdOrAll());

            h.title.setText(e.title);

            int color;
            try {
                color = kid != null ? Color.parseColor(kid.colorHex) : 0xFFC9A961;
            } catch (IllegalArgumentException ex) {
                color = 0xFFC9A961;
            }
            h.colorChip.setBackgroundColor(color);

            android.content.Context ctx = h.itemView.getContext();
            String kidLabel = kid != null ? kid.name : ctx.getString(R.string.kids_label_all);
            h.metaTop.setText(ctx.getString(R.string.kid_meta_join, kidLabel, typeLabel(ctx, e.type)));

            StringBuilder meta = new StringBuilder();
            if (e.allDay) {
                meta.append(ctx.getString(R.string.kid_all_day_short));
            } else {
                Calendar c = Calendar.getInstance();
                c.setTimeInMillis(e.startDate);
                meta.append(String.format(Locale.getDefault(), "%d:%02d",
                        c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)));
            }
            if (e.endDate > 0L) {
                Calendar cs = Calendar.getInstance(); cs.setTimeInMillis(e.startDate);
                Calendar ce = Calendar.getInstance(); ce.setTimeInMillis(e.endDate);
                if (cs.get(Calendar.DAY_OF_YEAR) != ce.get(Calendar.DAY_OF_YEAR)
                        || cs.get(Calendar.YEAR) != ce.get(Calendar.YEAR)) {
                    meta.append(" – ").append(new SimpleDateFormat("d.M.", Locale.getDefault())
                            .format(new java.util.Date(e.endDate)));
                }
            }
            if (!TextUtils.isEmpty(e.location)) {
                meta.append(" · ").append(e.location);
            }
            Double fee = amountsByEvent.get(e.id);
            if (fee != null) {
                meta.append(" · ").append(ctx.getString(R.string.ticket_amount,
                        PaymentTicketBinder.formatAmount(fee)));
            }
            h.metaBottom.setText(meta.toString());

            h.itemView.setOnClickListener(v -> listener.onClick(e));
            h.itemView.setOnLongClickListener(v -> { listener.onLongPress(e); return true; });
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private Kid findKid(long kidId) {
        for (Kid k : kids) if (k.id == kidId) return k;
        return null;
    }

    static String typeLabel(android.content.Context ctx, int type) {
        switch (type) {
            case KidEvent.TYPE_SCHOOL: return ctx.getString(R.string.kid_event_type_school);
            case KidEvent.TYPE_SPORT: return ctx.getString(R.string.kid_event_type_sport);
            case KidEvent.TYPE_HEALTH: return ctx.getString(R.string.kid_event_type_health);
            case KidEvent.TYPE_CULTURE: return ctx.getString(R.string.kid_event_type_culture);
            case KidEvent.TYPE_HOLIDAY: return ctx.getString(R.string.kid_event_type_holiday);
            default: return ctx.getString(R.string.kid_event_type_other);
        }
    }

    static class HeaderVH extends RecyclerView.ViewHolder {
        final TextView text;
        HeaderVH(@NonNull View item) {
            super(item);
            text = (TextView) item;
        }
    }

    static class EventVH extends RecyclerView.ViewHolder {
        final View colorChip;
        final TextView metaTop, title, metaBottom;
        EventVH(@NonNull View item) {
            super(item);
            colorChip = item.findViewById(R.id.kid_event_color_chip);
            metaTop = item.findViewById(R.id.kid_event_meta_top);
            title = item.findViewById(R.id.kid_event_title);
            metaBottom = item.findViewById(R.id.kid_event_meta_bottom);
        }
    }
}
