package sk.aetheriqa.noteiqa.data.entity;

import androidx.annotation.Nullable;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/**
 * Reminder – pripomienka viazaná na poznámku.
 *
 * Naplánovaná cez AlarmManager (presný čas) alebo WorkManager (toleranciou flexibilný).
 * Po zmazaní poznámky sa automaticky čistí (CASCADE).
 */
@Entity(
    tableName = "reminders",
    indices = {@Index("noteId"), @Index("triggerAt"), @Index("active")},
    foreignKeys = @ForeignKey(
        entity = Note.class,
        parentColumns = "id",
        childColumns = "noteId",
        onDelete = ForeignKey.CASCADE
    )
)
public class Reminder {

    public static final int REPEAT_NONE = 0;
    public static final int REPEAT_DAILY = 1;
    public static final int REPEAT_WEEKLY = 2;
    public static final int REPEAT_MONTHLY = 3;
    public static final int REPEAT_YEARLY = 4;

    @PrimaryKey(autoGenerate = true)
    public long id;

    public long noteId;

    /** Unix epoch millis – kedy spustiť. */
    public long triggerAt;

    public int repeatType = REPEAT_NONE;

    /** Pre WEEKLY: bitmask (1=Po, 2=Ut, 4=St, ...). */
    public int repeatDays = 0;

    public boolean active = true;

    @Nullable
    public String message;

    public long createdAt;
}
