package sk.aetheriqa.noteiqa.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import sk.aetheriqa.noteiqa.data.entity.Reminder;

@Dao
public interface ReminderDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(Reminder reminder);

    @Update
    int update(Reminder reminder);

    @Delete
    int delete(Reminder reminder);

    @Query("SELECT * FROM reminders WHERE active = 1 ORDER BY triggerAt ASC")
    LiveData<List<Reminder>> observeActive();

    /** Pre BootReceiver – vytiahne všetky reminders, ktoré majú byť reschedulované. */
    @Query("SELECT * FROM reminders WHERE active = 1 AND triggerAt > :now")
    List<Reminder> getActiveAfter(long now);

    @Query("SELECT * FROM reminders WHERE noteId = :noteId AND active = 1")
    List<Reminder> getForNote(long noteId);

    @Query("UPDATE reminders SET active = 0 WHERE id = :id")
    int deactivate(long id);

    @Query("DELETE FROM reminders WHERE noteId = :noteId")
    int deleteAllForNote(long noteId);

    /** Pre Export/Backup — sync read všetkých záznamov. */
    @Query("SELECT * FROM reminders")
    List<Reminder> getAllSync();
}
