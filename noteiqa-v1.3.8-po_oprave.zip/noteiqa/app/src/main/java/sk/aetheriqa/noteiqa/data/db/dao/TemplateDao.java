package sk.aetheriqa.noteiqa.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import sk.aetheriqa.noteiqa.data.entity.Template;

@Dao
public interface TemplateDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(Template template);

    @Update
    int update(Template template);

    @Delete
    int delete(Template template);

    @Query("SELECT * FROM templates ORDER BY systemTemplate DESC, sortOrder ASC, name ASC")
    LiveData<List<Template>> observeAll();

    @Query("SELECT * FROM templates WHERE id = :id")
    Template getById(long id);

    @Query("SELECT COUNT(*) FROM templates WHERE systemTemplate = 1")
    int countSystemTemplates();

    /** Pre Export/Backup — sync read všetkých záznamov. */
    @Query("SELECT * FROM templates")
    List<Template> getAllSync();
}
