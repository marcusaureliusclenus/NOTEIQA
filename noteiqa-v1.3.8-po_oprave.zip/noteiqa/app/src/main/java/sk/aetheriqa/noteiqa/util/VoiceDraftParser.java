package sk.aetheriqa.noteiqa.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * VoiceDraftParser – v1.3.0 — z vety (hlasový návrh) vyrobí NÁVRH záznamu.
 * Pravidlá, žiadne ML, žiadny cloud. Nič neukladá — potvrdzuje používateľ.
 *
 *  - dátum: dnes, zajtra, pozajtra, (v) pondelok…nedeľu, "15. 10.", "15. októbra"
 *  - čas: "o 16:30", "o 7", "o siedmej", "o pol ôsmej" (= 7:30);
 *    hodiny 1–6 bez "ráno" = popoludní (zajtra o piatej → 17:00)
 *  - dieťa: meno z DB (aj skloňované: Gabiky, Alexovi), "obe deti" / "oboje" = všetky
 *  - "ŠKD je zaplatené" → nájde nezaplatenú platbu, nič nové nevytvára;
 *    keď ju nenájde, povie to (PAYMENT_NOT_FOUND)
 *  - platba len ak vieme sumu alebo názov existujúcej platby
 *  - výlet / lekár / krúžok / tréning / divadlo / prázdniny … → udalosť
 *  - inak úloha s celou vetou
 *
 * Čistá Java (bez Android API) — testuje VoiceDraftParserTest.
 */
public final class VoiceDraftParser {

    public enum Kind { TASK, EVENT, PAYMENT, MARK_PAID, PAYMENT_NOT_FOUND }

    /** Typy udalostí — rovnaké hodnoty ako KidEvent.TYPE_*. */
    public static final int TYPE_SCHOOL = 0;
    public static final int TYPE_SPORT = 1;
    public static final int TYPE_HEALTH = 2;
    public static final int TYPE_CULTURE = 3;
    public static final int TYPE_HOLIDAY = 4;
    public static final int TYPE_OTHER = 5;

    /** Kľúčové slová udalostí: kmeň (bez diakritiky) → typ. Názov dá UI zo strings.xml. */
    public enum EventWord {
        DENTIST("zubar", TYPE_HEALTH), DOCTOR("lekar", TYPE_HEALTH), DOCTOR2("doktor", TYPE_HEALTH),
        VACCINATION("ockovan", TYPE_HEALTH), CHECKUP("prehliadk", TYPE_HEALTH),
        TRIP("vylet", TYPE_SCHOOL), SCHOOL("skol", TYPE_SCHOOL), PARENTS_MEETING("rodicovsk", TYPE_SCHOOL),
        CLUB("kruzok", TYPE_SPORT), CLUB2("kruzk", TYPE_SPORT), KARATE("karate", TYPE_SPORT),
        TRAINING("trening", TYPE_SPORT), MATCH("zapas", TYPE_SPORT), SWIMMING("plavani", TYPE_SPORT),
        FOOTBALL("futbal", TYPE_SPORT),
        THEATRE("divadl", TYPE_CULTURE), CINEMA("kino", TYPE_CULTURE), CONCERT("koncert", TYPE_CULTURE),
        HOLIDAYS("prazdnin", TYPE_HOLIDAY);

        public final String stem;
        public final int type;

        EventWord(String stem, int type) {
            this.stem = stem;
            this.type = type;
        }
    }

    public static final class KidRef {
        public final long id;
        public final String name;

        public KidRef(long id, String name) {
            this.id = id;
            this.name = name;
        }
    }

    public static final class PaymentRef {
        public final long id;
        public final long kidId;
        public final String title;

        public PaymentRef(long id, long kidId, String title) {
            this.id = id;
            this.kidId = kidId;
            this.title = title;
        }
    }

    public static final class Draft {
        public Kind kind = Kind.TASK;
        /** Navrhnutý názov (pri udalosti z kľúčového slova sa použije eventWord). */
        public String title;
        public EventWord eventWord;
        public int eventType = TYPE_OTHER;
        /** Začiatok dňa (00:00) alebo -1, ak dátum nezaznel. */
        public long dayStart = -1L;
        /** Minúty od polnoci alebo -1 (bez času). */
        public int minutes = -1;
        /** -1 = nevieme (UI sa spýta), 0 = všetky deti, inak id dieťaťa. */
        public long kidId = -1L;
        public BigDecimal amount;
        /** Nájdená existujúca platba (MARK_PAID alebo vzor pre novú). */
        public long paymentId = -1L;
        /** Pri PAYMENT_NOT_FOUND: čo sme hľadali (napr. "ŠKD"), môže byť null. */
        public String searchedTitle;
        public String rawText;
    }

    private static final String[] WEEKDAYS = {
            "pondel", "utor", "stred", "stvrt", "piat", "sobot", "nedel"};
    private static final String[] MONTHS = {
            "januar", "februar", "marc", "april", "maj", "jun", "jul", "august",
            "septembr", "oktobr", "novembr", "decembr"};
    private static final String[] HOUR_WORDS = {
            "jednej", "druhej", "tretej", "stvrtej", "piatej", "siestej", "siedmej",
            "osmej", "deviatej", "desiatej", "jedenastej", "dvanastej"};

    private static final Pattern P_TIME_HM = Pattern.compile("\\bo\\s*(\\d{1,2})[:.](\\d{2})\\b");
    private static final Pattern P_TIME_HALF = Pattern.compile(
            "\\bo\\s*pol\\s*(\\d{1,2}|" + String.join("|", HOUR_WORDS) + ")\\b");
    private static final Pattern P_TIME_H = Pattern.compile("\\bo\\s*(\\d{1,2})\\b(?![:.]\\d)");
    private static final Pattern P_TIME_WORD = Pattern.compile(
            "\\bo\\s*(" + String.join("|", HOUR_WORDS) + ")\\b");
    private static final Pattern P_DATE_NUM = Pattern.compile(
            "\\b(\\d{1,2})\\.\\s*(\\d{1,2})\\.(?:\\s*(\\d{4}))?");
    private static final Pattern P_DATE_MONTH = Pattern.compile(
            "\\b(\\d{1,2})\\.?\\s*(januara|februara|marca|aprila|maja|juna|jula|augusta|"
                    + "septembra|oktobra|novembra|decembra)\\b");
    private static final Pattern P_AMOUNT = Pattern.compile(
            "(\\d+(?:[.,]\\d{1,2})?)\\s*(?:€|eur\\w*)");
    private static final Pattern P_MARK_PAID = Pattern.compile(
            "\\b(zaplatil\\w*|zaplaten\\w*|uhradil\\w*|uhraden\\w*)\\b");
    private static final Pattern P_PAYMENT_WORD = Pattern.compile(
            "\\b(zaplat\\w*|platb\\w*|poplat\\w*|skd)\\b|€|\\beur");

    private VoiceDraftParser() {}

    public static Draft parse(String text, List<KidRef> kids, List<PaymentRef> unpaid, Calendar now) {
        Draft d = new Draft();
        d.rawText = text == null ? "" : text.trim();
        String n = normalize(d.rawText);

        parseDate(n, now, d);
        parseTime(n, d);
        d.kidId = parseKid(n, kids);

        Matcher am = P_AMOUNT.matcher(n);
        if (am.find()) {
            try {
                d.amount = new BigDecimal(am.group(1).replace(',', '.'));
            } catch (NumberFormatException ignored) {
                d.amount = null;
            }
        }

        // 1) "ŠKD je zaplatené" / "zaplatil som ŠKD" → označiť existujúcu, nič nové
        if (P_MARK_PAID.matcher(n).find()) {
            PaymentRef match = findPayment(n, unpaid, d.kidId);
            if (match != null) {
                d.kind = Kind.MARK_PAID;
                d.paymentId = match.id;
                d.title = match.title;
                d.kidId = match.kidId;
            } else {
                d.kind = Kind.PAYMENT_NOT_FOUND;
                d.searchedTitle = originalToken(d.rawText, "skd");
            }
            return d;
        }

        // 2) Platba — len ak vieme sumu alebo názov existujúcej platby
        if (P_PAYMENT_WORD.matcher(n).find()) {
            PaymentRef match = findPayment(n, unpaid, d.kidId);
            if (d.amount != null || match != null) {
                d.kind = Kind.PAYMENT;
                if (match != null) {
                    d.paymentId = match.id;
                    d.title = match.title;
                    if (d.kidId < 0) d.kidId = match.kidId;
                } else {
                    String skd = originalToken(d.rawText, "skd");
                    d.title = skd != null ? skd : leftoverTitle(d.rawText, kids);
                }
                return d;
            }
        }

        // 3) Udalosť podľa kľúčového slova
        for (String token : n.split("\\s+")) {
            for (EventWord w : EventWord.values()) {
                if (token.startsWith(w.stem)) {
                    d.kind = Kind.EVENT;
                    d.eventWord = w;
                    d.eventType = w.type;
                    return d;
                }
            }
        }

        // 4) Inak úloha s celou vetou
        d.kind = Kind.TASK;
        d.title = capitalize(d.rawText);
        return d;
    }

    // ===== Dátum / čas =====

    private static void parseDate(String n, Calendar now, Draft d) {
        Calendar day = startOfDay(now);
        if (containsWord(n, "pozajtra")) {
            day.add(Calendar.DAY_OF_MONTH, 2);
            d.dayStart = day.getTimeInMillis();
            return;
        }
        if (containsWord(n, "zajtra")) {
            day.add(Calendar.DAY_OF_MONTH, 1);
            d.dayStart = day.getTimeInMillis();
            return;
        }
        if (containsWord(n, "dnes") || containsWord(n, "dnes vecer")) {
            d.dayStart = day.getTimeInMillis();
            return;
        }

        Matcher m = P_DATE_MONTH.matcher(n);
        if (m.find()) {
            int dd = Integer.parseInt(m.group(1));
            int mm = monthIndex(m.group(2));
            d.dayStart = dateOrNextYear(now, dd, mm, -1);
            return;
        }
        m = P_DATE_NUM.matcher(n);
        if (m.find()) {
            int dd = Integer.parseInt(m.group(1));
            int mm = Integer.parseInt(m.group(2)) - 1;
            int yy = m.group(3) != null ? Integer.parseInt(m.group(3)) : -1;
            if (dd >= 1 && dd <= 31 && mm >= 0 && mm <= 11) {
                d.dayStart = dateOrNextYear(now, dd, mm, yy);
                return;
            }
        }

        // v pondelok … v nedeľu → najbližší taký deň po dnešku
        for (String token : n.split("\\s+")) {
            if (isHourWord(token)) continue; // "o piatej" nie je piatok
            for (int i = 0; i < WEEKDAYS.length; i++) {
                if (token.startsWith(WEEKDAYS[i])) {
                    int target = (i + 1) % 7 + 1;                 // Calendar: nedeľa = 1, pondelok = 2
                    int todayDow = day.get(Calendar.DAY_OF_WEEK);
                    int diff = (target - todayDow + 7) % 7;
                    if (diff == 0) diff = 7;
                    day.add(Calendar.DAY_OF_MONTH, diff);
                    d.dayStart = day.getTimeInMillis();
                    return;
                }
            }
        }
    }

    private static void parseTime(String n, Draft d) {
        int h = -1;
        int min = 0;
        boolean explicit24 = false;

        Matcher m = P_TIME_HALF.matcher(n);
        if (m.find()) {
            h = hourValue(m.group(1)) - 1;
            min = 30;
            if (h == 0) h = 12;
        } else if ((m = P_TIME_HM.matcher(n)).find()) {
            h = Integer.parseInt(m.group(1));
            min = Integer.parseInt(m.group(2));
            explicit24 = h >= 13;
        } else if ((m = P_TIME_WORD.matcher(n)).find()) {
            h = hourValue(m.group(1));
        } else if ((m = P_TIME_H.matcher(n)).find()) {
            h = Integer.parseInt(m.group(1));
            explicit24 = h >= 13;
        }
        if (h < 0 || h > 23 || min > 59) return;

        if (!explicit24) {
            boolean morning = n.contains("rano") || n.contains("dopoludn") || n.contains("doobed")
                    || n.contains("predpoludn");
            boolean evening = n.contains("vecer") || n.contains("poobed") || n.contains("popoludn")
                    || n.contains("odpoludn");
            if (evening && h < 12) h += 12;
            else if (!morning && h >= 1 && h <= 6) h += 12;   // "o piatej" = 17:00
        }
        d.minutes = h * 60 + min;
    }

    private static boolean isHourWord(String token) {
        for (String w : HOUR_WORDS) if (w.equals(token)) return true;
        return false;
    }

    private static int hourValue(String s) {
        for (int i = 0; i < HOUR_WORDS.length; i++) if (HOUR_WORDS[i].equals(s)) return i + 1;
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static int monthIndex(String genitive) {
        for (int i = 0; i < MONTHS.length; i++) if (genitive.startsWith(MONTHS[i])) return i;
        return 0;
    }

    private static long dateOrNextYear(Calendar now, int dd, int mm, int yy) {
        Calendar today = startOfDay(now);
        Calendar c = startOfDay(now);
        c.set(Calendar.DAY_OF_MONTH, 1);
        if (yy > 0) c.set(Calendar.YEAR, yy);
        c.set(Calendar.MONTH, mm);
        c.set(Calendar.DAY_OF_MONTH, Math.min(dd, c.getActualMaximum(Calendar.DAY_OF_MONTH)));
        if (yy <= 0 && c.before(today)) c.add(Calendar.YEAR, 1);
        return c.getTimeInMillis();
    }

    private static Calendar startOfDay(Calendar now) {
        Calendar c = (Calendar) now.clone();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c;
    }

    // ===== Dieťa / platba =====

    private static long parseKid(String n, List<KidRef> kids) {
        if (n.contains("obe deti") || n.contains("oboje") || n.contains("obidve")
                || n.contains("obaja") || n.contains("vsetky deti") || containsWord(n, "deti")) {
            return 0L;
        }
        long found = -1L;
        for (KidRef k : kids) {
            String stem = stem(normalize(k.name));
            if (stem.isEmpty()) continue;
            for (String token : n.split("[^a-z0-9]+")) {
                if (token.startsWith(stem)) {
                    if (found >= 0 && found != k.id) return 0L; // obe mená → spoločné
                    found = k.id;
                }
            }
        }
        return found;
    }

    /** Gabika → gabik (Gabiky, Gabike), Alex → alex (Alexa, Alexovi). */
    private static String stem(String name) {
        String s = name.trim();
        if (s.length() > 3 && "aeiouy".indexOf(s.charAt(s.length() - 1)) >= 0) {
            s = s.substring(0, s.length() - 1);
        }
        return s;
    }

    private static PaymentRef findPayment(String n, List<PaymentRef> unpaid, long kidId) {
        PaymentRef best = null;
        for (PaymentRef p : unpaid) {
            if (!titleMatches(n, normalize(p.title))) continue;
            if (best == null) best = p;
            if (kidId > 0 && p.kidId == kidId && best.kidId != kidId) best = p;
        }
        return best;
    }

    private static boolean titleMatches(String sentence, String title) {
        if (title.isEmpty()) return false;
        if (sentence.contains(title)) return true;
        String[] sentenceTokens = sentence.split("[^a-z0-9]+");
        for (String t : title.split("[^a-z0-9]+")) {
            if (t.length() < 3) continue;
            String st = t.length() > 4 ? t.substring(0, t.length() - 1) : t; // tolerancia skloňovania
            for (String s : sentenceTokens) {
                if (s.startsWith(st)) return true;
            }
        }
        return false;
    }

    /** Názov novej platby: veta bez slovies platenia, súm, dátumov, časov a mien detí. */
    private static String leftoverTitle(String raw, List<KidRef> kids) {
        List<String> keep = new ArrayList<>();
        for (String word : raw.split("\\s+")) {
            String w = normalize(word).replaceAll("[^a-z0-9€]", "");
            if (w.isEmpty() || w.matches("\\d.*") || w.equals("€") || w.startsWith("eur")) continue;
            if (w.startsWith("zaplat") || w.startsWith("platb") || w.startsWith("poplat")) continue;
            if (w.equals("o") || w.equals("v") || w.equals("na") || w.equals("za") || w.equals("do")
                    || w.equals("treba") || w.equals("musim") || w.equals("dnes")
                    || w.equals("zajtra") || w.equals("pozajtra")) continue;
            boolean isKid = false;
            for (KidRef k : kids) {
                String st = stem(normalize(k.name));
                if (!st.isEmpty() && w.startsWith(st)) isKid = true;
            }
            if (isKid) continue;
            keep.add(word.replaceAll("[,.;:!?]+$", ""));
        }
        String t = String.join(" ", keep).trim();
        if (t.length() > 60) t = t.substring(0, 60).trim();
        return capitalize(t);
    }

    // ===== Text =====

    /** Pôvodné slovo z vety, ktorého normalizovaný tvar obsahuje {@code key} (napr. "ŠKD"). */
    private static String originalToken(String raw, String key) {
        for (String word : raw.split("\\s+")) {
            String clean = word.replaceAll("[,.;:!?]+$", "");
            if (normalize(clean).contains(key)) return clean.toUpperCase(new Locale("sk", "SK"));
        }
        return null;
    }

    static String normalize(String s) {
        String stripped = DiacriticsUtils.stripDiacritics(s == null ? "" : s);
        return (stripped == null ? "" : stripped).toLowerCase(Locale.ROOT)
                .replaceAll("\\s+", " ").trim();
    }

    private static boolean containsWord(String n, String word) {
        return Pattern.compile("\\b" + Pattern.quote(word) + "\\b").matcher(n).find();
    }

    static String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase(new Locale("sk", "SK")) + s.substring(1);
    }
}
