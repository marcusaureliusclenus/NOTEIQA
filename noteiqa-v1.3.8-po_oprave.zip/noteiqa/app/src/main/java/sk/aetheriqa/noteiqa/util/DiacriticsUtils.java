package sk.aetheriqa.noteiqa.util;

import androidx.annotation.Nullable;

import java.text.Normalizer;
import java.util.regex.Pattern;

/**
 * DiacriticsUtils – odstraňovanie diakritiky pre fulltext vyhľadávanie.
 *
 * Použitie:
 *  - Pri ukladaní poznámky: searchIndex = stripDiacritics(title + " " + body).toLowerCase()
 *  - Pri vyhľadávaní: query = stripDiacritics(userInput).toLowerCase()
 *
 * Tým sa zaručí, že "salat" nájde "Šalát" a "stastny" nájde "Šťastný".
 */
public final class DiacriticsUtils {

    private static final Pattern DIACRITICS_PATTERN =
            Pattern.compile("\\p{InCombiningDiacriticalMarks}+");

    private DiacriticsUtils() {}

    /** Odstráni diakritiku zo Slovenčiny / Češtiny / nemčiny / poľštiny / atď. */
    @Nullable
    public static String stripDiacritics(@Nullable String input) {
        if (input == null) return null;
        String normalized = Normalizer.normalize(input, Normalizer.Form.NFD);
        return DIACRITICS_PATTERN.matcher(normalized).replaceAll("");
    }

    /**
     * Pripraví search index zo všetkých textových polí poznámky.
     * Volá sa pri každom INSERT/UPDATE Note.
     */
    public static String buildSearchIndex(@Nullable String title, @Nullable String body) {
        StringBuilder sb = new StringBuilder();
        if (title != null) sb.append(title).append(' ');
        if (body != null) sb.append(body);
        String stripped = stripDiacritics(sb.toString());
        return stripped == null ? "" : stripped.toLowerCase();
    }
}
