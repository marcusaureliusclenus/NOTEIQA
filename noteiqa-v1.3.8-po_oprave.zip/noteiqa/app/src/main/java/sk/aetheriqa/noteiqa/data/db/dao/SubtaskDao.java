package sk.aetheriqa.noteiqa.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import sk.aetheriqa.noteiqa.data.entity.Subtask;

@Dao
public interface SubtaskDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(Subtask subtask);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<Subtask> subtasks);

    @Update
    int update(Subtask subtask);

    @Delete
    int delete(Subtask subtask);

    @Query("SELECT * FROM subtasks WHERE taskId = :taskId ORDER BY sortOrder ASC")
    LiveData<List<Subtask>> observeForTask(long taskId);

    @Query("SELECT * FROM subtasks WHERE taskId = :taskId ORDER BY sortOrder ASC")
    List<Subtask> getForTask(long taskId);

    @Query("DELETE FROM subtasks WHERE taskId = :taskId")
    void deleteAllForTask(long taskId);

    @Query("UPDATE subtasks SET completed = :completed WHERE id = :id")
    int setCompleted(long id, boolean completed);

    /** Pre Export/Backup — sync read všetkých záznamov. */
    @Query("SELECT * FROM subtasks")
    List<Subtask> getAllSync();
}
