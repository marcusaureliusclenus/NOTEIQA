package sk.aetheriqa.noteiqa.data.repository;

import android.content.Context;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import sk.aetheriqa.noteiqa.data.db.AppDatabase;
import sk.aetheriqa.noteiqa.data.db.dao.WeightDao;
import sk.aetheriqa.noteiqa.data.entity.WeightEntry;
import sk.aetheriqa.noteiqa.data.entity.WeightGoal;
import sk.aetheriqa.noteiqa.util.DateUtils;

/**
 * WeightRepository – business logika modulu Chudnutie.
 *
 * Auto-vypĺňa pri logWeight():
 *  - measuredAt = teraz (ak nie je explicitne zadané)
 *  - dayOfWeek = odvodený z measuredAt cez DateUtils
 *
 * Vystavuje range queries pre graf (period 7d/30d/90d/1Y/Všetko).
 */
public class WeightRepository {

    private static volatile WeightRepository INSTANCE;

    private final WeightDao weightDao;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private WeightRepository(Context ctx) {
        this.weightDao = AppDatabase.getInstance(ctx).weightDao();
    }

    public static WeightRepository getInstance(Context ctx) {
        if (INSTANCE == null) {
            synchronized (WeightRepository.class) {
                if (INSTANCE == null) {
                    INSTANCE = new WeightRepository(ctx.getApplicationContext());
                }
            }
        }
        return INSTANCE;
    }

    // ===== Observable streams =====

    public LiveData<List<WeightEntry>> observeAll() {
        return weightDao.observeAll();
    }

    public LiveData<List<WeightEntry>> observeForPeriod(DateUtils.Period period) {
        long now = System.currentTimeMillis();
        long from = DateUtils.startOfPeriod(period, now);
        return weightDao.observeInRange(from, now);
    }

    public LiveData<List<WeightEntry>> observeLastN(int n) {
        return weightDao.observeLastN(n);
    }

    /** Najnovšie meranie alebo null. Pre dashboard "Posledné váženie". */
    public LiveData<WeightEntry> observeLatest() {
        return androidx.lifecycle.Transformations.map(
                weightDao.observeLastN(1),
                list -> (list == null || list.isEmpty()) ? null : list.get(0));
    }

    public LiveData<Double> observeMin(DateUtils.Period period) {
        long now = System.currentTimeMillis();
        return weightDao.observeMin(DateUtils.startOfPeriod(period, now), now);
    }

    public LiveData<Double> observeMax(DateUtils.Period period) {
        long now = System.currentTimeMillis();
        return weightDao.observeMax(DateUtils.startOfPeriod(period, now), now);
    }

    public LiveData<Double> observeAvg(DateUtils.Period period) {
        long now = System.currentTimeMillis();
        return weightDao.observeAvg(DateUtils.startOfPeriod(period, now), now);
    }

    public LiveData<WeightGoal> observeActiveGoal() {
        return weightDao.observeActiveGoal();
    }

    // ===== Mutations =====

    /**
     * Záznam váhy s auto-vyplnením času a dňa v týždni.
     *
     * @param kg hmotnosť
     * @param note voliteľná poznámka (napr. "menzes !", "ráno nalačno")
     */
    public void logWeight(double kg, String note) {
        logWeight(kg, note, 0);
    }

    /** v0.4.0 – varianta s mood bitmaskou. */
    public void logWeight(double kg, String note, int moodFlags) {
        executor.execute(() -> {
            long now = System.currentTimeMillis();
            int dow = DateUtils.isoDayOfWeek(now);
            WeightEntry entry = new WeightEntry(kg, now, dow, note);
            entry.moodFlags = moodFlags;
            weightDao.insert(entry);
        });
    }

    /** Pre prípad spätného doplnenia záznamu (manuálne zadaný dátum). */
    public void logWeightAt(double kg, long measuredAt, String note) {
        executor.execute(() -> {
            int dow = DateUtils.isoDayOfWeek(measuredAt);
            WeightEntry entry = new WeightEntry(kg, measuredAt, dow, note);
            weightDao.insert(entry);
        });
    }

    public void update(WeightEntry entry) {
        executor.execute(() -> weightDao.update(entry));
    }

    public void delete(WeightEntry entry) {
        executor.execute(() -> weightDao.delete(entry));
    }

    public void setGoal(double startKg, double targetKg, long targetDate) {
        executor.execute(() -> {
            weightDao.deactivateAllGoals();
            WeightGoal goal = new WeightGoal();
            goal.startKg = startKg;
            goal.targetKg = targetKg;
            goal.targetDate = targetDate;
            goal.startedAt = System.currentTimeMillis();
            goal.active = true;
            weightDao.insertGoal(goal);
        });
    }
}
