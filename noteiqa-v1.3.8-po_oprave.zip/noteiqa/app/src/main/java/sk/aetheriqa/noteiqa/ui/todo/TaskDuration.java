package sk.aetheriqa.noteiqa.ui.todo;

import android.content.Context;

import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Task;

/**
 * TaskDuration – v1.3.8 — texty pre „Trvanie úlohy“ (editor, detail, riadok v zozname).
 */
final class TaskDuration {

    private TaskDuration() {}

    /** 15 → "15 min.", 60 → "1 hodina", 120 → "2 hodiny". */
    static String formatMinutes(Context ctx, int minutes) {
        if (minutes == 60) return ctx.getString(R.string.task_duration_1h);
        if (minutes % 60 == 0) return ctx.getString(R.string.task_duration_hours, minutes / 60);
        return ctx.getString(R.string.task_duration_min, minutes);
    }

    /** Text do editora: "Bez konkrétneho času" / "45 min." / "do 16:40". */
    static String label(Context ctx, Task t) {
        if (t.endTimeMinutes != null) return ctx.getString(R.string.task_duration_until, hm(t.endTimeMinutes));
        if (t.durationMinutes != null) return formatMinutes(ctx, t.durationMinutes);
        return ctx.getString(R.string.task_due_time_unset);
    }

    /**
     * Čas v podtitule zoznamu: "9:00–9:45", "9:00–16:40", "do 16:40", "9:00 · 45 min."
     * alebo len "9:00". null, ak úloha nemá čas ani trvanie.
     */
    static String timeRange(Context ctx, Task t) {
        Integer start = t.dueTimeMinutes;
        Integer end = t.endTimeMinutes;
        if (end == null && start != null && t.durationMinutes != null) {
            int e = start + t.durationMinutes;
            if (e < 24 * 60) end = e;
        }
        if (start != null && end != null && end > start) return hm(start) + "–" + hm(end);
        if (start == null && t.endTimeMinutes != null) return ctx.getString(R.string.task_duration_until, hm(t.endTimeMinutes));
        if (start == null && t.durationMinutes != null) return formatMinutes(ctx, t.durationMinutes);
        if (start != null && t.durationMinutes != null) return hm(start) + " · " + formatMinutes(ctx, t.durationMinutes);
        return start != null ? hm(start) : null;
    }

    static String hm(int minutes) {
        return String.format(Locale.getDefault(), "%d:%02d", minutes / 60, minutes % 60);
    }
}
