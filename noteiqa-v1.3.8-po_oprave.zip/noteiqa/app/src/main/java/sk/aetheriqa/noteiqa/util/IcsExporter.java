package sk.aetheriqa.noteiqa.util;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;

import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.entity.Task;

/**
 * IcsExporter – vyrobí jednoduchý ICS (RFC 5545) kalendárny event z Tasku
 * a otvorí share/Open intent, aby si mohol Marek event pridať do
 * Google Calendar / Outlook / iného kalendára.
 *
 * Dĺžka eventu:
 *  - ak Task má dueTimeMinutes → jednohodinový event začínajúci v ten čas
 *  - inak → all-day event v dueDate
 */
public final class IcsExporter {

    private static final String AUTHORITY_SUFFIX = ".fileprovider";
    private static final String DTFORMAT_UTC = "yyyyMMdd'T'HHmmss'Z'";
    private static final String DTFORMAT_DATE = "yyyyMMdd";

    private IcsExporter() {}

    /**
     * Vytvorí ICS súbor v cache a vráti share intent.
     * Vracia null ak Task nemá dueDate (nemôžeme vyrobiť event bez dátumu).
     */
    @Nullable
    public static Intent buildShareIntent(Context ctx, Task task) {
        if (task.dueDate == null || task.dueDate == 0L) return null;

        String summary = TextUtils.isEmpty(task.title)
                ? ctx.getString(R.string.ics_default_task_title) : task.title;
        String description = TextUtils.isEmpty(task.note) ? "" : task.note;

        StringBuilder ics = new StringBuilder();
        ics.append("BEGIN:VCALENDAR\r\n");
        ics.append("VERSION:2.0\r\n");
        ics.append("PRODID:-//AETHERIQA//Noteiqa//SK\r\n");
        ics.append("CALSCALE:GREGORIAN\r\n");
        ics.append("METHOD:PUBLISH\r\n");
        ics.append("BEGIN:VEVENT\r\n");
        ics.append("UID:").append(UUID.randomUUID().toString()).append("@noteiqa\r\n");

        // DTSTAMP – kedy bol event vyrobený, vždy v UTC
        SimpleDateFormat utc = new SimpleDateFormat(DTFORMAT_UTC, Locale.US);
        utc.setTimeZone(TimeZone.getTimeZone("UTC"));
        ics.append("DTSTAMP:").append(utc.format(new Date())).append("\r\n");

        if (task.dueTimeMinutes != null) {
            // Časový event – DTSTART + DTEND s konkrétnym timezone (lokálny UTC posun)
            Calendar start = Calendar.getInstance();
            start.setTimeInMillis(task.dueDate);
            start.set(Calendar.HOUR_OF_DAY, task.dueTimeMinutes / 60);
            start.set(Calendar.MINUTE, task.dueTimeMinutes % 60);
            start.set(Calendar.SECOND, 0);
            start.set(Calendar.MILLISECOND, 0);

            Calendar end = (Calendar) start.clone();
            end.add(Calendar.HOUR_OF_DAY, 1);

            ics.append("DTSTART:").append(utc.format(start.getTime())).append("\r\n");
            ics.append("DTEND:").append(utc.format(end.getTime())).append("\r\n");
        } else {
            // All-day event
            SimpleDateFormat dateOnly = new SimpleDateFormat(DTFORMAT_DATE, Locale.US);
            String day = dateOnly.format(new Date(task.dueDate));

            // Pre all-day event musí byť DTSTART vo formáte VALUE=DATE
            ics.append("DTSTART;VALUE=DATE:").append(day).append("\r\n");
            // DTEND je deň po (exclusive)
            Calendar nextDay = Calendar.getInstance();
            nextDay.setTimeInMillis(task.dueDate);
            nextDay.add(Calendar.DAY_OF_MONTH, 1);
            ics.append("DTEND;VALUE=DATE:").append(dateOnly.format(nextDay.getTime())).append("\r\n");
        }

        ics.append("SUMMARY:").append(escape(summary)).append("\r\n");
        if (!description.isEmpty()) {
            ics.append("DESCRIPTION:").append(escape(description)).append("\r\n");
        }

        // Pripomenutie 15 min vopred (default)
        ics.append("BEGIN:VALARM\r\n");
        ics.append("ACTION:DISPLAY\r\n");
        ics.append("DESCRIPTION:").append(escape(summary)).append("\r\n");
        ics.append("TRIGGER:-PT15M\r\n");
        ics.append("END:VALARM\r\n");

        ics.append("END:VEVENT\r\n");
        ics.append("END:VCALENDAR\r\n");

        return writeAndShare(ctx, "task_" + task.id + ".ics", ics.toString(), summary);
    }

    /**
     * v1.2.0 — ICS pre udalosť dieťaťa (Deti → Kalendár → podržať → Pridať do kalendára).
     *  - celodenná: DTSTART/DTEND ako VALUE=DATE, DTEND exkluzívne (deň po konci)
     *  - s časom: DTEND = endDate, alebo +1 h ak koniec nie je zadaný
     */
    @Nullable
    public static Intent buildShareIntent(Context ctx, KidEvent event) {
        if (event.startDate <= 0L) return null;
        String summary = event.title;

        StringBuilder ics = new StringBuilder();
        ics.append("BEGIN:VCALENDAR\r\n");
        ics.append("VERSION:2.0\r\n");
        ics.append("PRODID:-//AETHERIQA//Noteiqa//SK\r\n");
        ics.append("CALSCALE:GREGORIAN\r\n");
        ics.append("METHOD:PUBLISH\r\n");
        ics.append("BEGIN:VEVENT\r\n");
        ics.append("UID:").append(UUID.randomUUID().toString()).append("@noteiqa\r\n");

        SimpleDateFormat utc = new SimpleDateFormat(DTFORMAT_UTC, Locale.US);
        utc.setTimeZone(TimeZone.getTimeZone("UTC"));
        ics.append("DTSTAMP:").append(utc.format(new Date())).append("\r\n");

        if (event.allDay) {
            SimpleDateFormat dateOnly = new SimpleDateFormat(DTFORMAT_DATE, Locale.US);
            long lastDay = event.endDate > event.startDate ? event.endDate : event.startDate;
            Calendar end = Calendar.getInstance();
            end.setTimeInMillis(lastDay);
            end.add(Calendar.DAY_OF_MONTH, 1);
            ics.append("DTSTART;VALUE=DATE:").append(dateOnly.format(new Date(event.startDate))).append("\r\n");
            ics.append("DTEND;VALUE=DATE:").append(dateOnly.format(end.getTime())).append("\r\n");
        } else {
            long end = event.endDate > event.startDate
                    ? event.endDate : event.startDate + 60L * 60 * 1000;
            ics.append("DTSTART:").append(utc.format(new Date(event.startDate))).append("\r\n");
            ics.append("DTEND:").append(utc.format(new Date(end))).append("\r\n");
        }

        ics.append("SUMMARY:").append(escape(summary)).append("\r\n");
        if (!TextUtils.isEmpty(event.location)) {
            ics.append("LOCATION:").append(escape(event.location)).append("\r\n");
        }
        if (!TextUtils.isEmpty(event.note)) {
            ics.append("DESCRIPTION:").append(escape(event.note)).append("\r\n");
        }
        ics.append("END:VEVENT\r\n");
        ics.append("END:VCALENDAR\r\n");

        return writeAndShare(ctx, "kid_event_" + event.id + ".ics", ics.toString(), summary);
    }

    /** Uloží ICS do cache/ics a vráti chooser intent (FileProvider). */
    @Nullable
    private static Intent writeAndShare(Context ctx, String fileName, String ics, String summary) {
        try {
            File cacheDir = new File(ctx.getCacheDir(), "ics");
            if (!cacheDir.exists()) cacheDir.mkdirs();
            File file = new File(cacheDir, fileName);
            try (FileWriter w = new FileWriter(file)) {
                w.write(ics);
            }

            Uri uri = FileProvider.getUriForFile(
                    ctx,
                    ctx.getPackageName() + AUTHORITY_SUFFIX,
                    file);

            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/calendar");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_SUBJECT, summary);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            return Intent.createChooser(send, ctx.getString(R.string.task_action_to_calendar));
        } catch (IOException e) {
            return null;
        }
    }

    /** Escape dvojbodky, čiarky, bodkočiarky, nový riadok podľa RFC 5545. */
    private static String escape(String text) {
        return text
                .replace("\\", "\\\\")
                .replace("\n", "\\n")
                .replace("\r", "")
                .replace(",", "\\,")
                .replace(";", "\\;");
    }
}
