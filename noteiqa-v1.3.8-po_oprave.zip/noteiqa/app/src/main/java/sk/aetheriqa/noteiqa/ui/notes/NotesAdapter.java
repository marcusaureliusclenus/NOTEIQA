package sk.aetheriqa.noteiqa.ui.notes;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.List;
import java.util.Map;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.ChecklistItem;
import sk.aetheriqa.noteiqa.data.entity.Note;
import sk.aetheriqa.noteiqa.util.DateUtils;

/**
 * NotesAdapter v2 – cards pre Poznámky aj Zoznamy.
 *
 *  - TYPE_TEXT karta: zobrazí body preview + voliteľný image thumbnail
 *  - TYPE_CHECKLIST karta: zobrazí prvé 3 položky checklistu s preškrtnutím
 *    pre dokončené
 *
 * Items sú v adaptore zoradené podľa updatedAt DESC (uhrá ich Fragment cez
 * sortedTasks LiveData; my len rendrujeme čo dostaneme).
 */
public class NotesAdapter extends ListAdapter<Note, NotesAdapter.NoteVH> {

    public interface OnNoteClickListener {
        void onNoteClick(Note note);
        void onNoteLongClick(Note note, View anchor);
    }

    private final OnNoteClickListener listener;

    /** noteId → list položiek pre TYPE_CHECKLIST karty. Setuje Fragment. */
    private Map<Long, List<ChecklistItem>> checklistsByNoteId = new java.util.HashMap<>();

    public NotesAdapter(OnNoteClickListener listener) {
        super(DIFF);
        this.listener = listener;
    }

    public void setChecklistMap(Map<Long, List<ChecklistItem>> map) {
        this.checklistsByNoteId = map == null ? new java.util.HashMap<>() : map;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public NoteVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_note, parent, false);
        return new NoteVH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteVH h, int position) {
        Note n = getItem(position);
        Context ctx = h.itemView.getContext();

        // Title
        if (TextUtils.isEmpty(n.title)) {
            h.title.setText(R.string.editor_title_default);
        } else {
            h.title.setText(n.title);
        }

        // Type icon (vidíme či je to Zoznam)
        if (n.type == Note.TYPE_CHECKLIST) {
            h.typeIcon.setVisibility(View.VISIBLE);
            h.typeIcon.setImageResource(R.drawable.ic_todo);
        } else {
            h.typeIcon.setVisibility(View.GONE);
        }

        // Body / Checklist preview
        if (n.type == Note.TYPE_CHECKLIST) {
            h.body.setVisibility(View.GONE);
            h.checklistPreview.setVisibility(View.VISIBLE);
            renderChecklistPreview(ctx, h.checklistPreview, n.id);
        } else {
            h.checklistPreview.setVisibility(View.GONE);
            if (TextUtils.isEmpty(n.body)) {
                h.body.setVisibility(View.GONE);
            } else {
                h.body.setVisibility(View.VISIBLE);
                h.body.setText(n.body);
            }
        }

        // Image thumbnail
        if (!TextUtils.isEmpty(n.attachmentImagePath)
                && new File(n.attachmentImagePath).exists()) {
            h.imageThumb.setVisibility(View.VISIBLE);
            // Lazy load — sample bitmap aby sme nedrhli pamäť
            try {
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inSampleSize = 4; // 1/4 rozmer
                h.imageThumb.setImageBitmap(BitmapFactory.decodeFile(n.attachmentImagePath, opts));
            } catch (OutOfMemoryError oom) {
                h.imageThumb.setVisibility(View.GONE);
            }
        } else {
            h.imageThumb.setVisibility(View.GONE);
            h.imageThumb.setImageDrawable(null);
        }

        // Meta
        long ts = n.updatedAt > 0 ? n.updatedAt : n.createdAt;
        h.meta.setText(DateUtils.formatWeightTimestamp(ts));

        // Pin
        h.pinIndicator.setVisibility(n.pinned ? View.VISIBLE : View.GONE);

        h.cardRoot.setOnClickListener(v -> listener.onNoteClick(n));
        h.cardRoot.setOnLongClickListener(v -> {
            listener.onNoteLongClick(n, v);
            return true;
        });
    }

    private void renderChecklistPreview(Context ctx, LinearLayout container, long noteId) {
        container.removeAllViews();
        List<ChecklistItem> items = checklistsByNoteId.get(noteId);
        if (items == null || items.isEmpty()) {
            // Žiadne položky → skryjeme preview úplne
            container.setVisibility(View.GONE);
            return;
        }

        LayoutInflater inf = LayoutInflater.from(ctx);
        int max = Math.min(3, items.size());
        for (int i = 0; i < max; i++) {
            ChecklistItem it = items.get(i);
            View row = inf.inflate(R.layout.item_checklist_preview_row, container, false);
            ImageView icon = row.findViewById(R.id.preview_check_icon);
            TextView text = row.findViewById(R.id.preview_check_text);

            // Použijeme jednoduché vector ikony
            if (it.checked) {
                icon.setImageResource(R.drawable.ic_check);
                icon.setColorFilter(ContextCompat.getColor(ctx, R.color.lea_gold));
                text.setText(it.text);
                text.setPaintFlags(text.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                text.setAlpha(0.55f);
            } else {
                icon.setImageResource(R.drawable.ic_circle_unchecked);
                icon.setColorFilter(ContextCompat.getColor(ctx, R.color.lea_gold));
                text.setText(it.text);
                text.setPaintFlags(text.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
                text.setAlpha(1f);
            }
            container.addView(row);
        }
        if (items.size() > max) {
            View more = inf.inflate(R.layout.item_checklist_preview_row, container, false);
            ImageView icon = more.findViewById(R.id.preview_check_icon);
            TextView text = more.findViewById(R.id.preview_check_text);
            icon.setVisibility(View.INVISIBLE);
            text.setText("+ " + (items.size() - max) + " ďalšie");
            text.setTextColor(ContextCompat.getColor(ctx, R.color.text_secondary));
            container.addView(more);
        }
    }

    static class NoteVH extends RecyclerView.ViewHolder {
        final View cardRoot;
        final ImageView typeIcon;
        final TextView title;
        final TextView body;
        final LinearLayout checklistPreview;
        final ImageView imageThumb;
        final TextView meta;
        final ImageView pinIndicator;

        NoteVH(@NonNull View itemView) {
            super(itemView);
            cardRoot = itemView.findViewById(R.id.note_card_root);
            typeIcon = itemView.findViewById(R.id.note_type_icon);
            title = itemView.findViewById(R.id.note_title);
            body = itemView.findViewById(R.id.note_body);
            checklistPreview = itemView.findViewById(R.id.note_checklist_preview);
            imageThumb = itemView.findViewById(R.id.note_image_thumb);
            meta = itemView.findViewById(R.id.note_meta);
            pinIndicator = itemView.findViewById(R.id.note_pin_indicator);
        }
    }

    private static final DiffUtil.ItemCallback<Note> DIFF = new DiffUtil.ItemCallback<Note>() {
        @Override
        public boolean areItemsTheSame(@NonNull Note a, @NonNull Note b) {
            return a.id == b.id;
        }

        @Override
        public boolean areContentsTheSame(@NonNull Note a, @NonNull Note b) {
            return a.updatedAt == b.updatedAt
                    && a.pinned == b.pinned
                    && a.state == b.state
                    && a.type == b.type
                    && TextUtils.equals(a.title, b.title)
                    && TextUtils.equals(a.body, b.body)
                    && TextUtils.equals(a.attachmentImagePath, b.attachmentImagePath);
        }
    };
}
