package sk.aetheriqa.noteiqa.data.entity;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;

/**
 * NoteTagCrossRef – junction table pre M:N vzťah medzi Note a Tag.
 *
 * Pri zmazaní Note alebo Tag sa automaticky čistí (CASCADE).
 */
@Entity(
    tableName = "note_tags",
    primaryKeys = {"noteId", "tagId"},
    indices = {@Index("tagId"), @Index("noteId")},
    foreignKeys = {
        @ForeignKey(
            entity = Note.class,
            parentColumns = "id",
            childColumns = "noteId",
            onDelete = ForeignKey.CASCADE
        ),
        @ForeignKey(
            entity = Tag.class,
            parentColumns = "id",
            childColumns = "tagId",
            onDelete = ForeignKey.CASCADE
        )
    }
)
public class NoteTagCrossRef {
    public long noteId;
    public long tagId;

    public NoteTagCrossRef() {}

    public NoteTagCrossRef(long noteId, long tagId) {
        this.noteId = noteId;
        this.tagId = tagId;
    }
}
