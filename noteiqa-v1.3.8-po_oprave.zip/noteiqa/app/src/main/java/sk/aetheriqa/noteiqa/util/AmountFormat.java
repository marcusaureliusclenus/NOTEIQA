package sk.aetheriqa.noteiqa.util;

import androidx.annotation.Nullable;

import java.util.Locale;

/**
 * AmountFormat – v1.3.5 — slovenský zápis súm: desatinná čiarka ("32,10").
 *
 * Čistá Java (bez Android API) — testuje sa JVM testom AmountFormatTest.
 * Písanie v poli rieši {@link DecimalCommaInput}, ktorý volá {@link #normalizeTyping}.
 */
public final class AmountFormat {

    private AmountFormat() {}

    /**
     * Úprava rozpísaného textu: bodka → čiarka, len jedna čiarka, najviac
     * {@code maxDecimals} číslic za ňou, iné znaky preč. "32.1" → "32,1", ",5" → "0,5".
     */
    public static String normalizeTyping(@Nullable String s, int maxDecimals) {
        if (s == null) return "";
        StringBuilder out = new StringBuilder(s.length() + 1);
        boolean comma = false;
        int decimals = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9') {
                if (comma) {
                    if (decimals >= maxDecimals) continue;
                    decimals++;
                }
                out.append(c);
            } else if ((c == ',' || c == '.') && !comma && maxDecimals > 0) {
                if (out.length() == 0) out.append('0');
                out.append(',');
                comma = true;
            }
        }
        return out.toString();
    }

    /** "32,10" / "32.10" / "32" → 32.1; prázdne alebo nečíslo → null. */
    @Nullable
    public static Double parse(@Nullable String s) {
        if (s == null) return null;
        String v = s.trim().replace(" ", "").replace("\u00A0", "").replace(',', '.');
        if (v.isEmpty()) return null;
        try {
            return Double.parseDouble(v);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** 32.1 → "32,10" (bez meny). */
    public static String format(double eur) {
        return String.format(Locale.US, "%.2f", eur).replace('.', ',');
    }
}
