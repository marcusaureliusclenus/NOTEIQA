package sk.aetheriqa.noteiqa.data.repository;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * UserProfile – jednoduchý wrapper nad SharedPreferences pre dashboard.
 *
 * Obsahuje:
 *  - meno (default "" → prejaví sa ako "Ahoj!" alebo placeholder)
 *  - cesta k profilovému foto (default null, kruhový placeholder)
 *
 * Toto NIE JE Room entity — sú to dva primitive fieldy a SharedPreferences je
 * efektívnejší (žiadne migrácie, žiadne LiveData potrebné).
 */
public final class UserProfile {

    private static final String PREFS_NAME = "noteiqa_user_profile";
    private static final String KEY_NAME = "user_name";
    private static final String KEY_AVATAR_PATH = "avatar_path";

    private static volatile UserProfile INSTANCE;

    private final SharedPreferences prefs;

    private UserProfile(Context ctx) {
        this.prefs = ctx.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static UserProfile getInstance(@NonNull Context ctx) {
        if (INSTANCE == null) {
            synchronized (UserProfile.class) {
                if (INSTANCE == null) {
                    INSTANCE = new UserProfile(ctx);
                }
            }
        }
        return INSTANCE;
    }

    @NonNull
    public String getName() {
        return prefs.getString(KEY_NAME, "");
    }

    public void setName(@NonNull String name) {
        prefs.edit().putString(KEY_NAME, name.trim()).apply();
    }

    public boolean hasName() {
        return !TextUtils.isEmpty(getName());
    }

    @Nullable
    public String getAvatarPath() {
        return prefs.getString(KEY_AVATAR_PATH, null);
    }

    public void setAvatarPath(@Nullable String path) {
        SharedPreferences.Editor e = prefs.edit();
        if (TextUtils.isEmpty(path)) {
            e.remove(KEY_AVATAR_PATH);
        } else {
            e.putString(KEY_AVATAR_PATH, path);
        }
        e.apply();
    }

    /**
     * Listener pre Home fragment — keď sa zmení meno alebo foto v Nastaveniach,
     * Home sa môže okamžite refreshnúť.
     */
    public void registerChangeListener(SharedPreferences.OnSharedPreferenceChangeListener l) {
        prefs.registerOnSharedPreferenceChangeListener(l);
    }

    public void unregisterChangeListener(SharedPreferences.OnSharedPreferenceChangeListener l) {
        prefs.unregisterOnSharedPreferenceChangeListener(l);
    }
}
