package sk.aetheriqa.noteiqa.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import sk.aetheriqa.noteiqa.data.entity.ChecklistItem;

@Dao
public interface ChecklistDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(ChecklistItem item);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<ChecklistItem> items);

    @Update
    int update(ChecklistItem item);

    @Delete
    int delete(ChecklistItem item);

    @Query("SELECT * FROM checklist_items WHERE noteId = :noteId ORDER BY sortOrder ASC")
    LiveData<List<ChecklistItem>> observeForNote(long noteId);

    @Query("SELECT * FROM checklist_items WHERE noteId = :noteId ORDER BY sortOrder ASC")
    List<ChecklistItem> getForNote(long noteId);

    @Query("DELETE FROM checklist_items WHERE noteId = :noteId")
    void deleteAllForNote(long noteId);

    @Query("UPDATE checklist_items SET checked = :checked, updatedAt = :now WHERE id = :id")
    int setChecked(long id, boolean checked, long now);

    /** Pre Export/Backup — sync read všetkých záznamov. */
    @Query("SELECT * FROM checklist_items")
    List<ChecklistItem> getAllSync();
}
