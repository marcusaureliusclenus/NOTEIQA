package sk.aetheriqa.noteiqa.util;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.sqlite.db.SupportSQLiteDatabase;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.db.AppDatabase;
import sk.aetheriqa.noteiqa.data.entity.ChecklistItem;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.entity.Note;
import sk.aetheriqa.noteiqa.data.entity.NoteTagCrossRef;
import sk.aetheriqa.noteiqa.data.entity.Reminder;
import sk.aetheriqa.noteiqa.data.entity.Subtask;
import sk.aetheriqa.noteiqa.data.entity.Tag;
import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.data.entity.TaskCategory;
import sk.aetheriqa.noteiqa.data.entity.Template;
import sk.aetheriqa.noteiqa.data.entity.WeightEntry;
import sk.aetheriqa.noteiqa.data.entity.WeightGoal;
import sk.aetheriqa.noteiqa.data.preferences.UserPreferences;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.data.repository.TaskRepository;
import sk.aetheriqa.noteiqa.notification.KidReminderScheduler;
import sk.aetheriqa.noteiqa.notification.ReminderScheduler;

/**
 * BackupImporter – v1.2.0 — obnova zo ZIP zálohy, ktorú vyrobil {@link BackupExporter}.
 *
 * Postup:
 *  1. ZIP sa rozbalí do cache/restore (ochrana proti "zip slip" ceste mimo zložky)
 *  2. data.json → kontrola format_version (1) a schema_version (5 … AppDatabase.VERSION)
 *  3. pred zmazaním sa vyrobí bezpečnostná záloha aktuálnych dát do cache/backup
 *  4. v JEDNEJ Room transakcii: zmazanie + vloženie tabuliek v poradí kvôli FK.
 *     Tabuľky, ktoré v zálohe nie sú (staršie zálohy bez Deti), ostanú nedotknuté.
 *  5. obnova príloh, profilového fota, quotes.md a mena
 *  6. re-schedule pripomienok (rovnako ako BootReceiver)
 *
 * JSON → entita ide reflexiou, zrkadlo k BackupExporter.entityToJson:
 * public, nie static, nie transient polia. Pole, ktoré v JSON chýba (staršia
 * schéma), dostane default hodnotu z novej inštancie entity.
 */
public final class BackupImporter {

    public interface OnImportListener {
        void onSuccess(ImportStats stats);
        void onError(String message);
    }

    public static class ImportStats {
        public int taskCount;
        public int noteCount;
        public int weightCount;
        public int kidPaymentCount;
        public int kidEventCount;
        public int attachmentCount;
    }

    /** Chyba s už preloženou (slovenskou) správou pre používateľa. */
    private static class ImportException extends Exception {
        ImportException(String message) { super(message); }
    }

    /** JSON kľúč → tabuľka → entita. Poradie = poradie vkladania (rodičia pred deťmi). */
    private static final Object[][] TABLES = {
            {"kids",            "kids",            Kid.class},
            {"kid_payments",    "kid_payments",    KidPayment.class},
            {"kid_events",      "kid_events",      KidEvent.class},
            {"categories",      "task_categories", TaskCategory.class},
            {"tasks",           "tasks",           Task.class},
            {"subtasks",        "subtasks",        Subtask.class},
            {"notes",           "notes",           Note.class},
            {"tags",            "tags",            Tag.class},
            {"checklist_items", "checklist_items", ChecklistItem.class},
            {"note_tags",       "note_tags",       NoteTagCrossRef.class},
            {"reminders",       "reminders",       Reminder.class},
            {"weight_entries",  "weight_entries",  WeightEntry.class},
            {"weight_goals",    "weight_goals",    WeightGoal.class},
            {"templates",       "templates",       Template.class},
    };

    private static final int MIN_SCHEMA_VERSION = 5;
    private static final String QUOTES_FILENAME = "motivational_quotes.md";

    private BackupImporter() {}

    /** Spustí import v background threade; callbacky idú na main thread. */
    public static void importAsync(Context ctx, Uri zipUri, OnImportListener listener) {
        Context appCtx = ctx.getApplicationContext();
        new Thread(() -> {
            Handler ui = new Handler(Looper.getMainLooper());
            try {
                ImportStats stats = doImport(appCtx, zipUri);
                ui.post(() -> listener.onSuccess(stats));
            } catch (ImportException e) {
                ui.post(() -> listener.onError(e.getMessage()));
            } catch (Exception e) {
                String detail = e.getMessage() == null
                        ? e.getClass().getSimpleName() : e.getMessage();
                String msg = appCtx.getString(R.string.restore_error_generic, detail);
                ui.post(() -> listener.onError(msg));
            }
        }, "BackupImporter").start();
    }

    private static ImportStats doImport(Context ctx, Uri zipUri) throws Exception {
        File workDir = new File(ctx.getCacheDir(), "restore");
        deleteRecursive(workDir);
        if (!workDir.mkdirs()) {
            throw new ImportException(ctx.getString(R.string.restore_error_io));
        }

        try {
            // 1) Rozbaľ ZIP
            unzip(ctx, zipUri, workDir);

            // 2) data.json + kontrola verzií
            File dataFile = new File(workDir, "data.json");
            if (!dataFile.isFile()) {
                throw new ImportException(ctx.getString(R.string.restore_error_no_data));
            }
            JSONObject root;
            try {
                root = new JSONObject(readText(dataFile));
            } catch (JSONException e) {
                throw new ImportException(ctx.getString(R.string.restore_error_bad_json));
            }
            int format = root.optInt("format_version", -1);
            if (format != BackupExporter.FORMAT_VERSION) {
                throw new ImportException(ctx.getString(R.string.restore_error_format, format));
            }
            int schema = root.optInt("schema_version", -1);
            if (schema < MIN_SCHEMA_VERSION || schema > AppDatabase.VERSION) {
                throw new ImportException(ctx.getString(R.string.restore_error_schema, schema));
            }

            // 3) Bezpečnostná záloha aktuálneho stavu (nie povinná — chyba ju len preskočí)
            try {
                BackupExporter.exportSync(ctx);
            } catch (Exception ignored) {
                // pokračujeme; používateľ importu už potvrdil prepísanie
            }

            // 4) Zruš alarmy starých dát, aby nezvonili pre neexistujúce id
            cancelExistingAlarms(ctx);

            // 5) DB v jednej transakcii
            File attachDir = ImageStorage.getDir(ctx);
            ImportStats stats = new ImportStats();
            writeDatabase(ctx, root, attachDir, stats);

            // 6) Súbory + preferencie
            restoreFiles(ctx, workDir, attachDir, root, stats);

            // 7) Seed detí, ak záloha deti nemala a tabuľka je prázdna; potom pripomienky
            KidRepository kidRepo = KidRepository.getInstance(ctx);
            kidRepo.ensureKidsSeeded();
            kidRepo.reschedulePendingReminders();
            TaskRepository.getInstance(ctx).getActiveRemindersAsync(tasks -> {
                if (tasks == null) return;
                for (Task t : tasks) ReminderScheduler.schedule(ctx, t);
            });

            return stats;
        } finally {
            deleteRecursive(workDir);
        }
    }

    // ===== DB =====

    private static void writeDatabase(Context ctx, JSONObject root, File attachDir,
                                      ImportStats stats) {
        AppDatabase db = AppDatabase.getInstance(ctx);
        db.runInTransaction(() -> {
            SupportSQLiteDatabase sdb = db.getOpenHelper().getWritableDatabase();

            // Mazanie v opačnom poradí (deti pred rodičmi), len tabuľky prítomné v zálohe
            for (int i = TABLES.length - 1; i >= 0; i--) {
                if (root.has((String) TABLES[i][0])) {
                    sdb.execSQL("DELETE FROM `" + TABLES[i][1] + "`");
                }
            }

            for (Object[] t : TABLES) {
                String key = (String) t[0];
                if (!root.has(key)) continue;
                JSONArray arr = root.optJSONArray(key);
                if (arr == null) continue;
                String table = (String) t[1];
                Class<?> klass = (Class<?>) t[2];

                for (int i = 0; i < arr.length(); i++) {
                    JSONObject obj = arr.optJSONObject(i);
                    if (obj == null) continue;
                    Object entity;
                    try {
                        entity = jsonToEntity(obj, klass);
                    } catch (ReflectiveOperationException e) {
                        throw new IllegalStateException(klass.getSimpleName() + ": " + e.getMessage(), e);
                    }
                    fixUpEntity(entity, attachDir);
                    sdb.insert(table, SQLiteDatabase.CONFLICT_REPLACE, entityToContentValues(entity));
                }

                switch (key) {
                    case "tasks": stats.taskCount = arr.length(); break;
                    case "notes": stats.noteCount = arr.length(); break;
                    case "weight_entries": stats.weightCount = arr.length(); break;
                    case "kid_payments": stats.kidPaymentCount = arr.length(); break;
                    case "kid_events": stats.kidEventCount = arr.length(); break;
                    default: break;
                }
            }
        });
    }

    /** Úpravy dát zo starších záloh / iného zariadenia. */
    private static void fixUpEntity(Object entity, File attachDir) {
        if (entity instanceof KidEvent) {
            // Zálohy pred 1.2.0: kidId = 0 znamenalo "všetky deti" → NULL
            KidEvent e = (KidEvent) entity;
            if (e.kidId != null && e.kidId <= 0L) e.kidId = null;
        } else if (entity instanceof Note) {
            // Cesta k prílohe je absolútna — na novom zariadení ju prepíšeme na lokálnu zložku
            Note n = (Note) entity;
            if (n.attachmentImagePath != null && !n.attachmentImagePath.isEmpty()) {
                n.attachmentImagePath =
                        new File(attachDir, new File(n.attachmentImagePath).getName()).getAbsolutePath();
            }
        }
    }

    /** Zrkadlo k BackupExporter.entityToJson. */
    @NonNull
    static Object jsonToEntity(JSONObject obj, Class<?> klass) throws ReflectiveOperationException {
        Object entity = klass.getDeclaredConstructor().newInstance();
        for (Field f : klass.getDeclaredFields()) {
            if (!isPersistable(f)) continue;
            String name = f.getName();
            if (!obj.has(name)) continue; // staršia schéma → default z konštruktora
            Class<?> type = f.getType();

            if (obj.isNull(name)) {
                if (!type.isPrimitive()) f.set(entity, null);
                continue;
            }
            if (type == long.class || type == Long.class) {
                f.set(entity, obj.optLong(name));
            } else if (type == int.class || type == Integer.class) {
                f.set(entity, obj.optInt(name));
            } else if (type == boolean.class || type == Boolean.class) {
                f.set(entity, obj.optBoolean(name));
            } else if (type == double.class || type == Double.class) {
                f.set(entity, obj.optDouble(name));
            } else if (type == float.class || type == Float.class) {
                f.set(entity, (float) obj.optDouble(name));
            } else if (type == String.class) {
                f.set(entity, obj.optString(name));
            }
        }
        return entity;
    }

    @NonNull
    private static ContentValues entityToContentValues(Object entity) {
        ContentValues cv = new ContentValues();
        for (Field f : entity.getClass().getDeclaredFields()) {
            if (!isPersistable(f)) continue;
            String col = f.getName(); // Room stĺpce = názvy polí (Note.searchIndex tiež)
            Object v;
            try {
                v = f.get(entity);
            } catch (IllegalAccessException e) {
                continue;
            }
            if (v == null) {
                cv.putNull(col);
            } else if (v instanceof Long) {
                cv.put(col, (Long) v);
            } else if (v instanceof Integer) {
                cv.put(col, (Integer) v);
            } else if (v instanceof Boolean) {
                cv.put(col, ((Boolean) v) ? 1 : 0);
            } else if (v instanceof Double) {
                cv.put(col, (Double) v);
            } else if (v instanceof Float) {
                cv.put(col, (Float) v);
            } else if (v instanceof String) {
                cv.put(col, (String) v);
            }
        }
        return cv;
    }

    private static boolean isPersistable(Field f) {
        int mods = f.getModifiers();
        return Modifier.isPublic(mods) && !Modifier.isStatic(mods) && !Modifier.isTransient(mods);
    }

    // ===== Alarmy =====

    private static void cancelExistingAlarms(Context ctx) {
        AppDatabase db = AppDatabase.getInstance(ctx);
        for (Task t : db.taskDao().getAllSync()) {
            if (t.reminderAt > 0L) ReminderScheduler.cancel(ctx, t.id);
        }
        for (KidPayment p : db.kidPaymentDao().getAllSync()) {
            KidReminderScheduler.cancelPayment(ctx, p.id);
        }
        for (KidEvent e : db.kidEventDao().getAllSync()) {
            KidReminderScheduler.cancelEvent(ctx, e.id);
        }
    }

    // ===== Súbory =====

    private static void restoreFiles(Context ctx, File workDir, File attachDir,
                                     JSONObject root, ImportStats stats) throws IOException {
        UserPreferences prefs = UserPreferences.get(ctx);

        // Prílohy poznámok
        File attachSrc = new File(workDir, "attachments");
        File[] attachments = attachSrc.listFiles();
        if (attachments != null) {
            for (File f : attachments) {
                if (!f.isFile()) continue;
                copyFile(f, new File(attachDir, f.getName()));
                stats.attachmentCount++;
            }
        }

        // Profilové foto
        File photoSrc = findFirstFile(new File(workDir, "photos"), "profile");
        if (photoSrc != null) {
            String name = "profile_" + System.currentTimeMillis() + extensionOf(photoSrc.getName());
            File target = new File(attachDir, name);
            copyFile(photoSrc, target);
            String old = prefs.getPhotoPath();
            if (old != null && !old.equals(target.getAbsolutePath())) {
                ImageStorage.deleteIfExists(old);
            }
            prefs.setPhotoPath(target.getAbsolutePath());
        } else {
            prefs.setPhotoPath(null);
        }

        // Motivačné vety
        File quotesSrc = new File(workDir, "quotes/quotes.md");
        if (quotesSrc.isFile()) {
            File target = new File(ctx.getFilesDir(), QUOTES_FILENAME);
            copyFile(quotesSrc, target);
            prefs.setQuotesFilePath(target.getAbsolutePath());
            prefs.clearQuoteHistory();
        }

        // Meno
        JSONObject prefsJson = root.optJSONObject("preferences");
        if (prefsJson != null) {
            String name = prefsJson.optString("displayName", "");
            if (!name.isEmpty()) prefs.setDisplayName(name);
        }
    }

    @Nullable
    private static File findFirstFile(File dir, String prefix) {
        File[] files = dir.listFiles();
        if (files == null) return null;
        for (File f : files) {
            if (f.isFile() && f.getName().startsWith(prefix)) return f;
        }
        return null;
    }

    private static void unzip(Context ctx, Uri zipUri, File targetDir) throws Exception {
        String canonicalRoot = targetDir.getCanonicalPath() + File.separator;
        boolean any = false;
        try (InputStream raw = ctx.getContentResolver().openInputStream(zipUri)) {
            if (raw == null) throw new ImportException(ctx.getString(R.string.restore_error_open));
            try (ZipInputStream zis = new ZipInputStream(raw)) {
                ZipEntry entry;
                byte[] buf = new byte[8 * 1024];
                while ((entry = zis.getNextEntry()) != null) {
                    any = true;
                    File out = new File(targetDir, entry.getName());
                    // Zip slip — položka nesmie mieriť mimo cieľovej zložky
                    if (!out.getCanonicalPath().startsWith(canonicalRoot)) {
                        throw new ImportException(ctx.getString(R.string.restore_error_not_backup));
                    }
                    if (entry.isDirectory()) {
                        //noinspection ResultOfMethodCallIgnored
                        out.mkdirs();
                        continue;
                    }
                    File parent = out.getParentFile();
                    if (parent != null && !parent.exists()) {
                        //noinspection ResultOfMethodCallIgnored
                        parent.mkdirs();
                    }
                    try (FileOutputStream fos = new FileOutputStream(out)) {
                        int read;
                        while ((read = zis.read(buf)) != -1) fos.write(buf, 0, read);
                    }
                    zis.closeEntry();
                }
            }
        } catch (java.util.zip.ZipException e) {
            throw new ImportException(ctx.getString(R.string.restore_error_not_backup));
        }
        if (!any) throw new ImportException(ctx.getString(R.string.restore_error_not_backup));
    }

    private static String readText(File f) throws IOException {
        try (FileInputStream in = new FileInputStream(f);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8 * 1024];
            int read;
            while ((read = in.read(buf)) != -1) out.write(buf, 0, read);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private static void copyFile(File src, File dst) throws IOException {
        try (FileInputStream in = new FileInputStream(src);
             FileOutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[8 * 1024];
            int read;
            while ((read = in.read(buf)) != -1) out.write(buf, 0, read);
        }
    }

    private static String extensionOf(String fileName) {
        int dot = fileName.lastIndexOf('.');
        return dot < 0 ? "" : fileName.substring(dot);
    }

    private static void deleteRecursive(File f) {
        if (f == null || !f.exists()) return;
        File[] children = f.listFiles();
        if (children != null) for (File c : children) deleteRecursive(c);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }
}
