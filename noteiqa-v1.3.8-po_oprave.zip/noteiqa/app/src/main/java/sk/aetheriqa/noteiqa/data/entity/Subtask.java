package sk.aetheriqa.noteiqa.data.entity;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/**
 * Subtask – podúloha pridaná k Task. CASCADE delete.
 */
@Entity(
    tableName = "subtasks",
    indices = {@Index("taskId")},
    foreignKeys = @ForeignKey(
        entity = Task.class,
        parentColumns = "id",
        childColumns = "taskId",
        onDelete = ForeignKey.CASCADE
    )
)
public class Subtask {

    @PrimaryKey(autoGenerate = true)
    public long id;

    public long taskId;

    @NonNull
    public String text = "";

    public boolean completed = false;

    public int sortOrder = 0;

    public long createdAt;
}
