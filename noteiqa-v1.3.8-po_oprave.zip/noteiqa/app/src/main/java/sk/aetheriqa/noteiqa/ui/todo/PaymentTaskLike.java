package sk.aetheriqa.noteiqa.ui.todo;

import sk.aetheriqa.noteiqa.data.entity.KidPayment;

/**
 * PaymentTaskLike – v1.3.6 — osobná platba (zadaná cez To Do → kategória Platba,
 * kidId NULL) zobrazená v „Môj to do list“ medzi úlohami.
 *
 * Nie je v DB ako úloha — žije v platbách. Riadok vyzerá ako úloha: zaškrtnutie
 * = zaplatené, tap = platobný lístok. Zaplatená z To Do zmizne (ako hotová úloha).
 */
public class PaymentTaskLike {

    public final KidPayment payment;

    public PaymentTaskLike(KidPayment payment) {
        this.payment = payment;
    }

    /** Bucket aj poradie podľa splatnosti (0:00 dňa → pred udalosťami s časom v ten deň). */
    public long timestamp() {
        return payment.dueDate;
    }
}
