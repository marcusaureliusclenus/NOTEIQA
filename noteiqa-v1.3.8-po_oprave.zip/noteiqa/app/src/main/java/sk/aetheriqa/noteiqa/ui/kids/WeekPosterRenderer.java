package sk.aetheriqa.noteiqa.ui.kids;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;

/**
 * WeekPosterRenderer – v1.3.0 — "Plagát týždňa detí" ako bitmapa (Canvas, žiadny WebView).
 *
 *  - šírka 1080 px, výška podľa obsahu: min 1080, max 2200 px;
 *    ak by obsah pretiekol, zmenší sa písmo chipov (obsah sa nikdy neoreže)
 *  - pondelok–nedeľa, dva pruhy (prvé dve deti podľa sortOrder), spoločná udalosť v oboch
 *  - nezaplatená platba = malá zlatá bodka pri dni
 *  - všetky texty zo strings.xml
 *
 * Ten istý obrázok sa ukazuje na obrazovke aj ukladá ako PNG.
 */
final class WeekPosterRenderer {

    static final int WIDTH = 1080;
    private static final int MIN_HEIGHT = 1080;
    private static final int MAX_HEIGHT = 2200;
    private static final int PAD = 48;
    private static final int BG = 0xFF0E0D0B;
    private static final int GOLD = 0xFFC9A961;

    /** Dáta jedného týždňa. */
    static final class Data {
        long weekStart;               // pondelok 00:00
        final List<Kid> kids = new ArrayList<>();          // max 2
        final List<KidEvent> events = new ArrayList<>();
        final List<KidPayment> payments = new ArrayList<>();
    }

    private static final class Chip {
        String time;    // "" pri celodennej
        String title;
        String pack;    // v1.3.4 — "desiata, súhlas" alebo null
        int color;
    }

    private final Context ctx;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final TextPaint text = new TextPaint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

    WeekPosterRenderer(Context ctx) {
        this.ctx = ctx;
        stroke.setStyle(Paint.Style.STROKE);
    }

    Bitmap render(Data d) {
        // 7 stĺpcov × 2 pruhy chipov
        List<List<List<Chip>>> bands = new ArrayList<>();
        for (int k = 0; k < 2; k++) {
            List<List<Chip>> days = new ArrayList<>();
            for (int i = 0; i < 7; i++) days.add(new ArrayList<>());
            bands.add(days);
        }
        boolean[] paymentDay = new boolean[7];
        long[] dayStart = new long[8];
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(d.weekStart);
        for (int i = 0; i < 8; i++) {
            dayStart[i] = c.getTimeInMillis();
            c.add(Calendar.DAY_OF_MONTH, 1);
        }

        for (KidEvent e : d.events) {
            for (int day = 0; day < 7; day++) {
                if (!e.coversDay(dayStart[day], dayStart[day + 1])) continue;
                boolean continuing = e.startDate < dayStart[day];
                for (int k = 0; k < 2 && k < d.kids.size(); k++) {
                    long kidId = e.kidIdOrAll();
                    if (kidId != 0L && kidId != d.kids.get(k).id) continue; // 0 = spoločná → oba pruhy
                    Chip chip = new Chip();
                    chip.time = e.allDay || continuing ? "" : timeOf(e.startDate);
                    chip.title = e.title;
                    // v1.3.4 — Čo zobrať: menšie pod názvom, len ak sa zmestí na 2 riadky
                    List<String> pack = e.packList();
                    chip.pack = pack.isEmpty() ? null : TextUtils.join(", ", pack);
                    chip.color = kidColor(d.kids.get(k));
                    bands.get(k).get(day).add(chip);
                }
            }
        }
        for (KidPayment p : d.payments) {
            for (int day = 0; day < 7; day++) {
                if (p.dueDate >= dayStart[day] && p.dueDate < dayStart[day + 1]) paymentDay[day] = true;
            }
        }

        // Písmo chipov zmenšuj, kým sa obsah nezmestí do MAX_HEIGHT (nikdy neorezávame)
        float chipSize = 28f;
        int height = measure(d, bands, chipSize);
        while (height > MAX_HEIGHT && chipSize > 16f) {
            chipSize -= 2f;
            height = measure(d, bands, chipSize);
        }
        height = Math.max(MIN_HEIGHT, height);

        Bitmap bmp = Bitmap.createBitmap(WIDTH, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        draw(canvas, d, bands, paymentDay, dayStart, chipSize, height);
        return bmp;
    }

    // ===== Layout (spoločné pre meranie aj kreslenie) =====

    private float colWidth() {
        return (WIDTH - 2f * PAD) / 7f;
    }

    private int measure(Data d, List<List<List<Chip>>> bands, float chipSize) {
        float y = headerBottom();
        y += 70; // riadok dní
        for (int k = 0; k < 2 && k < d.kids.size(); k++) {
            y += bandHeight(bands.get(k), chipSize);
        }
        y += 90; // pätička
        return (int) Math.ceil(y + PAD);
    }

    private float headerBottom() {
        return PAD + 40 + 30 + 76 + 24;
    }

    private float bandHeight(List<List<Chip>> days, float chipSize) {
        float maxCol = 0;
        for (List<Chip> chips : days) {
            float col = 0;
            for (Chip chip : chips) col += chipHeight(chip, chipSize) + 10;
            maxCol = Math.max(maxCol, col);
        }
        return 64 /* meno */ + Math.max(maxCol, 56) + 28;
    }

    private float chipHeight(Chip chip, float chipSize) {
        StaticLayout l = chipLayout(chip, chipSize);
        float h = 16 + l.getHeight();
        if (!TextUtils.isEmpty(chip.time)) h += chipSize * 0.85f + 4;
        StaticLayout p = packLayout(chip, chipSize);
        if (p != null) h += 4 + p.getHeight();
        return h;
    }

    /** v1.3.4 — "desiata, súhlas" menším písmom; null ak nie je alebo by mal viac ako 2 riadky. */
    private StaticLayout packLayout(Chip chip, float chipSize) {
        if (TextUtils.isEmpty(chip.pack)) return null;
        text.setTypeface(Typeface.DEFAULT);
        text.setTextSize(chipSize * 0.7f);
        int w = (int) (colWidth() - 8 - 14);
        StaticLayout l = StaticLayout.Builder.obtain(chip.pack, 0, chip.pack.length(), text, Math.max(w, 10))
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setIncludePad(false)
                .build();
        return l.getLineCount() <= 2 ? l : null;
    }

    private StaticLayout chipLayout(Chip chip, float chipSize) {
        text.setTypeface(Typeface.DEFAULT);
        text.setTextSize(chipSize);
        int w = (int) (colWidth() - 8 - 14);
        return StaticLayout.Builder.obtain(chip.title, 0, chip.title.length(), text, Math.max(w, 10))
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setMaxLines(3)
                .setEllipsize(TextUtils.TruncateAt.END)
                .setIncludePad(false)
                .build();
    }

    // ===== Kreslenie =====

    private void draw(Canvas cv, Data d, List<List<List<Chip>>> bands, boolean[] paymentDay,
                      long[] dayStart, float chipSize, int height) {
        cv.drawColor(BG);

        // Zlatý rám
        stroke.setColor(GOLD);
        stroke.setStrokeWidth(5f);
        cv.drawRoundRect(new RectF(22, 22, WIDTH - 22, height - 22), 28, 28, stroke);

        // Hlavička
        float y = PAD + 40;
        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setTextSize(24f);
        text.setColor(GOLD);
        text.setLetterSpacing(0.3f);
        drawCentered(cv, ctx.getString(R.string.poster_label), y);
        text.setLetterSpacing(0f);

        y += 30 + 60;
        text.setTypeface(Typeface.create(Typeface.SERIF, Typeface.NORMAL));
        text.setTextSize(58f);
        drawCentered(cv, ctx.getString(R.string.poster_title, rangeLabel(dayStart[0], dayStart[6])), y);

        // Riadok dní
        y = headerBottom() + 44;
        String[] dayNames = ctx.getResources().getStringArray(R.array.poster_days);
        Calendar c = Calendar.getInstance();
        for (int i = 0; i < 7; i++) {
            c.setTimeInMillis(dayStart[i]);
            float cx = PAD + colWidth() * i + colWidth() / 2f;
            text.setTypeface(Typeface.DEFAULT_BOLD);
            text.setTextSize(26f);
            text.setColor(ContextCompat.getColor(ctx, R.color.text_primary));
            String label = dayNames[i] + " " + c.get(Calendar.DAY_OF_MONTH) + ".";
            float w = text.measureText(label);
            cv.drawText(label, cx - w / 2f, y, text);
            if (paymentDay[i]) {
                fill.setColor(GOLD);
                cv.drawCircle(cx + w / 2f + 12, y - 9, 6, fill);
            }
        }

        // Pruhy detí
        y += 26;
        for (int k = 0; k < 2 && k < d.kids.size(); k++) {
            Kid kid = d.kids.get(k);
            int color = kidColor(kid);
            float bandTop = y;

            stroke.setColor(withAlpha(color, 0x55));
            stroke.setStrokeWidth(2f);
            cv.drawLine(PAD, bandTop + 8, WIDTH - PAD, bandTop + 8, stroke);

            text.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
            text.setTextSize(36f);
            text.setColor(color);
            cv.drawText(kid.name, PAD, bandTop + 52, text);

            float colTop = bandTop + 64;
            for (int day = 0; day < 7; day++) {
                float x = PAD + colWidth() * day + 4;
                float cy = colTop;
                for (Chip chip : bands.get(k).get(day)) {
                    float h = chipHeight(chip, chipSize);
                    RectF r = new RectF(x, cy, x + colWidth() - 8, cy + h);
                    fill.setColor(withAlpha(chip.color, 0x33));
                    cv.drawRoundRect(r, 12, 12, fill);
                    stroke.setColor(chip.color);
                    stroke.setStrokeWidth(2f);
                    cv.drawRoundRect(r, 12, 12, stroke);

                    float ty = cy + 8;
                    if (!TextUtils.isEmpty(chip.time)) {
                        text.setTypeface(Typeface.DEFAULT_BOLD);
                        text.setTextSize(chipSize * 0.85f);
                        text.setColor(GOLD);
                        cv.drawText(chip.time, x + 7, ty + chipSize * 0.85f, text);
                        ty += chipSize * 0.85f + 4;
                    }
                    text.setColor(ContextCompat.getColor(ctx, R.color.text_primary));
                    StaticLayout l = chipLayout(chip, chipSize);
                    cv.save();
                    cv.translate(x + 7, ty);
                    l.draw(cv);
                    cv.restore();
                    StaticLayout pl = packLayout(chip, chipSize);
                    if (pl != null) {
                        text.setColor(ContextCompat.getColor(ctx, R.color.text_secondary));
                        cv.save();
                        cv.translate(x + 7, ty + l.getHeight() + 4);
                        pl.draw(cv);
                        cv.restore();
                    }
                    cy += h + 10;
                }
            }
            y += bandHeight(bands.get(k), chipSize);
        }

        // Pätička
        text.setTypeface(Typeface.DEFAULT);
        text.setTextSize(24f);
        text.setColor(ContextCompat.getColor(ctx, R.color.text_secondary));
        drawCentered(cv, ctx.getString(R.string.poster_footer), height - PAD - 6);
    }

    private void drawCentered(Canvas cv, String s, float baseline) {
        float w = text.measureText(s);
        cv.drawText(s, (WIDTH - w) / 2f, baseline, text);
    }

    // ===== Pomocné =====

    /** "6.–12. október" alebo "29. september – 5. október". */
    private static String rangeLabel(long monday, long sunday) {
        Locale sk = new Locale("sk", "SK");
        Calendar a = Calendar.getInstance();
        a.setTimeInMillis(monday);
        Calendar b = Calendar.getInstance();
        b.setTimeInMillis(sunday);
        SimpleDateFormat month = new SimpleDateFormat("LLLL", sk);
        if (a.get(Calendar.MONTH) == b.get(Calendar.MONTH)) {
            return a.get(Calendar.DAY_OF_MONTH) + ".–" + b.get(Calendar.DAY_OF_MONTH) + ". "
                    + month.format(new Date(sunday));
        }
        return a.get(Calendar.DAY_OF_MONTH) + ". " + month.format(new Date(monday)) + " – "
                + b.get(Calendar.DAY_OF_MONTH) + ". " + month.format(new Date(sunday));
    }

    private static String timeOf(long ts) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ts);
        return String.format(Locale.getDefault(), "%d:%02d",
                c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
    }

    private static int kidColor(@Nullable Kid kid) {
        if (kid == null) return GOLD;
        try {
            return Color.parseColor(kid.colorHex);
        } catch (IllegalArgumentException e) {
            return GOLD;
        }
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (alpha << 24);
    }
}
