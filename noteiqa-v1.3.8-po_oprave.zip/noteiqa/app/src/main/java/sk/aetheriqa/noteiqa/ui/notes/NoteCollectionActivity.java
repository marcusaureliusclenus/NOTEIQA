package sk.aetheriqa.noteiqa.ui.notes;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;

import java.util.ArrayList;
import java.util.List;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.db.dao.TagWithCount;
import sk.aetheriqa.noteiqa.data.entity.Note;
import sk.aetheriqa.noteiqa.data.entity.Template;
import sk.aetheriqa.noteiqa.data.repository.NoteRepository;
import sk.aetheriqa.noteiqa.util.DateUtils;
import sk.aetheriqa.noteiqa.util.DialogThemes;

/**
 * NoteCollectionActivity – v1.2.0 — minimálne obrazovky z Nastavení, ktoré boli
 * dovtedy "Pripravujeme":
 *
 *  MODE_TRASH      Kôš — poznámky so STATE_TRASHED; tap = Obnoviť / Zmazať natrvalo.
 *                  Po 30 dňoch ich zmaže cleanup pri štarte appky.
 *  MODE_TAGS       Štítky — zoznam s počtom aktívnych poznámok; tap = poznámky so štítkom.
 *  MODE_TAG_NOTES  Aktívne poznámky s jedným štítkom; tap = otvoriť editor.
 *  MODE_TEMPLATES  Šablóny — tap = nová poznámka predvyplnená zo šablóny.
 */
public class NoteCollectionActivity extends AppCompatActivity {

    public static final String EXTRA_MODE = "mode";
    public static final String EXTRA_TAG_ID = "tagId";
    public static final String EXTRA_TAG_NAME = "tagName";

    public static final int MODE_TRASH = 0;
    public static final int MODE_TAGS = 1;
    public static final int MODE_TAG_NOTES = 2;
    public static final int MODE_TEMPLATES = 3;

    private NoteRepository repo;
    private RowAdapter adapter;
    private RecyclerView list;
    private View emptyState;

    public static Intent newIntent(Context ctx, int mode) {
        Intent i = new Intent(ctx, NoteCollectionActivity.class);
        i.putExtra(EXTRA_MODE, mode);
        return i;
    }

    public static Intent newTagNotesIntent(Context ctx, long tagId, String tagName) {
        Intent i = newIntent(ctx, MODE_TAG_NOTES);
        i.putExtra(EXTRA_TAG_ID, tagId);
        i.putExtra(EXTRA_TAG_NAME, tagName);
        return i;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_collection);

        repo = NoteRepository.getInstance(getApplicationContext());

        MaterialToolbar tb = findViewById(R.id.collection_toolbar);
        tb.setNavigationOnClickListener(v -> finish());

        list = findViewById(R.id.collection_list);
        emptyState = findViewById(R.id.collection_empty_state);
        adapter = new RowAdapter();
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);

        int mode = getIntent().getIntExtra(EXTRA_MODE, MODE_TRASH);
        switch (mode) {
            case MODE_TAGS:
                setupTags(tb);
                break;
            case MODE_TAG_NOTES:
                setupTagNotes(tb);
                break;
            case MODE_TEMPLATES:
                setupTemplates(tb);
                break;
            case MODE_TRASH:
            default:
                setupTrash(tb);
                break;
        }
    }

    // ===== Kôš =====

    private void setupTrash(MaterialToolbar tb) {
        tb.setTitle(R.string.more_trash);
        setEmpty(R.drawable.ic_trash, R.string.trash_empty_title, R.string.trash_empty_subtitle);
        repo.observeTrashed().observe(this, notes -> {
            List<Row> rows = new ArrayList<>();
            if (notes != null) {
                for (Note n : notes) {
                    rows.add(new Row(R.drawable.ic_trash, titleOf(n),
                            getString(R.string.trash_meta, DateUtils.formatLongDate(n.trashedAt)),
                            () -> showTrashActions(n)));
                }
            }
            submit(rows);
        });
    }

    private void showTrashActions(Note n) {
        new AlertDialog.Builder(this, DialogThemes.LEA)
                .setTitle(titleOf(n))
                .setItems(new CharSequence[]{
                        getString(R.string.trash_restore),
                        getString(R.string.trash_delete_forever)
                }, (d, which) -> {
                    if (which == 0) {
                        repo.restoreFromTrash(n.id);
                        Toast.makeText(this, R.string.trash_restored_toast, Toast.LENGTH_SHORT).show();
                    } else {
                        confirmDeleteForever(n);
                    }
                })
                .show();
    }

    private void confirmDeleteForever(Note n) {
        new AlertDialog.Builder(this, DialogThemes.LEA)
                .setTitle(R.string.trash_delete_forever)
                .setMessage(R.string.trash_delete_forever_confirm)
                .setPositiveButton(R.string.action_yes, (d, w) -> repo.deletePermanently(n.id))
                .setNegativeButton(R.string.action_no, null)
                .show();
    }

    // ===== Štítky =====

    private void setupTags(MaterialToolbar tb) {
        tb.setTitle(R.string.more_tags);
        setEmpty(R.drawable.ic_tag, R.string.tags_empty_title, R.string.tags_empty_subtitle);
        repo.observeTagsWithCounts().observe(this, tags -> {
            List<Row> rows = new ArrayList<>();
            if (tags != null) {
                for (TagWithCount t : tags) {
                    rows.add(new Row(R.drawable.ic_tag, t.name,
                            getString(R.string.tags_note_count, t.noteCount),
                            () -> startActivity(newTagNotesIntent(this, t.id, t.name))));
                }
            }
            submit(rows);
        });
    }

    private void setupTagNotes(MaterialToolbar tb) {
        long tagId = getIntent().getLongExtra(EXTRA_TAG_ID, 0L);
        String tagName = getIntent().getStringExtra(EXTRA_TAG_NAME);
        tb.setTitle(TextUtils.isEmpty(tagName) ? getString(R.string.more_tags) : tagName);
        setEmpty(R.drawable.ic_tag, R.string.tag_notes_empty_title, 0);
        repo.observeActiveByTag(tagId).observe(this, notes -> {
            List<Row> rows = new ArrayList<>();
            if (notes != null) {
                for (Note n : notes) {
                    rows.add(new Row(R.drawable.ic_note, titleOf(n),
                            DateUtils.formatLongDate(n.updatedAt),
                            () -> openNote(n)));
                }
            }
            submit(rows);
        });
    }

    private void openNote(Note n) {
        if (n.type == Note.TYPE_CHECKLIST) {
            startActivity(ChecklistEditorActivity.newIntent(this, n.id));
        } else {
            startActivity(NoteEditorActivity.newIntent(this, n.id));
        }
    }

    // ===== Šablóny =====

    private void setupTemplates(MaterialToolbar tb) {
        tb.setTitle(R.string.more_templates);
        setEmpty(R.drawable.ic_template, R.string.templates_empty_title, R.string.templates_empty_subtitle);
        repo.ensureTemplatesSeeded(this);
        repo.observeTemplates().observe(this, templates -> {
            List<Row> rows = new ArrayList<>();
            if (templates != null) {
                for (Template t : templates) {
                    rows.add(new Row(R.drawable.ic_template, t.name, firstLine(t.body),
                            () -> {
                                startActivity(NoteEditorActivity.newTemplateIntent(
                                        this, t.title, t.body));
                                finish();
                            }));
                }
            }
            submit(rows);
        });
    }

    // ===== Helpers =====

    private void setEmpty(@DrawableRes int icon, @StringRes int title, @StringRes int subtitle) {
        ((ImageView) findViewById(R.id.collection_empty_icon)).setImageResource(icon);
        ((TextView) findViewById(R.id.collection_empty_title)).setText(title);
        TextView sub = findViewById(R.id.collection_empty_subtitle);
        if (subtitle != 0) {
            sub.setText(subtitle);
            sub.setVisibility(View.VISIBLE);
        } else {
            sub.setVisibility(View.GONE);
        }
    }

    private void submit(List<Row> rows) {
        adapter.submit(rows);
        boolean empty = rows.isEmpty();
        emptyState.setVisibility(empty ? View.VISIBLE : View.GONE);
        list.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    private String titleOf(Note n) {
        if (!TextUtils.isEmpty(n.title)) return n.title;
        String first = firstLine(n.body);
        return TextUtils.isEmpty(first) ? getString(R.string.note_untitled) : first;
    }

    private static String firstLine(@Nullable String s) {
        if (TextUtils.isEmpty(s)) return "";
        int nl = s.indexOf('\n');
        return (nl < 0 ? s : s.substring(0, nl)).trim();
    }

    // ===== Adapter =====

    private static final class Row {
        @DrawableRes final int icon;
        final String title;
        final String meta;
        final Runnable onClick;

        Row(@DrawableRes int icon, String title, String meta, Runnable onClick) {
            this.icon = icon;
            this.title = title;
            this.meta = meta;
            this.onClick = onClick;
        }
    }

    private static final class RowAdapter extends RecyclerView.Adapter<RowAdapter.VH> {
        private final List<Row> rows = new ArrayList<>();

        void submit(List<Row> newRows) {
            rows.clear();
            rows.addAll(newRows);
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_collection_row, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            Row r = rows.get(position);
            h.icon.setImageResource(r.icon);
            h.title.setText(r.title);
            h.meta.setText(r.meta);
            h.meta.setVisibility(TextUtils.isEmpty(r.meta) ? View.GONE : View.VISIBLE);
            h.itemView.setOnClickListener(v -> r.onClick.run());
        }

        @Override
        public int getItemCount() {
            return rows.size();
        }

        static final class VH extends RecyclerView.ViewHolder {
            final ImageView icon;
            final TextView title, meta;

            VH(@NonNull View v) {
                super(v);
                icon = v.findViewById(R.id.collection_row_icon);
                title = v.findViewById(R.id.collection_row_title);
                meta = v.findViewById(R.id.collection_row_meta);
            }
        }
    }
}
