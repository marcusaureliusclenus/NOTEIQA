package sk.aetheriqa.noteiqa.data.db.dao;

/**
 * v1.2.0 — riadok pre zoznam Štítky v Nastaveniach: štítok + počet aktívnych poznámok.
 * Room POJO (nie entita) pre {@link TagDao#observeWithCounts()}.
 */
public class TagWithCount {
    public long id;
    public String name;
    public int noteCount;
}
