package sk.aetheriqa.noteiqa.ui.kids;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognitionService;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.data.repository.TaskRepository;
import sk.aetheriqa.noteiqa.util.DateUtils;
import sk.aetheriqa.noteiqa.util.ExactAlarmNotice;
import sk.aetheriqa.noteiqa.util.VoiceDraftParser;

/**
 * VoiceDraftSheet – v1.3.0 — "Hlas, ktorý sa stane riadkom".
 *
 * Android SpeechRecognizer (sk-SK, EXTRA_PREFER_OFFLINE). Na zariadeniach bez
 * stiahnutého slovenského modelu systém prepisuje cez Google — preto v UI hovoríme
 * "hlasový návrh", nie "offline". Žiadny vlastný endpoint, žiadne LLM.
 *
 * Výsledok → VoiceDraftParser → karta "Rozumel som" s upraviteľnými poľami.
 * Uloží sa až po "Uložiť" cez existujúce repository.
 */
final class VoiceDraftSheet extends BottomSheetDialog {

    private final Context ctx;
    private final long defaultKidId;
    /** Text z hlasového dialógu systému (fallback) — vtedy sa nepočúva, rovno návrh. */
    @Nullable private final String initialText;
    /** Ak rozpoznávanie v sheete zlyhá: otvor hlasový dialóg systému (Google). */
    @Nullable private final Runnable systemFallback;
    /** 0 = s EXTRA_PREFER_OFFLINE, 1 = bez neho (online), potom fallback. */
    private int attempt = 0;
    private boolean listeningNow = false;
    private final KidRepository kidRepo;
    private final Handler main = new Handler(Looper.getMainLooper());

    @Nullable private SpeechRecognizer recognizer;
    @Nullable private ObjectAnimator pulse;

    private final List<Kid> kids = new ArrayList<>();
    private final List<KidPayment> unpaid = new ArrayList<>();
    private VoiceDraftParser.Draft draft;
    private long dayStart = -1L;
    private int minutes = -1;

    private View listening, result, fields;
    private TextView partial, heard, message;
    private MaterialButtonToggleGroup kindGroup, kidGroup;
    private MaterialButton kidA, kidB, kidAll, dateBtn, timeBtn, saveBtn, cancelBtn;
    private EditText titleInput, amountInput;

    VoiceDraftSheet(Context ctx, long defaultKidId, @Nullable String initialText,
                    @Nullable Runnable systemFallback) {
        super(ctx);
        this.ctx = ctx;
        this.defaultKidId = defaultKidId;
        this.initialText = initialText;
        this.systemFallback = systemFallback;
        this.kidRepo = KidRepository.getInstance(ctx);

        View v = LayoutInflater.from(ctx).inflate(R.layout.bottom_sheet_voice, null, false);
        setContentView(v);
        listening = v.findViewById(R.id.voice_listening);
        result = v.findViewById(R.id.voice_result);
        fields = v.findViewById(R.id.voice_fields);
        partial = v.findViewById(R.id.voice_partial);
        heard = v.findViewById(R.id.voice_heard);
        message = v.findViewById(R.id.voice_message);
        kindGroup = v.findViewById(R.id.voice_kind_group);
        kidGroup = v.findViewById(R.id.voice_kid_group);
        kidA = v.findViewById(R.id.voice_kid_a);
        kidB = v.findViewById(R.id.voice_kid_b);
        kidAll = v.findViewById(R.id.voice_kid_all);
        titleInput = v.findViewById(R.id.voice_title);
        amountInput = v.findViewById(R.id.voice_amount);
        sk.aetheriqa.noteiqa.util.DecimalCommaInput.attach(amountInput); // v1.3.5 — desatinná čiarka
        dateBtn = v.findViewById(R.id.voice_date);
        timeBtn = v.findViewById(R.id.voice_time);
        saveBtn = v.findViewById(R.id.voice_save);
        cancelBtn = v.findViewById(R.id.voice_cancel);

        cancelBtn.setOnClickListener(x -> dismiss());
        dateBtn.setOnClickListener(x -> pickDate());
        timeBtn.setOnClickListener(x -> pickTime());
        kindGroup.addOnButtonCheckedListener((g, id, checked) -> { if (checked) applyKindUi(); });

        View pulseDot = v.findViewById(R.id.voice_dot);
        // ťuk na bod = počúvaj znova (po "nič som nezachytil")
        pulseDot.setOnClickListener(x -> {
            if (!listeningNow && result.getVisibility() != View.VISIBLE) restartListening();
        });
        pulse = ObjectAnimator.ofFloat(pulseDot, View.ALPHA, 1f, 0.35f);
        pulse.setDuration(260L);
        pulse.setRepeatMode(ValueAnimator.REVERSE);
        pulse.setRepeatCount(ValueAnimator.INFINITE);

        setOnDismissListener(d -> release());
    }

    @Override
    public void show() {
        super.show();
        View sheet = findViewById(com.google.android.material.R.id.design_bottom_sheet);
        if (sheet != null) sheet.setBackgroundColor(Color.TRANSPARENT);
        getBehavior().setState(BottomSheetBehavior.STATE_EXPANDED);
        if (pulse != null) pulse.start();

        // deti + nezaplatené platby pre parser, potom počúvaj (SpeechRecognizer na main threade)
        new Thread(() -> {
            List<Kid> k = kidRepo.getKidsSync();
            List<KidPayment> u = kidRepo.getUnpaidSync();
            main.post(() -> {
                if (!isShowing()) return;
                kids.clear();
                for (int i = 0; i < k.size() && i < 2; i++) kids.add(k.get(i));
                unpaid.clear();
                unpaid.addAll(u);
                if (initialText != null) showDraft(initialText);
                else startListening();
            });
        }, "VoiceDraftLoad").start();
    }

    // ===== Rozpoznávanie =====

    private void startListening() {
        recognizer = createRecognizer();
        if (recognizer == null) {
            hardFail(-1);
            return;
        }
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                partial.setText(R.string.voice_speak_now);
            }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {}
            @Override public void onEvent(int eventType, Bundle params) {}

            @Override
            public void onError(int error) {
                listeningNow = false;
                onRecognitionError(error);
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
                String t = first(partialResults);
                if (!TextUtils.isEmpty(t)) partial.setText(t);
            }

            @Override
            public void onResults(Bundle results) {
                listeningNow = false;
                String t = first(results);
                if (TextUtils.isEmpty(t)) {
                    nothingHeard();
                } else {
                    showDraft(t);
                }
            }
        });

        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "sk-SK");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        // 1. pokus: offline, ak má zariadenie slovenský model; 2. pokus: bez tejto preferencie
        if (attempt == 0) i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.getPackageName());
        try {
            listeningNow = true;
            if (pulse != null && !pulse.isStarted()) pulse.start();
            recognizer.startListening(i);
        } catch (RuntimeException e) {
            listeningNow = false;
            onRecognitionError(SpeechRecognizer.ERROR_CLIENT);
        }
    }

    /**
     * Preferuj službu Google: na niektorých telefónoch (napr. Xiaomi) je predvolená
     * služba výrobcu, ktorá slovenčinu nepozná a hneď vráti chybu.
     */
    @Nullable
    private SpeechRecognizer createRecognizer() {
        destroyRecognizer();
        try {
            ComponentName google = findGoogleRecognitionService();
            return google != null
                    ? SpeechRecognizer.createSpeechRecognizer(ctx, google)
                    : SpeechRecognizer.createSpeechRecognizer(ctx);
        } catch (RuntimeException e) {
            return null;
        }
    }

    @Nullable
    private ComponentName findGoogleRecognitionService() {
        List<ResolveInfo> services = ctx.getPackageManager().queryIntentServices(
                new Intent(RecognitionService.SERVICE_INTERFACE), 0);
        for (ResolveInfo ri : services) {
            if (ri.serviceInfo != null
                    && "com.google.android.googlequicksearchbox".equals(ri.serviceInfo.packageName)) {
                return new ComponentName(ri.serviceInfo.packageName, ri.serviceInfo.name);
            }
        }
        for (ResolveInfo ri : services) {
            if (ri.serviceInfo != null && ri.serviceInfo.packageName.startsWith("com.google.android")) {
                return new ComponentName(ri.serviceInfo.packageName, ri.serviceInfo.name);
            }
        }
        return null;
    }

    private void onRecognitionError(int error) {
        if (!isShowing()) return;
        switch (error) {
            case SpeechRecognizer.ERROR_NO_MATCH:
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                // nič nepovedané / nezachytené — nechaj sheet otvorený, ťuk na bod = znova
                nothingHeard();
                return;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                Toast.makeText(ctx, R.string.voice_no_permission, Toast.LENGTH_LONG).show();
                dismiss();
                return;
            default:
                break;
        }
        if (attempt == 0) {
            // offline model chýba / služba je zaneprázdnená → skús znova bez offline preferencie
            attempt = 1;
            main.postDelayed(() -> { if (isShowing()) startListening(); }, 300L);
            return;
        }
        hardFail(error);
    }

    private void nothingHeard() {
        if (pulse != null) pulse.cancel();
        partial.setText(R.string.voice_nothing_heard);
    }

    private void restartListening() {
        attempt = 0;
        partial.setText("");
        startListening();
    }

    /** Ani druhý pokus nevyšiel — hlasový dialóg systému, inak toast s kódom chyby. */
    private void hardFail(int error) {
        if (!isShowing()) return;
        dismiss();
        if (systemFallback != null) {
            systemFallback.run();
        } else {
            Toast.makeText(ctx, ctx.getString(R.string.voice_failed_code, error),
                    Toast.LENGTH_LONG).show();
        }
    }

    @Nullable
    private static String first(@Nullable Bundle b) {
        if (b == null) return null;
        ArrayList<String> list = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return list == null || list.isEmpty() ? null : list.get(0);
    }

    private void release() {
        if (pulse != null) pulse.cancel();
        destroyRecognizer();
    }

    private void destroyRecognizer() {
        listeningNow = false;
        if (recognizer != null) {
            try {
                recognizer.destroy();
            } catch (RuntimeException ignored) {
            }
            recognizer = null;
        }
    }

    // ===== Karta "Rozumel som" =====

    private void showDraft(String text) {
        if (pulse != null) pulse.cancel();
        List<VoiceDraftParser.KidRef> kidRefs = new ArrayList<>();
        for (Kid k : kids) kidRefs.add(new VoiceDraftParser.KidRef(k.id, k.name));
        List<VoiceDraftParser.PaymentRef> payRefs = new ArrayList<>();
        for (KidPayment p : unpaid) payRefs.add(new VoiceDraftParser.PaymentRef(p.id, p.kidIdOrZero(), p.title));

        draft = VoiceDraftParser.parse(text, kidRefs, payRefs, Calendar.getInstance());
        dayStart = draft.dayStart;
        minutes = draft.minutes;

        listening.setVisibility(View.GONE);
        result.setVisibility(View.VISIBLE);
        heard.setText(ctx.getString(R.string.voice_heard, text));

        if (draft.kind == VoiceDraftParser.Kind.MARK_PAID) {
            fields.setVisibility(View.GONE);
            message.setVisibility(View.VISIBLE);
            Kid kid = findKid(draft.kidId);
            message.setText(kid != null
                    ? ctx.getString(R.string.voice_mark_paid_question, draft.title, kid.name)
                    : ctx.getString(R.string.voice_mark_paid_question_nokid, draft.title));
            saveBtn.setText(R.string.kid_payment_mark_paid);
            saveBtn.setOnClickListener(x -> {
                KidPaymentContextDialog.setCompletedWithToast(ctx, kidRepo, draft.paymentId, true);
                dismiss();
            });
            return;
        }
        if (draft.kind == VoiceDraftParser.Kind.PAYMENT_NOT_FOUND) {
            fields.setVisibility(View.GONE);
            message.setVisibility(View.VISIBLE);
            message.setText(draft.searchedTitle != null
                    ? ctx.getString(R.string.voice_payment_not_found_named, draft.searchedTitle)
                    : ctx.getString(R.string.voice_payment_not_found));
            saveBtn.setVisibility(View.GONE);
            cancelBtn.setText(R.string.action_close);
            return;
        }

        // Udalosť / platba / úloha — upraviteľné polia
        message.setVisibility(View.GONE);
        fields.setVisibility(View.VISIBLE);
        if (kids.size() >= 2) {
            kidA.setText(kids.get(0).name);
            kidB.setText(kids.get(1).name);
        } else {
            kidGroup.setVisibility(View.GONE);
        }

        long kidId = draft.kidId >= 0 ? draft.kidId : defaultKidId;
        if (kids.size() >= 2) {
            if (kidId == kids.get(0).id) kidGroup.check(R.id.voice_kid_a);
            else if (kidId == kids.get(1).id) kidGroup.check(R.id.voice_kid_b);
            else if (kidId == KidRepository.KID_ID_ALL) kidGroup.check(R.id.voice_kid_all);
        }

        String title = draft.title;
        if (draft.eventWord != null) title = ctx.getString(eventTitleRes(draft.eventWord));
        titleInput.setText(title);
        if (draft.amount != null) amountInput.setText(draft.amount.toPlainString().replace('.', ','));

        int kindId = draft.kind == VoiceDraftParser.Kind.EVENT ? R.id.voice_kind_event
                : draft.kind == VoiceDraftParser.Kind.PAYMENT ? R.id.voice_kind_payment
                : R.id.voice_kind_task;
        kindGroup.check(kindId);
        applyKindUi();
        refreshDateTime();
        saveBtn.setOnClickListener(x -> save());
    }

    private void applyKindUi() {
        int checked = kindGroup.getCheckedButtonId();
        boolean payment = checked == R.id.voice_kind_payment;
        boolean task = checked == R.id.voice_kind_task;
        amountInput.setVisibility(payment ? View.VISIBLE : View.GONE);
        kidGroup.setVisibility(task || kids.size() < 2 ? View.GONE : View.VISIBLE);
        // platba musí mať konkrétne dieťa
        kidAll.setEnabled(!payment);
        if (payment && kidGroup.getCheckedButtonId() == R.id.voice_kid_all) kidGroup.clearChecked();
        timeBtn.setVisibility(payment ? View.GONE : View.VISIBLE);
    }

    private void refreshDateTime() {
        dateBtn.setText(dayStart > 0L ? DateUtils.formatNumericDate(dayStart)
                : ctx.getString(R.string.kid_pick_date));
        timeBtn.setText(minutes >= 0
                ? String.format(Locale.getDefault(), "%d:%02d", minutes / 60, minutes % 60)
                : ctx.getString(R.string.voice_no_time));
    }

    private void pickDate() {
        Calendar c = Calendar.getInstance();
        if (dayStart > 0L) c.setTimeInMillis(dayStart);
        new DatePickerDialog(ctx, (view, y, m, d) -> {
            Calendar picked = Calendar.getInstance();
            picked.clear();
            picked.set(y, m, d, 0, 0, 0);
            dayStart = picked.getTimeInMillis();
            refreshDateTime();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void pickTime() {
        int h = minutes >= 0 ? minutes / 60 : 9;
        int m = minutes >= 0 ? minutes % 60 : 0;
        TimePickerDialog dlg = new TimePickerDialog(ctx, (view, hh, mm) -> {
            minutes = hh * 60 + mm;
            refreshDateTime();
        }, h, m, true);
        dlg.setButton(TimePickerDialog.BUTTON_NEUTRAL, ctx.getString(R.string.voice_no_time), (d, w) -> {
            minutes = -1;
            refreshDateTime();
        });
        dlg.show();
    }

    // ===== Uloženie (až po potvrdení) =====

    private void save() {
        String title = titleInput.getText().toString().trim();
        if (title.isEmpty()) {
            Toast.makeText(ctx, R.string.voice_title_missing, Toast.LENGTH_SHORT).show();
            return;
        }
        int kind = kindGroup.getCheckedButtonId();
        long now = System.currentTimeMillis();

        if (kind == R.id.voice_kind_event) {
            if (dayStart <= 0L) {
                Toast.makeText(ctx, R.string.kid_event_error_start, Toast.LENGTH_SHORT).show();
                return;
            }
            KidEvent e = new KidEvent();
            e.assignKid(selectedKidId(true));
            e.title = title;
            e.type = draft.eventWord != null ? draft.eventWord.type : KidEvent.TYPE_OTHER;
            e.allDay = minutes < 0;
            e.startDate = minutes < 0 ? dayStart : dayStart + minutes * 60_000L;
            // Default ako editor: deň vopred o 9:00
            long notify = atNine(dayStart, -1);
            e.notifyAt = notify > now ? notify : 0L;
            ExactAlarmNotice.maybeWarn(ctx, e.notifyAt);
            kidRepo.saveEvent(e, id -> toastOnMain(R.string.kid_event_saved));
            dismiss();
        } else if (kind == R.id.voice_kind_payment) {
            long kidId = selectedKidId(false);
            if (kidId <= 0L) {
                Toast.makeText(ctx, R.string.kid_payment_error_kid, Toast.LENGTH_SHORT).show();
                return;
            }
            if (dayStart <= 0L) {
                Toast.makeText(ctx, R.string.kid_payment_error_due, Toast.LENGTH_SHORT).show();
                return;
            }
            KidPayment p = new KidPayment();
            KidPayment template = findUnpaid(draft.paymentId);
            if (template != null) {
                // rovnaký názov ako existujúca platba → zober IBAN, symboly, spôsob
                p.paymentMethod = template.paymentMethod;
                p.iban = template.iban;
                p.variableSymbol = template.variableSymbol;
                p.specificSymbol = template.specificSymbol;
                p.paymentNote = template.paymentNote;
                p.cashRecipient = template.cashRecipient;
            }
            p.kidId = kidId;
            p.title = title;
            p.amountEur = parseAmount(amountInput.getText().toString());
            p.dueDate = dayStart;
            // Default ako editor: 2 dni pred splatnosťou o 9:00
            long notify = atNine(dayStart, -2);
            p.notifyAt = notify > now ? notify : 0L;
            ExactAlarmNotice.maybeWarn(ctx, p.notifyAt);
            kidRepo.savePayment(p, id -> toastOnMain(R.string.kid_payment_saved));
            dismiss();
        } else {
            Task t = new Task();
            t.title = title;
            if (dayStart > 0L) {
                t.dueDate = dayStart;
                if (minutes >= 0) t.dueTimeMinutes = minutes;
            }
            TaskRepository.getInstance(ctx).save(t, id -> toastOnMain(R.string.task_saved_toast));
            dismiss();
        }
    }

    private long selectedKidId(boolean allowAll) {
        int checked = kidGroup.getCheckedButtonId();
        if (kids.size() >= 2) {
            if (checked == R.id.voice_kid_a) return kids.get(0).id;
            if (checked == R.id.voice_kid_b) return kids.get(1).id;
        }
        return allowAll ? KidRepository.KID_ID_ALL : -1L;
    }

    private static long atNine(long day, int dayOffset) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(day);
        c.add(Calendar.DAY_OF_MONTH, dayOffset);
        c.set(Calendar.HOUR_OF_DAY, 9);
        c.set(Calendar.MINUTE, 0);
        return c.getTimeInMillis();
    }

    @Nullable
    private static Double parseAmount(String s) {
        String v = s.trim().replace(',', '.');
        if (v.isEmpty()) return null;
        try {
            return new BigDecimal(v).doubleValue();
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void toastOnMain(int res) {
        // Handler, nie View.post — sheet je po uložení už zatvorený
        main.post(() -> Toast.makeText(ctx.getApplicationContext(), res, Toast.LENGTH_SHORT).show());
    }

    @Nullable
    private Kid findKid(long id) {
        for (Kid k : kids) if (k.id == id) return k;
        return null;
    }

    @Nullable
    private KidPayment findUnpaid(long id) {
        if (id <= 0L) return null;
        for (KidPayment p : unpaid) if (p.id == id) return p;
        return null;
    }

    private static int eventTitleRes(@NonNull VoiceDraftParser.EventWord w) {
        switch (w) {
            case DENTIST: return R.string.voice_event_dentist;
            case DOCTOR:
            case DOCTOR2: return R.string.voice_event_doctor;
            case VACCINATION: return R.string.voice_event_vaccination;
            case CHECKUP: return R.string.voice_event_checkup;
            case TRIP: return R.string.voice_event_trip;
            case SCHOOL: return R.string.voice_event_school;
            case PARENTS_MEETING: return R.string.voice_event_parents_meeting;
            case CLUB:
            case CLUB2: return R.string.voice_event_club;
            case KARATE: return R.string.voice_event_karate;
            case TRAINING: return R.string.voice_event_training;
            case MATCH: return R.string.voice_event_match;
            case SWIMMING: return R.string.voice_event_swimming;
            case FOOTBALL: return R.string.voice_event_football;
            case THEATRE: return R.string.voice_event_theatre;
            case CINEMA: return R.string.voice_event_cinema;
            case CONCERT: return R.string.voice_event_concert;
            case HOLIDAYS: return R.string.voice_event_holidays;
            default: return R.string.kid_event_type_other;
        }
    }
}
