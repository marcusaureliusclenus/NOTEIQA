package sk.aetheriqa.noteiqa.util;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.function.ToLongFunction;

import sk.aetheriqa.noteiqa.data.entity.Task;

/**
 * TodoDayMerge – v1.3.6 — vloženie detských udalostí a osobných platieb medzi úlohy
 * jedného bucketu „Môj to do list“.
 *
 * Pravidlo: položka ide hneď pod poslednú úlohu svojho dňa (alebo skoršieho dňa),
 * teda pod všetky úlohy v ten deň; viac položiek v jednom mieste je zoradených podľa
 * času začiatku. Poradie úloh sa nemení (ani ručné zoradenie). Úloha bez dátumu
 * sa berie ako „neskôr než všetko“, takže udalosti idú nad ňu.
 *
 * Čistá Java — testuje TodoDayMergeTest.
 */
public final class TodoDayMerge {

    private TodoDayMerge() {}

    public static <T> List<Object> merge(List<Task> tasks, List<T> extras, ToLongFunction<T> timestamp) {
        List<Object> out = new ArrayList<>();
        List<Task> ts = tasks != null ? tasks : Collections.emptyList();
        if (extras == null || extras.isEmpty()) {
            out.addAll(ts);
            return out;
        }
        List<T> sorted = new ArrayList<>(extras);
        Collections.sort(sorted, (a, b) -> Long.compare(timestamp.applyAsLong(a), timestamp.applyAsLong(b)));

        // pre každú extra položku: index, pred ktorú úlohu ide (= za poslednú úlohu s dňom <= jej deň)
        int[] slot = new int[sorted.size()];
        for (int e = 0; e < sorted.size(); e++) {
            long day = dayKey(timestamp.applyAsLong(sorted.get(e)));
            int last = -1;
            for (int i = 0; i < ts.size(); i++) {
                if (taskDay(ts.get(i)) <= day) last = i;
            }
            slot[e] = last + 1;
        }
        for (int i = 0; i <= ts.size(); i++) {
            for (int e = 0; e < sorted.size(); e++) {
                if (slot[e] == i) out.add(sorted.get(e));
            }
            if (i < ts.size()) out.add(ts.get(i));
        }
        return out;
    }

    private static long taskDay(Task t) {
        if (t.dueDate == null || t.dueDate == 0L) return Long.MAX_VALUE;
        return dayKey(t.dueDate);
    }

    /** yyyyDDD v lokálnej zóne (bez java.time). */
    static long dayKey(long ts) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ts);
        return c.get(Calendar.YEAR) * 1000L + c.get(Calendar.DAY_OF_YEAR);
    }
}
