package sk.aetheriqa.noteiqa.ui.todo;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.data.repository.TaskRepository;
import sk.aetheriqa.noteiqa.util.DateUtils;

/**
 * ArchivedTasksActivity – zoznam archivovaných úloh (dokončených aj
 * zmazaných). Read-only — klik na úlohu otvorí detail v read-only móde, kde
 * sú akcie skryté. Per Marekovo rozhodnutie: žiadne obnovenie z UI tlačidlom
 * (môže sa pridať neskôr ako menu item).
 */
public class ArchivedTasksActivity extends AppCompatActivity {

    private ArchivedAdapter adapter;
    private View emptyState;
    private RecyclerView list;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_archived_tasks);

        MaterialToolbar tb = findViewById(R.id.archive_toolbar);
        tb.setNavigationOnClickListener(v -> finish());
        tb.inflateMenu(R.menu.archive_menu);
        tb.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.action_clear_archive) {
                confirmAndClearArchive();
                return true;
            }
            return false;
        });

        TaskRepository repo = TaskRepository.getInstance(getApplicationContext());

        list = findViewById(R.id.archive_list);
        emptyState = findViewById(R.id.archive_empty_state);

        adapter = new ArchivedAdapter(task ->
                startActivity(TaskDetailActivity.newReadOnlyIntent(this, task.id)));
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);

        repo.observeArchived().observe(this, tasks -> {
            adapter.submitList(tasks);
            boolean empty = tasks == null || tasks.isEmpty();
            emptyState.setVisibility(empty ? View.VISIBLE : View.GONE);
            list.setVisibility(empty ? View.GONE : View.VISIBLE);
        });
    }

    /**
     * v0.5.4 — toolbar overflow "Vymazať archív".
     * Zobrazí Áno/Nie potvrdenie a po potvrdení permanentne zmaže
     * všetky archivované úlohy + zruší prípadné alarmy.
     */
    private void confirmAndClearArchive() {
        new androidx.appcompat.app.AlertDialog.Builder(this,
                sk.aetheriqa.noteiqa.util.DialogThemes.LEA)
                .setTitle(R.string.archive_clear_confirm_title)
                .setMessage(R.string.archive_clear_tasks_message)
                .setPositiveButton(R.string.action_yes, (d, w) ->
                        TaskRepository.getInstance(getApplicationContext())
                                .deleteAllArchived(count -> runOnUiThread(() ->
                                        android.widget.Toast.makeText(this,
                                                getString(R.string.archive_clear_done, count),
                                                android.widget.Toast.LENGTH_SHORT).show())))
                .setNegativeButton(R.string.action_no, null)
                .show();
    }

    public static Intent newIntent(Context ctx) {
        return new Intent(ctx, ArchivedTasksActivity.class);
    }

    // ===== Adapter =====

    static class ArchivedAdapter extends ListAdapter<Task, ArchivedAdapter.VH> {

        interface OnClick { void onClick(Task t); }

        private final OnClick clickListener;

        ArchivedAdapter(OnClick clickListener) {
            super(DIFF);
            this.clickListener = clickListener;
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_archived_task, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            Task t = getItem(position);
            h.title.setText(TextUtils.isEmpty(t.title) ? "—" : t.title);
            h.meta.setText("archivované " + DateUtils.formatLongDate(t.archivedAt));
            h.itemView.setOnClickListener(v -> clickListener.onClick(t));
        }

        static class VH extends RecyclerView.ViewHolder {
            final TextView title, meta;
            VH(View v) {
                super(v);
                title = v.findViewById(R.id.archived_title);
                meta = v.findViewById(R.id.archived_meta);
            }
        }

        private static final DiffUtil.ItemCallback<Task> DIFF = new DiffUtil.ItemCallback<Task>() {
            @Override public boolean areItemsTheSame(@NonNull Task a, @NonNull Task b) { return a.id == b.id; }
            @Override public boolean areContentsTheSame(@NonNull Task a, @NonNull Task b) {
                return a.archivedAt == b.archivedAt && TextUtils.equals(a.title, b.title);
            }
        };
    }
}
