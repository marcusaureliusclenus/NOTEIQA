package sk.aetheriqa.noteiqa.ui.kids;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.util.DialogThemes;

/**
 * KidPaymentsSubFragment – zoznam platieb filtrovaný podľa vybraného dieťaťa.
 *
 * Klik na kartu → KidPaymentContextDialog (copy-friendly IBAN / hotovosť detaily).
 * Long-press → zmazať.
 */
public class KidPaymentsSubFragment extends Fragment {

    private static final String ARG_KID_ID = "kidId";

    private long kidId;
    private KidRepository repo;
    private KidPaymentsAdapter adapter;
    private RecyclerView list;
    private View empty;

    private List<Kid> kidsCache;

    public static KidPaymentsSubFragment newInstance(long kidId) {
        KidPaymentsSubFragment f = new KidPaymentsSubFragment();
        Bundle b = new Bundle();
        b.putLong(ARG_KID_ID, kidId);
        f.setArguments(b);
        return f;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_kid_payments, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        kidId = getArguments() != null ? getArguments().getLong(ARG_KID_ID, 0L) : 0L;
        repo = KidRepository.getInstance(requireContext());

        TextView monthTotal = view.findViewById(R.id.kid_payments_month_total);
        repo.observeOutstandingThisMonth(kidId).observe(getViewLifecycleOwner(), sum -> {
            double value = sum != null ? sum : 0d;
            if (value <= 0.0001d) {
                monthTotal.setText(R.string.kid_payments_month_clear);
            } else {
                String formatted = String.format(Locale.getDefault(), "%.2f", value).replace('.', ',');
                monthTotal.setText(getString(R.string.kid_payments_month_left, formatted));
            }
        });

        list = view.findViewById(R.id.kid_payments_list);
        empty = view.findViewById(R.id.kid_payments_empty);
        list.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new KidPaymentsAdapter(new KidPaymentsAdapter.Listener() {
            @Override public void onClick(KidPayment p) {
                // v1.3.0 — primárne platobný lístok (dialóg ostáva ako fallback)
                startActivity(PaymentTicketActivity.newIntent(requireContext(), p.id));
            }
            @Override public void onLongPress(KidPayment p) {
                showDeleteConfirm(p);
            }
            @Override public void onCheck(KidPayment p, boolean checked) {
                KidPaymentContextDialog.setCompletedWithToast(requireContext(), repo, p.id, checked);
            }
        });
        list.setAdapter(adapter);

        // Načítaj mená detí kvôli zobrazeniu chip-u pri režime "Oboje"
        repo.observeKids().observe(getViewLifecycleOwner(), kids -> {
            kidsCache = kids;
            adapter.setKids(kids);
        });

        // Filter podľa kidId
        Observer<List<KidPayment>> observer = payments -> {
            if (payments == null || payments.isEmpty()) {
                empty.setVisibility(View.VISIBLE);
                list.setVisibility(View.GONE);
                adapter.submit(new java.util.ArrayList<>());
            } else {
                empty.setVisibility(View.GONE);
                list.setVisibility(View.VISIBLE);
                adapter.submit(payments);
            }
        };

        if (kidId == KidRepository.KID_ID_ALL) {
            repo.observePayments().observe(getViewLifecycleOwner(), observer);
        } else {
            repo.observePaymentsByKid(kidId).observe(getViewLifecycleOwner(), observer);
        }
    }

    private void showDeleteConfirm(KidPayment p) {
        new AlertDialog.Builder(requireContext(), DialogThemes.LEA)
                .setTitle(R.string.kid_delete_confirm_title)
                .setMessage(R.string.kid_delete_confirm_message)
                .setPositiveButton(R.string.action_yes, (d, w) -> {
                    repo.deletePayment(p.id);
                })
                .setNegativeButton(R.string.action_no, null)
                .show();
    }
}
