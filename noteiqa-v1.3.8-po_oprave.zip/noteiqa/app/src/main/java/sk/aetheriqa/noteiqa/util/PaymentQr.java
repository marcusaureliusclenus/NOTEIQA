package sk.aetheriqa.noteiqa.util;

import android.text.TextUtils;

import androidx.annotation.Nullable;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import sk.aetheriqa.noteiqa.data.entity.KidPayment;

/**
 * PaymentQr – v1.3.0 — most medzi KidPayment a PayBySquare.
 * QR len pre prevod s IBAN a sumou a len ak PayBySquare prešiel referenčným vektorom.
 */
public final class PaymentQr {

    private PaymentQr() {}

    public static boolean canRender(KidPayment p) {
        return hasTransferData(p)
                && !TextUtils.isEmpty(trim(p.beneficiaryName))
                && PayBySquare.isVerified();
    }

    /**
     * v1.3.3 — prevod s IBAN a sumou, ale bez mena príjemcu → lístok ukáže
     * „QR treba meno príjemcu“ namiesto QR. Banky Pay by Square bez mena neprijmú.
     */
    public static boolean missingBeneficiary(KidPayment p) {
        return hasTransferData(p) && TextUtils.isEmpty(trim(p.beneficiaryName));
    }

    private static boolean hasTransferData(KidPayment p) {
        return p != null
                && p.paymentMethod == KidPayment.METHOD_TRANSFER
                && !TextUtils.isEmpty(p.iban)
                && p.amountEur != null && p.amountEur > 0d;
    }

    @Nullable
    private static String trim(@Nullable String s) {
        return s == null ? null : s.trim();
    }

    /** PAY by square reťazec alebo null (nedá sa / chyba). */
    @Nullable
    public static String code(KidPayment p) {
        if (!canRender(p)) return null;
        PayBySquare.Input in = new PayBySquare.Input();
        in.amount = BigDecimal.valueOf(p.amountEur);
        long due = p.dueDate > 0L ? p.dueDate : System.currentTimeMillis();
        in.dueDate = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date(due));
        in.variableSymbol = p.variableSymbol;
        in.specificSymbol = p.specificSymbol;
        in.constantSymbol = p.constantSymbol; // v1.3.4 — KS, ak je
        in.paymentNote = p.paymentNote;
        in.iban = p.iban;
        // v1.3.3 — meno / názov príjemcu z editora (PayBySquare: max 70, bez diakritiky)
        in.beneficiaryName = p.beneficiaryName.trim();
        try {
            return PayBySquare.generate(in);
        } catch (Exception e) {
            return null;
        }
    }
}
