package sk.aetheriqa.noteiqa.ui.kids;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Calendar;
import java.util.List;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.util.AmountFormat;
import sk.aetheriqa.noteiqa.util.DateUtils;
import sk.aetheriqa.noteiqa.util.PayBySquare;
import sk.aetheriqa.noteiqa.util.DecimalCommaInput;
import sk.aetheriqa.noteiqa.util.DialogThemes;
import sk.aetheriqa.noteiqa.util.ExactAlarmNotice;

/**
 * KidPaymentEditorActivity – vytvorenie / úprava platby.
 *
 * Extras:
 *   EXTRA_ID = 0 → new, > 0 → edit
 *   EXTRA_KID_ID = predvolené dieťa
 *   EXTRA_PERSONAL = v1.3.4 — osobná platba z To Do (bez „Pre koho“, kidId NULL)
 *   EXTRA_REPEAT_FROM = v1.3.4 — nová platba predvyplnená zo zaplatenej
 *                       (bez splatnosti, hneď kalendár, originPaymentId = pôvodná)
 */
public class KidPaymentEditorActivity extends AppCompatActivity {

    public static final String EXTRA_ID = "paymentId";
    public static final String EXTRA_KID_ID = "kidId";
    public static final String EXTRA_PERSONAL = "personal";
    public static final String EXTRA_REPEAT_FROM = "repeatFrom";

    private KidRepository repo;
    private KidPayment editing;

    private MaterialButtonToggleGroup kidGroup;
    private MaterialButton kidAbtn, kidBbtn;
    private Kid kidA, kidB;
    private long selectedKidId = 0L;
    /** v1.3.5 — načítanie z PAY by square QR. */
    private PayBySquareScanner qrScanner;

    /** v1.3.4 — osobná platba: bez výberu dieťaťa, kidId = NULL. */
    private boolean personal;

    private EditText title, beneficiary, amount, iban, vs, ss, ks, msg, cashRecipient, note;
    private RadioGroup methodGroup;
    private RadioButton mTransfer, mCash, mOther;
    private View transferGroup, cashGroup;
    private MaterialButton dueBtn, notifyBtn, recurrenceBtn;

    private long dueDate = 0L;
    private long notifyAt = 0L;
    private int recurrence = KidPayment.RECURRENCE_NONE;
    /** v1.3.3 — pre RECURRENCE_EXACT. 0 = nič. */
    private long exactDueDate = 0L;

    public static Intent newIntent(Context ctx, long paymentId, long kidId) {
        Intent i = new Intent(ctx, KidPaymentEditorActivity.class);
        i.putExtra(EXTRA_ID, paymentId);
        i.putExtra(EXTRA_KID_ID, kidId);
        return i;
    }

    /** v1.3.4 — nová osobná platba (To Do → kategória Platba). */
    public static Intent newPersonalIntent(Context ctx) {
        Intent i = new Intent(ctx, KidPaymentEditorActivity.class);
        i.putExtra(EXTRA_PERSONAL, true);
        return i;
    }

    /** v1.3.4 — „Opakovať“ na zaplatenom lístku: nová platba z tejto. */
    public static Intent newRepeatIntent(Context ctx, long fromPaymentId) {
        Intent i = new Intent(ctx, KidPaymentEditorActivity.class);
        i.putExtra(EXTRA_REPEAT_FROM, fromPaymentId);
        return i;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kid_payment_editor);

        repo = KidRepository.getInstance(this);

        MaterialToolbar tb = findViewById(R.id.editor_toolbar);
        tb.setNavigationOnClickListener(v -> finish());
        tb.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();
            if (id == R.id.action_delete) { deleteConfirm(); return true; }
            return false;
        });

        FloatingActionButton fabSave = findViewById(R.id.fab_save);
        fabSave.setOnClickListener(v -> save());

        kidGroup = findViewById(R.id.ed_kid_group);
        kidAbtn = findViewById(R.id.ed_kid_a);
        kidBbtn = findViewById(R.id.ed_kid_b);

        title = findViewById(R.id.ed_title);
        beneficiary = findViewById(R.id.ed_beneficiary);
        amount = findViewById(R.id.ed_amount);
        DecimalCommaInput.attach(amount); // v1.3.5 — 32,10 € (čiarka)
        methodGroup = findViewById(R.id.ed_method_group);
        mTransfer = findViewById(R.id.ed_method_transfer);
        mCash = findViewById(R.id.ed_method_cash);
        mOther = findViewById(R.id.ed_method_other);
        transferGroup = findViewById(R.id.ed_transfer_group);
        cashGroup = findViewById(R.id.ed_cash_group);
        iban = findViewById(R.id.ed_iban);
        vs = findViewById(R.id.ed_vs);
        ss = findViewById(R.id.ed_ss);
        ks = findViewById(R.id.ed_ks);
        msg = findViewById(R.id.ed_msg);
        cashRecipient = findViewById(R.id.ed_cash_recipient);
        note = findViewById(R.id.ed_note);
        dueBtn = findViewById(R.id.ed_due_btn);
        notifyBtn = findViewById(R.id.ed_notify_btn);
        recurrenceBtn = findViewById(R.id.ed_recurrence_btn);

        methodGroup.setOnCheckedChangeListener((g, checkedId) -> updateMethodVisibility());
        mTransfer.setChecked(true);

        dueBtn.setOnClickListener(v -> pickDueDate());
        notifyBtn.setOnClickListener(v -> pickNotifyDate());
        recurrenceBtn.setOnClickListener(v -> pickRecurrence());

        qrScanner = new PayBySquareScanner(this, this::applyQr);
        findViewById(R.id.ed_qr_btn).setOnClickListener(v -> qrScanner.start());

        loadKids();

        long editId = getIntent().getLongExtra(EXTRA_ID, 0L);
        long repeatFrom = getIntent().getLongExtra(EXTRA_REPEAT_FROM, 0L);
        if (editId > 0L) {
            tb.setTitle(R.string.kid_payment_edit_title);
            loadPayment(editId, false);
        } else if (repeatFrom > 0L) {
            loadPayment(repeatFrom, true);
        } else {
            editing = new KidPayment();
            if (getIntent().getBooleanExtra(EXTRA_PERSONAL, false)) {
                setPersonal(true);
            } else {
                editing.kidId = getIntent().getLongExtra(EXTRA_KID_ID, 0L);
                selectedKidId = editing.kidIdOrZero();
            }
        }
    }

    /** v1.3.4 — osobná platba: riadok „Pre koho“ preč, všetko ostatné ostáva. */
    private void setPersonal(boolean on) {
        personal = on;
        int vis = on ? View.GONE : View.VISIBLE;
        findViewById(R.id.ed_kid_label).setVisibility(vis);
        kidGroup.setVisibility(vis);
    }

    private void loadKids() {
        new Thread(() -> {
            List<Kid> kids = repo.getKidsSync();
            runOnUiThread(() -> {
                if (kids == null || kids.size() < 2) return;
                kidA = kids.get(0);
                kidB = kids.get(1);
                kidAbtn.setText(kidA.name);
                kidBbtn.setText(kidB.name);

                kidGroup.addOnButtonCheckedListener((g, checkedId, isChecked) -> {
                    if (!isChecked) return;
                    if (checkedId == R.id.ed_kid_a) selectedKidId = kidA.id;
                    else if (checkedId == R.id.ed_kid_b) selectedKidId = kidB.id;
                });

                if (selectedKidId == kidA.id) kidGroup.check(R.id.ed_kid_a);
                else if (selectedKidId == kidB.id) kidGroup.check(R.id.ed_kid_b);
                else kidGroup.check(R.id.ed_kid_a);
            });
        }, "load-kids").start();
    }

    /**
     * @param asRepeat v1.3.4 — true: nová platba z {@code id} (Opakovať) — polia sa skopírujú,
     *                 splatnosť ostane prázdna, opakovanie bez, a hneď sa otvorí kalendár.
     */
    private void loadPayment(long id, boolean asRepeat) {
        new Thread(() -> {
            KidPayment p = repo.getPaymentSync(id);
            if (p == null) return;
            runOnUiThread(() -> {
                if (asRepeat) {
                    editing = new KidPayment();
                    editing.kidId = p.kidId;
                    editing.originPaymentId = p.id;
                } else {
                    editing = p;
                }
                setPersonal(p.isPersonal());
                selectedKidId = p.kidIdOrZero();
                title.setText(p.title);
                beneficiary.setText(p.beneficiaryName);
                if (p.amountEur != null) {
                    amount.setText(String.format(java.util.Locale.getDefault(),
                            "%.2f", p.amountEur).replace('.', ','));
                }
                if (p.paymentMethod == KidPayment.METHOD_CASH) mCash.setChecked(true);
                else if (p.paymentMethod == KidPayment.METHOD_OTHER) mOther.setChecked(true);
                else mTransfer.setChecked(true);
                iban.setText(p.iban);
                vs.setText(p.variableSymbol);
                ss.setText(p.specificSymbol);
                ks.setText(p.constantSymbol);
                msg.setText(p.paymentNote);
                cashRecipient.setText(p.cashRecipient);
                note.setText(p.note);
                if (asRepeat) {
                    dueDate = 0L;
                    notifyAt = 0L;
                    recurrence = KidPayment.RECURRENCE_NONE;
                    exactDueDate = 0L;
                } else {
                    dueDate = p.dueDate;
                    notifyAt = p.notifyAt;
                    recurrence = p.recurrence;
                    exactDueDate = p.exactDueDate;
                }
                refreshButtons();

                if (kidA != null && kidB != null) {
                    if (selectedKidId == kidA.id) kidGroup.check(R.id.ed_kid_a);
                    else if (selectedKidId == kidB.id) kidGroup.check(R.id.ed_kid_b);
                }
                // zrušenie pickera nechá splatnosť prázdnu; uloženie bez nej toastne
                if (asRepeat) pickDueDate();
            });
        }, "load-payment").start();
    }

    private void updateMethodVisibility() {
        int checked = methodGroup.getCheckedRadioButtonId();
        transferGroup.setVisibility(checked == R.id.ed_method_transfer ? View.VISIBLE : View.GONE);
        cashGroup.setVisibility(checked == R.id.ed_method_cash ? View.VISIBLE : View.GONE);
    }

    private void refreshButtons() {
        dueBtn.setText(dueDate > 0L
                ? DateUtils.formatLongDate(dueDate)
                : getString(R.string.kid_pick_date));
        notifyBtn.setText(notifyAt > 0L
                ? DateUtils.formatLongDate(notifyAt) + " " + timeOf(notifyAt)
                : getString(R.string.kid_no_reminder));
        recurrenceBtn.setText(recurrenceLabel(recurrence));
    }

    private String timeOf(long ts) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ts);
        return String.format(java.util.Locale.getDefault(), "%d:%02d",
                c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
    }

    private String recurrenceLabel(int rec) {
        switch (rec) {
            case KidPayment.RECURRENCE_MONTHLY: return getString(R.string.kid_recurrence_monthly);
            case KidPayment.RECURRENCE_QUARTERLY: return getString(R.string.kid_recurrence_quarterly);
            case KidPayment.RECURRENCE_SEMIANNUAL: return getString(R.string.kid_recurrence_semiannual);
            case KidPayment.RECURRENCE_YEARLY: return getString(R.string.kid_recurrence_yearly);
            case KidPayment.RECURRENCE_EXACT:
                return exactDueDate > 0L
                        ? getString(R.string.kid_recurrence_exact_on, KidPaymentsAdapter.formatDayMonthYear(exactDueDate))
                        : getString(R.string.kid_recurrence_exact);
            default: return getString(R.string.kid_recurrence_none);
        }
    }

    // v1.1.1 — Picker bez theme overlay (rovnako ako TaskEditorActivity): dedí tmavú
    // Theme.Material3.Dark z aktivity. ThemeOverlay.Noteiqa.Dialog je overlay pre
    // MaterialAlertDialog, nie plná téma pre framework DatePicker → dával svetlý podklad.
    private void pickDueDate() {
        Calendar c = Calendar.getInstance();
        if (dueDate > 0L) c.setTimeInMillis(dueDate);
        DatePickerDialog dlg = new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    Calendar picked = Calendar.getInstance();
                    picked.set(year, month, dayOfMonth, 0, 0, 0);
                    picked.set(Calendar.MILLISECOND, 0);
                    dueDate = picked.getTimeInMillis();
                    refreshButtons();
                },
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dlg.show();
    }

    private void pickNotifyDate() {
        Calendar c = Calendar.getInstance();
        if (notifyAt > 0L) c.setTimeInMillis(notifyAt);
        else if (dueDate > 0L) {
            c.setTimeInMillis(dueDate);
            c.add(Calendar.DAY_OF_MONTH, -2);
            c.set(Calendar.HOUR_OF_DAY, 9);
        }
        DatePickerDialog datePicker = new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    Calendar picked = Calendar.getInstance();
                    picked.set(year, month, dayOfMonth, 9, 0, 0);
                    picked.set(Calendar.MILLISECOND, 0);
                    TimePickerDialog tp = new TimePickerDialog(this,
                            (v, h, m) -> {
                                picked.set(Calendar.HOUR_OF_DAY, h);
                                picked.set(Calendar.MINUTE, m);
                                notifyAt = picked.getTimeInMillis();
                                refreshButtons();
                            }, 9, 0, true);
                    tp.show();
                },
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        datePicker.show();
    }

    private void pickRecurrence() {
        String[] items = new String[]{
                getString(R.string.kid_recurrence_none),
                getString(R.string.kid_recurrence_monthly),
                getString(R.string.kid_recurrence_quarterly),
                getString(R.string.kid_recurrence_semiannual),
                getString(R.string.kid_recurrence_yearly),
                getString(R.string.kid_recurrence_exact)
        };
        int[] values = new int[]{
                KidPayment.RECURRENCE_NONE,
                KidPayment.RECURRENCE_MONTHLY,
                KidPayment.RECURRENCE_QUARTERLY,
                KidPayment.RECURRENCE_SEMIANNUAL,
                KidPayment.RECURRENCE_YEARLY,
                KidPayment.RECURRENCE_EXACT
        };
        new AlertDialog.Builder(this, DialogThemes.LEA)
                .setTitle(R.string.kid_payment_recurrence)
                .setItems(items, (d, which) -> {
                    if (values[which] == KidPayment.RECURRENCE_EXACT) {
                        pickExactDate();
                        return;
                    }
                    recurrence = values[which];
                    refreshButtons();
                })
                .show();
    }

    /**
     * v1.3.3 — „Presný dátum“: hneď kalendár (bez theme overlay, ako ostatné pickery).
     * Zrušenie pickera nechá pôvodné opakovanie.
     */
    private void pickExactDate() {
        Calendar c = Calendar.getInstance();
        if (exactDueDate > 0L) c.setTimeInMillis(exactDueDate);
        else if (dueDate > 0L) {
            c.setTimeInMillis(dueDate);
            c.add(Calendar.MONTH, 1);
        }
        DatePickerDialog dlg = new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    Calendar picked = Calendar.getInstance();
                    picked.set(year, month, dayOfMonth, 0, 0, 0);
                    picked.set(Calendar.MILLISECOND, 0);
                    exactDueDate = picked.getTimeInMillis();
                    recurrence = KidPayment.RECURRENCE_EXACT;
                    refreshButtons();
                },
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dlg.show();
    }

    /**
     * v1.3.5 — vyplní polia z naskenovaného PAY by square. Prázdne hodnoty z QR
     * nič neprepíšu; dieťa, pripomienka a opakovanie ostávajú. Názov sa doplní,
     * len ak je prázdny (správa pre príjemcu, inak meno príjemcu).
     */
    private void applyQr(String raw) {
        PayBySquare.Input in;
        try {
            in = PayBySquare.parse(raw);
        } catch (Exception e) {
            Toast.makeText(this, R.string.qr_scan_not_pbs, Toast.LENGTH_LONG).show();
            return;
        }
        mTransfer.setChecked(true);
        if (in.amount != null) amount.setText(AmountFormat.format(in.amount.doubleValue()));
        setIfPresent(beneficiary, in.beneficiaryName);
        setIfPresent(iban, in.iban);
        setIfPresent(vs, in.variableSymbol);
        setIfPresent(ss, in.specificSymbol);
        setIfPresent(ks, in.constantSymbol);
        setIfPresent(msg, in.paymentNote);
        if (TextUtils.isEmpty(title.getText())) {
            title.setText(!TextUtils.isEmpty(in.paymentNote) ? in.paymentNote : in.beneficiaryName);
        }
        long due = parseYmd(in.dueDate);
        if (due > 0L) dueDate = due;
        refreshButtons();
        Toast.makeText(this, R.string.qr_scan_applied, Toast.LENGTH_SHORT).show();
    }

    private static void setIfPresent(EditText field, @androidx.annotation.Nullable String value) {
        if (value != null && !value.trim().isEmpty()) field.setText(value.trim());
    }

    /** "20261015" → polnoc toho dňa; zlý / prázdny dátum → 0. */
    private static long parseYmd(@androidx.annotation.Nullable String ymd) {
        if (ymd == null || !ymd.matches("\\d{8}")) return 0L;
        int y = Integer.parseInt(ymd.substring(0, 4));
        int m = Integer.parseInt(ymd.substring(4, 6));
        int d = Integer.parseInt(ymd.substring(6, 8));
        if (m < 1 || m > 12 || d < 1 || d > 31) return 0L;
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(y, m - 1, d, 0, 0, 0);
        return c.getTimeInMillis();
    }

    private void save() {
        String t = title.getText() != null ? title.getText().toString().trim() : "";
        if (TextUtils.isEmpty(t)) {
            Toast.makeText(this, R.string.kid_payment_error_title, Toast.LENGTH_SHORT).show();
            return;
        }
        if (dueDate <= 0L) {
            Toast.makeText(this, R.string.kid_payment_error_due, Toast.LENGTH_SHORT).show();
            return;
        }
        if (!personal && selectedKidId <= 0L) {
            Toast.makeText(this, R.string.kid_payment_error_kid, Toast.LENGTH_SHORT).show();
            return;
        }
        int checked = methodGroup.getCheckedRadioButtonId();
        String ben = strOrNull(beneficiary);
        if (checked == R.id.ed_method_transfer && ben == null) {
            Toast.makeText(this, R.string.kid_payment_error_beneficiary, Toast.LENGTH_SHORT).show();
            return;
        }
        if (recurrence == KidPayment.RECURRENCE_EXACT && exactDueDate <= dueDate) {
            Toast.makeText(this, R.string.kid_payment_error_exact_date, Toast.LENGTH_SHORT).show();
            return;
        }

        if (editing == null) editing = new KidPayment();
        editing.kidId = personal ? null : selectedKidId;
        editing.title = t;
        editing.beneficiaryName = ben;

        String am = amount.getText() != null ? amount.getText().toString().trim() : "";
        am = am.replace(',', '.');
        if (!am.isEmpty()) {
            try { editing.amountEur = Double.parseDouble(am); }
            catch (NumberFormatException e) { editing.amountEur = null; }
        } else {
            editing.amountEur = null;
        }

        if (checked == R.id.ed_method_cash) editing.paymentMethod = KidPayment.METHOD_CASH;
        else if (checked == R.id.ed_method_other) editing.paymentMethod = KidPayment.METHOD_OTHER;
        else editing.paymentMethod = KidPayment.METHOD_TRANSFER;

        editing.iban = strOrNull(iban);
        editing.variableSymbol = strOrNull(vs);
        editing.specificSymbol = strOrNull(ss);
        editing.constantSymbol = strOrNull(ks);
        editing.paymentNote = strOrNull(msg);
        editing.cashRecipient = strOrNull(cashRecipient);
        editing.note = strOrNull(note);
        editing.dueDate = dueDate;
        editing.notifyAt = notifyAt;
        editing.recurrence = recurrence;
        editing.exactDueDate = recurrence == KidPayment.RECURRENCE_EXACT ? exactDueDate : 0L;

        ExactAlarmNotice.maybeWarn(this, notifyAt);
        repo.savePayment(editing, id -> runOnUiThread(() -> {
            Toast.makeText(this, R.string.kid_payment_saved, Toast.LENGTH_SHORT).show();
            finish();
        }));
    }

    private String strOrNull(EditText field) {
        if (field.getText() == null) return null;
        String s = field.getText().toString().trim();
        return s.isEmpty() ? null : s;
    }

    private void deleteConfirm() {
        if (editing == null || editing.id == 0L) { finish(); return; }
        new AlertDialog.Builder(this, DialogThemes.LEA)
                .setTitle(R.string.kid_delete_confirm_title)
                .setMessage(R.string.kid_delete_confirm_message)
                .setPositiveButton(R.string.action_yes, (d, w) -> {
                    repo.deletePayment(editing.id);
                    Toast.makeText(this, R.string.kid_payment_deleted, Toast.LENGTH_SHORT).show();
                    finish();
                })
                .setNegativeButton(R.string.action_no, null)
                .show();
    }
}
