package sk.aetheriqa.noteiqa.util;

import sk.aetheriqa.noteiqa.R;

/**
 * DialogThemes – centralizovaný theme overlay pre všetky AlertDialog-y v appke.
 *
 * Použitie:
 *   new AlertDialog.Builder(ctx, DialogThemes.LEA)
 *
 * Všetky context menu, confirm dialógy, list dialógy v To Do aj v Notes používajú
 * tento overlay → konzistentne tmavé pozadie + gold tlačidlá + serif title.
 */
public final class DialogThemes {

    /** LEA tmavé pozadie + gold accents. */
    public static final int LEA = R.style.ThemeOverlay_Noteiqa_Dialog;

    private DialogThemes() {}
}
