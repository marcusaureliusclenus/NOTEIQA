package sk.aetheriqa.noteiqa.ui.todo;

import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;

/**
 * KidEventTaskLike – nosič pre KidEvent injectnutý do TasksAdapter items listu.
 *
 * V UI sa vykresľuje ako task s odlišným štýlom:
 *  - Menší font (šedšia farba)
 *  - Malá ikona dieťaťa ic_kid_small vľavo
 *  - Text: "Alex: Výlet do Bratislavy" (kid name + event title)
 *  - Klik → otvorí KidEventEditorActivity
 *
 * NIE JE uložený v DB — vytvára sa v pamäti z aktuálnych KidEvents pri
 * každom refreshi TasksFragment.
 */
public class KidEventTaskLike {

    public final KidEvent event;
    public final Kid kid; // môže byť null (kidId = 0 → oboje)

    public KidEventTaskLike(KidEvent event, Kid kid) {
        this.event = event;
        this.kid = kid;
    }

    /** "Alex: Výlet do Bratislavy" alebo "Deti: Prázdniny" pri spoločnej udalosti. */
    public String displayTitle(android.content.Context ctx) {
        String prefix = kid != null ? kid.name : ctx.getString(sk.aetheriqa.noteiqa.R.string.kids_label_all);
        return ctx.getString(sk.aetheriqa.noteiqa.R.string.kid_event_todo_title, prefix, event.title);
    }

    /**
     * v1.3.6 — druhý riadok: "UT 6.10.2026 8:00 · miesto" (celodenná bez času,
     * bez miesta len dátum). Rovnaký formát dátumu ako podtitul úlohy.
     */
    public String metaLine() {
        StringBuilder sb = new StringBuilder();
        sb.append(sk.aetheriqa.noteiqa.util.DateUtils.slovakDayShort(event.startDate)
                .toUpperCase(new java.util.Locale("sk")));
        sb.append(' ').append(sk.aetheriqa.noteiqa.util.DateUtils.formatLongDate(event.startDate));
        if (!event.allDay) {
            java.util.Calendar c = java.util.Calendar.getInstance();
            c.setTimeInMillis(event.startDate);
            sb.append(' ').append(String.format(java.util.Locale.getDefault(), "%d:%02d",
                    c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE)));
        }
        if (event.location != null && !event.location.trim().isEmpty()) {
            sb.append(" · ").append(event.location.trim());
        }
        return sb.toString();
    }

    /** Timestamp pre bucketovanie — používa startDate udalosti. */
    public long timestamp() {
        return event.startDate;
    }
}
