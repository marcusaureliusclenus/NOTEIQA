package sk.aetheriqa.noteiqa.data.entity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/**
 * Note – základná entita poznámky.
 *
 * Typy poznámok:
 *  - TYPE_TEXT: voľný text + markdown
 *  - TYPE_CHECKLIST: zoznam zaškrtávateľných položiek (cez ChecklistItem)
 *  - TYPE_TABLE: tabuľka (JSON serialized do `tableJson`)
 *
 * Stavy:
 *  - STATE_ACTIVE: bežná poznámka v zozname
 *  - STATE_ARCHIVED: archív
 *  - STATE_TRASHED: kôš (TTL 30 dní cez WorkManager cleanup job)
 *
 * Diakritika je normalizovaná do `searchIndex` pre fulltext bez háčikov a dĺžňov.
 */
@Entity(
    tableName = "notes",
    indices = {
        @Index("state"),
        @Index("pinned"),
        @Index("updatedAt"),
        @Index("type")
    }
)
public class Note {

    public static final int TYPE_TEXT = 0;
    public static final int TYPE_CHECKLIST = 1;
    public static final int TYPE_TABLE = 2;

    public static final int STATE_ACTIVE = 0;
    public static final int STATE_ARCHIVED = 1;
    public static final int STATE_TRASHED = 2;

    @PrimaryKey(autoGenerate = true)
    public long id;

    /** Typ poznámky – TEXT / CHECKLIST / TABLE */
    public int type = TYPE_TEXT;

    /** Stav – ACTIVE / ARCHIVED / TRASHED */
    public int state = STATE_ACTIVE;

    @Nullable
    public String title;

    /** Telo poznámky (pre TYPE_TEXT). Pri checkliste je null. */
    @Nullable
    public String body;

    /** JSON tabuľky (pre TYPE_TABLE). Schéma: { "rows": [...], "cols": [...] } */
    @Nullable
    public String tableJson;

    /**
     * Search index – telo + title bez diakritiky, lowercase.
     * Umožňuje hľadať "salat" a nájsť "šalát".
     */
    @ColumnInfo(name = "searchIndex")
    @Nullable
    public String searchIndex;

    /** Hex farba štítku/zvýraznenia (napr. "#D4AF37"). Voliteľné. */
    @Nullable
    public String color;

    public boolean pinned = false;

    /** Voliteľný PIN/biometria zámok pre konkrétnu poznámku (fáza 2). */
    public boolean locked = false;

    /**
     * Cesta k pripojenému obrázku (interná zložka appky).
     * Null = poznámka bez obrázka. Pre v0.4.0 podporujeme 1 obrázok na poznámku.
     */
    @Nullable
    public String attachmentImagePath;

    /** Unix epoch millis */
    public long createdAt;
    public long updatedAt;
    /** Kedy bola hodená do koša (pre TTL cleanup). 0 ak nie je v koši. */
    public long trashedAt = 0L;

    public Note() {}

    @NonNull
    public static Note newText(@Nullable String title, @Nullable String body) {
        Note n = new Note();
        n.type = TYPE_TEXT;
        n.title = title;
        n.body = body;
        long now = System.currentTimeMillis();
        n.createdAt = now;
        n.updatedAt = now;
        return n;
    }
}
