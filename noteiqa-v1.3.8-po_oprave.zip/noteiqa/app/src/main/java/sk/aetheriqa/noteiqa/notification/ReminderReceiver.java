package sk.aetheriqa.noteiqa.notification;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;

import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.data.repository.TaskRepository;

/**
 * ReminderReceiver – AlarmManager trigger pre pripomienky úloh.
 *
 * Príjme intent s taskId, na background threade načíta úlohu z DB a
 * delegát na NotificationHelper.showTaskReminder().
 *
 * Edge cases:
 *  - úloha už neexistuje → neukáže nič
 *  - úloha bola archivovaná → neukáže nič (cleanup)
 *  - úloha má reminderAt vynulovaný (používateľ zrušil) → neukáže nič
 */
public class ReminderReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        long taskId = intent.getLongExtra(ReminderScheduler.EXTRA_TASK_ID, 0L);
        if (taskId == 0L) return;

        // BroadcastReceiver má ~10s pred ANR – DB read posunieme na background
        // a vyrobíme notifikáciu späť na main thread cez NotificationHelper.
        Context appCtx = context.getApplicationContext();
        new Thread(() -> {
            Task task = TaskRepository.getInstance(appCtx).getByIdSync(taskId);
            if (task == null) return;
            if (task.archivedAt > 0) return;
            if (task.reminderAt == 0L) return; // používateľ medzitým zrušil

            new Handler(Looper.getMainLooper()).post(() ->
                    NotificationHelper.showTaskReminder(appCtx, task));
        }, "ReminderReceiver-load").start();
    }
}
