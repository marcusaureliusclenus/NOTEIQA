package sk.aetheriqa.noteiqa.data.entity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/**
 * Tag – štítok pre kategorizáciu poznámok.
 *
 * Many-to-many vzťah s Note cez {@link NoteTagCrossRef}.
 * Používateľ si môže vytvoriť ľubovoľné štítky s vlastnou farbou.
 */
@Entity(tableName = "tags", indices = {@Index(value = "name", unique = true)})
public class Tag {

    @PrimaryKey(autoGenerate = true)
    public long id;

    @NonNull
    public String name = "";

    /** Hex farba (default zlatá). */
    @Nullable
    public String color;

    /** Pre triedenie v UI – nižšie číslo = vyššie v zozname. */
    public int sortOrder = 0;

    /** Built-in štítok (Osobné/Práca/Nákup/Rodina/Nápady) – nedá sa zmazať. */
    public boolean systemTag = false;
}
