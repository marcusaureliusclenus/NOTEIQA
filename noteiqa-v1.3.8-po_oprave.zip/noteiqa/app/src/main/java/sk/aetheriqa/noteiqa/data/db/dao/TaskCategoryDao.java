package sk.aetheriqa.noteiqa.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import sk.aetheriqa.noteiqa.data.entity.TaskCategory;

@Dao
public interface TaskCategoryDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insert(TaskCategory category);

    @Update
    int update(TaskCategory category);

    @Delete
    int delete(TaskCategory category);

    @Query("SELECT * FROM task_categories ORDER BY systemCategory DESC, sortOrder ASC, name ASC")
    LiveData<List<TaskCategory>> observeAll();

    @Query("SELECT * FROM task_categories ORDER BY systemCategory DESC, sortOrder ASC, name ASC")
    List<TaskCategory> getAll();

    @Query("SELECT * FROM task_categories WHERE id = :id")
    TaskCategory getById(long id);

    @Query("SELECT COUNT(*) FROM task_categories")
    int count();
}
