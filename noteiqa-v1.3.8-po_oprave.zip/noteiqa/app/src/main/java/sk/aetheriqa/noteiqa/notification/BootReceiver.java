package sk.aetheriqa.noteiqa.notification;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import sk.aetheriqa.noteiqa.data.entity.Task;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.data.repository.TaskRepository;

/**
 * BootReceiver – po reštarte zariadenia obnoví naplánované pripomienky.
 *
 * Android pri boote vyhadzuje všetky AlarmManager-y, takže ich treba znova
 * pre-schedulovať z DB. Pre každú úlohu, ktorá:
 *   - nie je archivovaná (archivedAt == 0)
 *   - má reminderAt v budúcnosti (> now)
 * sa zavolá ReminderScheduler.schedule().
 *
 * Limitujeme sa len na ACTION_BOOT_COMPLETED – nereagujeme na MY_PACKAGE_REPLACED
 * (po update appky AlarmManager pretrvá).
 */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;

        // BroadcastReceiver má ~10s; DB read posunieme na background.
        Context appCtx = context.getApplicationContext();
        TaskRepository repo = TaskRepository.getInstance(appCtx);

        // Použijeme existujúce DAO API, ktoré vráti task list cez callback.
        repo.getActiveRemindersAsync(tasks -> {
            if (tasks == null) return;
            for (Task t : tasks) {
                ReminderScheduler.schedule(appCtx, t);
            }
        });

        // v1.1.0 — Deti modul reminders (platby aj udalosti).
        KidRepository.getInstance(appCtx).reschedulePendingReminders();
    }
}
