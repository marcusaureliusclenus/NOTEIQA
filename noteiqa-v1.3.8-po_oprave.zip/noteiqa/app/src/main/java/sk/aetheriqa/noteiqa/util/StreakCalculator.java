package sk.aetheriqa.noteiqa.util;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.db.AppDatabase;
import sk.aetheriqa.noteiqa.data.entity.WeightEntry;
import sk.aetheriqa.noteiqa.data.preferences.UserPreferences;

/**
 * StreakCalculator – výpočet 3 typov "streakov" pre dashboard:
 *
 *  1. weightStreakDays — koľko po sebe nasledujúcich dní (vrátane dnešného)
 *     bola Gabika vážená? Reset pri preskočení dňa.
 *
 *  2. tasksDoneThisWeek — počet hotových úloh v aktuálnom týždni (pondelok→nedeľa).
 *     (Marek si môže neskôr zmeniť na nedeľu→sobotu, ale pre week počítanie
 *     je pondelok→nedeľa štandardnejší a presnejší.)
 *
 *  3. appAge — formátovaná doba odkedy bola appka prvýkrát spustená (napr.
 *     "5 dní s appkou", "3 mesiace s appkou", "2 roky s appkou").
 *
 * Všetky volania sú **synchronné** — voľaj len z background threadu.
 *
 * Achievement thresholds (zobrazí sa len ak streak >= prahu):
 *   - weight:   3 dni
 *   - tasks:    3 úlohy/týždeň
 *   - app:      7 dní
 */
public final class StreakCalculator {

    public static final int MIN_WEIGHT_STREAK = 3;
    public static final int MIN_TASKS_STREAK = 3;
    public static final int MIN_APP_DAYS = 7;

    public static class Streaks {
        public int weightStreakDays;
        public int tasksDoneThisWeek;
        public long appAgeDays;

        public boolean hasWeightStreak() { return weightStreakDays >= MIN_WEIGHT_STREAK; }
        public boolean hasTasksStreak()  { return tasksDoneThisWeek >= MIN_TASKS_STREAK; }
        public boolean hasAppAge()       { return appAgeDays >= MIN_APP_DAYS; }
    }

    private StreakCalculator() {}

    @NonNull
    public static Streaks compute(Context ctx) {
        Streaks s = new Streaks();
        AppDatabase db = AppDatabase.getInstance(ctx);

        // 1) Weight streak — pozri váženia DESC, počítaj backwards od dnes
        List<WeightEntry> weights = db.weightDao().getAllSyncDesc();
        s.weightStreakDays = computeWeightStreak(weights);

        // 2) Tasks done this week
        long[] week = currentWeekRange();
        s.tasksDoneThisWeek = db.taskDao().countCompletedInRange(week[0], week[1]);

        // 3) App age v dňoch
        long firstLaunch = UserPreferences.get(ctx).getFirstLaunchAt();
        if (firstLaunch > 0L) {
            long deltaMs = System.currentTimeMillis() - firstLaunch;
            s.appAgeDays = Math.max(0L, deltaMs / (24L * 60 * 60 * 1000));
        }

        return s;
    }

    /**
     * Počíta dni v rade počnúc dnešným pri DESC zoradení váženia.
     * Pravidlo: ak je dnes vážená, počítam dni dopredu — pokiaľ
     * deň-pred-dnešným má váženie, +1; ak preskočený, stop.
     *
     * Ak dnes nie je vážená ale včera áno, streak sa NEROZBÍJA — tzv.
     * "grace period" 1 deň, lebo Gabika sa môže ešte za chvíľu vážiť.
     * Ak ale včera ani dnes nie je vážená, streak je 0.
     */
    static int computeWeightStreak(@Nullable List<WeightEntry> weightsDesc) {
        if (weightsDesc == null || weightsDesc.isEmpty()) return 0;

        // Vyextrahuj unikátne dni (yyyy-MM-dd) kedy bola vážená
        Set<Integer> daysWithEntry = new HashSet<>();
        for (WeightEntry w : weightsDesc) {
            daysWithEntry.add(dayKey(w.measuredAt));
        }

        int todayKey = dayKey(System.currentTimeMillis());
        int yesterdayKey = todayKey - 1;

        // Grace period: ak dnes nie je vážená, ale včera áno, počítame od včera
        int startKey;
        if (daysWithEntry.contains(todayKey)) {
            startKey = todayKey;
        } else if (daysWithEntry.contains(yesterdayKey)) {
            startKey = yesterdayKey;
        } else {
            return 0;
        }

        int streak = 0;
        int cursor = startKey;
        while (daysWithEntry.contains(cursor)) {
            streak++;
            cursor--;
        }
        return streak;
    }

    /** Vráti počet dní od epochy (yyyy-MM-dd) v lokálnom timezone. */
    private static int dayKey(long millis) {
        Calendar c = Calendar.getInstance(TimeZone.getDefault());
        c.setTimeInMillis(millis);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return (int) (c.getTimeInMillis() / (24L * 60 * 60 * 1000));
    }

    /** Vráti [startOfWeekMonday00:00, startOfNextWeekMonday00:00). */
    public static long[] currentWeekRange() {
        Calendar c = Calendar.getInstance(TimeZone.getDefault());
        c.setFirstDayOfWeek(Calendar.MONDAY);
        c.setMinimalDaysInFirstWeek(4); // ISO-8601
        // Posunúť na pondelok 00:00
        int dow = c.get(Calendar.DAY_OF_WEEK); // SUNDAY=1, MONDAY=2, ...
        int diff = (dow == Calendar.SUNDAY) ? -6 : (Calendar.MONDAY - dow);
        c.add(Calendar.DAY_OF_YEAR, diff);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        long start = c.getTimeInMillis();
        c.add(Calendar.DAY_OF_YEAR, 7);
        long end = c.getTimeInMillis();
        return new long[]{start, end};
    }

    /**
     * Sformátuje appAgeDays do prirodzeného SK textu pre chip.
     * < 30 dní → "X dní s appkou"
     * < 12 mesiacov → "X mesiacov s appkou"
     * else → "X rokov s appkou"
     */
    @NonNull
    public static String formatAppAge(Context ctx, long days) {
        if (days < 30) {
            return ctx.getString(R.string.streak_app_days, (int) days);
        }
        if (days < 365) {
            int months = (int) (days / 30);
            return ctx.getString(R.string.streak_app_months, months);
        }
        int years = (int) (days / 365);
        return ctx.getString(R.string.streak_app_years, years);
    }
}
