package sk.aetheriqa.noteiqa.ui.kids;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Observer;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.tabs.TabLayout;

import java.util.List;

import sk.aetheriqa.noteiqa.MainActivity;
import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;

/**
 * KidsFragment – hostiteľ Deti modulu.
 *
 * Layout:
 *   [Header "Deti"]
 *   [Segment toggle: Alex | Gabika | Oboje]
 *   [TabLayout: Poplatky a platby | Kalendár udalostí]
 *   [FrameLayout kids_content — sub-fragment (Payments alebo Events)]
 *   [FAB kids_fab_add — pridá platbu alebo udalosť podľa aktuálneho tabu]
 *
 * Prvý button je vždy Alex (id 1), druhý Gabika (id 2), tretí "Oboje" (kidId = 0).
 * Farby chipov sú dynamické — pri select sa použije farba dieťaťa (backgroundTint).
 */
public class KidsFragment extends Fragment {

    /** Aktuálne vybrané kidId. 0 = Oboje. */
    private long selectedKidId = KidRepository.KID_ID_ALL;

    /** Aktuálny sub-tab: 0 = Platby, 1 = Kalendár. */
    private int selectedTab = 0;

    private KidRepository repo;
    private MaterialButton btnA, btnB, btnAll;
    private MaterialButtonToggleGroup filterGroup;
    private TabLayout tabs;
    private Kid kidA, kidB;
    private VoiceDraftLauncher voice;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_kids, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        repo = KidRepository.getInstance(requireContext());

        filterGroup = view.findViewById(R.id.kids_filter_group);
        btnA = view.findViewById(R.id.kids_filter_a);
        btnB = view.findViewById(R.id.kids_filter_b);
        btnAll = view.findViewById(R.id.kids_filter_all);
        tabs = view.findViewById(R.id.kids_tabs);

        // Observe deti — naplň prvé 2 buttony menami; ak sa Alex/Gabika ešte nezaseedovali,
        // buttony zostanú s "..." a čakajú na dáta.
        repo.observeKids().observe(getViewLifecycleOwner(), new Observer<List<Kid>>() {
            @Override
            public void onChanged(List<Kid> kids) {
                if (kids == null || kids.size() < 2) {
                    btnA.setText("…");
                    btnB.setText("…");
                    return;
                }
                kidA = kids.get(0);
                kidB = kids.get(1);
                btnA.setText(kidA.name);
                btnB.setText(kidB.name);

                // Farebný stroke podľa dieťaťa
                try {
                    btnA.setStrokeColor(android.content.res.ColorStateList
                            .valueOf(Color.parseColor(kidA.colorHex)));
                    btnB.setStrokeColor(android.content.res.ColorStateList
                            .valueOf(Color.parseColor(kidB.colorHex)));
                } catch (IllegalArgumentException ignored) {}

                if (filterGroup.getCheckedButtonId() == View.NO_ID) {
                    filterGroup.check(R.id.kids_filter_all);
                }
            }
        });

        filterGroup.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (!isChecked) return;
            if (checkedId == R.id.kids_filter_a && kidA != null) {
                selectedKidId = kidA.id;
            } else if (checkedId == R.id.kids_filter_b && kidB != null) {
                selectedKidId = kidB.id;
            } else {
                selectedKidId = KidRepository.KID_ID_ALL;
            }
            refreshSubFragment();
        });

        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override public void onTabSelected(TabLayout.Tab tab) {
                selectedTab = tab.getPosition();
                refreshSubFragment();
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });

        View fab = view.findViewById(R.id.kids_fab_add);
        // v1.3.2 — FAB rozbalí 4 voľby (Platba, Udalosť, Hlas, Z fotky); žiadny skrytý dlhý stisk
        fab.setOnClickListener(this::showFabMenu);
        voice = new VoiceDraftLauncher(this);

        // v1.3.2 — "Týždeň" (text) → plagát; menu → Pre druhého
        view.findViewById(R.id.kids_week).setOnClickListener(v ->
                startActivity(KidsWeekPosterActivity.newIntent(requireContext())));
        view.findViewById(R.id.kids_more).setOnClickListener(this::showMenu);

        // Handle deep-link (notifikácia z KidReminder)
        handleIncomingDeepLink();

        // Initial state
        refreshSubFragment();
    }

    private void showMenu(View anchor) {
        PopupMenu menu = new PopupMenu(requireContext(), anchor);
        menu.inflate(R.menu.kids_menu);
        menu.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.kids_action_parent_list) {
                ForOtherSheet.show(requireContext());
                return true;
            }
            return false;
        });
        menu.show();
    }

    private void showFabMenu(View anchor) {
        PopupMenu menu = new PopupMenu(requireContext(), anchor);
        menu.inflate(R.menu.kids_fab_menu);
        menu.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();
            if (id == R.id.kids_fab_payment) {
                openEditor(true);
            } else if (id == R.id.kids_fab_event) {
                openEditor(false);
            } else if (id == R.id.kids_fab_voice) {
                voice.start(selectedKidId);
            } else if (id == R.id.kids_fab_photo) {
                startActivity(PhotoDraftActivity.newIntent(requireContext(), selectedKidId));
            } else {
                return false;
            }
            return true;
        });
        menu.show();
    }

    private void refreshSubFragment() {
        Fragment target;
        if (selectedTab == 0) {
            target = KidPaymentsSubFragment.newInstance(selectedKidId);
        } else {
            target = KidEventsSubFragment.newInstance(selectedKidId);
        }
        FragmentTransaction tx = getChildFragmentManager().beginTransaction();
        tx.replace(R.id.kids_content, target);
        tx.commitNowAllowingStateLoss();
    }

    private void openEditor(boolean payment) {
        // Platba musí mať konkrétne dieťa; udalosť pri "Oboje" ostane spoločná.
        long paymentKidId = selectedKidId != KidRepository.KID_ID_ALL
                ? selectedKidId
                : (kidA != null ? kidA.id : 0L);

        Intent intent;
        if (payment) {
            intent = KidPaymentEditorActivity.newIntent(requireContext(), 0L, paymentKidId);
        } else {
            intent = KidEventEditorActivity.newIntent(requireContext(), 0L, selectedKidId);
        }
        startActivity(intent);
    }

    private void handleIncomingDeepLink() {
        Intent intent = requireActivity().getIntent();
        if (intent == null) return;
        if (!MainActivity.ACTION_OPEN_KIDS.equals(intent.getAction())) return;

        long paymentId = intent.getLongExtra(MainActivity.EXTRA_OPEN_PAYMENT_ID, 0L);
        long eventId = intent.getLongExtra(MainActivity.EXTRA_OPEN_EVENT_ID, 0L);

        if (paymentId > 0L) {
            // Otvor Platby tab a zobraz context dialog s tou konkrétnou platbou
            tabs.selectTab(tabs.getTabAt(0));
            // v1.3.0 — platobný lístok namiesto dialógu
            startActivity(PaymentTicketActivity.newIntent(requireContext(), paymentId));
            intent.removeExtra(MainActivity.EXTRA_OPEN_PAYMENT_ID);
        } else if (eventId > 0L) {
            tabs.selectTab(tabs.getTabAt(1));
            intent.removeExtra(MainActivity.EXTRA_OPEN_EVENT_ID);
        }
    }
}
