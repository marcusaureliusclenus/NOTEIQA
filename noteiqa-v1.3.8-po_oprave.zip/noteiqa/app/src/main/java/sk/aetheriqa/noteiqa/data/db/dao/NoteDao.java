package sk.aetheriqa.noteiqa.data.db.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import sk.aetheriqa.noteiqa.data.entity.Note;

@Dao
public interface NoteDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(Note note);

    @Update
    int update(Note note);

    @Delete
    int delete(Note note);

    /** Hlavný zoznam – pripnuté hore, potom podľa updatedAt DESC. */
    @Query("SELECT * FROM notes WHERE state = 0 ORDER BY pinned DESC, updatedAt DESC")
    LiveData<List<Note>> observeActive();

    @Query("SELECT * FROM notes WHERE state = 1 ORDER BY updatedAt DESC")
    LiveData<List<Note>> observeArchived();

    @Query("SELECT * FROM notes WHERE state = 2 ORDER BY trashedAt DESC")
    LiveData<List<Note>> observeTrashed();

    @Query("SELECT * FROM notes WHERE id = :id")
    LiveData<Note> observeById(long id);

    @Query("SELECT * FROM notes WHERE id = :id")
    Note getById(long id);

    /**
     * Diakritika-aware vyhľadávanie. Hľadáme v pred-normalizovanom searchIndex
     * stĺpci, takže "salat" nájde "Šalát". Volajúca strana musí query
     * normalizovať cez DiacriticsUtils.stripDiacritics(query).
     */
    @Query("SELECT * FROM notes WHERE state = 0 AND " +
           "(searchIndex LIKE '%' || :normalized || '%') " +
           "ORDER BY pinned DESC, updatedAt DESC")
    LiveData<List<Note>> search(String normalized);

    @Query("UPDATE notes SET state = 1, updatedAt = :now WHERE id = :id")
    int archive(long id, long now);

    @Query("UPDATE notes SET state = 0, updatedAt = :now WHERE id = :id")
    int unarchive(long id, long now);

    @Query("UPDATE notes SET state = 2, trashedAt = :now WHERE id = :id")
    int trash(long id, long now);

    @Query("UPDATE notes SET state = 0, trashedAt = 0 WHERE id = :id")
    int restoreFromTrash(long id);

    @Query("UPDATE notes SET pinned = :pinned WHERE id = :id")
    int setPinned(long id, boolean pinned);

    /** Periodický cleanup – mazanie poznámok v koši starších ako 30 dní. */
    @Query("DELETE FROM notes WHERE state = 2 AND trashedAt < :cutoffMillis")
    int purgeOldTrashed(long cutoffMillis);

    /** v1.2.0 — aktívne poznámky so štítkom (Nastavenia → Štítky → štítok). */
    @Query("SELECT n.* FROM notes n INNER JOIN note_tags nt ON nt.noteId = n.id " +
           "WHERE nt.tagId = :tagId AND n.state = 0 ORDER BY n.pinned DESC, n.updatedAt DESC")
    LiveData<List<Note>> observeActiveByTag(long tagId);

    /** v1.2.0 — trvalé zmazanie z koša (checklist + tag väzby kaskádou). */
    @Query("DELETE FROM notes WHERE id = :id")
    int deleteById(long id);

    /** v1.2.0 — prílohy poznámok v koši starších ako cutoff (zmažú sa spolu s poznámkou). */
    @Query("SELECT attachmentImagePath FROM notes WHERE state = 2 AND trashedAt < :cutoffMillis " +
           "AND attachmentImagePath IS NOT NULL")
    List<String> getOldTrashedAttachmentsSync(long cutoffMillis);

    /** Pre Export/Backup — sync read všetkých záznamov. */
    @Query("SELECT * FROM notes")
    List<Note> getAllSync();

    /** v0.5.4 — permanentne zmaže všetky archivované poznámky (a kaskádou ich checklist itemy + tag väzby). */
    @Query("DELETE FROM notes WHERE state = 1")
    int deleteAllArchived();
}
