package sk.aetheriqa.noteiqa.util;

import org.tukaani.xz.LZMA2Options;
import org.tukaani.xz.LZMAInputStream;
import org.tukaani.xz.LZMAOutputStream;
import org.tukaani.xz.UnsupportedOptionsException;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.zip.CRC32;

/**
 * PayBySquare – v1.3.0 — lokálne generovanie "PAY by square" reťazca pre QR
 * (slovenský bankový štandard). Žiadne API, žiadny bysquare.com.
 *
 * Postup (rovnaký ako referenčná implementácia matusf/pay-by-square):
 *  1. tab-separated payload: (prázdne) 1 1 suma EUR yyyyMMdd VS KS ŠS (prázdne)
 *     správa 1 IBAN BIC 0 0 príjemca adresa1 adresa2
 *  2. CRC32 (IEEE, java.util.zip.CRC32) nad UTF-8 payloadom, 4 B little-endian, pred dáta
 *  3. LZMA1 raw (lc=3, lp=0, pb=2, slovník 128 KiB), bez .lzma hlavičky
 *  4. pred to 2 nulové bajty (typ/verzia 1.0.0) + dĺžka nekomprimovaných dát (uint16 LE)
 *  5. bity po 5 → abeceda 0-9A-V, doplnené nulami na násobok 5
 *
 * Čistá Java (bez Android API) — overuje sa JVM testom PayBySquareTest
 * a za behu {@link #isVerified()} voči referenčnému vektoru. Ak overenie
 * zlyhá, UI QR ani "Poslať" (obálku) nezobrazí.
 */
public final class PayBySquare {

    private static final String ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUV";
    private static final int DICT_SIZE = 128 * 1024;
    private static final int MAX_NOTE = 140;
    private static final int MAX_NAME = 70;

    /**
     * Referenčný vektor (amount 25.00, EUR, 2026-10-15, VS 123, IBAN SK8975000000000012345671,
     * správa "Test platba", príjemca "Test"). Hodnota je byte-exact výstup referenčnej
     * implementácie pay-by-square 0.2.0 (Python, liblzma) a dekóduje sa aj knižnicou
     * bysquare 4.1.0 (npm) na rovnakú platbu — pozri PayBySquareTest.
     */
    static final String REFERENCE_CODE =
            "0005A00044EC20BG9C6MKK3ELT0OMOE54BVA9H9LF40NLI3BCBMLLH9E48VDE5KUC59P3PB0MBBUBBDBBU7BHEO6SDKIS2PRU64NG7B8TQGTKC9OGR1TC8R566ATVVJ8GA00";

    private static volatile Boolean verified;

    private PayBySquare() {}

    /** Vstup pre jednoduchý platobný príkaz. */
    public static final class Input {
        public BigDecimal amount;
        public String currency = "EUR";
        /** yyyyMMdd; prázdne/null = dnes rieši volajúci (PaymentTicket dá dueDate alebo dnes). */
        public String dueDate;
        public String variableSymbol;
        public String constantSymbol;
        public String specificSymbol;
        public String paymentNote;
        public String iban;
        public String bic;
        public String beneficiaryName;

        public static Input reference() {
            Input in = new Input();
            in.amount = new BigDecimal("25.00");
            in.dueDate = "20261015";
            in.variableSymbol = "123";
            in.specificSymbol = "";
            in.paymentNote = "Test platba";
            in.iban = "SK8975000000000012345671";
            in.beneficiaryName = "Test";
            return in;
        }
    }

    /**
     * Overí implementáciu voči referenčnému vektoru (raz, výsledok sa pamätá).
     * false = QR v UI nezobrazovať, len kopírovanie údajov.
     */
    public static boolean isVerified() {
        Boolean v = verified;
        if (v == null) {
            boolean ok;
            try {
                ok = REFERENCE_CODE.equals(generate(Input.reference()));
            } catch (Throwable t) {
                ok = false;
            }
            verified = v = ok;
        }
        return v;
    }

    /** Vyrobí PAY by square reťazec pre QR. */
    public static String generate(Input in) throws IOException {
        return encode(buildPayload(in));
    }

    /** Tab-separated payload (verejné kvôli testom). */
    public static String buildPayload(Input in) {
        if (in.amount == null) throw new IllegalArgumentException("amount");
        String iban = clean(in.iban).replace(" ", "").toUpperCase(Locale.ROOT);
        if (iban.isEmpty()) throw new IllegalArgumentException("iban");

        String amount = in.amount.setScale(2, RoundingMode.HALF_UP).toPlainString();
        String name = DiacriticsUtils.stripDiacritics(limit(clean(in.beneficiaryName), MAX_NAME));

        return String.join("\t",
                "",                                   // invoiceId
                "1",                                  // počet platieb
                "1",                                  // jednoduchý platobný príkaz
                amount,
                clean(in.currency).isEmpty() ? "EUR" : clean(in.currency),
                clean(in.dueDate),
                digits(in.variableSymbol),
                digits(in.constantSymbol),
                digits(in.specificSymbol),
                "",                                   // SEPA referencia (symboly sú vyššie)
                limit(clean(in.paymentNote), MAX_NOTE),
                "1",                                  // počet účtov
                iban,
                clean(in.bic).toUpperCase(Locale.ROOT),
                "0",                                  // nie trvalý príkaz
                "0",                                  // nie inkaso
                name == null ? "" : name,
                "",                                   // adresa 1
                "");                                  // adresa 2
    }

    /** Kroky 2–5 nad hotovým payloadom. */
    public static String encode(String payload) throws IOException {
        byte[] data = payload.getBytes(StandardCharsets.UTF_8);

        CRC32 crc = new CRC32();
        crc.update(data);
        long c = crc.getValue();
        byte[] total = new byte[data.length + 4];
        total[0] = (byte) c;
        total[1] = (byte) (c >>> 8);
        total[2] = (byte) (c >>> 16);
        total[3] = (byte) (c >>> 24);
        System.arraycopy(data, 0, total, 4, data.length);
        if (total.length > 0xFFFF) throw new IllegalArgumentException("payload too long");

        byte[] compressed = lzmaRaw(total);

        byte[] out = new byte[4 + compressed.length];
        out[0] = 0x00;
        out[1] = 0x00;
        out[2] = (byte) total.length;
        out[3] = (byte) (total.length >>> 8);
        System.arraycopy(compressed, 0, out, 4, compressed.length);

        return toBase32Hex(out);
    }

    /**
     * Spätný dekód na payload (bez CRC) — pre testy a kontrolu, že kód je čitateľný.
     * Vyhodí IOException pri zlom CRC.
     */
    public static String decodeToPayload(String code) throws IOException {
        byte[] bytes = fromBase32Hex(code);
        if (bytes.length < 4) throw new IOException("too short");
        int length = (bytes[2] & 0xFF) | ((bytes[3] & 0xFF) << 8);
        byte[] body = new byte[bytes.length - 4];
        System.arraycopy(bytes, 4, body, 0, body.length);

        // LZMA s end markerom (liblzma, táto trieda) aj bez neho (iné generátory, napr. bysquare npm)
        byte[] total;
        try {
            total = lzmaDecode(body, -1, length);
        } catch (IOException withMarkerFailed) {
            total = lzmaDecode(body, length, length);
        }
        long expectedCrc = (total[0] & 0xFFL) | ((total[1] & 0xFFL) << 8)
                | ((total[2] & 0xFFL) << 16) | ((total[3] & 0xFFL) << 24);
        CRC32 crc = new CRC32();
        crc.update(total, 4, total.length - 4);
        if (crc.getValue() != expectedCrc) throw new IOException("crc");
        return new String(total, 4, total.length - 4, StandardCharsets.UTF_8);
    }

    /**
     * v1.3.5 — načítanie platby z naskenovaného PAY by square QR (opak {@link #generate}).
     * Berie prvú platbu (jednorazový príkaz, trvalý príkaz aj inkaso — polia sú rovnaké).
     * Kód môže mať medzery / malé písmená. Pri nečitateľnom kóde IOException.
     *
     * Payload podľa štandardu: invoiceId, počet platieb, potom pre každú: typ, suma, mena,
     * dátum, VS, KS, ŠS, referencia, správa, počet účtov, (IBAN, BIC)×n, rozšírenie trvalého
     * príkazu (0/1 + 4 polia), rozšírenie inkasa (0/1 + 10 polí), príjemca, adresa 1, adresa 2.
     * Príjemca (verzia 1.1) môže chýbať — staršie generátory ho nedávajú.
     */
    public static Input parse(String code) throws IOException {
        if (code == null) throw new IOException("empty");
        String c = code.replaceAll("\\s", "").toUpperCase(Locale.ROOT);
        if (c.isEmpty()) throw new IOException("empty");
        byte[] head = fromBase32Hex(c.substring(0, Math.min(2, c.length())));
        if (head.length > 0 && ((head[0] & 0xF0) >> 4) != 0) throw new IOException("not PAY by square");

        String[] f = decodeToPayload(c).split("\t", -1);
        int i = 1; // [0] invoiceId
        int count = intAt(f, i++);
        if (count < 1) throw new IOException("no payment");

        Input in = new Input();
        i++; // typ platby
        String amount = at(f, i++);
        if (!amount.isEmpty()) {
            try {
                in.amount = new BigDecimal(amount.replace(',', '.'));
            } catch (NumberFormatException e) {
                in.amount = null;
            }
        }
        String currency = at(f, i++);
        in.currency = currency.isEmpty() ? "EUR" : currency;
        in.dueDate = at(f, i++);
        in.variableSymbol = at(f, i++);
        in.constantSymbol = at(f, i++);
        in.specificSymbol = at(f, i++);
        String reference = at(f, i++);
        in.paymentNote = at(f, i++);
        int accounts = intAt(f, i++);
        if (accounts >= 1) {
            in.iban = at(f, i++);
            in.bic = at(f, i++);
            i += 2 * (accounts - 1);
        }
        if ("1".equals(at(f, i++))) i += 4;   // trvalý príkaz: deň, mesiac, periodicita, posledný dátum
        if ("1".equals(at(f, i++))) i += 10;  // inkaso
        in.beneficiaryName = at(f, i);

        // Symboly niekedy len v SEPA referencii: "/VS123/SS456/KS0308"
        if (in.variableSymbol.isEmpty()) in.variableSymbol = symbolFromReference(reference, "VS");
        if (in.specificSymbol.isEmpty()) in.specificSymbol = symbolFromReference(reference, "SS");
        if (in.constantSymbol.isEmpty()) in.constantSymbol = symbolFromReference(reference, "KS");
        if (in.iban == null || in.iban.isEmpty()) throw new IOException("no iban");
        return in;
    }

    private static String at(String[] f, int i) {
        return i >= 0 && i < f.length ? f[i].trim() : "";
    }

    private static int intAt(String[] f, int i) {
        try {
            return Integer.parseInt(at(f, i));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static String symbolFromReference(String ref, String key) {
        if (ref == null) return "";
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("/" + key + "(\\d{1,10})").matcher(ref.toUpperCase(Locale.ROOT));
        return m.find() ? m.group(1) : "";
    }

    // ===== Internals =====

    private static byte[] lzmaDecode(byte[] body, long uncompSize, int length) throws IOException {
        byte[] total = new byte[length];
        try (InputStream in = new LZMAInputStream(new ByteArrayInputStream(body),
                uncompSize, 3, 0, 2, DICT_SIZE, null)) {
            int off = 0;
            while (off < length) {
                int r = in.read(total, off, length - off);
                if (r < 0) throw new IOException("truncated");
                off += r;
            }
        }
        return total;
    }

    /** LZMA1 raw (bez 13 B .lzma hlavičky), s end markerom ako liblzma FORMAT_RAW. */
    private static byte[] lzmaRaw(byte[] data) throws IOException {
        LZMA2Options opts = new LZMA2Options();
        try {
            opts.setDictSize(DICT_SIZE);
            opts.setLcLp(3, 0);
            opts.setPb(2);
        } catch (UnsupportedOptionsException e) {
            throw new IOException(e);
        }
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (LZMAOutputStream lz = new LZMAOutputStream(bos, opts, true)) {
            lz.write(data);
        }
        return bos.toByteArray();
    }

    static String toBase32Hex(byte[] bytes) {
        StringBuilder sb = new StringBuilder((bytes.length * 8 + 4) / 5);
        int buffer = 0;
        int bits = 0;
        for (byte b : bytes) {
            buffer = (buffer << 8) | (b & 0xFF);
            bits += 8;
            while (bits >= 5) {
                sb.append(ALPHABET.charAt((buffer >> (bits - 5)) & 0x1F));
                bits -= 5;
            }
        }
        if (bits > 0) sb.append(ALPHABET.charAt((buffer << (5 - bits)) & 0x1F));
        return sb.toString();
    }

    static byte[] fromBase32Hex(String s) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int buffer = 0;
        int bits = 0;
        for (int i = 0; i < s.length(); i++) {
            int v = ALPHABET.indexOf(s.charAt(i));
            if (v < 0) throw new IOException("bad char");
            buffer = (buffer << 5) | v;
            bits += 5;
            if (bits >= 8) {
                out.write((buffer >> (bits - 8)) & 0xFF);
                bits -= 8;
            }
        }
        return out.toByteArray();
    }

    private static String clean(String s) {
        if (s == null) return "";
        return s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim();
    }

    private static String digits(String s) {
        return clean(s).replaceAll("[^0-9]", "");
    }

    private static String limit(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max);
    }
}
