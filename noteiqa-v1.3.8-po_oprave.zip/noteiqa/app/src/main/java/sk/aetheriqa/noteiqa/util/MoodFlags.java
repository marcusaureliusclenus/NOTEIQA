package sk.aetheriqa.noteiqa.util;

import androidx.annotation.StringRes;

import java.util.ArrayList;
import java.util.List;

import sk.aetheriqa.noteiqa.R;

/**
 * MoodFlags – kompaktný reprezentátor 7 mood checkboxov pri vážení.
 *
 * Bitmask uložený v WeightEntry.moodFlags:
 *  bit 0  (1)  – menzes
 *  bit 1  (2)  – po cvičení
 *  bit 2  (4)  – málo spánku
 *  bit 3  (8)  – včera prejedená
 *  bit 4  (16) – včera alkohol
 *  bit 5  (32) – zapečená
 *  bit 6  (64) – málo vody
 */
public final class MoodFlags {

    public static final int MENZES = 1 << 0;
    public static final int PO_CVICENI = 1 << 1;
    public static final int MALO_SPANKU = 1 << 2;
    public static final int VCERA_PREJEDENA = 1 << 3;
    public static final int VCERA_ALKOHOL = 1 << 4;
    public static final int ZAPECENA = 1 << 5;
    public static final int MALO_VODY = 1 << 6;

    /** Všetky flagy v poradí pre UI rendering. */
    public static final int[] ALL = {
            MENZES, PO_CVICENI, MALO_SPANKU,
            VCERA_PREJEDENA, VCERA_ALKOHOL, ZAPECENA, MALO_VODY
    };

    private MoodFlags() {}

    @StringRes
    public static int labelFor(int flag) {
        if (flag == MENZES) return R.string.mood_menzes;
        if (flag == PO_CVICENI) return R.string.mood_po_cviceni;
        if (flag == MALO_SPANKU) return R.string.mood_malo_spanku;
        if (flag == VCERA_PREJEDENA) return R.string.mood_vcera_prejedena;
        if (flag == VCERA_ALKOHOL) return R.string.mood_vcera_alkohol;
        if (flag == ZAPECENA) return R.string.mood_zapecena;
        if (flag == MALO_VODY) return R.string.mood_malo_vody;
        throw new IllegalArgumentException("Unknown mood flag: " + flag);
    }

    public static boolean has(int bitmask, int flag) {
        return (bitmask & flag) != 0;
    }

    public static int set(int bitmask, int flag, boolean enabled) {
        return enabled ? (bitmask | flag) : (bitmask & ~flag);
    }

    /** Ľudská sumarizácia pre "Posledné záznamy" – vráti aktívne flagy ako čiarka-zoznam. */
    public static List<String> activeLabels(android.content.Context ctx, int bitmask) {
        List<String> out = new ArrayList<>();
        for (int flag : ALL) {
            if (has(bitmask, flag)) {
                out.add(ctx.getString(labelFor(flag)));
            }
        }
        return out;
    }

    /** Spočíta kolko je aktívnych flagov (pre štatistiky). */
    public static int count(int bitmask) {
        int n = 0;
        for (int flag : ALL) if (has(bitmask, flag)) n++;
        return n;
    }
}
