package sk.aetheriqa.noteiqa.data.entity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/**
 * TaskCategory – kategória pre To Do úlohy.
 *
 * Built-in (systemCategory=true) sa pri prvom spustení vytvoria z FirstRunSeeder:
 *   Práca, Osobné, Rodina, Zdravie, Domov, Iné
 *
 * Custom kategórie si používateľ pridáva sám.
 */
@Entity(tableName = "task_categories",
        indices = {@Index(value = "name", unique = true)})
public class TaskCategory {

    @PrimaryKey(autoGenerate = true)
    public long id;

    @NonNull
    public String name = "";

    /** Hex farba (LEA paleta gold-tóny). */
    @Nullable
    public String color;

    public int sortOrder = 0;

    public boolean systemCategory = false;
}
