package sk.aetheriqa.noteiqa.ui.kids;

import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.ArrayList;
import java.util.List;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.util.DialogThemes;
import sk.aetheriqa.noteiqa.util.PaymentQr;

/**
 * ForOtherSheet – v1.3.2 — "Pre druhého": jeden vstup z Detí pre tri existujúce výstupy.
 *
 *  - Text    → ParentListDialog (výber obdobia, share text/plain)
 *  - Plagát  → KidsWeekPosterActivity
 *  - Lístok  → nezaplatená platba s QR: jedna = rovno lístok, viac = výber, žiadna = toast
 *
 * Poslať na samotnom lístku ostáva; toto je len vstup z Detí.
 */
final class ForOtherSheet {

    private ForOtherSheet() {}

    static void show(Context ctx) {
        BottomSheetDialog dialog = new BottomSheetDialog(ctx);
        View v = LayoutInflater.from(ctx).inflate(R.layout.bottom_sheet_for_other, null, false);
        dialog.setContentView(v);

        v.findViewById(R.id.for_other_text).setOnClickListener(x -> {
            dialog.dismiss();
            ParentListDialog.show(ctx);
        });
        v.findViewById(R.id.for_other_poster).setOnClickListener(x -> {
            dialog.dismiss();
            ctx.startActivity(KidsWeekPosterActivity.newIntent(ctx));
        });
        v.findViewById(R.id.for_other_ticket).setOnClickListener(x -> {
            dialog.dismiss();
            openTicket(ctx);
        });

        dialog.show();
        View sheet = dialog.findViewById(com.google.android.material.R.id.design_bottom_sheet);
        if (sheet != null) sheet.setBackgroundColor(Color.TRANSPARENT);
    }

    /** Nezaplatené platby, z ktorých ide zložiť QR (prevod s IBAN a sumou). */
    private static void openTicket(Context ctx) {
        KidRepository repo = KidRepository.getInstance(ctx);
        new Thread(() -> {
            List<KidPayment> sendable = new ArrayList<>();
            for (KidPayment p : repo.getUnpaidSync()) {
                if (!p.isPersonal() && PaymentQr.canRender(p)) sendable.add(p);
            }
            List<Kid> kids = repo.getKidsSync();
            new Handler(Looper.getMainLooper()).post(() -> {
                if (sendable.isEmpty()) {
                    Toast.makeText(ctx, R.string.for_other_no_payment, Toast.LENGTH_SHORT).show();
                    return;
                }
                if (sendable.size() == 1) {
                    ctx.startActivity(PaymentTicketActivity.newIntent(ctx, sendable.get(0).id));
                    return;
                }
                CharSequence[] names = new CharSequence[sendable.size()];
                for (int i = 0; i < sendable.size(); i++) {
                    KidPayment p = sendable.get(i);
                    String kid = "";
                    for (Kid k : kids) if (k.id == p.kidIdOrZero()) { kid = k.name; break; }
                    names[i] = kid.isEmpty() ? p.title
                            : ctx.getString(R.string.for_other_ticket_item, p.title, kid);
                }
                new AlertDialog.Builder(ctx, DialogThemes.LEA)
                        .setTitle(R.string.for_other_pick)
                        .setItems(names, (d, which) -> ctx.startActivity(
                                PaymentTicketActivity.newIntent(ctx, sendable.get(which).id)))
                        .show();
            });
        }, "ForOtherTicket").start();
    }
}
