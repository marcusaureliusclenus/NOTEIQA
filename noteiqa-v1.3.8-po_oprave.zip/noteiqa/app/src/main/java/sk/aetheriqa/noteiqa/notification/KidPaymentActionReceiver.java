package sk.aetheriqa.noteiqa.notification;

import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.widget.Toast;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.util.DateUtils;

/**
 * KidPaymentActionReceiver – v1.2.0 — akcie priamo z notifikácie platby.
 *
 *  ACTION_PAID       → označí zaplatené (+ ďalšia inštancia pri opakovaní, KidRepository)
 *  ACTION_COPY_IBAN  → IBAN do schránky
 *
 * PendingIntenty sú IMMUTABLE — id platby je v extras od vytvorenia, nič sa nedopĺňa.
 * requestCode rozsahy (mix s offsetom 30M / 31M) sa nekryjú s pripomienkami (10M / 20M).
 */
public class KidPaymentActionReceiver extends BroadcastReceiver {

    public static final String ACTION_PAID = "sk.aetheriqa.noteiqa.KID_PAYMENT_PAID";
    public static final String ACTION_COPY_IBAN = "sk.aetheriqa.noteiqa.KID_PAYMENT_COPY_IBAN";
    public static final String EXTRA_PAYMENT_ID = "paymentId";

    static final int PAID_REQUEST_OFFSET = 30_000_000;
    static final int COPY_REQUEST_OFFSET = 31_000_000;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        final long id = intent.getLongExtra(EXTRA_PAYMENT_ID, 0L);
        if (id <= 0L) return;
        final String action = intent.getAction();
        final Context appCtx = context.getApplicationContext();
        final PendingResult pending = goAsync();

        new Thread(() -> {
            try {
                KidRepository repo = KidRepository.getInstance(appCtx);
                if (ACTION_PAID.equals(action)) {
                    KidPayment next = repo.setPaymentCompletedSync(id, true);
                    NotificationHelper.cancelKidPayment(appCtx, id);
                    String msg = next != null
                            ? appCtx.getString(R.string.kid_payment_paid_next,
                                    DateUtils.formatNumericDate(next.dueDate))
                            : appCtx.getString(R.string.kid_payment_marked_paid);
                    toast(appCtx, msg);
                } else if (ACTION_COPY_IBAN.equals(action)) {
                    KidPayment p = repo.getPaymentSync(id);
                    if (p != null && !TextUtils.isEmpty(p.iban)) {
                        new Handler(Looper.getMainLooper()).post(() -> {
                            ClipboardManager cm = (ClipboardManager)
                                    appCtx.getSystemService(Context.CLIPBOARD_SERVICE);
                            if (cm != null) {
                                cm.setPrimaryClip(ClipData.newPlainText(
                                        appCtx.getString(R.string.kid_payment_iban_hint), p.iban));
                            }
                            Toast.makeText(appCtx, R.string.kid_payment_iban_copied,
                                    Toast.LENGTH_SHORT).show();
                        });
                    }
                }
            } finally {
                pending.finish();
            }
        }, "KidPaymentAction").start();
    }

    private static void toast(Context ctx, String msg) {
        new Handler(Looper.getMainLooper()).post(() ->
                Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show());
    }
}
