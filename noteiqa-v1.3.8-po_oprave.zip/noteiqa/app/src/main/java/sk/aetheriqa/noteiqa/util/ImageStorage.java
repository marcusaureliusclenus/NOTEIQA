package sk.aetheriqa.noteiqa.util;

import android.content.Context;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

/**
 * ImageStorage – kopíruje obrázky vybrané z Galerie do internej zložky appky.
 *
 * Cieľ: aj keď používateľ neskôr zmaže pôvodný obrázok z Galerie, naša kópia
 * v internom storage ostane. Per Marekovo rozhodnutie.
 *
 * Cesta: /data/data/sk.aetheriqa.noteiqa/files/note_attachments/{uuid}.jpg
 */
public final class ImageStorage {

    private static final String DIR = "note_attachments";

    private ImageStorage() {}

    public static File getDir(Context ctx) {
        File d = new File(ctx.getFilesDir(), DIR);
        if (!d.exists()) d.mkdirs();
        return d;
    }

    /**
     * Skopíruje obrázok zo zdrojového Uri do internej zložky.
     * Vráti absolútnu cestu, alebo null pri chybe.
     */
    public static String importImage(Context ctx, Uri sourceUri) {
        File dir = getDir(ctx);
        // Vždy ako .jpg — podporujeme JPEG, PNG, WebP, ale prípona je len cosmetic
        File target = new File(dir, UUID.randomUUID().toString() + ".jpg");

        try (InputStream in = ctx.getContentResolver().openInputStream(sourceUri);
             FileOutputStream out = new FileOutputStream(target)) {
            if (in == null) return null;
            byte[] buffer = new byte[8 * 1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            out.flush();
            return target.getAbsolutePath();
        } catch (IOException e) {
            return null;
        }
    }

    /** Bezpečné mazanie obrázka po zmene/odstránení z poznámky. */
    public static void deleteIfExists(String path) {
        if (path == null || path.isEmpty()) return;
        File f = new File(path);
        if (f.exists() && f.getAbsolutePath().contains(DIR)) {
            f.delete();
        }
    }
}
