package sk.aetheriqa.noteiqa.ui.kids;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.KidEvent;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.util.DialogThemes;
import sk.aetheriqa.noteiqa.util.IcsExporter;

public class KidEventsSubFragment extends Fragment {

    private static final String ARG_KID_ID = "kidId";

    private long kidId;
    private KidRepository repo;
    private KidEventsAdapter adapter;
    private RecyclerView list;
    private View empty;

    public static KidEventsSubFragment newInstance(long kidId) {
        KidEventsSubFragment f = new KidEventsSubFragment();
        Bundle b = new Bundle();
        b.putLong(ARG_KID_ID, kidId);
        f.setArguments(b);
        return f;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_kid_events, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        kidId = getArguments() != null ? getArguments().getLong(ARG_KID_ID, 0L) : 0L;
        repo = KidRepository.getInstance(requireContext());

        list = view.findViewById(R.id.kid_events_list);
        empty = view.findViewById(R.id.kid_events_empty);
        list.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new KidEventsAdapter(new KidEventsAdapter.Listener() {
            @Override public void onClick(KidEvent e) {
                startActivity(KidEventEditorActivity.newIntent(requireContext(), e.id, e.kidIdOrAll()));
            }
            @Override public void onLongPress(KidEvent e) {
                showEventMenu(e);
            }
        });
        list.setAdapter(adapter);

        repo.observeKids().observe(getViewLifecycleOwner(), adapter::setKids);
        repo.observeEventPayments().observe(getViewLifecycleOwner(), adapter::setEventPayments);

        Observer<List<KidEvent>> observer = events -> {
            if (events == null || events.isEmpty()) {
                empty.setVisibility(View.VISIBLE);
                list.setVisibility(View.GONE);
                adapter.submit(new java.util.ArrayList<>());
            } else {
                empty.setVisibility(View.GONE);
                list.setVisibility(View.VISIBLE);
                adapter.submit(events);
            }
        };

        if (kidId == KidRepository.KID_ID_ALL) {
            repo.observeEvents().observe(getViewLifecycleOwner(), observer);
        } else {
            repo.observeEventsByKid(kidId).observe(getViewLifecycleOwner(), observer);
        }
    }

    /** v1.2.0 — podržanie: Pridať do kalendára (ICS) / Vymazať. */
    private void showEventMenu(KidEvent e) {
        new AlertDialog.Builder(requireContext(), DialogThemes.LEA)
                .setTitle(e.title)
                .setItems(new CharSequence[]{
                        getString(R.string.kid_event_add_to_calendar),
                        getString(R.string.task_action_remove)
                }, (d, which) -> {
                    if (which == 0) {
                        Intent share = IcsExporter.buildShareIntent(requireContext(), e);
                        if (share != null) {
                            startActivity(share);
                        } else {
                            Toast.makeText(requireContext(), R.string.ics_export_failed,
                                    Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        confirmDelete(e);
                    }
                })
                .show();
    }

    private void confirmDelete(KidEvent e) {
        new AlertDialog.Builder(requireContext(), DialogThemes.LEA)
                .setTitle(R.string.kid_delete_confirm_title)
                .setMessage(R.string.kid_delete_confirm_message)
                .setPositiveButton(R.string.action_yes, (d, w) -> repo.deleteEvent(e.id))
                .setNegativeButton(R.string.action_no, null)
                .show();
    }
}
