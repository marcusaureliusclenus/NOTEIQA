package sk.aetheriqa.noteiqa.ui.kids;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import java.util.Locale;

import sk.aetheriqa.noteiqa.R;
import sk.aetheriqa.noteiqa.data.entity.Kid;
import sk.aetheriqa.noteiqa.data.entity.KidPayment;
import sk.aetheriqa.noteiqa.data.repository.KidRepository;
import sk.aetheriqa.noteiqa.util.DateUtils;
import sk.aetheriqa.noteiqa.util.DialogThemes;

/**
 * KidPaymentContextDialog – zobrazí detaily platby s copy-friendly rows.
 *
 * Každý údaj (IBAN, VS, ŠS, správa, hotovosť pre koho) má vedľa seba
 * copy tlačidlo — jeden tap = údaj v schránke, hotový za 10 sekúnd.
 *
 * Tlačidlá dole: "Kopírovať všetko" a "Označiť zaplatené / nezaplatené".
 */
public class KidPaymentContextDialog {

    private KidPaymentContextDialog() {}

    /**
     * Načíta platbu z DB na background threade a potom zobrazí dialog na UI thread.
     */
    public static void show(Context ctx, KidRepository repo, long paymentId) {
        new Thread(() -> {
            KidPayment p = repo.getPaymentSync(paymentId);
            if (p == null) return;
            Kid kid = null;
            for (Kid k : repo.getKidsSync()) if (k.id == p.kidIdOrZero()) { kid = k; break; }
            final Kid finalKid = kid;
            new android.os.Handler(android.os.Looper.getMainLooper()).post(() ->
                    showInternal(ctx, repo, p, finalKid));
        }, "KidPaymentDialog-load").start();
    }

    private static void showInternal(Context ctx, KidRepository repo, KidPayment p, Kid kid) {
        View content = LayoutInflater.from(ctx)
                .inflate(R.layout.dialog_kid_payment_context, null, false);

        TextView title = content.findViewById(R.id.dlg_title);
        TextView amount = content.findViewById(R.id.dlg_amount);
        TextView due = content.findViewById(R.id.dlg_due);
        TextView note = content.findViewById(R.id.dlg_note);
        LinearLayout details = content.findViewById(R.id.dlg_details_container);

        String kidName = kid != null ? kid.name : "";
        title.setText(TextUtils.isEmpty(kidName)
                ? p.title
                : (kidName + ": " + p.title));

        if (p.amountEur != null) {
            amount.setText(String.format(Locale.getDefault(), "%.2f €", p.amountEur)
                    .replace('.', ','));
        } else {
            amount.setVisibility(View.GONE);
        }

        if (p.dueDate > 0L) {
            due.setText(ctx.getString(R.string.kid_payment_dialog_due,
                    DateUtils.formatLongDate(p.dueDate)));
        } else {
            due.setVisibility(View.GONE);
        }

        // Dynamické riadky podľa typu platby
        if (p.paymentMethod == KidPayment.METHOD_TRANSFER) {
            if (!TextUtils.isEmpty(p.beneficiaryName)) {
                addRow(details, ctx, ctx.getString(R.string.kid_payment_label_beneficiary), p.beneficiaryName);
            }
            if (!TextUtils.isEmpty(p.iban)) {
                addRow(details, ctx, ctx.getString(R.string.kid_payment_iban_hint), p.iban);
            }
            if (!TextUtils.isEmpty(p.variableSymbol)) {
                addRow(details, ctx, ctx.getString(R.string.kid_payment_label_vs), p.variableSymbol);
            }
            if (!TextUtils.isEmpty(p.specificSymbol)) {
                addRow(details, ctx, ctx.getString(R.string.kid_payment_label_ss), p.specificSymbol);
            }
            if (!TextUtils.isEmpty(p.constantSymbol)) {
                addRow(details, ctx, ctx.getString(R.string.kid_payment_label_ks), p.constantSymbol);
            }
            if (!TextUtils.isEmpty(p.paymentNote)) {
                addRow(details, ctx, ctx.getString(R.string.kid_payment_label_msg), p.paymentNote);
            }
        } else if (p.paymentMethod == KidPayment.METHOD_CASH) {
            if (!TextUtils.isEmpty(p.cashRecipient)) {
                addRow(details, ctx, ctx.getString(R.string.kid_payment_label_cash), p.cashRecipient);
            }
        }

        if (!TextUtils.isEmpty(p.note)) {
            note.setVisibility(View.VISIBLE);
            note.setText(ctx.getString(R.string.kid_payment_note_line, p.note));
        }

        final String allTextFinal = buildCopyText(ctx, p);

        String toggleText = p.completed
                ? ctx.getString(R.string.kid_payment_mark_unpaid)
                : ctx.getString(R.string.kid_payment_mark_paid);

        new AlertDialog.Builder(ctx, DialogThemes.LEA)
                .setView(content)
                .setPositiveButton(R.string.kid_payment_copy_all, (d, w) -> {
                    if (!allTextFinal.isEmpty()) {
                        copyToClipboard(ctx, ctx.getString(R.string.kid_payment_clip_label), allTextFinal);
                        Toast.makeText(ctx, R.string.kid_payment_copied,
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(toggleText, (d, w) ->
                        setCompletedWithToast(ctx, repo, p.id, !p.completed))
                .setNeutralButton(R.string.action_close, null)
                .show();
    }

    /**
     * Text pre "Kopírovať všetko": suma, IBAN, VS, ŠS, správa (pri prevode)
     * alebo hotovosť pre (pri hotovosti). v1.3.0 — zdieľa ho aj platobný lístok.
     */
    public static String buildCopyText(Context ctx, KidPayment p) {
        StringBuilder allText = new StringBuilder();
        if (p.amountEur != null) {
            String sum = String.format(Locale.getDefault(), "%.2f", p.amountEur).replace('.', ',');
            allText.append(ctx.getString(R.string.kid_payment_dialog_amount, sum)).append('\n');
        }
        if (p.paymentMethod == KidPayment.METHOD_TRANSFER) {
            if (!TextUtils.isEmpty(p.beneficiaryName)) {
                allText.append(ctx.getString(R.string.kid_payment_dialog_beneficiary, p.beneficiaryName)).append('\n');
            }
            if (!TextUtils.isEmpty(p.iban)) {
                allText.append(ctx.getString(R.string.kid_payment_dialog_iban, p.iban)).append('\n');
            }
            if (!TextUtils.isEmpty(p.variableSymbol)) {
                allText.append(ctx.getString(R.string.kid_payment_dialog_vs, p.variableSymbol)).append('\n');
            }
            if (!TextUtils.isEmpty(p.specificSymbol)) {
                allText.append(ctx.getString(R.string.kid_payment_dialog_ss, p.specificSymbol)).append('\n');
            }
            if (!TextUtils.isEmpty(p.constantSymbol)) {
                allText.append(ctx.getString(R.string.kid_payment_dialog_ks, p.constantSymbol)).append('\n');
            }
            if (!TextUtils.isEmpty(p.paymentNote)) {
                allText.append(ctx.getString(R.string.kid_payment_dialog_msg, p.paymentNote)).append('\n');
            }
        } else if (p.paymentMethod == KidPayment.METHOD_CASH) {
            if (!TextUtils.isEmpty(p.cashRecipient)) {
                allText.append(ctx.getString(R.string.kid_payment_dialog_cash, p.cashRecipient)).append('\n');
            }
        }
        return allText.toString().trim();
    }

    /** v1.3.0 — skopíruje {@link #buildCopyText} do schránky; false ak nie je čo kopírovať. */
    public static boolean copyAll(Context ctx, KidPayment p) {
        String text = buildCopyText(ctx, p);
        if (text.isEmpty()) return false;
        copyToClipboard(ctx, ctx.getString(R.string.kid_payment_clip_label), text);
        return true;
    }

    /**
     * v1.2.0 — spoločný vstup pre checkbox v liste aj pre tento dialóg.
     * Logika opakovania je v KidRepository; tu len toast s ďalšou splatnosťou.
     */
    public static void setCompletedWithToast(Context ctx, KidRepository repo,
                                             long paymentId, boolean completed) {
        Context appCtx = ctx.getApplicationContext();
        repo.setPaymentCompleted(paymentId, completed, next -> {
            String msg;
            if (!completed) {
                msg = appCtx.getString(R.string.kid_payment_marked_unpaid);
            } else if (next != null) {
                msg = appCtx.getString(R.string.kid_payment_paid_next,
                        DateUtils.formatNumericDate(next.dueDate));
            } else {
                msg = appCtx.getString(R.string.kid_payment_marked_paid);
            }
            Toast.makeText(appCtx, msg, Toast.LENGTH_SHORT).show();
        });
    }

    private static void addRow(LinearLayout container, Context ctx,
                               String label, String value) {
        View row = LayoutInflater.from(ctx)
                .inflate(R.layout.item_kid_payment_detail_row, container, false);
        TextView lblView = row.findViewById(R.id.row_label);
        TextView valView = row.findViewById(R.id.row_value);
        ImageView copyBtn = row.findViewById(R.id.row_copy);

        lblView.setText(label);
        valView.setText(value);
        copyBtn.setOnClickListener(v -> {
            copyToClipboard(ctx, label, value);
            Toast.makeText(ctx, R.string.kid_payment_copied,
                    Toast.LENGTH_SHORT).show();
        });
        container.addView(row);
    }

    private static void copyToClipboard(Context ctx, String label, String value) {
        ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null) return;
        cm.setPrimaryClip(ClipData.newPlainText(label, value));
    }
}
