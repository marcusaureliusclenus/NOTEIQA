package sk.aetheriqa.noteiqa.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.EncodeHintType;
import com.google.zxing.RGBLuminanceSource;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.QRCodeReader;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import org.junit.Test;

import java.math.BigDecimal;
import java.util.EnumMap;
import java.util.Map;

/**
 * v1.3.0 — referenčné vektory PAY by square.
 *
 * Očakávané reťazce sú výstup nezávislej referenčnej implementácie
 * pay-by-square 0.2.0 (PyPI, matusf/pay-by-square, liblzma) pre rovnaký vstup.
 * Zhoda je byte-exact. Kódy navyše dekóduje knižnica bysquare 4.1.0 (npm)
 * na rovnakú platbu — BYSQUARE_NPM_CODE je naopak výstup bysquare (iný LZMA
 * enkóder, suma "25" bez desatín), ktorý musí vedieť prečítať náš dekóder.
 *
 * Ak tento test neprejde, PayBySquare.isVerified() vráti false a UI QR ani
 * obálku (Poslať) nezobrazí.
 */
public class PayBySquareTest {

    /** pay-by-square 0.2.0: generate(amount=25.00, iban=SK8975000000000012345671,
     *  date=2026-10-15, variable_symbol='123', note='Test platba', beneficiary_name='Test') */
    private static final String REFERENCE =
            "0005A00044EC20BG9C6MKK3ELT0OMOE54BVA9H9LF40NLI3BCBMLLH9E48VDE5KUC59P3PB0MBBUBBDBBU7BHEO6SDKIS2PRU64NG7B8TQGTKC9OGR1TC8R566ATVVJ8GA00";

    /** pay-by-square 0.2.0: amount=1234.5, VS 202610, ŠS 77, note='ŠKD október – Gabika',
     *  beneficiary_name='Zakladna skola Lubica' (UTF-8 v správe). */
    private static final String REFERENCE_DIACRITICS =
            "0007K0003GMVRIHVPVTCKMPKAOMKUS4M3Q9AHPPOGQA9LA5DOJ8Q2KV4RK4Q6K2UJPQIU1ICCL3I4KN3V8R3HNH1SPCHI52FA8GILTAKASHFUI7FVVC2G7CQ0T3DFBG7BCHCTG64MPME38TLR171P526B9QG63BTHENCV4GKML1JNUS63IVVPSU000";

    /** bysquare 4.1.0 (npm), verzia 1.0.0, deburr=false, rovnaký vstup ako REFERENCE. */
    private static final String BYSQUARE_NPM_CODE =
            "000540001DGP9M092TREA1S1H30U2N82D53O0TCLQUNPGGHN45VEQPB66PO526R7HO0CK7LL3KQKHNPF0VRD8V7H5L97U99IG7KOGC6A73V8J82T7NOR8BVUT1KG0";

    @Test
    public void referenceVector_isByteExact() throws Exception {
        assertEquals(REFERENCE, PayBySquare.generate(PayBySquare.Input.reference()));
        assertEquals(REFERENCE, PayBySquare.REFERENCE_CODE);
        assertTrue(PayBySquare.isVerified());
    }

    @Test
    public void diacriticsVector_isByteExact() throws Exception {
        PayBySquare.Input in = PayBySquare.Input.reference();
        in.amount = new BigDecimal("1234.5");
        in.variableSymbol = "2026 10";               // medzery sa odstránia
        in.specificSymbol = "77";
        in.paymentNote = "ŠKD október – Gabika";     // správa ostáva UTF-8 s diakritikou
        in.beneficiaryName = "Základná škola Ľubica"; // príjemca bez diakritiky
        in.iban = "sk89 7500 0000 0000 1234 5671";   // medzery + malé písmená
        assertEquals(REFERENCE_DIACRITICS, PayBySquare.generate(in));
    }

    @Test
    public void payload_roundTrips() throws Exception {
        String payload = PayBySquare.buildPayload(PayBySquare.Input.reference());
        assertEquals("\t1\t1\t25.00\tEUR\t20261015\t123\t\t\t\tTest platba\t1\t"
                + "SK8975000000000012345671\t\t0\t0\tTest\t\t", payload);
        assertEquals(payload, PayBySquare.decodeToPayload(REFERENCE));
    }

    @Test
    public void decodesOtherEncoder() throws Exception {
        assertEquals("\t1\t1\t25\tEUR\t20261015\t123\t\t\t\tTest platba\t1\t"
                        + "SK8975000000000012345671\t\t0\t0\tTest\t\t",
                PayBySquare.decodeToPayload(BYSQUARE_NPM_CODE));
    }

    /** v1.3.5 — načítanie z QR: kód z iného generátora (bysquare npm). */
    @Test
    public void parse_otherEncoder() throws Exception {
        PayBySquare.Input in = PayBySquare.parse(BYSQUARE_NPM_CODE);
        assertEquals(0, new BigDecimal("25").compareTo(in.amount));
        assertEquals("EUR", in.currency);
        assertEquals("20261015", in.dueDate);
        assertEquals("123", in.variableSymbol);
        assertEquals("Test platba", in.paymentNote);
        assertEquals("SK8975000000000012345671", in.iban);
        assertEquals("Test", in.beneficiaryName);
    }

    /** v1.3.5 — generate → parse vráti tie isté polia (aj KS, ŠS, diakritiku v správe). */
    @Test
    public void parse_roundTrip() throws Exception {
        PayBySquare.Input in = PayBySquare.Input.reference();
        in.amount = new BigDecimal("32.10");
        in.specificSymbol = "77";
        in.constantSymbol = "0308";
        in.paymentNote = "ŠKD október – Gabika";
        in.beneficiaryName = "Zakladna skola Lubica";
        PayBySquare.Input out = PayBySquare.parse(" " + PayBySquare.generate(in).toLowerCase() + "\n");
        assertEquals(0, new BigDecimal("32.10").compareTo(out.amount));
        assertEquals("123", out.variableSymbol);
        assertEquals("77", out.specificSymbol);
        assertEquals("0308", out.constantSymbol);
        assertEquals("ŠKD október – Gabika", out.paymentNote);
        assertEquals("SK8975000000000012345671", out.iban);
        assertEquals("Zakladna skola Lubica", out.beneficiaryName);
    }

    @Test(expected = java.io.IOException.class)
    public void parse_rejectsGarbage() throws Exception {
        PayBySquare.parse("https://example.com");
    }

    @Test
    public void qrCode_scansBackToSameString() throws Exception {
        Map<EncodeHintType, Object> hints = new EnumMap<>(EncodeHintType.class);
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
        hints.put(EncodeHintType.MARGIN, 4);
        BitMatrix m = new QRCodeWriter().encode(REFERENCE, BarcodeFormat.QR_CODE, 400, 400, hints);

        int[] px = new int[m.getWidth() * m.getHeight()];
        for (int y = 0; y < m.getHeight(); y++) {
            for (int x = 0; x < m.getWidth(); x++) {
                px[y * m.getWidth() + x] = m.get(x, y) ? 0xFF000000 : 0xFFF4EFE4;
            }
        }
        RGBLuminanceSource src = new RGBLuminanceSource(m.getWidth(), m.getHeight(), px);
        String scanned = new QRCodeReader()
                .decode(new BinaryBitmap(new HybridBinarizer(src))).getText();
        assertEquals(REFERENCE, scanned);
    }
}
