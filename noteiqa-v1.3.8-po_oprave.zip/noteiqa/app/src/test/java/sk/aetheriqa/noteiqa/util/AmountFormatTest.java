package sk.aetheriqa.noteiqa.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;

/** v1.3.5 — desatinná čiarka pri sumách. */
public class AmountFormatTest {

    @Test
    public void dotBecomesComma() {
        assertEquals("32,10", AmountFormat.normalizeTyping("32.10", 2));
        assertEquals("32,1", AmountFormat.normalizeTyping("32,1", 2));
    }

    @Test
    public void onlyOneSeparatorAndTwoDecimals() {
        assertEquals("32,10", AmountFormat.normalizeTyping("32,10,5", 2));
        assertEquals("32,10", AmountFormat.normalizeTyping("32,105", 2));
        assertEquals("0,5", AmountFormat.normalizeTyping(",5", 2));
        assertEquals("2", AmountFormat.normalizeTyping("2", 2));
    }

    @Test
    public void parseAndFormat() {
        assertEquals(32.1, AmountFormat.parse("32,10"), 1e-9);
        assertEquals(2.0, AmountFormat.parse("2"), 1e-9);
        assertNull(AmountFormat.parse(""));
        assertNull(AmountFormat.parse("abc"));
        assertEquals("32,10", AmountFormat.format(32.1));
        assertEquals("2,00", AmountFormat.format(2));
    }
}
