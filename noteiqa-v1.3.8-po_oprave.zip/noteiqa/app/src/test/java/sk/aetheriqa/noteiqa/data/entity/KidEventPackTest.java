package sk.aetheriqa.noteiqa.data.entity;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.Arrays;

/** v1.3.4 — „Čo zobrať“: prázdne riadky sa neukladajú, poradie ostáva. */
public class KidEventPackTest {

    @Test
    public void emptyLinesAreDropped() {
        assertEquals("desiata\nsúhlas",
                KidEvent.joinPack(Arrays.asList(" desiata ", "", "súhlas", "   ")));
    }

    @Test
    public void allEmptyIsNull() {
        assertNull(KidEvent.joinPack(Arrays.asList("", " ", null, "")));
    }

    @Test
    public void packListRoundTrip() {
        KidEvent e = new KidEvent();
        e.packItems = KidEvent.joinPack(Arrays.asList("desiata", "súhlas", "prezuvky", ""));
        assertEquals(Arrays.asList("desiata", "súhlas", "prezuvky"), e.packList());
        e.packItems = null;
        assertTrue(e.packList().isEmpty());
    }
}
