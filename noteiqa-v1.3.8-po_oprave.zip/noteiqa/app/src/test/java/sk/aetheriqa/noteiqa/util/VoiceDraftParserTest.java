package sk.aetheriqa.noteiqa.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

/** v1.3.0 — pravidlový parser hlasového návrhu. "Dnes" = štvrtok 1. 10. 2026 10:00. */
public class VoiceDraftParserTest {

    private static final List<VoiceDraftParser.KidRef> KIDS = Arrays.asList(
            new VoiceDraftParser.KidRef(1, "Alex"),
            new VoiceDraftParser.KidRef(2, "Gabika"));

    private static final List<VoiceDraftParser.PaymentRef> UNPAID = Arrays.asList(
            new VoiceDraftParser.PaymentRef(10, 1, "ŠKD"),
            new VoiceDraftParser.PaymentRef(11, 2, "Karate október"));

    private static Calendar now() {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(2026, Calendar.OCTOBER, 1, 10, 0, 0);
        return c;
    }

    private static long day(int y, int m, int d) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(y, m, d, 0, 0, 0);
        return c.getTimeInMillis();
    }

    private static VoiceDraftParser.Draft parse(String s) {
        return VoiceDraftParser.parse(s, KIDS, UNPAID, now());
    }

    @Test
    public void briefExample_dentistTomorrowAtFive() {
        VoiceDraftParser.Draft d = parse("zajtra o piatej má Gabika zubára");
        assertEquals(VoiceDraftParser.Kind.EVENT, d.kind);
        assertEquals(VoiceDraftParser.EventWord.DENTIST, d.eventWord);
        assertEquals(VoiceDraftParser.TYPE_HEALTH, d.eventType);
        assertEquals(2L, d.kidId);
        assertEquals(day(2026, Calendar.OCTOBER, 2), d.dayStart);
        assertEquals(17 * 60, d.minutes);
    }

    @Test
    public void skdPaid_marksExistingPayment() {
        VoiceDraftParser.Draft d = parse("ŠKD je zaplatené");
        assertEquals(VoiceDraftParser.Kind.MARK_PAID, d.kind);
        assertEquals(10L, d.paymentId);
    }

    @Test
    public void paidButUnknown_saysNotFound() {
        VoiceDraftParser.Draft d = VoiceDraftParser.parse("ŠKD je zaplatené", KIDS,
                Collections.<VoiceDraftParser.PaymentRef>emptyList(), now());
        assertEquals(VoiceDraftParser.Kind.PAYMENT_NOT_FOUND, d.kind);
        assertEquals("ŠKD", d.searchedTitle);
        assertNull(d.amount);
    }

    @Test
    public void iPaidKarate_findsDeclinedTitle() {
        VoiceDraftParser.Draft d = parse("zaplatil som karate pre Gabiku");
        assertEquals(VoiceDraftParser.Kind.MARK_PAID, d.kind);
        assertEquals(11L, d.paymentId);
    }

    @Test
    public void newPaymentWithAmount() {
        VoiceDraftParser.Draft d = parse("zaplatiť výlet Alexovi 12,50 eur do 15. 10.");
        assertEquals(VoiceDraftParser.Kind.PAYMENT, d.kind);
        assertEquals(new BigDecimal("12.50"), d.amount);
        assertEquals(1L, d.kidId);
        assertEquals(day(2026, Calendar.OCTOBER, 15), d.dayStart);
        assertNotNull(d.title);
    }

    @Test
    public void paymentWithoutAmountOrKnownTitle_isNotPayment() {
        VoiceDraftParser.Draft d = parse("treba zaplatiť niečo");
        assertEquals(VoiceDraftParser.Kind.TASK, d.kind);
    }

    @Test
    public void halfPastSeven_andWeekday() {
        VoiceDraftParser.Draft d = parse("v pondelok o pol ôsmej tréning Alex");
        assertEquals(VoiceDraftParser.Kind.EVENT, d.kind);
        assertEquals(VoiceDraftParser.TYPE_SPORT, d.eventType);
        assertEquals(7 * 60 + 30, d.minutes);
        assertEquals(day(2026, Calendar.OCTOBER, 5), d.dayStart); // najbližší pondelok
        assertEquals(1L, d.kidId);
    }

    @Test
    public void fridayAtFive_isNotConfusedWithPiatej() {
        VoiceDraftParser.Draft d = parse("v piatok o piatej divadlo obe deti");
        assertEquals(day(2026, Calendar.OCTOBER, 2), d.dayStart);
        assertEquals(17 * 60, d.minutes);
        assertEquals(0L, d.kidId);
        assertEquals(VoiceDraftParser.TYPE_CULTURE, d.eventType);
    }

    @Test
    public void explicitTimeAndMonthName() {
        VoiceDraftParser.Draft d = parse("15. októbra o 16:30 krúžok");
        assertEquals(day(2026, Calendar.OCTOBER, 15), d.dayStart);
        assertEquals(16 * 60 + 30, d.minutes);
        assertEquals(VoiceDraftParser.Kind.EVENT, d.kind);
    }

    @Test
    public void pastDateWithoutYear_rollsToNextYear() {
        VoiceDraftParser.Draft d = parse("5. 1. zavolať babke");
        assertEquals(day(2027, Calendar.JANUARY, 5), d.dayStart);
        assertEquals(VoiceDraftParser.Kind.TASK, d.kind);
        assertEquals("5. 1. zavolať babke", d.title);
    }

    @Test
    public void morningKeepsAm() {
        VoiceDraftParser.Draft d = parse("zajtra ráno o šiestej výlet");
        assertEquals(6 * 60, d.minutes);
    }

    @Test
    public void plainTask() {
        VoiceDraftParser.Draft d = parse("kúpiť mlieko");
        assertEquals(VoiceDraftParser.Kind.TASK, d.kind);
        assertEquals("Kúpiť mlieko", d.title);
        assertEquals(-1L, d.dayStart);
        assertEquals(-1, d.minutes);
        assertEquals(-1L, d.kidId);
    }
}
