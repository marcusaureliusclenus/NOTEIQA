package sk.aetheriqa.noteiqa.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;

/**
 * v1.3.3 — udalosti detí v To Do (classifyTimestamp) musia mať rovnakú hranicu
 * týždňa ako úlohy (classify): nedeľa–sobota, sobota vrátane.
 */
public class TaskBucketSorterTest {

    private static final LocalDate SUNDAY = LocalDate.of(2026, 10, 4);

    private static long at(int month, int day) {
        return LocalDate.of(2026, month, day).atTime(LocalTime.of(17, 0))
                .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }

    @Test
    public void sundayEventsLaterThisWeekAreThisWeek() {
        assertEquals(TaskBucketSorter.Bucket.THIS_WEEK, TaskBucketSorter.classifyTimestamp(at(10, 6), SUNDAY));
        assertEquals(TaskBucketSorter.Bucket.THIS_WEEK, TaskBucketSorter.classifyTimestamp(at(10, 9), SUNDAY));
        assertEquals(TaskBucketSorter.Bucket.THIS_WEEK, TaskBucketSorter.classifyTimestamp(at(10, 10), SUNDAY));
    }

    @Test
    public void nextSundayIsNotThisWeek() {
        assertEquals(TaskBucketSorter.Bucket.THIS_MONTH, TaskBucketSorter.classifyTimestamp(at(10, 11), SUNDAY));
    }

    @Test
    public void todayAndTomorrow() {
        assertEquals(TaskBucketSorter.Bucket.TODAY, TaskBucketSorter.classifyTimestamp(at(10, 4), SUNDAY));
        assertEquals(TaskBucketSorter.Bucket.TOMORROW, TaskBucketSorter.classifyTimestamp(at(10, 5), SUNDAY));
    }

    @Test
    public void endOfWeekIsSaturday() {
        assertEquals(LocalDate.of(2026, 10, 10), TaskBucketSorter.endOfWeek(SUNDAY));
        assertEquals(LocalDate.of(2026, 10, 10), TaskBucketSorter.endOfWeek(LocalDate.of(2026, 10, 7)));
        assertEquals(LocalDate.of(2026, 10, 10), TaskBucketSorter.endOfWeek(LocalDate.of(2026, 10, 10)));
    }
}
