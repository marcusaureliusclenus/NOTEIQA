package sk.aetheriqa.noteiqa.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

/** v1.3.0 — návrh platby / udalosti z OCR textu. "Dnes" = 1. 10. 2026. */
public class PaperDraftParserTest {

    private static final List<VoiceDraftParser.KidRef> KIDS = Arrays.asList(
            new VoiceDraftParser.KidRef(1, "Alex"),
            new VoiceDraftParser.KidRef(2, "Gabika"));

    private static Calendar now() {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(2026, Calendar.OCTOBER, 1, 10, 0, 0);
        return c;
    }

    private static long day(int y, int m, int d) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(y, m, d, 0, 0, 0);
        return c.getTimeInMillis();
    }

    @Test
    public void schoolClubPaymentSlip() {
        String ocr = "Školský klub detí – október\n"
                + "Žiak: Gabika Nováková, 2.B\n"
                + "IBAN: SK89 7500 0000 0000 1234 5671\n"
                + "VS: 202610   ŠS: 77\n"
                + "Suma k úhrade: 25,00 €\n"
                + "Splatnosť: 15.10.2026";
        PaperDraftParser.Result r = PaperDraftParser.parse(ocr, KIDS, now());
        assertTrue(r.payment);
        assertEquals("SK8975000000000012345671", r.iban);
        assertTrue(r.ibanValid);
        assertEquals(new BigDecimal("25.00"), r.amount);
        assertEquals("202610", r.variableSymbol);
        assertEquals("77", r.specificSymbol);
        assertEquals(day(2026, Calendar.OCTOBER, 15), r.dayStart);
        assertEquals(2L, r.kidId);
        assertEquals("Školský klub detí – október", r.title);
    }

    @Test
    public void cyrillicLookalikesAndOcrDigits() {
        // "SК89" s cyrilským К a O namiesto nuly v čísle účtu
        String ocr = "Platba za výlet\nS\u041a89 75O0 0000 0000 1234 5671\n12.50 EUR";
        PaperDraftParser.Result r = PaperDraftParser.parse(ocr, KIDS, now());
        assertEquals("SK8975000000000012345671", r.iban);
        assertTrue(r.ibanValid);
        assertEquals(new BigDecimal("12.50"), r.amount);
    }

    @Test
    public void wrongChecksum_isFlagged() {
        PaperDraftParser.Result r = PaperDraftParser.parse(
                "SK89 7500 0000 0000 1234 5672", KIDS, now());
        assertEquals("SK8975000000000012345672", r.iban);
        assertFalse(r.ibanValid);
    }

    @Test
    public void eventInvitation() {
        String ocr = "Divadelné predstavenie\nPre: Alex\n22. 10.\nZačiatok 17:30";
        PaperDraftParser.Result r = PaperDraftParser.parse(ocr, KIDS, now());
        assertFalse(r.payment);
        assertEquals(day(2026, Calendar.OCTOBER, 22), r.dayStart);
        assertEquals(17 * 60 + 30, r.minutes);
        assertEquals(1L, r.kidId);
        assertEquals("Divadelné predstavenie", r.title);
    }

    @Test
    public void noText() {
        assertTrue(PaperDraftParser.parse("  \n ", KIDS, now()).empty);
    }

    @Test
    public void amountBeforeCurrency_andThousands() {
        PaperDraftParser.Result r = PaperDraftParser.parse("Lyžiarsky kurz\nEUR 1 234,50", KIDS, now());
        assertEquals(new BigDecimal("1234.50"), r.amount);
        assertNull(r.iban);
    }
}
