package sk.aetheriqa.noteiqa.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import sk.aetheriqa.noteiqa.data.entity.Task;

/** v1.3.6 — detské udalosti pod úlohami svojho dňa, zoradené podľa času. */
public class TodoDayMergeTest {

    private static long at(int day, int hour) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(2026, Calendar.OCTOBER, day, hour, 0, 0);
        return c.getTimeInMillis();
    }

    private static Task task(String title, int day) {
        Task t = new Task();
        t.title = title;
        t.dueDate = at(day, 0);
        return t;
    }

    private static List<String> names(List<Object> merged) {
        List<String> out = new ArrayList<>();
        for (Object o : merged) out.add(o instanceof Task ? ((Task) o).title : (String) o);
        return out;
    }

    @Test
    public void eventsGoBelowTasksOfTheirDaySortedByTime() {
        List<Task> tasks = Arrays.asList(task("t6a", 6), task("t6b", 6), task("t8", 8));
        // udalosti ako "názov@deň@hodina"
        List<String> events = Arrays.asList("koncert@6@18", "skola@6@8", "vylet@7@9", "zapas@9@10");
        List<Object> merged = TodoDayMerge.merge(tasks, events, s -> {
            String[] p = s.split("@");
            return at(Integer.parseInt(p[1]), Integer.parseInt(p[2]));
        });
        List<String> expected = Arrays.asList(
                "t6a", "t6b", "skola@6@8", "koncert@6@18", "vylet@7@9", "t8", "zapas@9@10");
        assertEquals(expected, names(merged));
    }

    @Test
    public void eventBeforeAllTasksGoesFirst() {
        List<Task> tasks = Arrays.asList(task("t9", 9));
        List<Object> merged = TodoDayMerge.merge(tasks, Arrays.asList("e@7@8"), s -> at(7, 8));
        assertEquals(Arrays.asList("e@7@8", "t9"), names(merged));
    }

    @Test
    public void undatedTaskStaysBelowEvents() {
        Task undated = new Task();
        undated.title = "bez datumu";
        List<Object> merged = TodoDayMerge.merge(Arrays.asList(undated), Arrays.asList("e@20@8"), s -> at(20, 8));
        assertEquals(Arrays.asList("e@20@8", "bez datumu"), names(merged));
    }
}
