Room exportuje schému databázy sem pri každom builde (`room.schemaLocation`).
Po prvom builde verzie 1.2.0 vznikne
`sk.aetheriqa.noteiqa.data.db.AppDatabase/8.json` — commitni ho spolu s kódom.
