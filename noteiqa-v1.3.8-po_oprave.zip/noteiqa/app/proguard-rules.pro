# Noteiqa – ProGuard rules
# Žiadne tracking SDKs, čisté pravidlá

# Room
-keep class androidx.room.** { *; }
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# MPAndroidChart
-keep class com.github.mikephil.charting.** { *; }
-dontwarn com.github.mikephil.charting.**

# Reflection-based JSON serializers (ak by sa neskôr pridali)
-keepattributes Signature
-keepattributes *Annotation*

# Sk lokalizácia – zachovať všetky string resources
-keep class **.R$string { *; }

# v1.2.0 — Backup export/import serializuje Room entity reflexiou podľa názvov
# polí (BackupExporter.entityToJson / BackupImporter.jsonToEntity). R8 nesmie
# polia premenovať ani odstrániť no-arg konštruktor, inak by data.json
# v release builde mal obfuskované kľúče a obnova by nefungovala.
-keep class sk.aetheriqa.noteiqa.data.entity.** { *; }

# v1.3.0 — ZXing core (QR) a xz (LZMA pre PAY by square): bez reflexie, ale
# PayBySquare.isVerified() overuje výstup za behu — nech R8 nič nezmení
-keep class com.google.zxing.** { *; }
-dontwarn com.google.zxing.**
-keep class org.tukaani.xz.** { *; }
-dontwarn org.tukaani.xz.**

# v1.3.0 — ML Kit text recognition (Play Services); knižnica má vlastné consumer
# rules, toto je poistka pre release minify
-keep class com.google.mlkit.** { *; }
-dontwarn com.google.mlkit.**
-keep class com.google.android.gms.internal.mlkit_vision_text_common.** { *; }
-dontwarn com.google.android.gms.internal.mlkit_vision_text_common.**
