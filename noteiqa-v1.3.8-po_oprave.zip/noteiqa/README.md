# NOTEIQA

> **Tichý zápisník.** Bez reklám, bez trackingu, bez šumu.
> Piaty produkt rodiny **AETHERIQA** (DEEPVERA · PROKURA · PREVERA · NEXTERA · **NOTEIQA**).

---

## Filozofia

Jeden princíp: **bezfrikčný zápis, rýchle nájdenie, žiadny šum.**

- Žiadne reklamy, žiadne onboarding flow, žiadne "Rate us" pop-upy
- Žiadny analytics SDK, žiadny crash reporter, žiadne tracking
- Lokálna databáza, žiadny povinný cloud, žiadne účty
- Premium estetika: čierna + zlato (Manrope font, gold `#D4AF37`)

---

## Aktuálny stav: Skeleton (v0.1.0-alpha)

Tento commit obsahuje **kompletný projektový skeleton** — všetko, čo je potrebné, aby sa appka skompilovala, spustila a aby sa do nej dali postupne dopĺňať funkcie. UI je placeholder. Implementácia funkcionality nasleduje v ďalších míľnikoch (viď Roadmapa nižšie).

### Čo skeleton obsahuje

- ✅ Gradle konfigurácia (AGP 8.2, Java 17, min SDK 24, target SDK 34)
- ✅ Manifest s presne definovanými povoleniami (mic, notifikácie, alarmy)
- ✅ Premium dark/gold téma (Material 3, Manrope downloadable font)
- ✅ MainActivity + spodná navigácia (Poznámky · Chudnutie · Viac)
- ✅ 3 fragmenty s prázdnym stavom (placeholder UI)
- ✅ Kompletná DB schéma (Room): 8 entít + 6 DAO
- ✅ Repository vrstva (NoteRepository, WeightRepository)
- ✅ Utility triedy (DateUtils, DiacriticsUtils)
- ✅ Notifikačná infraštruktúra (kanály, receivery)
- ✅ Adaptive launcher icon (zlatý "N" monogram na čiernom)
- ✅ Backup rules (auto-backup povolený)

---

## Setup

### Požiadavky

- Android Studio Hedgehog (2023.1.1) alebo novší
- JDK 17
- Android SDK Platform 34
- Internet pri prvom builde (downloadable font + dependencies)

### Otvorenie projektu

```bash
# 1. Rozbaľ ZIP do svojho dev priečinka
unzip noteiqa-skeleton.zip
cd noteiqa

# 2. Otvor v Android Studio cez File → Open → vyber priečinok "noteiqa"

# 3. Pri prvom otvorení AS automaticky:
#    - Stiahne Gradle wrapper (8.4)
#    - Stiahne všetky závislosti
#    - Vygeneruje gradlew / gradlew.bat
#    - Sync projekt
```

Ak používaš command-line a máš Gradle nainštalovaný globálne:

```bash
gradle wrapper --gradle-version 8.4
./gradlew assembleDebug
```

APK skončí v `app/build/outputs/apk/debug/app-debug.apk`.

---

## Architektúra

```
Presentation (UI)        Business logic        Data
─────────────────        ──────────────        ────────────
MainActivity                                   Room (SQLite)
├─ NotesFragment    ──►  NoteRepository  ──►   ├─ NoteDao
├─ ChudnutieFrag    ──►  WeightRepository ──►  ├─ TagDao
├─ MoreFragment     ──►  (TemplateRepo)   ──►  ├─ ChecklistDao
└─ NoteEditorAct    ──►  (ReminderRepo)   ──►  ├─ ReminderDao
                                               ├─ WeightDao
ViewModels (per screen)                        └─ TemplateDao
└─ LiveData<...>    ◄──  Repository    ◄──  DAOs
```

### Kľúčové vzory

- **Single source of truth**: Room DB. Všetko tečie cez `LiveData` z DAO → Repository → ViewModel → UI.
- **Background thread**: každá DB mutation cez `ExecutorService` v Repository. UI thread sa nikdy neblokuje.
- **Diakritika-aware search**: pri INSERT/UPDATE Note sa stavia `searchIndex` (lowercase, bez diakritiky). Hľadanie "salat" nájde "Šalát".
- **Cascading delete**: zmazanie Note → cascade na ChecklistItem, Reminder, NoteTagCrossRef.
- **Auto-čistenie koša**: poznámky v koši staršie ako 30 dní sa mažú cez WorkManager job.

### Modul Chudnutie — špec

Štyri zóny v `fragment_chudnutie.xml`:

1. **Quick log** — pole na kg + tlačidlo "Zaznamenať". Auto-vyplní `measuredAt` (teraz), `dayOfWeek` (cez `DateUtils.isoDayOfWeek`), voliteľná poznámka (napr. "menzes !", "po tréningu").
2. **Graf** — MPAndroidChart `LineChart` so zlatou krivkou. Prepínač obdobia: 7d / 30d / 90d / 1Y / Všetko (`DateUtils.Period`).
3. **Cieľ** — `WeightGoal` entita (max 1 aktívny). Progress bar + horizontálna čiara cieľa v grafe.
4. **História** — `RecyclerView` s posledných 10 záznamov. Long-press → upraviť/zmazať.

Single profile (potvrdené v specifikácii).

---

## Štruktúra projektu

```
noteiqa/
├── settings.gradle
├── build.gradle                      ← top-level (plugin verzie)
├── gradle.properties
└── app/
    ├── build.gradle                  ← dependencies, SDK verzie, namespace
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/sk/aetheriqa/noteiqa/
        │   ├── NoteiqaApplication.java
        │   ├── MainActivity.java
        │   ├── ui/
        │   │   ├── notes/            ← NotesFragment, NoteEditorActivity
        │   │   ├── chudnutie/        ← ChudnutieFragment (4 zóny)
        │   │   └── more/             ← MoreFragment
        │   ├── data/
        │   │   ├── db/
        │   │   │   ├── AppDatabase.java
        │   │   │   └── dao/          ← 6× DAO interface
        │   │   ├── entity/           ← 8× @Entity classes
        │   │   └── repository/       ← NoteRepository, WeightRepository
        │   ├── notification/         ← NotificationHelper, ReminderReceiver, BootReceiver
        │   └── util/                 ← DateUtils, DiacriticsUtils
        └── res/
            ├── color/                ← bottom_nav_item_color (selector)
            ├── drawable/             ← ic_note, ic_scale, ic_more, ic_add, ic_mic, launcher
            ├── font/                 ← noteiqa_font_family (Manrope downloadable)
            ├── layout/               ← activity/fragment/item layouty
            ├── menu/                 ← bottom_nav_menu
            ├── mipmap-anydpi-v26/    ← adaptive ic_launcher
            ├── values/               ← colors, themes, strings (sk), dimens
            ├── values-en/            ← anglický fallback
            └── xml/                  ← backup_rules, data_extraction_rules
```

---

## Roadmapa

### Fáza 1.0 — Skeleton ✅ (TENTO COMMIT)

Všetko vyššie spomenuté.

### Fáza 1.1 — Editor poznámky a zoznam

- [ ] `NoteEditorActivity` — title field, body field s markdown-lite, auto-save (debounce 800ms)
- [ ] `NotesAdapter` (RecyclerView) — karty s preview, dátumom, štítkami
- [ ] FAB long-press menu: poznámka / zoznam / hlas / šablóna
- [ ] Swipe gestá: archivovať vľavo, pin vpravo
- [ ] Long-press → kontextové menu (zdieľať, zmazať, zmeniť farbu)

### Fáza 1.2 — Pripomienky

- [ ] `ReminderScheduler` — AlarmManager + WorkManager kombinácia
- [ ] `ReminderReceiver` plná implementácia (NotificationCompat builder)
- [ ] `BootReceiver` — re-schedule po reboote
- [ ] Bottom sheet picker pre nastavenie pripomienky v editore

### Fáza 1.3 — Chudnutie modul (live)

- [ ] MPAndroidChart `LineChart` setup so zlatou krivkou + fill gradient
- [ ] `ChudnutieViewModel` so všetkými LiveData streams (entries, stats, goal)
- [ ] `WeightHistoryAdapter` so swipe-to-delete a long-press edit
- [ ] Bottom sheet pre nastavenie cieľa
- [ ] Fáza 2: Trendová čiara (kĺzavý 7d priemer)

### Fáza 1.4 — Šablóny

- [ ] Built-in šablóny pri prvom spustení (Nákup, Deti — rozmery, Cestovný checklist, Zápisnica)
- [ ] "Uložiť ako šablónu" v editore
- [ ] Preview pri výbere šablóny

### Fáza 1.5 — Hlasový zápis sk-SK

- [ ] `VoiceInputManager` — wrapper nad `SpeechRecognizer`
- [ ] Smart parsing: "pripomeň mi zajtra o 8" → vytvorí pripomienku
- [ ] Continuous listening pre dlhšie diktovanie
- [ ] Permission flow s rationale

### Fáza 2.0 — Premium features

- [ ] PIN/biometria zámok pre konkrétne poznámky (`androidx.biometric`)
- [ ] Export PDF / MD / TXT / HTML (z LEA prebrať)
- [ ] Lokálny backup na SD/Drive
- [ ] Widget na home screen (quicknote + posledné 3 poznámky)
- [ ] Auto-tagging cez Claude API (voliteľné, on-demand)
- [ ] Smart linking: `@kontakt`, `#tag`, `2026-05-10` ako reminder

---

## Konvencie

- **Java**, nie Kotlin (konzistencia s LEA, MeninySMS)
- **Slovenčina** ako primárny jazyk (anglický fallback v `values-en/`)
- **8pt grid** pre spacing (`@dimen/space_xs..xxl`)
- **Žiadne magic numbery** v layoutoch — vždy cez `dimens.xml`
- **Žiadne hardcoded farby** v layoutoch — vždy cez `colors.xml` alebo theme attr
- **Repository pattern** — žiadne DAO volania priamo z UI
- **Background DB ops** — vždy cez `ExecutorService`, nikdy na UI thread

---

## Brand

```
Primárna paleta:
  ─ Background:    #0A0A0A (near-black)
  ─ Surface:       #141414
  ─ Surface elev:  #1F1F1F
  ─ Gold:          #D4AF37  ← brand color
  ─ Gold light:    #E8C865
  ─ Text:          #F5F5F0 (warm white)

Typografia:
  Manrope (cez Google Fonts downloadable provider)
```

---

**NOTEIQA · AETHERIQA · 2026**
